/* start up code */

#include "hal/hw/XOSC.h"
#include "hal/hw/CLOCKS.h"
#include "hal/hw/ROSC.h"
#include "hal/hw/PLL_SYS.h"
#include "hal/hw/PSM.h"
#include "hal/hw/RESETS.h"
typedef void(*VECTOR_FUNCTION_Type)(void);

void default_Handler(void);
extern void main(void);
__attribute__((__noreturn__)) void Reset_Handler();

const VECTOR_FUNCTION_Type __VECTOR_TABLE[64] __attribute__((used, section(".vectors"))) = {
    /*  0: Initial Stack Pointer    */ (VECTOR_FUNCTION_Type)(0x20040000),
    /*  1: Reset Handler            */ Reset_Handler,
    /*  2: NMI Handler        (-14) */ default_Handler,
    /*  3: Hard Fault Handler (-13) */ default_Handler,
    /*  4: reserved           (-12) */ default_Handler,
    /*  5: reserved           (-11) */ default_Handler,
    /*  6: reserved           (-10) */ default_Handler,
    /*  7: reserved           ( -9) */ default_Handler,
    /*  8: reserved           ( -8) */ default_Handler,
    /*  9: reserved           ( -7) */ default_Handler,
    /* 10: reserved           ( -6) */ default_Handler,
    /* 11: SVCall Handler     ( -5) */ default_Handler,
    /* 12: reserved           ( -4) */ default_Handler,
    /* 13: reserved           ( -3) */ default_Handler,
    /* 14: PendSV Handler     ( -2) */ default_Handler,
    /* 15: SysTick Handler    ( -1) */ default_Handler,
    /* 16: WWDG (Window Watchdog interrupt)(  0) */ default_Handler,
    /* 17: PVD (PVD through EINT line 16 detection interrupt)(  1) */ default_Handler,
    /* 18: TAMP_STAMP (Tamper and TimeStamp interrupts through the EINTline22)(  2) */ default_Handler,
    /* 19: RTC_WKUP (RTC Wakeup interrupt through the EINT line 22)(  3) */ default_Handler,
    /* 20: FLASH (Flash global interrupt)(  4) */ default_Handler,
    /* 21: RCM (RCM global interrupt)(  5) */ default_Handler,
    /* 22: EINT0 (EINT Line0 interrupt)(  6) */ default_Handler,
    /* 23: EINT1 (EINT Line1 interrupt)(  7) */ default_Handler,
    /* 24: EINT2 (EINT Line2 interrupt)(  8) */ default_Handler,
    /* 25: EINT3 (EINT Line3 interrupt)(  9) */ default_Handler,
    /* 26: EINT4 (EINT Line4 interrupt)( 10) */ default_Handler,
    /* 27: DMA1_STR0 (DMA1 Stream 0 global interrupt)( 11) */ default_Handler,
    /* 28: DMA1_STR1 (DMA1 Stream 1 global interrupt)( 12) */ default_Handler,
    /* 29: DMA1_STR2 (DMA1 Stream 2 global interrupt)( 13) */ default_Handler,
    /* 30: DMA1_STR3 (DMA1 Stream 3 global interrupt)( 14) */ default_Handler,
    /* 31: DMA1_STR4 (DMA1 Stream 4 global interrupt)( 15) */ default_Handler,
    /* 32: DMA1_STR5 (DMA1 Stream 5 global interrupt)( 16) */ default_Handler,
    /* 33: DMA1_STR6 (DMA1 Stream 6 global interrupt)( 17) */ default_Handler,
    /* 34: ADC (ADC1 global interrupt)( 18) */ default_Handler,
    /* 35: CAN1_TX (CAN1 TX interrupts)( 19) */ default_Handler,
    /* 36: CAN1_RX0 (CAN1 RX0 interrupts)( 20) */ default_Handler,
    /* 37: CAN1_RX1 (CAN1 RX1 interrupts)( 21) */ default_Handler,
    /* 38: CAN1_SCE (CAN1 SCE interrupt)( 22) */ default_Handler,
    /* 39: EINT9_5 (EINT Line[9:5] interrupts)( 23) */ default_Handler,
    /* 40: TMR1_BRK_TMR9 (TMR1 Break interrupt and TMR9 global interrupt)( 24) */ default_Handler,
    /* 41: TMR1_UP_TMR10 (TMR1 Update interrupt and TMR10 global interrupt)( 25) */ default_Handler,
    /* 42: TMR1_TRG_COM_TMR11 (TMR1 Trigger and Commutation interrupts and TMR11 global interrupt)( 26) */ default_Handler,
    /* 43: TMR1_CC (TMR1 Capture Compare interrupt)( 27) */ default_Handler,
    /* 44: TMR2 (TMR2 global interrupt)( 28) */ default_Handler,
    /* 45: TMR3 (TMR3 global interrupt)( 29) */ default_Handler,
    /* 46: TMR4 (TMR4 global interrupt)( 30) */ default_Handler,
    /* 47: I2C1_EV (I2C1 event interrupt)( 31) */ default_Handler,
    /* 48: I2C1_ER (I2C1 error interrupt)( 32) */ default_Handler,
    /* 49: I2C2_EV (I2C2 event interrupt)( 33) */ default_Handler,
    /* 50: I2C2_ER (I2C2 error interrupt)( 34) */ default_Handler,
    /* 51: SPI1 (SPI1 global interrupt)( 35) */ default_Handler,
    /* 52: SPI2 (SPI2 global interrupt)( 36) */ default_Handler,
    /* 53: USART1 (USART1 global interrupt)( 37) */ default_Handler,
    /* 54: USART2 (USART2 global interrupt)( 38) */ default_Handler,
    /* 55: USART3 (USART3 global interrupt)( 39) */ default_Handler,
    /* 56: EINT15_10 (EINT Line[15:10] interrupts)( 40) */ default_Handler,
    /* 57: RTC_Alarm (RTC Alarms (A and B) through EINT line 17 interrupt)( 41) */ default_Handler,
    /* 58: OTG_FS_WKUP (USB On-The-Go FS Wakeup through EINT line interrupt)( 42) */ default_Handler,
    /* 59: TMR8_BRK_TMR12 (TMR8 Break interrupt and TMR12 global interrupt)( 43) */ default_Handler,
    /* 60: TMR8_UP_TMR13 (TMR8 Update interrupt and TMR13 global interrupt)( 44) */ default_Handler,
    /* 61: TMR8_TRG_COM_TMR14 (TMR8 Trigger and Commutation interrupts and TMR14 global interrupt)( 45) */ default_Handler,
    /* 62: TMR8_CC (TMR8 Capture Compare interrupt)( 46) */ default_Handler,
    /* 63: DMA1_STR7 (DMA1 Stream 7 global interrupt)( 47) */ default_Handler,
};

void default_Handler(void) {
    while(1);
}

__attribute__((__noreturn__)) void Reset_Handler() {
    PSM->FRCE_ON = 0xffff; // power on all needed blocks
    // wait for powered on blocks to become available
    while(0xffff != 0xffff & PSM->DONE) {
        ;
    }
    RESETS->RESET &= ~0x1082; // take BUSCTRL, JTAG and PLL_SYS out of Reset state
    while(0 != 0x1082 & RESETS->RESET_DONE) {
        ;
    }
    // configure clock: pico has XOSC = 12 MHz
    XOSC->STARTUP = 0x2f; // = 47 * 256 = 1ms @ 12MHz
    // power up XOSC
    XOSC->CTRL = 0xfabaa0;
    // wait for XOSC to stabilize
    while(0 == 0x80000000 & XOSC->STATUS) {
        ;
    }
    // switch clk_ref and clk_sys to XOSC
    CLOCKS->CLK_REF_CTRL = 0x2;
    // wait for switch to happen
    while(0x4 != CLOCKS->CLK_REF_SELECTED) {
        ;
    }
    // configure system PLL
    // program the clk_ref divider ( 1)
    PLL_SYS->CS = 0x1;
    // program feedback divider ( 125)
    PLL_SYS->FBDIV_INT = 0x7d;
    // turn on main power and VCO
    PLL_SYS->PWR = 0x0;
    // wait for VCO clock to lock
    while(0 == 0x80000000 & PLL_SYS->CS) {
        ;
    }
    // set up post dividers and turn them on (6, 2)
    PLL_SYS->PRIM = 0x62000;
    // switch sys aux to PLL
    CLOCKS->CLK_SYS_CTRL = 0;
    // switch sys mux to aux
    CLOCKS->CLK_SYS_CTRL = 1;
    // wait for locked
    while(2 != CLOCKS->CLK_SYS_SELECTED) {
        ;
    }
    CLOCKS->CLK_PERI_CTRL = 0x20; // clock source is PLL_SYS - can glitch
    CLOCKS->CLK_PERI_CTRL = 0x4020; // enable clk_peri
    // power down ROSC
    ROSC->CTRL = 0x00d1efa4;
    // ROSC = off; XOSC = 12 MHz; PLL_SYS = 125 MHz
    // clk_ref = 12 MHz; clk_sys = 125 MHz; clk_peri = 125 MHz
    main();
    for(;;) {
        ;// main exited - WTF???
    }
}

