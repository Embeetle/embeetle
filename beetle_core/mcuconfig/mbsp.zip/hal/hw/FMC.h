#ifndef HW_FMC_H
#define HW_FMC_H
/** Flash memory controller */
/** Interrupt : FLASH (Vector: 4) Flash global interrupt */
/** Memory Block starting at 0x40023C00 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define FMC_ACCTRL_WAITP_OFFSET                            0
#define FMC_ACCTRL_WAITP_MASK                              7

#define FMC_ACCTRL_PREFEN_OFFSET                           8
#define FMC_ACCTRL_PREFEN_MASK                             0x100

#define FMC_ACCTRL_ICACHEEN_OFFSET                         9
#define FMC_ACCTRL_ICACHEEN_MASK                           0x200

#define FMC_ACCTRL_DCACHEEN_OFFSET                         10
#define FMC_ACCTRL_DCACHEEN_MASK                           0x400

#define FMC_ACCTRL_ICACHERST_OFFSET                        11
#define FMC_ACCTRL_ICACHERST_MASK                          0x800

#define FMC_ACCTRL_DCACHERST_OFFSET                        12
#define FMC_ACCTRL_DCACHERST_MASK                          0x1000

#define FMC_KEY_KEY_OFFSET                                 0
#define FMC_KEY_KEY_MASK                                   0xffffffff

#define FMC_OPTKEY_OPTKEY_OFFSET                           0
#define FMC_OPTKEY_OPTKEY_MASK                             0xffffffff

#define FMC_STS_OPRCMP_OFFSET                              0
#define FMC_STS_OPRCMP_MASK                                1

#define FMC_STS_OPRERR_OFFSET                              1
#define FMC_STS_OPRERR_MASK                                2

#define FMC_STS_WPROTERR_OFFSET                            4
#define FMC_STS_WPROTERR_MASK                              0x10

#define FMC_STS_PGALGERR_OFFSET                            5
#define FMC_STS_PGALGERR_MASK                              0x20

#define FMC_STS_PGPRLERR_OFFSET                            6
#define FMC_STS_PGPRLERR_MASK                              0x40

#define FMC_STS_PGSEQERR_OFFSET                            7
#define FMC_STS_PGSEQERR_MASK                              0x80

#define FMC_STS_BUSY_OFFSET                                16
#define FMC_STS_BUSY_MASK                                  0x10000

#define FMC_CTRL_PG_OFFSET                                 0
#define FMC_CTRL_PG_MASK                                   1

#define FMC_CTRL_SERS_OFFSET                               1
#define FMC_CTRL_SERS_MASK                                 2

#define FMC_CTRL_MERS_OFFSET                               2
#define FMC_CTRL_MERS_MASK                                 4

#define FMC_CTRL_SNUM_OFFSET                               3
#define FMC_CTRL_SNUM_MASK                                 0x78

#define FMC_CTRL_PGSIZE_OFFSET                             8
#define FMC_CTRL_PGSIZE_MASK                               0x300

#define FMC_CTRL_START_OFFSET                              16
#define FMC_CTRL_START_MASK                                0x10000

#define FMC_CTRL_OPCINTEN_OFFSET                           24
#define FMC_CTRL_OPCINTEN_MASK                             0x1000000

#define FMC_CTRL_ERRINTEN_OFFSET                           25
#define FMC_CTRL_ERRINTEN_MASK                             0x2000000

#define FMC_CTRL_LOCK_OFFSET                               31
#define FMC_CTRL_LOCK_MASK                                 0x80000000

#define FMC_OPTCTRL_OPTLOCK_OFFSET                         0
#define FMC_OPTCTRL_OPTLOCK_MASK                           1

#define FMC_OPTCTRL_OPTSTART_OFFSET                        1
#define FMC_OPTCTRL_OPTSTART_MASK                          2

#define FMC_OPTCTRL_BORLVL_OFFSET                          2
#define FMC_OPTCTRL_BORLVL_MASK                            0xc

#define FMC_OPTCTRL_WDTSEL_OFFSET                          5
#define FMC_OPTCTRL_WDTSEL_MASK                            0x20

#define FMC_OPTCTRL_RSTSTOP_OFFSET                         6
#define FMC_OPTCTRL_RSTSTOP_MASK                           0x40

#define FMC_OPTCTRL_RSTSTDB_OFFSET                         7
#define FMC_OPTCTRL_RSTSTDB_MASK                           0x80

#define FMC_OPTCTRL_RPROT_OFFSET                           8
#define FMC_OPTCTRL_RPROT_MASK                             0xff00

#define FMC_OPTCTRL_NWPROT_OFFSET                          16
#define FMC_OPTCTRL_NWPROT_MASK                            0xff0000

#define FMC_OPTCTRL_PCROPEN_OFFSET                         31
#define FMC_OPTCTRL_PCROPEN_MASK                           0x80000000


typedef struct
{

/** ACCTRL ACCTRL (offset: 0x0)
  Flash access control register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: WAITP
  offset: 0, size: 3, access: read-write
  Wait Period
  Field: PREFEN
  offset: 8, size: 1, access: read-write
  Prefetch enable
  Field: ICACHEEN
  offset: 9, size: 1, access: read-write
  Instruction cache enable
  Field: DCACHEEN
  offset: 10, size: 1, access: read-write
  Data cache enable
  Field: ICACHERST
  offset: 11, size: 1, access: write-only
  Instruction cache reset
  Field: DCACHERST
  offset: 12, size: 1, access: read-write
  Data cache reset
*/
volatile uint32_t ACCTRL;

/** KEY KEY (offset: 0x4)
  Flash key register
  access : write-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: KEY
  offset: 0, size: 32, access: 
  key
*/
volatile uint32_t KEY;

/** OPTKEY OPTKEY (offset: 0x8)
  Flash option key register
  access : write-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OPTKEY
  offset: 0, size: 32, access: 
  Option byte key
*/
volatile uint32_t OPTKEY;

/** STS STS (offset: 0xc)
  Status register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OPRCMP
  offset: 0, size: 1, access: read-write
  End of operation
  Field: OPRERR
  offset: 1, size: 1, access: read-write
  Operation error
  Field: WPROTERR
  offset: 4, size: 1, access: read-write
  Write protection error
  Field: PGALGERR
  offset: 5, size: 1, access: read-write
  Programming alignment error
  Field: PGPRLERR
  offset: 6, size: 1, access: read-write
  Programming parallelism error
  Field: PGSEQERR
  offset: 7, size: 1, access: read-write
  Programming sequence error
  Field: BUSY
  offset: 16, size: 1, access: read-only
  Busy
*/
volatile uint32_t STS;

/** CTRL CTRL (offset: 0x10)
  Control register
  access : read-write
  reset value : 0x80000000
  reset mask : 0xFFFFFFFF
  Field: PG
  offset: 0, size: 1, access: 
  Programming
  Field: SERS
  offset: 1, size: 1, access: 
  Sector Erase
  Field: MERS
  offset: 2, size: 1, access: 
  Mass Erase
  Field: SNUM
  offset: 3, size: 4, access: 
  Sector number
  Field: PGSIZE
  offset: 8, size: 2, access: 
  Program size
  Field: START
  offset: 16, size: 1, access: 
  Start
  Field: OPCINTEN
  offset: 24, size: 1, access: 
  End of operation interrupt enable
  Field: ERRINTEN
  offset: 25, size: 1, access: 
  Error interrupt enable
  Field: LOCK
  offset: 31, size: 1, access: 
  Lock
*/
volatile uint32_t CTRL;

/** OPTCTRL OPTCTRL (offset: 0x14)
  Flash option control register
  access : read-write
  reset value : 0xFFFAAED
  reset mask : 0xFFFFFFFF
  Field: OPTLOCK
  offset: 0, size: 1, access: 
  Option lock
  Field: OPTSTART
  offset: 1, size: 1, access: 
  Option start
  Field: BORLVL
  offset: 2, size: 2, access: 
  Brownout reset Level
  Field: WDTSEL
  offset: 5, size: 1, access: 
  Watchdog Select
  Field: RSTSTOP
  offset: 6, size: 1, access: 
  nRST_STOP User option mode
  Field: RSTSTDB
  offset: 7, size: 1, access: 
  nReset in STANDBY Mode
  Field: RPROT
  offset: 8, size: 8, access: 
  Read protect
  Field: NWPROT
  offset: 16, size: 8, access: 
  Not write protect
  Field: PCROPEN
  offset: 31, size: 1, access: 
  PCROP Enable
*/
volatile uint32_t OPTCTRL;
} FMC_type;

#define FMC ((FMC_type *) 0x40023C00)

#endif // HW_FMC_H
