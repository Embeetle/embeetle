#ifndef HW_CRC_H
#define HW_CRC_H
/** Cryptographic processor */
/** Memory Block starting at 0x40023000 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define CRC_DATA_DATA_OFFSET                               0
#define CRC_DATA_DATA_MASK                                 0xffffffff

#define CRC_INDATA_INDATA_OFFSET                           0
#define CRC_INDATA_INDATA_MASK                             0xff

#define CRC_CTRL_RST_OFFSET                                0
#define CRC_CTRL_RST_MASK                                  1


typedef struct
{

/** DATA DATA (offset: 0x0)
  Data register
  access : read-write
  reset value : 0xFFFFFFFF
  reset mask : 0xFFFFFFFF
  Field: DATA
  offset: 0, size: 32, access: 
  Data Register
*/
volatile uint32_t DATA;

/** INDATA INDATA (offset: 0x4)
  Independent Data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INDATA
  offset: 0, size: 8, access: 
  Independent Data register
*/
volatile uint32_t INDATA;

/** CTRL CTRL (offset: 0x8)
  Control register
  access : write-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RST
  offset: 0, size: 1, access: 
  Reset CRC Calculation Unit
*/
volatile uint32_t CTRL;
} CRC_type;

#define CRC ((CRC_type *) 0x40023000)

#endif // HW_CRC_H
