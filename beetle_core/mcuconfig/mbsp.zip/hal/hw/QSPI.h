#ifndef HW_QSPI_H
#define HW_QSPI_H
/** Quick Serial peripheral interface */
/** Interrupt : QSPI (Vector: 83) QSPI global interrupt */
/** Memory Block starting at 0xA0001000 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define QSPI_CTRL1_DFS_OFFSET                              0
#define QSPI_CTRL1_DFS_MASK                                0x1f

#define QSPI_CTRL1_CPHA_OFFSET                             8
#define QSPI_CTRL1_CPHA_MASK                               0x100

#define QSPI_CTRL1_CPOL_OFFSET                             9
#define QSPI_CTRL1_CPOL_MASK                               0x200

#define QSPI_CTRL1_TXMODE_OFFSET                           10
#define QSPI_CTRL1_TXMODE_MASK                             0xc00

#define QSPI_CTRL1_SSTEN_OFFSET                            14
#define QSPI_CTRL1_SSTEN_MASK                              0x4000

#define QSPI_CTRL1_FRF_OFFSET                              22
#define QSPI_CTRL1_FRF_MASK                                0xc00000

#define QSPI_CTRL2_NDF_OFFSET                              0
#define QSPI_CTRL2_NDF_MASK                                0xffff

#define QSPI_SSIEN_EN_OFFSET                               0
#define QSPI_SSIEN_EN_MASK                                 1

#define QSPI_SLAEN_SLAEN_OFFSET                            0
#define QSPI_SLAEN_SLAEN_MASK                              1

#define QSPI_BR_CLKDIV_OFFSET                              0
#define QSPI_BR_CLKDIV_MASK                                0xffff

#define QSPI_TFTL_TFT_OFFSET                               0
#define QSPI_TFTL_TFT_MASK                                 7

#define QSPI_TFTL_TFTH_OFFSET                              16
#define QSPI_TFTL_TFTH_MASK                                0x70000

#define QSPI_RFTL_RFT_OFFSET                               0
#define QSPI_RFTL_RFT_MASK                                 7

#define QSPI_TFL_TFL_OFFSET                                0
#define QSPI_TFL_TFL_MASK                                  7

#define QSPI_RFL_RFL_OFFSET                                0
#define QSPI_RFL_RFL_MASK                                  7

#define QSPI_STS_BUSYF_OFFSET                              0
#define QSPI_STS_BUSYF_MASK                                1

#define QSPI_STS_TFNF_OFFSET                               1
#define QSPI_STS_TFNF_MASK                                 2

#define QSPI_STS_TFEF_OFFSET                               2
#define QSPI_STS_TFEF_MASK                                 4

#define QSPI_STS_RFNEF_OFFSET                              3
#define QSPI_STS_RFNEF_MASK                                8

#define QSPI_STS_RFFF_OFFSET                               4
#define QSPI_STS_RFFF_MASK                                 0x10

#define QSPI_STS_DCEF_OFFSET                               6
#define QSPI_STS_DCEF_MASK                                 0x40

#define QSPI_INTEN_TFEIE_OFFSET                            0
#define QSPI_INTEN_TFEIE_MASK                              1

#define QSPI_INTEN_TFOIE_OFFSET                            1
#define QSPI_INTEN_TFOIE_MASK                              2

#define QSPI_INTEN_RFUIE_OFFSET                            2
#define QSPI_INTEN_RFUIE_MASK                              4

#define QSPI_INTEN_RFOIE_OFFSET                            3
#define QSPI_INTEN_RFOIE_MASK                              8

#define QSPI_INTEN_RFFIE_OFFSET                            4
#define QSPI_INTEN_RFFIE_MASK                              0x10

#define QSPI_INTEN_MSTIE_OFFSET                            5
#define QSPI_INTEN_MSTIE_MASK                              0x20

#define QSPI_ISTS_TFEIF_OFFSET                             0
#define QSPI_ISTS_TFEIF_MASK                               1

#define QSPI_ISTS_TFOIF_OFFSET                             1
#define QSPI_ISTS_TFOIF_MASK                               2

#define QSPI_ISTS_RFUIF_OFFSET                             2
#define QSPI_ISTS_RFUIF_MASK                               4

#define QSPI_ISTS_RFOIF_OFFSET                             3
#define QSPI_ISTS_RFOIF_MASK                               8

#define QSPI_ISTS_RFFIF_OFFSET                             4
#define QSPI_ISTS_RFFIF_MASK                               0x10

#define QSPI_ISTS_MSTIF_OFFSET                             5
#define QSPI_ISTS_MSTIF_MASK                               0x20

#define QSPI_RIS_TFEIF_OFFSET                              0
#define QSPI_RIS_TFEIF_MASK                                1

#define QSPI_RIS_TFOIF_OFFSET                              1
#define QSPI_RIS_TFOIF_MASK                                2

#define QSPI_RIS_RFUIF_OFFSET                              2
#define QSPI_RIS_RFUIF_MASK                                4

#define QSPI_RIS_RXOIR_OFFSET                              3
#define QSPI_RIS_RXOIR_MASK                                8

#define QSPI_RIS_RXFIR_OFFSET                              4
#define QSPI_RIS_RXFIR_MASK                                0x10

#define QSPI_RIS_MSTIR_OFFSET                              5
#define QSPI_RIS_MSTIR_MASK                                0x20

#define QSPI_TFOIC_TFOIC_OFFSET                            0
#define QSPI_TFOIC_TFOIC_MASK                              1

#define QSPI_RFOIC_RFOIC_OFFSET                            0
#define QSPI_RFOIC_RFOIC_MASK                              1

#define QSPI_RFUIC_RFUIC_OFFSET                            0
#define QSPI_RFUIC_RFUIC_MASK                              1

#define QSPI_MIC_MIC_OFFSET                                0
#define QSPI_MIC_MIC_MASK                                  1

#define QSPI_ICF_ICF_OFFSET                                0
#define QSPI_ICF_ICF_MASK                                  1

#define QSPI_DMACTRL_RDMAEN_OFFSET                         0
#define QSPI_DMACTRL_RDMAEN_MASK                           1

#define QSPI_DMACTRL_TDMAEN_OFFSET                         1
#define QSPI_DMACTRL_TDMAEN_MASK                           2

#define QSPI_DMATDL_DMATDL_OFFSET                          0
#define QSPI_DMATDL_DMATDL_MASK                            7

#define QSPI_DMARDL_DMARDL_OFFSET                          0
#define QSPI_DMARDL_DMARDL_MASK                            7

#define QSPI_DATA_DATA_OFFSET                              0
#define QSPI_DATA_DATA_MASK                                0xffffffff

#define QSPI_RSD_RSD_OFFSET                                0
#define QSPI_RSD_RSD_MASK                                  0xff

#define QSPI_RSD_RSE_OFFSET                                16
#define QSPI_RSD_RSE_MASK                                  0x10000

#define QSPI_CTRL3_IAT_OFFSET                              0
#define QSPI_CTRL3_IAT_MASK                                3

#define QSPI_CTRL3_ADDRLEN_OFFSET                          2
#define QSPI_CTRL3_ADDRLEN_MASK                            0x3c

#define QSPI_CTRL3_INSLEN_OFFSET                           8
#define QSPI_CTRL3_INSLEN_MASK                             0x300

#define QSPI_CTRL3_WAITCYC_OFFSET                          11
#define QSPI_CTRL3_WAITCYC_MASK                            0xf800

#define QSPI_CTRL3_CSEN_OFFSET                             30
#define QSPI_CTRL3_CSEN_MASK                               0x40000000

#define QSPI_IOSW_IOSW_OFFSET                              0
#define QSPI_IOSW_IOSW_MASK                                1


typedef struct
{

/** CTRL1 CTRL1 (offset: 0x0)
  Control register 1
  access : read-write
  reset value : 0x4007
  reset mask : 0xFFFFFFFF
  Field: DFS
  offset: 0, size: 5, access: 
  DFS
  Field: CPHA
  offset: 8, size: 1, access: 
  CPHA
  Field: CPOL
  offset: 9, size: 1, access: 
  CPOL
  Field: TXMODE
  offset: 10, size: 2, access: 
  TXMODE
  Field: SSTEN
  offset: 14, size: 1, access: 
  SSTEN
  Field: FRF
  offset: 22, size: 2, access: 
  FRF
*/
volatile uint32_t CTRL1;

/** CTRL2 CTRL2 (offset: 0x4)
  Control register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: NDF
  offset: 0, size: 16, access: 
  NDF
*/
volatile uint32_t CTRL2;

/** SSIEN SSIEN (offset: 0x8)
  QSPI Enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EN
  offset: 0, size: 1, access: 
  EN
*/
volatile uint32_t SSIEN;
volatile uint32_t reserved0;

/** SLAEN SLAEN (offset: 0x10)
  QSPI Slave enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SLAEN
  offset: 0, size: 1, access: 
  SLAEN
*/
volatile uint32_t SLAEN;

/** BR BR (offset: 0x14)
  Baudrate register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CLKDIV
  offset: 0, size: 16, access: 
  CLKDIV
*/
volatile uint32_t BR;

/** TFTL TFTL (offset: 0x18)
  Transmission FIFO threshhold level register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TFT
  offset: 0, size: 3, access: 
  TFT
  Field: TFTH
  offset: 16, size: 3, access: 
  TFTH
*/
volatile uint32_t TFTL;

/** RFTL RFTL (offset: 0x1c)
  Reception FIFO threshhold level register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RFT
  offset: 0, size: 3, access: 
  RFT
*/
volatile uint32_t RFTL;

/** TFL TFL (offset: 0x20)
  Transmission FIFO level register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TFL
  offset: 0, size: 3, access: 
  TFL
*/
volatile uint32_t TFL;

/** RFL RFL (offset: 0x24)
  Reception FIFO level register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RFL
  offset: 0, size: 3, access: 
  RFL
*/
volatile uint32_t RFL;

/** STS STS (offset: 0x28)
  Status register
  access : read-write
  reset value : 0x6
  reset mask : 0xFFFFFFFF
  Field: BUSYF
  offset: 0, size: 1, access: 
  BUSYF
  Field: TFNF
  offset: 1, size: 1, access: 
  TFNF
  Field: TFEF
  offset: 2, size: 1, access: 
  TFEF
  Field: RFNEF
  offset: 3, size: 1, access: 
  RFNEF
  Field: RFFF
  offset: 4, size: 1, access: 
  RFFF
  Field: DCEF
  offset: 6, size: 1, access: 
  DCEF
*/
volatile uint32_t STS;

/** INTEN INTEN (offset: 0x2c)
  Interrupt enable register
  access : read-write
  reset value : 0x7F
  reset mask : 0xFFFFFFFF
  Field: TFEIE
  offset: 0, size: 1, access: 
  TFEIE
  Field: TFOIE
  offset: 1, size: 1, access: 
  TFOIE
  Field: RFUIE
  offset: 2, size: 1, access: 
  RFUIE
  Field: RFOIE
  offset: 3, size: 1, access: 
  RFOIE
  Field: RFFIE
  offset: 4, size: 1, access: 
  RFFIE
  Field: MSTIE
  offset: 5, size: 1, access: 
  MSTIE
*/
volatile uint32_t INTEN;

/** ISTS ISTS (offset: 0x30)
  Interrupt status register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TFEIF
  offset: 0, size: 1, access: 
  TFEIF
  Field: TFOIF
  offset: 1, size: 1, access: 
  TFOIF
  Field: RFUIF
  offset: 2, size: 1, access: 
  RFUIF
  Field: RFOIF
  offset: 3, size: 1, access: 
  RFOIF
  Field: RFFIF
  offset: 4, size: 1, access: 
  RFFIF
  Field: MSTIF
  offset: 5, size: 1, access: 
  MSTIF
*/
volatile uint32_t ISTS;

/** RIS RIS (offset: 0x34)
  Raw interrupt register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TFEIF
  offset: 0, size: 1, access: 
  TFEIF
  Field: TFOIF
  offset: 1, size: 1, access: 
  TFOIF
  Field: RFUIF
  offset: 2, size: 1, access: 
  RFUIF
  Field: RXOIR
  offset: 3, size: 1, access: 
  RXOIR
  Field: RXFIR
  offset: 4, size: 1, access: 
  RXFIR
  Field: MSTIR
  offset: 5, size: 1, access: 
  MSTIR
*/
volatile uint32_t RIS;

/** TFOIC TFOIC (offset: 0x38)
  Transmission FIFO overflow interrupt clear register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TFOIC
  offset: 0, size: 1, access: 
  TFOIC
*/
volatile uint32_t TFOIC;

/** RFOIC RFOIC (offset: 0x3c)
  Reception FIFO overflow interrupt clear register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RFOIC
  offset: 0, size: 1, access: 
  RFOIC
*/
volatile uint32_t RFOIC;

/** RFUIC RFUIC (offset: 0x40)
  Reception FIFO underflow interrupt clear register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RFUIC
  offset: 0, size: 1, access: 
  RFUIC
*/
volatile uint32_t RFUIC;

/** MIC MIC (offset: 0x44)
  Master interrupt clear register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MIC
  offset: 0, size: 1, access: 
  MIC
*/
volatile uint32_t MIC;

/** ICF ICF (offset: 0x48)
  Interrupt clear register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ICF
  offset: 0, size: 1, access: 
  ICF
*/
volatile uint32_t ICF;

/** DMACTRL DMACTRL (offset: 0x4c)
  dma control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RDMAEN
  offset: 0, size: 1, access: 
  Receive DMA Enable
  Field: TDMAEN
  offset: 1, size: 1, access: 
  Transmit DMA Enable
*/
volatile uint32_t DMACTRL;

/** DMATDL DMATDL (offset: 0x50)
  dma tx data level register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DMATDL
  offset: 0, size: 3, access: 
  DMATDL
*/
volatile uint32_t DMATDL;

/** DMARDL DMARDL (offset: 0x54)
  dma rx data level register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DMARDL
  offset: 0, size: 3, access: 
  DMARDL
*/
volatile uint32_t DMARDL;
volatile uint32_t reserved1[2];

/** DATA DATA (offset: 0x60)
  data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATA
  offset: 0, size: 32, access: 
  Data register
*/
volatile uint32_t DATA;
volatile uint32_t reserved2[35];

/** RSD RSD (offset: 0xf0)
  Reception sample register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RSD
  offset: 0, size: 8, access: 
  RSD
  Field: RSE
  offset: 16, size: 1, access: 
  RSE
*/
volatile uint32_t RSD;

/** CTRL3 CTRL3 (offset: 0xf4)
  Control register 3
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IAT
  offset: 0, size: 2, access: 
  IAT
  Field: ADDRLEN
  offset: 2, size: 4, access: 
  ADDRLEN
  Field: INSLEN
  offset: 8, size: 2, access: 
  INSLEN
  Field: WAITCYC
  offset: 11, size: 5, access: 
  WAITCYC
  Field: CSEN
  offset: 30, size: 1, access: 
  CSEN
*/
volatile uint32_t CTRL3;
volatile uint32_t reserved3[66];

/** IOSW IOSW (offset: 0x200)
  IO switch register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IOSW
  offset: 0, size: 1, access: 
  I/O switch
*/
volatile uint32_t IOSW;
} QSPI_type;

#define QSPI ((QSPI_type *) 0xA0001000)

#endif // HW_QSPI_H
