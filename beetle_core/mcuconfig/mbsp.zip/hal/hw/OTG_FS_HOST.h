#ifndef HW_OTG_FS_HOST_H
#define HW_OTG_FS_HOST_H
/** USB on the go full speed */
/** Memory Block starting at 0x50000400 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define OTG_FS_HOST_HCFG_PHYCLKSEL_OFFSET                  0
#define OTG_FS_HOST_HCFG_PHYCLKSEL_MASK                    3

#define OTG_FS_HOST_HCFG_FSSPT_OFFSET                      2
#define OTG_FS_HOST_HCFG_FSSPT_MASK                        4

#define OTG_FS_HOST_HFIVL_FIVL_OFFSET                      0
#define OTG_FS_HOST_HFIVL_FIVL_MASK                        0xffff

#define OTG_FS_HOST_HFIFM_FNUM_OFFSET                      0
#define OTG_FS_HOST_HFIFM_FNUM_MASK                        0xffff

#define OTG_FS_HOST_HFIFM_FRTIME_OFFSET                    16
#define OTG_FS_HOST_HFIFM_FRTIME_MASK                      0xffff0000

#define OTG_FS_HOST_HPTXSTS_FSPACE_OFFSET                  0
#define OTG_FS_HOST_HPTXSTS_FSPACE_MASK                    0xffff

#define OTG_FS_HOST_HPTXSTS_QSPACE_OFFSET                  16
#define OTG_FS_HOST_HPTXSTS_QSPACE_MASK                    0xff0000

#define OTG_FS_HOST_HPTXSTS_QTOP_OFFSET                    24
#define OTG_FS_HOST_HPTXSTS_QTOP_MASK                      0xff000000

#define OTG_FS_HOST_HACHINT_ACHINT_OFFSET                  0
#define OTG_FS_HOST_HACHINT_ACHINT_MASK                    0xffff

#define OTG_FS_HOST_HACHIMASK_ACHIMASK_OFFSET              0
#define OTG_FS_HOST_HACHIMASK_ACHIMASK_MASK                0xffff

#define OTG_FS_HOST_HPORTCSTS_PCNNTFLG_OFFSET              0
#define OTG_FS_HOST_HPORTCSTS_PCNNTFLG_MASK                1

#define OTG_FS_HOST_HPORTCSTS_PCINTFLG_OFFSET              1
#define OTG_FS_HOST_HPORTCSTS_PCINTFLG_MASK                2

#define OTG_FS_HOST_HPORTCSTS_PEN_OFFSET                   2
#define OTG_FS_HOST_HPORTCSTS_PEN_MASK                     4

#define OTG_FS_HOST_HPORTCSTS_PENCHG_OFFSET                3
#define OTG_FS_HOST_HPORTCSTS_PENCHG_MASK                  8

#define OTG_FS_HOST_HPORTCSTS_POVC_OFFSET                  4
#define OTG_FS_HOST_HPORTCSTS_POVC_MASK                    0x10

#define OTG_FS_HOST_HPORTCSTS_POVCCHG_OFFSET               5
#define OTG_FS_HOST_HPORTCSTS_POVCCHG_MASK                 0x20

#define OTG_FS_HOST_HPORTCSTS_PRS_OFFSET                   6
#define OTG_FS_HOST_HPORTCSTS_PRS_MASK                     0x40

#define OTG_FS_HOST_HPORTCSTS_PSUS_OFFSET                  7
#define OTG_FS_HOST_HPORTCSTS_PSUS_MASK                    0x80

#define OTG_FS_HOST_HPORTCSTS_PRST_OFFSET                  8
#define OTG_FS_HOST_HPORTCSTS_PRST_MASK                    0x100

#define OTG_FS_HOST_HPORTCSTS_PDLSTS_OFFSET                10
#define OTG_FS_HOST_HPORTCSTS_PDLSTS_MASK                  0xc00

#define OTG_FS_HOST_HPORTCSTS_PP_OFFSET                    12
#define OTG_FS_HOST_HPORTCSTS_PP_MASK                      0x1000

#define OTG_FS_HOST_HPORTCSTS_PTSEL_OFFSET                 13
#define OTG_FS_HOST_HPORTCSTS_PTSEL_MASK                   0x1e000

#define OTG_FS_HOST_HPORTCSTS_PSPDSEL_OFFSET               17
#define OTG_FS_HOST_HPORTCSTS_PSPDSEL_MASK                 0x60000

#define OTG_FS_HOST_HCH0_MAXPSIZE_OFFSET                   0
#define OTG_FS_HOST_HCH0_MAXPSIZE_MASK                     0x7ff

#define OTG_FS_HOST_HCH0_EDPNUM_OFFSET                     11
#define OTG_FS_HOST_HCH0_EDPNUM_MASK                       0x7800

#define OTG_FS_HOST_HCH0_EDPDRT_OFFSET                     15
#define OTG_FS_HOST_HCH0_EDPDRT_MASK                       0x8000

#define OTG_FS_HOST_HCH0_LSDV_OFFSET                       17
#define OTG_FS_HOST_HCH0_LSDV_MASK                         0x20000

#define OTG_FS_HOST_HCH0_EDPTYP_OFFSET                     18
#define OTG_FS_HOST_HCH0_EDPTYP_MASK                       0xc0000

#define OTG_FS_HOST_HCH0_CNTSEL_OFFSET                     20
#define OTG_FS_HOST_HCH0_CNTSEL_MASK                       0x300000

#define OTG_FS_HOST_HCH0_DVADDR_OFFSET                     22
#define OTG_FS_HOST_HCH0_DVADDR_MASK                       0x1fc00000

#define OTG_FS_HOST_HCH0_ODDF_OFFSET                       29
#define OTG_FS_HOST_HCH0_ODDF_MASK                         0x20000000

#define OTG_FS_HOST_HCH0_CHINT_OFFSET                      30
#define OTG_FS_HOST_HCH0_CHINT_MASK                        0x40000000

#define OTG_FS_HOST_HCH0_CHEN_OFFSET                       31
#define OTG_FS_HOST_HCH0_CHEN_MASK                         0x80000000

#define OTG_FS_HOST_HCHINT0_TSFCMPN_OFFSET                 0
#define OTG_FS_HOST_HCHINT0_TSFCMPN_MASK                   1

#define OTG_FS_HOST_HCHINT0_TSFCMPAN_OFFSET                1
#define OTG_FS_HOST_HCHINT0_TSFCMPAN_MASK                  2

#define OTG_FS_HOST_HCHINT0_RXSTALL_OFFSET                 3
#define OTG_FS_HOST_HCHINT0_RXSTALL_MASK                   8

#define OTG_FS_HOST_HCHINT0_RXNAK_OFFSET                   4
#define OTG_FS_HOST_HCHINT0_RXNAK_MASK                     0x10

#define OTG_FS_HOST_HCHINT0_RXTXACK_OFFSET                 5
#define OTG_FS_HOST_HCHINT0_RXTXACK_MASK                   0x20

#define OTG_FS_HOST_HCHINT0_TERR_OFFSET                    7
#define OTG_FS_HOST_HCHINT0_TERR_MASK                      0x80

#define OTG_FS_HOST_HCHINT0_BABBLE_OFFSET                  8
#define OTG_FS_HOST_HCHINT0_BABBLE_MASK                    0x100

#define OTG_FS_HOST_HCHINT0_FOVR_OFFSET                    9
#define OTG_FS_HOST_HCHINT0_FOVR_MASK                      0x200

#define OTG_FS_HOST_HCHINT0_DTOG_OFFSET                    10
#define OTG_FS_HOST_HCHINT0_DTOG_MASK                      0x400

#define OTG_FS_HOST_HCHIMASK0_TSFCMPNM_OFFSET              0
#define OTG_FS_HOST_HCHIMASK0_TSFCMPNM_MASK                1

#define OTG_FS_HOST_HCHIMASK0_TSFCMPANM_OFFSET             1
#define OTG_FS_HOST_HCHIMASK0_TSFCMPANM_MASK               2

#define OTG_FS_HOST_HCHIMASK0_RXSTALLM_OFFSET              3
#define OTG_FS_HOST_HCHIMASK0_RXSTALLM_MASK                8

#define OTG_FS_HOST_HCHIMASK0_RXNAKM_OFFSET                4
#define OTG_FS_HOST_HCHIMASK0_RXNAKM_MASK                  0x10

#define OTG_FS_HOST_HCHIMASK0_RXTXACKM_OFFSET              5
#define OTG_FS_HOST_HCHIMASK0_RXTXACKM_MASK                0x20

#define OTG_FS_HOST_HCHIMASK0_RXNYETM_OFFSET               6
#define OTG_FS_HOST_HCHIMASK0_RXNYETM_MASK                 0x40

#define OTG_FS_HOST_HCHIMASK0_TERRM_OFFSET                 7
#define OTG_FS_HOST_HCHIMASK0_TERRM_MASK                   0x80

#define OTG_FS_HOST_HCHIMASK0_BABBLEM_OFFSET               8
#define OTG_FS_HOST_HCHIMASK0_BABBLEM_MASK                 0x100

#define OTG_FS_HOST_HCHIMASK0_FOVRM_OFFSET                 9
#define OTG_FS_HOST_HCHIMASK0_FOVRM_MASK                   0x200

#define OTG_FS_HOST_HCHIMASK0_DTOGM_OFFSET                 10
#define OTG_FS_HOST_HCHIMASK0_DTOGM_MASK                   0x400

#define OTG_FS_HOST_HCHTSIZE0_TSFSIZE_OFFSET               0
#define OTG_FS_HOST_HCHTSIZE0_TSFSIZE_MASK                 0x7ffff

#define OTG_FS_HOST_HCHTSIZE0_PCKTCNT_OFFSET               19
#define OTG_FS_HOST_HCHTSIZE0_PCKTCNT_MASK                 0x1ff80000

#define OTG_FS_HOST_HCHTSIZE0_DATAPID_OFFSET               29
#define OTG_FS_HOST_HCHTSIZE0_DATAPID_MASK                 0x60000000

#define OTG_FS_HOST_HCH1_MAXPSIZE_OFFSET                   0
#define OTG_FS_HOST_HCH1_MAXPSIZE_MASK                     0x7ff

#define OTG_FS_HOST_HCH1_EDPNUM_OFFSET                     11
#define OTG_FS_HOST_HCH1_EDPNUM_MASK                       0x7800

#define OTG_FS_HOST_HCH1_EDPDRT_OFFSET                     15
#define OTG_FS_HOST_HCH1_EDPDRT_MASK                       0x8000

#define OTG_FS_HOST_HCH1_LSDV_OFFSET                       17
#define OTG_FS_HOST_HCH1_LSDV_MASK                         0x20000

#define OTG_FS_HOST_HCH1_EDPTYP_OFFSET                     18
#define OTG_FS_HOST_HCH1_EDPTYP_MASK                       0xc0000

#define OTG_FS_HOST_HCH1_CNTSEL_OFFSET                     20
#define OTG_FS_HOST_HCH1_CNTSEL_MASK                       0x300000

#define OTG_FS_HOST_HCH1_DVADDR_OFFSET                     22
#define OTG_FS_HOST_HCH1_DVADDR_MASK                       0x1fc00000

#define OTG_FS_HOST_HCH1_ODDF_OFFSET                       29
#define OTG_FS_HOST_HCH1_ODDF_MASK                         0x20000000

#define OTG_FS_HOST_HCH1_CHINT_OFFSET                      30
#define OTG_FS_HOST_HCH1_CHINT_MASK                        0x40000000

#define OTG_FS_HOST_HCH1_CHEN_OFFSET                       31
#define OTG_FS_HOST_HCH1_CHEN_MASK                         0x80000000

#define OTG_FS_HOST_HCHINT1_TSFCMPN_OFFSET                 0
#define OTG_FS_HOST_HCHINT1_TSFCMPN_MASK                   1

#define OTG_FS_HOST_HCHINT1_TSFCMPAN_OFFSET                1
#define OTG_FS_HOST_HCHINT1_TSFCMPAN_MASK                  2

#define OTG_FS_HOST_HCHINT1_RXSTALL_OFFSET                 3
#define OTG_FS_HOST_HCHINT1_RXSTALL_MASK                   8

#define OTG_FS_HOST_HCHINT1_RXNAK_OFFSET                   4
#define OTG_FS_HOST_HCHINT1_RXNAK_MASK                     0x10

#define OTG_FS_HOST_HCHINT1_RXTXACK_OFFSET                 5
#define OTG_FS_HOST_HCHINT1_RXTXACK_MASK                   0x20

#define OTG_FS_HOST_HCHINT1_TERR_OFFSET                    7
#define OTG_FS_HOST_HCHINT1_TERR_MASK                      0x80

#define OTG_FS_HOST_HCHINT1_BABBLE_OFFSET                  8
#define OTG_FS_HOST_HCHINT1_BABBLE_MASK                    0x100

#define OTG_FS_HOST_HCHINT1_FOVR_OFFSET                    9
#define OTG_FS_HOST_HCHINT1_FOVR_MASK                      0x200

#define OTG_FS_HOST_HCHINT1_DTOG_OFFSET                    10
#define OTG_FS_HOST_HCHINT1_DTOG_MASK                      0x400

#define OTG_FS_HOST_HCHIMASK1_TSFCMPNM_OFFSET              0
#define OTG_FS_HOST_HCHIMASK1_TSFCMPNM_MASK                1

#define OTG_FS_HOST_HCHIMASK1_TSFCMPANM_OFFSET             1
#define OTG_FS_HOST_HCHIMASK1_TSFCMPANM_MASK               2

#define OTG_FS_HOST_HCHIMASK1_RXSTALLM_OFFSET              3
#define OTG_FS_HOST_HCHIMASK1_RXSTALLM_MASK                8

#define OTG_FS_HOST_HCHIMASK1_RXNAKM_OFFSET                4
#define OTG_FS_HOST_HCHIMASK1_RXNAKM_MASK                  0x10

#define OTG_FS_HOST_HCHIMASK1_RXTXACKM_OFFSET              5
#define OTG_FS_HOST_HCHIMASK1_RXTXACKM_MASK                0x20

#define OTG_FS_HOST_HCHIMASK1_RXNYETM_OFFSET               6
#define OTG_FS_HOST_HCHIMASK1_RXNYETM_MASK                 0x40

#define OTG_FS_HOST_HCHIMASK1_TERRM_OFFSET                 7
#define OTG_FS_HOST_HCHIMASK1_TERRM_MASK                   0x80

#define OTG_FS_HOST_HCHIMASK1_BABBLEM_OFFSET               8
#define OTG_FS_HOST_HCHIMASK1_BABBLEM_MASK                 0x100

#define OTG_FS_HOST_HCHIMASK1_FOVRM_OFFSET                 9
#define OTG_FS_HOST_HCHIMASK1_FOVRM_MASK                   0x200

#define OTG_FS_HOST_HCHIMASK1_DTOGM_OFFSET                 10
#define OTG_FS_HOST_HCHIMASK1_DTOGM_MASK                   0x400

#define OTG_FS_HOST_HCHTSIZE1_TSFSIZE_OFFSET               0
#define OTG_FS_HOST_HCHTSIZE1_TSFSIZE_MASK                 0x7ffff

#define OTG_FS_HOST_HCHTSIZE1_PCKTCNT_OFFSET               19
#define OTG_FS_HOST_HCHTSIZE1_PCKTCNT_MASK                 0x1ff80000

#define OTG_FS_HOST_HCHTSIZE1_DATAPID_OFFSET               29
#define OTG_FS_HOST_HCHTSIZE1_DATAPID_MASK                 0x60000000

#define OTG_FS_HOST_HCH2_MAXPSIZE_OFFSET                   0
#define OTG_FS_HOST_HCH2_MAXPSIZE_MASK                     0x7ff

#define OTG_FS_HOST_HCH2_EDPNUM_OFFSET                     11
#define OTG_FS_HOST_HCH2_EDPNUM_MASK                       0x7800

#define OTG_FS_HOST_HCH2_EDPDRT_OFFSET                     15
#define OTG_FS_HOST_HCH2_EDPDRT_MASK                       0x8000

#define OTG_FS_HOST_HCH2_LSDV_OFFSET                       17
#define OTG_FS_HOST_HCH2_LSDV_MASK                         0x20000

#define OTG_FS_HOST_HCH2_EDPTYP_OFFSET                     18
#define OTG_FS_HOST_HCH2_EDPTYP_MASK                       0xc0000

#define OTG_FS_HOST_HCH2_CNTSEL_OFFSET                     20
#define OTG_FS_HOST_HCH2_CNTSEL_MASK                       0x300000

#define OTG_FS_HOST_HCH2_DVADDR_OFFSET                     22
#define OTG_FS_HOST_HCH2_DVADDR_MASK                       0x1fc00000

#define OTG_FS_HOST_HCH2_ODDF_OFFSET                       29
#define OTG_FS_HOST_HCH2_ODDF_MASK                         0x20000000

#define OTG_FS_HOST_HCH2_CHINT_OFFSET                      30
#define OTG_FS_HOST_HCH2_CHINT_MASK                        0x40000000

#define OTG_FS_HOST_HCH2_CHEN_OFFSET                       31
#define OTG_FS_HOST_HCH2_CHEN_MASK                         0x80000000

#define OTG_FS_HOST_HCHINT2_TSFCMPN_OFFSET                 0
#define OTG_FS_HOST_HCHINT2_TSFCMPN_MASK                   1

#define OTG_FS_HOST_HCHINT2_TSFCMPAN_OFFSET                1
#define OTG_FS_HOST_HCHINT2_TSFCMPAN_MASK                  2

#define OTG_FS_HOST_HCHINT2_RXSTALL_OFFSET                 3
#define OTG_FS_HOST_HCHINT2_RXSTALL_MASK                   8

#define OTG_FS_HOST_HCHINT2_RXNAK_OFFSET                   4
#define OTG_FS_HOST_HCHINT2_RXNAK_MASK                     0x10

#define OTG_FS_HOST_HCHINT2_RXTXACK_OFFSET                 5
#define OTG_FS_HOST_HCHINT2_RXTXACK_MASK                   0x20

#define OTG_FS_HOST_HCHINT2_TERR_OFFSET                    7
#define OTG_FS_HOST_HCHINT2_TERR_MASK                      0x80

#define OTG_FS_HOST_HCHINT2_BABBLE_OFFSET                  8
#define OTG_FS_HOST_HCHINT2_BABBLE_MASK                    0x100

#define OTG_FS_HOST_HCHINT2_FOVR_OFFSET                    9
#define OTG_FS_HOST_HCHINT2_FOVR_MASK                      0x200

#define OTG_FS_HOST_HCHINT2_DTOG_OFFSET                    10
#define OTG_FS_HOST_HCHINT2_DTOG_MASK                      0x400

#define OTG_FS_HOST_HCHIMASK2_TSFCMPNM_OFFSET              0
#define OTG_FS_HOST_HCHIMASK2_TSFCMPNM_MASK                1

#define OTG_FS_HOST_HCHIMASK2_TSFCMPANM_OFFSET             1
#define OTG_FS_HOST_HCHIMASK2_TSFCMPANM_MASK               2

#define OTG_FS_HOST_HCHIMASK2_RXSTALLM_OFFSET              3
#define OTG_FS_HOST_HCHIMASK2_RXSTALLM_MASK                8

#define OTG_FS_HOST_HCHIMASK2_RXNAKM_OFFSET                4
#define OTG_FS_HOST_HCHIMASK2_RXNAKM_MASK                  0x10

#define OTG_FS_HOST_HCHIMASK2_RXTXACKM_OFFSET              5
#define OTG_FS_HOST_HCHIMASK2_RXTXACKM_MASK                0x20

#define OTG_FS_HOST_HCHIMASK2_RXNYETM_OFFSET               6
#define OTG_FS_HOST_HCHIMASK2_RXNYETM_MASK                 0x40

#define OTG_FS_HOST_HCHIMASK2_TERRM_OFFSET                 7
#define OTG_FS_HOST_HCHIMASK2_TERRM_MASK                   0x80

#define OTG_FS_HOST_HCHIMASK2_BABBLEM_OFFSET               8
#define OTG_FS_HOST_HCHIMASK2_BABBLEM_MASK                 0x100

#define OTG_FS_HOST_HCHIMASK2_FOVRM_OFFSET                 9
#define OTG_FS_HOST_HCHIMASK2_FOVRM_MASK                   0x200

#define OTG_FS_HOST_HCHIMASK2_DTOGM_OFFSET                 10
#define OTG_FS_HOST_HCHIMASK2_DTOGM_MASK                   0x400

#define OTG_FS_HOST_HCHTSIZE2_TSFSIZE_OFFSET               0
#define OTG_FS_HOST_HCHTSIZE2_TSFSIZE_MASK                 0x7ffff

#define OTG_FS_HOST_HCHTSIZE2_PCKTCNT_OFFSET               19
#define OTG_FS_HOST_HCHTSIZE2_PCKTCNT_MASK                 0x1ff80000

#define OTG_FS_HOST_HCHTSIZE2_DATAPID_OFFSET               29
#define OTG_FS_HOST_HCHTSIZE2_DATAPID_MASK                 0x60000000

#define OTG_FS_HOST_HCH3_MAXPSIZE_OFFSET                   0
#define OTG_FS_HOST_HCH3_MAXPSIZE_MASK                     0x7ff

#define OTG_FS_HOST_HCH3_EDPNUM_OFFSET                     11
#define OTG_FS_HOST_HCH3_EDPNUM_MASK                       0x7800

#define OTG_FS_HOST_HCH3_EDPDRT_OFFSET                     15
#define OTG_FS_HOST_HCH3_EDPDRT_MASK                       0x8000

#define OTG_FS_HOST_HCH3_LSDV_OFFSET                       17
#define OTG_FS_HOST_HCH3_LSDV_MASK                         0x20000

#define OTG_FS_HOST_HCH3_EDPTYP_OFFSET                     18
#define OTG_FS_HOST_HCH3_EDPTYP_MASK                       0xc0000

#define OTG_FS_HOST_HCH3_CNTSEL_OFFSET                     20
#define OTG_FS_HOST_HCH3_CNTSEL_MASK                       0x300000

#define OTG_FS_HOST_HCH3_DVADDR_OFFSET                     22
#define OTG_FS_HOST_HCH3_DVADDR_MASK                       0x1fc00000

#define OTG_FS_HOST_HCH3_ODDF_OFFSET                       29
#define OTG_FS_HOST_HCH3_ODDF_MASK                         0x20000000

#define OTG_FS_HOST_HCH3_CHINT_OFFSET                      30
#define OTG_FS_HOST_HCH3_CHINT_MASK                        0x40000000

#define OTG_FS_HOST_HCH3_CHEN_OFFSET                       31
#define OTG_FS_HOST_HCH3_CHEN_MASK                         0x80000000

#define OTG_FS_HOST_HCHINT3_TSFCMPN_OFFSET                 0
#define OTG_FS_HOST_HCHINT3_TSFCMPN_MASK                   1

#define OTG_FS_HOST_HCHINT3_TSFCMPAN_OFFSET                1
#define OTG_FS_HOST_HCHINT3_TSFCMPAN_MASK                  2

#define OTG_FS_HOST_HCHINT3_RXSTALL_OFFSET                 3
#define OTG_FS_HOST_HCHINT3_RXSTALL_MASK                   8

#define OTG_FS_HOST_HCHINT3_RXNAK_OFFSET                   4
#define OTG_FS_HOST_HCHINT3_RXNAK_MASK                     0x10

#define OTG_FS_HOST_HCHINT3_RXTXACK_OFFSET                 5
#define OTG_FS_HOST_HCHINT3_RXTXACK_MASK                   0x20

#define OTG_FS_HOST_HCHINT3_TERR_OFFSET                    7
#define OTG_FS_HOST_HCHINT3_TERR_MASK                      0x80

#define OTG_FS_HOST_HCHINT3_BABBLE_OFFSET                  8
#define OTG_FS_HOST_HCHINT3_BABBLE_MASK                    0x100

#define OTG_FS_HOST_HCHINT3_FOVR_OFFSET                    9
#define OTG_FS_HOST_HCHINT3_FOVR_MASK                      0x200

#define OTG_FS_HOST_HCHINT3_DTOG_OFFSET                    10
#define OTG_FS_HOST_HCHINT3_DTOG_MASK                      0x400

#define OTG_FS_HOST_HCHIMASK3_TSFCMPNM_OFFSET              0
#define OTG_FS_HOST_HCHIMASK3_TSFCMPNM_MASK                1

#define OTG_FS_HOST_HCHIMASK3_TSFCMPANM_OFFSET             1
#define OTG_FS_HOST_HCHIMASK3_TSFCMPANM_MASK               2

#define OTG_FS_HOST_HCHIMASK3_RXSTALLM_OFFSET              3
#define OTG_FS_HOST_HCHIMASK3_RXSTALLM_MASK                8

#define OTG_FS_HOST_HCHIMASK3_RXNAKM_OFFSET                4
#define OTG_FS_HOST_HCHIMASK3_RXNAKM_MASK                  0x10

#define OTG_FS_HOST_HCHIMASK3_RXTXACKM_OFFSET              5
#define OTG_FS_HOST_HCHIMASK3_RXTXACKM_MASK                0x20

#define OTG_FS_HOST_HCHIMASK3_RXNYETM_OFFSET               6
#define OTG_FS_HOST_HCHIMASK3_RXNYETM_MASK                 0x40

#define OTG_FS_HOST_HCHIMASK3_TERRM_OFFSET                 7
#define OTG_FS_HOST_HCHIMASK3_TERRM_MASK                   0x80

#define OTG_FS_HOST_HCHIMASK3_BABBLEM_OFFSET               8
#define OTG_FS_HOST_HCHIMASK3_BABBLEM_MASK                 0x100

#define OTG_FS_HOST_HCHIMASK3_FOVRM_OFFSET                 9
#define OTG_FS_HOST_HCHIMASK3_FOVRM_MASK                   0x200

#define OTG_FS_HOST_HCHIMASK3_DTOGM_OFFSET                 10
#define OTG_FS_HOST_HCHIMASK3_DTOGM_MASK                   0x400

#define OTG_FS_HOST_HCHTSIZE3_TSFSIZE_OFFSET               0
#define OTG_FS_HOST_HCHTSIZE3_TSFSIZE_MASK                 0x7ffff

#define OTG_FS_HOST_HCHTSIZE3_PCKTCNT_OFFSET               19
#define OTG_FS_HOST_HCHTSIZE3_PCKTCNT_MASK                 0x1ff80000

#define OTG_FS_HOST_HCHTSIZE3_DATAPID_OFFSET               29
#define OTG_FS_HOST_HCHTSIZE3_DATAPID_MASK                 0x60000000

#define OTG_FS_HOST_HCH4_MAXPSIZE_OFFSET                   0
#define OTG_FS_HOST_HCH4_MAXPSIZE_MASK                     0x7ff

#define OTG_FS_HOST_HCH4_EDPNUM_OFFSET                     11
#define OTG_FS_HOST_HCH4_EDPNUM_MASK                       0x7800

#define OTG_FS_HOST_HCH4_EDPDRT_OFFSET                     15
#define OTG_FS_HOST_HCH4_EDPDRT_MASK                       0x8000

#define OTG_FS_HOST_HCH4_LSDV_OFFSET                       17
#define OTG_FS_HOST_HCH4_LSDV_MASK                         0x20000

#define OTG_FS_HOST_HCH4_EDPTYP_OFFSET                     18
#define OTG_FS_HOST_HCH4_EDPTYP_MASK                       0xc0000

#define OTG_FS_HOST_HCH4_CNTSEL_OFFSET                     20
#define OTG_FS_HOST_HCH4_CNTSEL_MASK                       0x300000

#define OTG_FS_HOST_HCH4_DVADDR_OFFSET                     22
#define OTG_FS_HOST_HCH4_DVADDR_MASK                       0x1fc00000

#define OTG_FS_HOST_HCH4_ODDF_OFFSET                       29
#define OTG_FS_HOST_HCH4_ODDF_MASK                         0x20000000

#define OTG_FS_HOST_HCH4_CHINT_OFFSET                      30
#define OTG_FS_HOST_HCH4_CHINT_MASK                        0x40000000

#define OTG_FS_HOST_HCH4_CHEN_OFFSET                       31
#define OTG_FS_HOST_HCH4_CHEN_MASK                         0x80000000

#define OTG_FS_HOST_HCHINT4_TSFCMPN_OFFSET                 0
#define OTG_FS_HOST_HCHINT4_TSFCMPN_MASK                   1

#define OTG_FS_HOST_HCHINT4_TSFCMPAN_OFFSET                1
#define OTG_FS_HOST_HCHINT4_TSFCMPAN_MASK                  2

#define OTG_FS_HOST_HCHINT4_RXSTALL_OFFSET                 3
#define OTG_FS_HOST_HCHINT4_RXSTALL_MASK                   8

#define OTG_FS_HOST_HCHINT4_RXNAK_OFFSET                   4
#define OTG_FS_HOST_HCHINT4_RXNAK_MASK                     0x10

#define OTG_FS_HOST_HCHINT4_RXTXACK_OFFSET                 5
#define OTG_FS_HOST_HCHINT4_RXTXACK_MASK                   0x20

#define OTG_FS_HOST_HCHINT4_TERR_OFFSET                    7
#define OTG_FS_HOST_HCHINT4_TERR_MASK                      0x80

#define OTG_FS_HOST_HCHINT4_BABBLE_OFFSET                  8
#define OTG_FS_HOST_HCHINT4_BABBLE_MASK                    0x100

#define OTG_FS_HOST_HCHINT4_FOVR_OFFSET                    9
#define OTG_FS_HOST_HCHINT4_FOVR_MASK                      0x200

#define OTG_FS_HOST_HCHINT4_DTOG_OFFSET                    10
#define OTG_FS_HOST_HCHINT4_DTOG_MASK                      0x400

#define OTG_FS_HOST_HCHIMASK4_TSFCMPNM_OFFSET              0
#define OTG_FS_HOST_HCHIMASK4_TSFCMPNM_MASK                1

#define OTG_FS_HOST_HCHIMASK4_TSFCMPANM_OFFSET             1
#define OTG_FS_HOST_HCHIMASK4_TSFCMPANM_MASK               2

#define OTG_FS_HOST_HCHIMASK4_RXSTALLM_OFFSET              3
#define OTG_FS_HOST_HCHIMASK4_RXSTALLM_MASK                8

#define OTG_FS_HOST_HCHIMASK4_RXNAKM_OFFSET                4
#define OTG_FS_HOST_HCHIMASK4_RXNAKM_MASK                  0x10

#define OTG_FS_HOST_HCHIMASK4_RXTXACKM_OFFSET              5
#define OTG_FS_HOST_HCHIMASK4_RXTXACKM_MASK                0x20

#define OTG_FS_HOST_HCHIMASK4_RXNYETM_OFFSET               6
#define OTG_FS_HOST_HCHIMASK4_RXNYETM_MASK                 0x40

#define OTG_FS_HOST_HCHIMASK4_TERRM_OFFSET                 7
#define OTG_FS_HOST_HCHIMASK4_TERRM_MASK                   0x80

#define OTG_FS_HOST_HCHIMASK4_BABBLEM_OFFSET               8
#define OTG_FS_HOST_HCHIMASK4_BABBLEM_MASK                 0x100

#define OTG_FS_HOST_HCHIMASK4_FOVRM_OFFSET                 9
#define OTG_FS_HOST_HCHIMASK4_FOVRM_MASK                   0x200

#define OTG_FS_HOST_HCHIMASK4_DTOGM_OFFSET                 10
#define OTG_FS_HOST_HCHIMASK4_DTOGM_MASK                   0x400

#define OTG_FS_HOST_HCHTSIZE4_TSFSIZE_OFFSET               0
#define OTG_FS_HOST_HCHTSIZE4_TSFSIZE_MASK                 0x7ffff

#define OTG_FS_HOST_HCHTSIZE4_PCKTCNT_OFFSET               19
#define OTG_FS_HOST_HCHTSIZE4_PCKTCNT_MASK                 0x1ff80000

#define OTG_FS_HOST_HCHTSIZE4_DATAPID_OFFSET               29
#define OTG_FS_HOST_HCHTSIZE4_DATAPID_MASK                 0x60000000

#define OTG_FS_HOST_HCH5_MAXPSIZE_OFFSET                   0
#define OTG_FS_HOST_HCH5_MAXPSIZE_MASK                     0x7ff

#define OTG_FS_HOST_HCH5_EDPNUM_OFFSET                     11
#define OTG_FS_HOST_HCH5_EDPNUM_MASK                       0x7800

#define OTG_FS_HOST_HCH5_EDPDRT_OFFSET                     15
#define OTG_FS_HOST_HCH5_EDPDRT_MASK                       0x8000

#define OTG_FS_HOST_HCH5_LSDV_OFFSET                       17
#define OTG_FS_HOST_HCH5_LSDV_MASK                         0x20000

#define OTG_FS_HOST_HCH5_EDPTYP_OFFSET                     18
#define OTG_FS_HOST_HCH5_EDPTYP_MASK                       0xc0000

#define OTG_FS_HOST_HCH5_CNTSEL_OFFSET                     20
#define OTG_FS_HOST_HCH5_CNTSEL_MASK                       0x300000

#define OTG_FS_HOST_HCH5_DVADDR_OFFSET                     22
#define OTG_FS_HOST_HCH5_DVADDR_MASK                       0x1fc00000

#define OTG_FS_HOST_HCH5_ODDF_OFFSET                       29
#define OTG_FS_HOST_HCH5_ODDF_MASK                         0x20000000

#define OTG_FS_HOST_HCH5_CHINT_OFFSET                      30
#define OTG_FS_HOST_HCH5_CHINT_MASK                        0x40000000

#define OTG_FS_HOST_HCH5_CHEN_OFFSET                       31
#define OTG_FS_HOST_HCH5_CHEN_MASK                         0x80000000

#define OTG_FS_HOST_HCHINT5_TSFCMPN_OFFSET                 0
#define OTG_FS_HOST_HCHINT5_TSFCMPN_MASK                   1

#define OTG_FS_HOST_HCHINT5_TSFCMPAN_OFFSET                1
#define OTG_FS_HOST_HCHINT5_TSFCMPAN_MASK                  2

#define OTG_FS_HOST_HCHINT5_RXSTALL_OFFSET                 3
#define OTG_FS_HOST_HCHINT5_RXSTALL_MASK                   8

#define OTG_FS_HOST_HCHINT5_RXNAK_OFFSET                   4
#define OTG_FS_HOST_HCHINT5_RXNAK_MASK                     0x10

#define OTG_FS_HOST_HCHINT5_RXTXACK_OFFSET                 5
#define OTG_FS_HOST_HCHINT5_RXTXACK_MASK                   0x20

#define OTG_FS_HOST_HCHINT5_TERR_OFFSET                    7
#define OTG_FS_HOST_HCHINT5_TERR_MASK                      0x80

#define OTG_FS_HOST_HCHINT5_BABBLE_OFFSET                  8
#define OTG_FS_HOST_HCHINT5_BABBLE_MASK                    0x100

#define OTG_FS_HOST_HCHINT5_FOVR_OFFSET                    9
#define OTG_FS_HOST_HCHINT5_FOVR_MASK                      0x200

#define OTG_FS_HOST_HCHINT5_DTOG_OFFSET                    10
#define OTG_FS_HOST_HCHINT5_DTOG_MASK                      0x400

#define OTG_FS_HOST_HCHIMASK5_TSFCMPNM_OFFSET              0
#define OTG_FS_HOST_HCHIMASK5_TSFCMPNM_MASK                1

#define OTG_FS_HOST_HCHIMASK5_TSFCMPANM_OFFSET             1
#define OTG_FS_HOST_HCHIMASK5_TSFCMPANM_MASK               2

#define OTG_FS_HOST_HCHIMASK5_RXSTALLM_OFFSET              3
#define OTG_FS_HOST_HCHIMASK5_RXSTALLM_MASK                8

#define OTG_FS_HOST_HCHIMASK5_RXNAKM_OFFSET                4
#define OTG_FS_HOST_HCHIMASK5_RXNAKM_MASK                  0x10

#define OTG_FS_HOST_HCHIMASK5_RXTXACKM_OFFSET              5
#define OTG_FS_HOST_HCHIMASK5_RXTXACKM_MASK                0x20

#define OTG_FS_HOST_HCHIMASK5_RXNYETM_OFFSET               6
#define OTG_FS_HOST_HCHIMASK5_RXNYETM_MASK                 0x40

#define OTG_FS_HOST_HCHIMASK5_TERRM_OFFSET                 7
#define OTG_FS_HOST_HCHIMASK5_TERRM_MASK                   0x80

#define OTG_FS_HOST_HCHIMASK5_BABBLEM_OFFSET               8
#define OTG_FS_HOST_HCHIMASK5_BABBLEM_MASK                 0x100

#define OTG_FS_HOST_HCHIMASK5_FOVRM_OFFSET                 9
#define OTG_FS_HOST_HCHIMASK5_FOVRM_MASK                   0x200

#define OTG_FS_HOST_HCHIMASK5_DTOGM_OFFSET                 10
#define OTG_FS_HOST_HCHIMASK5_DTOGM_MASK                   0x400

#define OTG_FS_HOST_HCHTSIZE5_TSFSIZE_OFFSET               0
#define OTG_FS_HOST_HCHTSIZE5_TSFSIZE_MASK                 0x7ffff

#define OTG_FS_HOST_HCHTSIZE5_PCKTCNT_OFFSET               19
#define OTG_FS_HOST_HCHTSIZE5_PCKTCNT_MASK                 0x1ff80000

#define OTG_FS_HOST_HCHTSIZE5_DATAPID_OFFSET               29
#define OTG_FS_HOST_HCHTSIZE5_DATAPID_MASK                 0x60000000

#define OTG_FS_HOST_HCH6_MAXPSIZE_OFFSET                   0
#define OTG_FS_HOST_HCH6_MAXPSIZE_MASK                     0x7ff

#define OTG_FS_HOST_HCH6_EDPNUM_OFFSET                     11
#define OTG_FS_HOST_HCH6_EDPNUM_MASK                       0x7800

#define OTG_FS_HOST_HCH6_EDPDRT_OFFSET                     15
#define OTG_FS_HOST_HCH6_EDPDRT_MASK                       0x8000

#define OTG_FS_HOST_HCH6_LSDV_OFFSET                       17
#define OTG_FS_HOST_HCH6_LSDV_MASK                         0x20000

#define OTG_FS_HOST_HCH6_EDPTYP_OFFSET                     18
#define OTG_FS_HOST_HCH6_EDPTYP_MASK                       0xc0000

#define OTG_FS_HOST_HCH6_CNTSEL_OFFSET                     20
#define OTG_FS_HOST_HCH6_CNTSEL_MASK                       0x300000

#define OTG_FS_HOST_HCH6_DVADDR_OFFSET                     22
#define OTG_FS_HOST_HCH6_DVADDR_MASK                       0x1fc00000

#define OTG_FS_HOST_HCH6_ODDF_OFFSET                       29
#define OTG_FS_HOST_HCH6_ODDF_MASK                         0x20000000

#define OTG_FS_HOST_HCH6_CHINT_OFFSET                      30
#define OTG_FS_HOST_HCH6_CHINT_MASK                        0x40000000

#define OTG_FS_HOST_HCH6_CHEN_OFFSET                       31
#define OTG_FS_HOST_HCH6_CHEN_MASK                         0x80000000

#define OTG_FS_HOST_HCHINT6_TSFCMPN_OFFSET                 0
#define OTG_FS_HOST_HCHINT6_TSFCMPN_MASK                   1

#define OTG_FS_HOST_HCHINT6_TSFCMPAN_OFFSET                1
#define OTG_FS_HOST_HCHINT6_TSFCMPAN_MASK                  2

#define OTG_FS_HOST_HCHINT6_RXSTALL_OFFSET                 3
#define OTG_FS_HOST_HCHINT6_RXSTALL_MASK                   8

#define OTG_FS_HOST_HCHINT6_RXNAK_OFFSET                   4
#define OTG_FS_HOST_HCHINT6_RXNAK_MASK                     0x10

#define OTG_FS_HOST_HCHINT6_RXTXACK_OFFSET                 5
#define OTG_FS_HOST_HCHINT6_RXTXACK_MASK                   0x20

#define OTG_FS_HOST_HCHINT6_TERR_OFFSET                    7
#define OTG_FS_HOST_HCHINT6_TERR_MASK                      0x80

#define OTG_FS_HOST_HCHINT6_BABBLE_OFFSET                  8
#define OTG_FS_HOST_HCHINT6_BABBLE_MASK                    0x100

#define OTG_FS_HOST_HCHINT6_FOVR_OFFSET                    9
#define OTG_FS_HOST_HCHINT6_FOVR_MASK                      0x200

#define OTG_FS_HOST_HCHINT6_DTOG_OFFSET                    10
#define OTG_FS_HOST_HCHINT6_DTOG_MASK                      0x400

#define OTG_FS_HOST_HCHIMASK6_TSFCMPNM_OFFSET              0
#define OTG_FS_HOST_HCHIMASK6_TSFCMPNM_MASK                1

#define OTG_FS_HOST_HCHIMASK6_TSFCMPANM_OFFSET             1
#define OTG_FS_HOST_HCHIMASK6_TSFCMPANM_MASK               2

#define OTG_FS_HOST_HCHIMASK6_RXSTALLM_OFFSET              3
#define OTG_FS_HOST_HCHIMASK6_RXSTALLM_MASK                8

#define OTG_FS_HOST_HCHIMASK6_RXNAKM_OFFSET                4
#define OTG_FS_HOST_HCHIMASK6_RXNAKM_MASK                  0x10

#define OTG_FS_HOST_HCHIMASK6_RXTXACKM_OFFSET              5
#define OTG_FS_HOST_HCHIMASK6_RXTXACKM_MASK                0x20

#define OTG_FS_HOST_HCHIMASK6_RXNYETM_OFFSET               6
#define OTG_FS_HOST_HCHIMASK6_RXNYETM_MASK                 0x40

#define OTG_FS_HOST_HCHIMASK6_TERRM_OFFSET                 7
#define OTG_FS_HOST_HCHIMASK6_TERRM_MASK                   0x80

#define OTG_FS_HOST_HCHIMASK6_BABBLEM_OFFSET               8
#define OTG_FS_HOST_HCHIMASK6_BABBLEM_MASK                 0x100

#define OTG_FS_HOST_HCHIMASK6_FOVRM_OFFSET                 9
#define OTG_FS_HOST_HCHIMASK6_FOVRM_MASK                   0x200

#define OTG_FS_HOST_HCHIMASK6_DTOGM_OFFSET                 10
#define OTG_FS_HOST_HCHIMASK6_DTOGM_MASK                   0x400

#define OTG_FS_HOST_HCHTSIZE6_TSFSIZE_OFFSET               0
#define OTG_FS_HOST_HCHTSIZE6_TSFSIZE_MASK                 0x7ffff

#define OTG_FS_HOST_HCHTSIZE6_PCKTCNT_OFFSET               19
#define OTG_FS_HOST_HCHTSIZE6_PCKTCNT_MASK                 0x1ff80000

#define OTG_FS_HOST_HCHTSIZE6_DATAPID_OFFSET               29
#define OTG_FS_HOST_HCHTSIZE6_DATAPID_MASK                 0x60000000

#define OTG_FS_HOST_HCH7_MAXPSIZE_OFFSET                   0
#define OTG_FS_HOST_HCH7_MAXPSIZE_MASK                     0x7ff

#define OTG_FS_HOST_HCH7_EDPNUM_OFFSET                     11
#define OTG_FS_HOST_HCH7_EDPNUM_MASK                       0x7800

#define OTG_FS_HOST_HCH7_EDPDRT_OFFSET                     15
#define OTG_FS_HOST_HCH7_EDPDRT_MASK                       0x8000

#define OTG_FS_HOST_HCH7_LSDV_OFFSET                       17
#define OTG_FS_HOST_HCH7_LSDV_MASK                         0x20000

#define OTG_FS_HOST_HCH7_EDPTYP_OFFSET                     18
#define OTG_FS_HOST_HCH7_EDPTYP_MASK                       0xc0000

#define OTG_FS_HOST_HCH7_CNTSEL_OFFSET                     20
#define OTG_FS_HOST_HCH7_CNTSEL_MASK                       0x300000

#define OTG_FS_HOST_HCH7_DVADDR_OFFSET                     22
#define OTG_FS_HOST_HCH7_DVADDR_MASK                       0x1fc00000

#define OTG_FS_HOST_HCH7_ODDF_OFFSET                       29
#define OTG_FS_HOST_HCH7_ODDF_MASK                         0x20000000

#define OTG_FS_HOST_HCH7_CHINT_OFFSET                      30
#define OTG_FS_HOST_HCH7_CHINT_MASK                        0x40000000

#define OTG_FS_HOST_HCH7_CHEN_OFFSET                       31
#define OTG_FS_HOST_HCH7_CHEN_MASK                         0x80000000

#define OTG_FS_HOST_HCHINT7_TSFCMPN_OFFSET                 0
#define OTG_FS_HOST_HCHINT7_TSFCMPN_MASK                   1

#define OTG_FS_HOST_HCHINT7_TSFCMPAN_OFFSET                1
#define OTG_FS_HOST_HCHINT7_TSFCMPAN_MASK                  2

#define OTG_FS_HOST_HCHINT7_RXSTALL_OFFSET                 3
#define OTG_FS_HOST_HCHINT7_RXSTALL_MASK                   8

#define OTG_FS_HOST_HCHINT7_RXNAK_OFFSET                   4
#define OTG_FS_HOST_HCHINT7_RXNAK_MASK                     0x10

#define OTG_FS_HOST_HCHINT7_RXTXACK_OFFSET                 5
#define OTG_FS_HOST_HCHINT7_RXTXACK_MASK                   0x20

#define OTG_FS_HOST_HCHINT7_TERR_OFFSET                    7
#define OTG_FS_HOST_HCHINT7_TERR_MASK                      0x80

#define OTG_FS_HOST_HCHINT7_BABBLE_OFFSET                  8
#define OTG_FS_HOST_HCHINT7_BABBLE_MASK                    0x100

#define OTG_FS_HOST_HCHINT7_FOVR_OFFSET                    9
#define OTG_FS_HOST_HCHINT7_FOVR_MASK                      0x200

#define OTG_FS_HOST_HCHINT7_DTOG_OFFSET                    10
#define OTG_FS_HOST_HCHINT7_DTOG_MASK                      0x400

#define OTG_FS_HOST_HCHIMASK7_TSFCMPNM_OFFSET              0
#define OTG_FS_HOST_HCHIMASK7_TSFCMPNM_MASK                1

#define OTG_FS_HOST_HCHIMASK7_TSFCMPANM_OFFSET             1
#define OTG_FS_HOST_HCHIMASK7_TSFCMPANM_MASK               2

#define OTG_FS_HOST_HCHIMASK7_RXSTALLM_OFFSET              3
#define OTG_FS_HOST_HCHIMASK7_RXSTALLM_MASK                8

#define OTG_FS_HOST_HCHIMASK7_RXNAKM_OFFSET                4
#define OTG_FS_HOST_HCHIMASK7_RXNAKM_MASK                  0x10

#define OTG_FS_HOST_HCHIMASK7_RXTXACKM_OFFSET              5
#define OTG_FS_HOST_HCHIMASK7_RXTXACKM_MASK                0x20

#define OTG_FS_HOST_HCHIMASK7_RXNYETM_OFFSET               6
#define OTG_FS_HOST_HCHIMASK7_RXNYETM_MASK                 0x40

#define OTG_FS_HOST_HCHIMASK7_TERRM_OFFSET                 7
#define OTG_FS_HOST_HCHIMASK7_TERRM_MASK                   0x80

#define OTG_FS_HOST_HCHIMASK7_BABBLEM_OFFSET               8
#define OTG_FS_HOST_HCHIMASK7_BABBLEM_MASK                 0x100

#define OTG_FS_HOST_HCHIMASK7_FOVRM_OFFSET                 9
#define OTG_FS_HOST_HCHIMASK7_FOVRM_MASK                   0x200

#define OTG_FS_HOST_HCHIMASK7_DTOGM_OFFSET                 10
#define OTG_FS_HOST_HCHIMASK7_DTOGM_MASK                   0x400

#define OTG_FS_HOST_HCHTSIZE7_TSFSIZE_OFFSET               0
#define OTG_FS_HOST_HCHTSIZE7_TSFSIZE_MASK                 0x7ffff

#define OTG_FS_HOST_HCHTSIZE7_PCKTCNT_OFFSET               19
#define OTG_FS_HOST_HCHTSIZE7_PCKTCNT_MASK                 0x1ff80000

#define OTG_FS_HOST_HCHTSIZE7_DATAPID_OFFSET               29
#define OTG_FS_HOST_HCHTSIZE7_DATAPID_MASK                 0x60000000


typedef struct
{

/** HCFG HCFG (offset: 0x0)
  OTG_FS host configuration register (OTG_FS_HCFG)
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PHYCLKSEL
  offset: 0, size: 2, access: read-write
  FS/LS PHY clock select
  Field: FSSPT
  offset: 2, size: 1, access: read-only
  FS- and LS-only support
*/
volatile uint32_t HCFG;

/** HFIVL HFIVL (offset: 0x4)
  OTG_FS Host frame interval register
  access : read-write
  reset value : 0xEA60
  reset mask : 0xFFFFFFFF
  Field: FIVL
  offset: 0, size: 16, access: 
  Frame interval
*/
volatile uint32_t HFIVL;

/** HFIFM HFIFM (offset: 0x8)
  OTG_FS host frame number/frame time remaining register (OTG_FS_HFNUM)
  access : read-only
  reset value : 0x3FFF
  reset mask : 0xFFFFFFFF
  Field: FNUM
  offset: 0, size: 16, access: 
  Frame number
  Field: FRTIME
  offset: 16, size: 16, access: 
  Frame time remaining
*/
volatile uint32_t HFIFM;
volatile uint32_t reserved0;

/** HPTXSTS HPTXSTS (offset: 0x10)
  OTG_FS_Host periodic transmit FIFO/queue status register (OTG_FS_HPTXSTS)
  reset value : 0x80100
  reset mask : 0xFFFFFFFF
  Field: FSPACE
  offset: 0, size: 16, access: read-write
  Periodic transmit data FIFO space available
  Field: QSPACE
  offset: 16, size: 8, access: read-only
  Periodic transmit request queue space available
  Field: QTOP
  offset: 24, size: 8, access: read-only
  Top of the periodic transmit request queue
*/
volatile uint32_t HPTXSTS;

/** HACHINT HACHINT (offset: 0x14)
  OTG_FS Host all channels interrupt register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ACHINT
  offset: 0, size: 16, access: 
  Channel interrupts
*/
volatile uint32_t HACHINT;

/** HACHIMASK HACHIMASK (offset: 0x18)
  OTG_FS host all channels interrupt mask register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ACHIMASK
  offset: 0, size: 16, access: 
  Channel interrupt mask
*/
volatile uint32_t HACHIMASK;
volatile uint32_t reserved1[9];

/** HPORTCSTS HPORTCSTS (offset: 0x40)
  OTG_FS host port control and status register (OTG_FS_HPRT)
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PCNNTFLG
  offset: 0, size: 1, access: read-only
  Port connect status
  Field: PCINTFLG
  offset: 1, size: 1, access: read-write
  Port connect detected
  Field: PEN
  offset: 2, size: 1, access: read-write
  Port enable
  Field: PENCHG
  offset: 3, size: 1, access: read-write
  Port enable/disable change
  Field: POVC
  offset: 4, size: 1, access: read-only
  Port overcurrent active
  Field: POVCCHG
  offset: 5, size: 1, access: read-write
  Port overcurrent change
  Field: PRS
  offset: 6, size: 1, access: read-write
  Port resume
  Field: PSUS
  offset: 7, size: 1, access: read-write
  Port suspend
  Field: PRST
  offset: 8, size: 1, access: read-write
  Port reset
  Field: PDLSTS
  offset: 10, size: 2, access: read-only
  Port line status
  Field: PP
  offset: 12, size: 1, access: read-write
  Port power
  Field: PTSEL
  offset: 13, size: 4, access: read-write
  Port test control
  Field: PSPDSEL
  offset: 17, size: 2, access: read-only
  Port speed
*/
volatile uint32_t HPORTCSTS;
volatile uint32_t reserved2[47];

/** HCH0 HCH0 (offset: 0x100)
  OTG_FS host channel-0 characteristics register (OTG_FS_HCCHAR0)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MAXPSIZE
  offset: 0, size: 11, access: 
  Maximum packet size
  Field: EDPNUM
  offset: 11, size: 4, access: 
  Endpoint number
  Field: EDPDRT
  offset: 15, size: 1, access: 
  Endpoint direction
  Field: LSDV
  offset: 17, size: 1, access: 
  Low-speed device
  Field: EDPTYP
  offset: 18, size: 2, access: 
  Endpoint type
  Field: CNTSEL
  offset: 20, size: 2, access: 
  Multicount
  Field: DVADDR
  offset: 22, size: 7, access: 
  Device address
  Field: ODDF
  offset: 29, size: 1, access: 
  Odd frame
  Field: CHINT
  offset: 30, size: 1, access: 
  Channel disable
  Field: CHEN
  offset: 31, size: 1, access: 
  Channel enable
*/
volatile uint32_t HCH0;
volatile uint32_t reserved3;

/** HCHINT0 HCHINT0 (offset: 0x108)
  OTG_FS host channel-0 interrupt register (OTG_FS_HCINT0)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPN
  offset: 0, size: 1, access: 
  Transfer completed
  Field: TSFCMPAN
  offset: 1, size: 1, access: 
  Channel halted
  Field: RXSTALL
  offset: 3, size: 1, access: 
  STALL response received interrupt
  Field: RXNAK
  offset: 4, size: 1, access: 
  NAK response received interrupt
  Field: RXTXACK
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt
  Field: TERR
  offset: 7, size: 1, access: 
  Transaction error
  Field: BABBLE
  offset: 8, size: 1, access: 
  Babble error
  Field: FOVR
  offset: 9, size: 1, access: 
  Frame overrun
  Field: DTOG
  offset: 10, size: 1, access: 
  Data toggle error
*/
volatile uint32_t HCHINT0;

/** HCHIMASK0 HCHIMASK0 (offset: 0x10c)
  OTG_FS host channel-0 mask register (OTG_FS_HCINTMSK0)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPNM
  offset: 0, size: 1, access: 
  Transfer completed mask
  Field: TSFCMPANM
  offset: 1, size: 1, access: 
  Channel halted mask
  Field: RXSTALLM
  offset: 3, size: 1, access: 
  STALL response received interrupt mask
  Field: RXNAKM
  offset: 4, size: 1, access: 
  NAK response received interrupt mask
  Field: RXTXACKM
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt mask
  Field: RXNYETM
  offset: 6, size: 1, access: 
  response received interrupt mask
  Field: TERRM
  offset: 7, size: 1, access: 
  Transaction error mask
  Field: BABBLEM
  offset: 8, size: 1, access: 
  Babble error mask
  Field: FOVRM
  offset: 9, size: 1, access: 
  Frame overrun mask
  Field: DTOGM
  offset: 10, size: 1, access: 
  Data toggle error mask
*/
volatile uint32_t HCHIMASK0;

/** HCHTSIZE0 HCHTSIZE0 (offset: 0x110)
  OTG_FS host channel-0 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFSIZE
  offset: 0, size: 19, access: 
  Transfer size
  Field: PCKTCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: DATAPID
  offset: 29, size: 2, access: 
  Data PID
*/
volatile uint32_t HCHTSIZE0;
volatile uint32_t reserved4[3];

/** HCH1 HCH1 (offset: 0x120)
  OTG_FS host channel-1 characteristics register (OTG_FS_HCCHAR1)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MAXPSIZE
  offset: 0, size: 11, access: 
  Maximum packet size
  Field: EDPNUM
  offset: 11, size: 4, access: 
  Endpoint number
  Field: EDPDRT
  offset: 15, size: 1, access: 
  Endpoint direction
  Field: LSDV
  offset: 17, size: 1, access: 
  Low-speed device
  Field: EDPTYP
  offset: 18, size: 2, access: 
  Endpoint type
  Field: CNTSEL
  offset: 20, size: 2, access: 
  Multicount
  Field: DVADDR
  offset: 22, size: 7, access: 
  Device address
  Field: ODDF
  offset: 29, size: 1, access: 
  Odd frame
  Field: CHINT
  offset: 30, size: 1, access: 
  Channel disable
  Field: CHEN
  offset: 31, size: 1, access: 
  Channel enable
*/
volatile uint32_t HCH1;
volatile uint32_t reserved5;

/** HCHINT1 HCHINT1 (offset: 0x128)
  OTG_FS host channel-1 interrupt register (OTG_FS_HCINT1)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPN
  offset: 0, size: 1, access: 
  Transfer completed
  Field: TSFCMPAN
  offset: 1, size: 1, access: 
  Channel halted
  Field: RXSTALL
  offset: 3, size: 1, access: 
  STALL response received interrupt
  Field: RXNAK
  offset: 4, size: 1, access: 
  NAK response received interrupt
  Field: RXTXACK
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt
  Field: TERR
  offset: 7, size: 1, access: 
  Transaction error
  Field: BABBLE
  offset: 8, size: 1, access: 
  Babble error
  Field: FOVR
  offset: 9, size: 1, access: 
  Frame overrun
  Field: DTOG
  offset: 10, size: 1, access: 
  Data toggle error
*/
volatile uint32_t HCHINT1;

/** HCHIMASK1 HCHIMASK1 (offset: 0x12c)
  OTG_FS host channel-1 mask register (OTG_FS_HCINTMSK1)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPNM
  offset: 0, size: 1, access: 
  Transfer completed mask
  Field: TSFCMPANM
  offset: 1, size: 1, access: 
  Channel halted mask
  Field: RXSTALLM
  offset: 3, size: 1, access: 
  STALL response received interrupt mask
  Field: RXNAKM
  offset: 4, size: 1, access: 
  NAK response received interrupt mask
  Field: RXTXACKM
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt mask
  Field: RXNYETM
  offset: 6, size: 1, access: 
  response received interrupt mask
  Field: TERRM
  offset: 7, size: 1, access: 
  Transaction error mask
  Field: BABBLEM
  offset: 8, size: 1, access: 
  Babble error mask
  Field: FOVRM
  offset: 9, size: 1, access: 
  Frame overrun mask
  Field: DTOGM
  offset: 10, size: 1, access: 
  Data toggle error mask
*/
volatile uint32_t HCHIMASK1;

/** HCHTSIZE1 HCHTSIZE1 (offset: 0x130)
  OTG_FS host channel-1 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFSIZE
  offset: 0, size: 19, access: 
  Transfer size
  Field: PCKTCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: DATAPID
  offset: 29, size: 2, access: 
  Data PID
*/
volatile uint32_t HCHTSIZE1;
volatile uint32_t reserved6[3];

/** HCH2 HCH2 (offset: 0x140)
  OTG_FS host channel-2 characteristics register (OTG_FS_HCCHAR2)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MAXPSIZE
  offset: 0, size: 11, access: 
  Maximum packet size
  Field: EDPNUM
  offset: 11, size: 4, access: 
  Endpoint number
  Field: EDPDRT
  offset: 15, size: 1, access: 
  Endpoint direction
  Field: LSDV
  offset: 17, size: 1, access: 
  Low-speed device
  Field: EDPTYP
  offset: 18, size: 2, access: 
  Endpoint type
  Field: CNTSEL
  offset: 20, size: 2, access: 
  Multicount
  Field: DVADDR
  offset: 22, size: 7, access: 
  Device address
  Field: ODDF
  offset: 29, size: 1, access: 
  Odd frame
  Field: CHINT
  offset: 30, size: 1, access: 
  Channel disable
  Field: CHEN
  offset: 31, size: 1, access: 
  Channel enable
*/
volatile uint32_t HCH2;
volatile uint32_t reserved7;

/** HCHINT2 HCHINT2 (offset: 0x148)
  OTG_FS host channel-2 interrupt register (OTG_FS_HCINT2)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPN
  offset: 0, size: 1, access: 
  Transfer completed
  Field: TSFCMPAN
  offset: 1, size: 1, access: 
  Channel halted
  Field: RXSTALL
  offset: 3, size: 1, access: 
  STALL response received interrupt
  Field: RXNAK
  offset: 4, size: 1, access: 
  NAK response received interrupt
  Field: RXTXACK
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt
  Field: TERR
  offset: 7, size: 1, access: 
  Transaction error
  Field: BABBLE
  offset: 8, size: 1, access: 
  Babble error
  Field: FOVR
  offset: 9, size: 1, access: 
  Frame overrun
  Field: DTOG
  offset: 10, size: 1, access: 
  Data toggle error
*/
volatile uint32_t HCHINT2;

/** HCHIMASK2 HCHIMASK2 (offset: 0x14c)
  OTG_FS host channel-2 mask register (OTG_FS_HCINTMSK2)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPNM
  offset: 0, size: 1, access: 
  Transfer completed mask
  Field: TSFCMPANM
  offset: 1, size: 1, access: 
  Channel halted mask
  Field: RXSTALLM
  offset: 3, size: 1, access: 
  STALL response received interrupt mask
  Field: RXNAKM
  offset: 4, size: 1, access: 
  NAK response received interrupt mask
  Field: RXTXACKM
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt mask
  Field: RXNYETM
  offset: 6, size: 1, access: 
  response received interrupt mask
  Field: TERRM
  offset: 7, size: 1, access: 
  Transaction error mask
  Field: BABBLEM
  offset: 8, size: 1, access: 
  Babble error mask
  Field: FOVRM
  offset: 9, size: 1, access: 
  Frame overrun mask
  Field: DTOGM
  offset: 10, size: 1, access: 
  Data toggle error mask
*/
volatile uint32_t HCHIMASK2;

/** HCHTSIZE2 HCHTSIZE2 (offset: 0x150)
  OTG_FS host channel-2 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFSIZE
  offset: 0, size: 19, access: 
  Transfer size
  Field: PCKTCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: DATAPID
  offset: 29, size: 2, access: 
  Data PID
*/
volatile uint32_t HCHTSIZE2;
volatile uint32_t reserved8[3];

/** HCH3 HCH3 (offset: 0x160)
  OTG_FS host channel-3 characteristics register (OTG_FS_HCCHAR3)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MAXPSIZE
  offset: 0, size: 11, access: 
  Maximum packet size
  Field: EDPNUM
  offset: 11, size: 4, access: 
  Endpoint number
  Field: EDPDRT
  offset: 15, size: 1, access: 
  Endpoint direction
  Field: LSDV
  offset: 17, size: 1, access: 
  Low-speed device
  Field: EDPTYP
  offset: 18, size: 2, access: 
  Endpoint type
  Field: CNTSEL
  offset: 20, size: 2, access: 
  Multicount
  Field: DVADDR
  offset: 22, size: 7, access: 
  Device address
  Field: ODDF
  offset: 29, size: 1, access: 
  Odd frame
  Field: CHINT
  offset: 30, size: 1, access: 
  Channel disable
  Field: CHEN
  offset: 31, size: 1, access: 
  Channel enable
*/
volatile uint32_t HCH3;
volatile uint32_t reserved9;

/** HCHINT3 HCHINT3 (offset: 0x168)
  OTG_FS host channel-3 interrupt register (OTG_FS_HCINT3)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPN
  offset: 0, size: 1, access: 
  Transfer completed
  Field: TSFCMPAN
  offset: 1, size: 1, access: 
  Channel halted
  Field: RXSTALL
  offset: 3, size: 1, access: 
  STALL response received interrupt
  Field: RXNAK
  offset: 4, size: 1, access: 
  NAK response received interrupt
  Field: RXTXACK
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt
  Field: TERR
  offset: 7, size: 1, access: 
  Transaction error
  Field: BABBLE
  offset: 8, size: 1, access: 
  Babble error
  Field: FOVR
  offset: 9, size: 1, access: 
  Frame overrun
  Field: DTOG
  offset: 10, size: 1, access: 
  Data toggle error
*/
volatile uint32_t HCHINT3;

/** HCHIMASK3 HCHIMASK3 (offset: 0x16c)
  OTG_FS host channel-3 mask register (OTG_FS_HCINTMSK3)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPNM
  offset: 0, size: 1, access: 
  Transfer completed mask
  Field: TSFCMPANM
  offset: 1, size: 1, access: 
  Channel halted mask
  Field: RXSTALLM
  offset: 3, size: 1, access: 
  STALL response received interrupt mask
  Field: RXNAKM
  offset: 4, size: 1, access: 
  NAK response received interrupt mask
  Field: RXTXACKM
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt mask
  Field: RXNYETM
  offset: 6, size: 1, access: 
  response received interrupt mask
  Field: TERRM
  offset: 7, size: 1, access: 
  Transaction error mask
  Field: BABBLEM
  offset: 8, size: 1, access: 
  Babble error mask
  Field: FOVRM
  offset: 9, size: 1, access: 
  Frame overrun mask
  Field: DTOGM
  offset: 10, size: 1, access: 
  Data toggle error mask
*/
volatile uint32_t HCHIMASK3;

/** HCHTSIZE3 HCHTSIZE3 (offset: 0x170)
  OTG_FS host channel-3 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFSIZE
  offset: 0, size: 19, access: 
  Transfer size
  Field: PCKTCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: DATAPID
  offset: 29, size: 2, access: 
  Data PID
*/
volatile uint32_t HCHTSIZE3;
volatile uint32_t reserved10[3];

/** HCH4 HCH4 (offset: 0x180)
  OTG_FS host channel-4 characteristics register (OTG_FS_HCCHAR4)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MAXPSIZE
  offset: 0, size: 11, access: 
  Maximum packet size
  Field: EDPNUM
  offset: 11, size: 4, access: 
  Endpoint number
  Field: EDPDRT
  offset: 15, size: 1, access: 
  Endpoint direction
  Field: LSDV
  offset: 17, size: 1, access: 
  Low-speed device
  Field: EDPTYP
  offset: 18, size: 2, access: 
  Endpoint type
  Field: CNTSEL
  offset: 20, size: 2, access: 
  Multicount
  Field: DVADDR
  offset: 22, size: 7, access: 
  Device address
  Field: ODDF
  offset: 29, size: 1, access: 
  Odd frame
  Field: CHINT
  offset: 30, size: 1, access: 
  Channel disable
  Field: CHEN
  offset: 31, size: 1, access: 
  Channel enable
*/
volatile uint32_t HCH4;
volatile uint32_t reserved11;

/** HCHINT4 HCHINT4 (offset: 0x188)
  OTG_FS host channel-4 interrupt register (OTG_FS_HCINT4)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPN
  offset: 0, size: 1, access: 
  Transfer completed
  Field: TSFCMPAN
  offset: 1, size: 1, access: 
  Channel halted
  Field: RXSTALL
  offset: 3, size: 1, access: 
  STALL response received interrupt
  Field: RXNAK
  offset: 4, size: 1, access: 
  NAK response received interrupt
  Field: RXTXACK
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt
  Field: TERR
  offset: 7, size: 1, access: 
  Transaction error
  Field: BABBLE
  offset: 8, size: 1, access: 
  Babble error
  Field: FOVR
  offset: 9, size: 1, access: 
  Frame overrun
  Field: DTOG
  offset: 10, size: 1, access: 
  Data toggle error
*/
volatile uint32_t HCHINT4;

/** HCHIMASK4 HCHIMASK4 (offset: 0x18c)
  OTG_FS host channel-4 mask register (OTG_FS_HCINTMSK4)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPNM
  offset: 0, size: 1, access: 
  Transfer completed mask
  Field: TSFCMPANM
  offset: 1, size: 1, access: 
  Channel halted mask
  Field: RXSTALLM
  offset: 3, size: 1, access: 
  STALL response received interrupt mask
  Field: RXNAKM
  offset: 4, size: 1, access: 
  NAK response received interrupt mask
  Field: RXTXACKM
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt mask
  Field: RXNYETM
  offset: 6, size: 1, access: 
  response received interrupt mask
  Field: TERRM
  offset: 7, size: 1, access: 
  Transaction error mask
  Field: BABBLEM
  offset: 8, size: 1, access: 
  Babble error mask
  Field: FOVRM
  offset: 9, size: 1, access: 
  Frame overrun mask
  Field: DTOGM
  offset: 10, size: 1, access: 
  Data toggle error mask
*/
volatile uint32_t HCHIMASK4;

/** HCHTSIZE4 HCHTSIZE4 (offset: 0x190)
  OTG_FS host channel-x transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFSIZE
  offset: 0, size: 19, access: 
  Transfer size
  Field: PCKTCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: DATAPID
  offset: 29, size: 2, access: 
  Data PID
*/
volatile uint32_t HCHTSIZE4;
volatile uint32_t reserved12[3];

/** HCH5 HCH5 (offset: 0x1a0)
  OTG_FS host channel-5 characteristics register (OTG_FS_HCCHAR5)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MAXPSIZE
  offset: 0, size: 11, access: 
  Maximum packet size
  Field: EDPNUM
  offset: 11, size: 4, access: 
  Endpoint number
  Field: EDPDRT
  offset: 15, size: 1, access: 
  Endpoint direction
  Field: LSDV
  offset: 17, size: 1, access: 
  Low-speed device
  Field: EDPTYP
  offset: 18, size: 2, access: 
  Endpoint type
  Field: CNTSEL
  offset: 20, size: 2, access: 
  Multicount
  Field: DVADDR
  offset: 22, size: 7, access: 
  Device address
  Field: ODDF
  offset: 29, size: 1, access: 
  Odd frame
  Field: CHINT
  offset: 30, size: 1, access: 
  Channel disable
  Field: CHEN
  offset: 31, size: 1, access: 
  Channel enable
*/
volatile uint32_t HCH5;
volatile uint32_t reserved13;

/** HCHINT5 HCHINT5 (offset: 0x1a8)
  OTG_FS host channel-5 interrupt register (OTG_FS_HCINT5)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPN
  offset: 0, size: 1, access: 
  Transfer completed
  Field: TSFCMPAN
  offset: 1, size: 1, access: 
  Channel halted
  Field: RXSTALL
  offset: 3, size: 1, access: 
  STALL response received interrupt
  Field: RXNAK
  offset: 4, size: 1, access: 
  NAK response received interrupt
  Field: RXTXACK
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt
  Field: TERR
  offset: 7, size: 1, access: 
  Transaction error
  Field: BABBLE
  offset: 8, size: 1, access: 
  Babble error
  Field: FOVR
  offset: 9, size: 1, access: 
  Frame overrun
  Field: DTOG
  offset: 10, size: 1, access: 
  Data toggle error
*/
volatile uint32_t HCHINT5;

/** HCHIMASK5 HCHIMASK5 (offset: 0x1ac)
  OTG_FS host channel-5 mask register (OTG_FS_HCINTMSK5)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPNM
  offset: 0, size: 1, access: 
  Transfer completed mask
  Field: TSFCMPANM
  offset: 1, size: 1, access: 
  Channel halted mask
  Field: RXSTALLM
  offset: 3, size: 1, access: 
  STALL response received interrupt mask
  Field: RXNAKM
  offset: 4, size: 1, access: 
  NAK response received interrupt mask
  Field: RXTXACKM
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt mask
  Field: RXNYETM
  offset: 6, size: 1, access: 
  response received interrupt mask
  Field: TERRM
  offset: 7, size: 1, access: 
  Transaction error mask
  Field: BABBLEM
  offset: 8, size: 1, access: 
  Babble error mask
  Field: FOVRM
  offset: 9, size: 1, access: 
  Frame overrun mask
  Field: DTOGM
  offset: 10, size: 1, access: 
  Data toggle error mask
*/
volatile uint32_t HCHIMASK5;

/** HCHTSIZE5 HCHTSIZE5 (offset: 0x1b0)
  OTG_FS host channel-5 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFSIZE
  offset: 0, size: 19, access: 
  Transfer size
  Field: PCKTCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: DATAPID
  offset: 29, size: 2, access: 
  Data PID
*/
volatile uint32_t HCHTSIZE5;
volatile uint32_t reserved14[3];

/** HCH6 HCH6 (offset: 0x1c0)
  OTG_FS host channel-6 characteristics register (OTG_FS_HCCHAR6)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MAXPSIZE
  offset: 0, size: 11, access: 
  Maximum packet size
  Field: EDPNUM
  offset: 11, size: 4, access: 
  Endpoint number
  Field: EDPDRT
  offset: 15, size: 1, access: 
  Endpoint direction
  Field: LSDV
  offset: 17, size: 1, access: 
  Low-speed device
  Field: EDPTYP
  offset: 18, size: 2, access: 
  Endpoint type
  Field: CNTSEL
  offset: 20, size: 2, access: 
  Multicount
  Field: DVADDR
  offset: 22, size: 7, access: 
  Device address
  Field: ODDF
  offset: 29, size: 1, access: 
  Odd frame
  Field: CHINT
  offset: 30, size: 1, access: 
  Channel disable
  Field: CHEN
  offset: 31, size: 1, access: 
  Channel enable
*/
volatile uint32_t HCH6;
volatile uint32_t reserved15;

/** HCHINT6 HCHINT6 (offset: 0x1c8)
  OTG_FS host channel-6 interrupt register (OTG_FS_HCINT6)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPN
  offset: 0, size: 1, access: 
  Transfer completed
  Field: TSFCMPAN
  offset: 1, size: 1, access: 
  Channel halted
  Field: RXSTALL
  offset: 3, size: 1, access: 
  STALL response received interrupt
  Field: RXNAK
  offset: 4, size: 1, access: 
  NAK response received interrupt
  Field: RXTXACK
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt
  Field: TERR
  offset: 7, size: 1, access: 
  Transaction error
  Field: BABBLE
  offset: 8, size: 1, access: 
  Babble error
  Field: FOVR
  offset: 9, size: 1, access: 
  Frame overrun
  Field: DTOG
  offset: 10, size: 1, access: 
  Data toggle error
*/
volatile uint32_t HCHINT6;

/** HCHIMASK6 HCHIMASK6 (offset: 0x1cc)
  OTG_FS host channel-6 mask register (OTG_FS_HCINTMSK6)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPNM
  offset: 0, size: 1, access: 
  Transfer completed mask
  Field: TSFCMPANM
  offset: 1, size: 1, access: 
  Channel halted mask
  Field: RXSTALLM
  offset: 3, size: 1, access: 
  STALL response received interrupt mask
  Field: RXNAKM
  offset: 4, size: 1, access: 
  NAK response received interrupt mask
  Field: RXTXACKM
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt mask
  Field: RXNYETM
  offset: 6, size: 1, access: 
  response received interrupt mask
  Field: TERRM
  offset: 7, size: 1, access: 
  Transaction error mask
  Field: BABBLEM
  offset: 8, size: 1, access: 
  Babble error mask
  Field: FOVRM
  offset: 9, size: 1, access: 
  Frame overrun mask
  Field: DTOGM
  offset: 10, size: 1, access: 
  Data toggle error mask
*/
volatile uint32_t HCHIMASK6;

/** HCHTSIZE6 HCHTSIZE6 (offset: 0x1d0)
  OTG_FS host channel-6 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFSIZE
  offset: 0, size: 19, access: 
  Transfer size
  Field: PCKTCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: DATAPID
  offset: 29, size: 2, access: 
  Data PID
*/
volatile uint32_t HCHTSIZE6;
volatile uint32_t reserved16[3];

/** HCH7 HCH7 (offset: 0x1e0)
  OTG_FS host channel-7 characteristics register (OTG_FS_HCCHAR7)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MAXPSIZE
  offset: 0, size: 11, access: 
  Maximum packet size
  Field: EDPNUM
  offset: 11, size: 4, access: 
  Endpoint number
  Field: EDPDRT
  offset: 15, size: 1, access: 
  Endpoint direction
  Field: LSDV
  offset: 17, size: 1, access: 
  Low-speed device
  Field: EDPTYP
  offset: 18, size: 2, access: 
  Endpoint type
  Field: CNTSEL
  offset: 20, size: 2, access: 
  Multicount
  Field: DVADDR
  offset: 22, size: 7, access: 
  Device address
  Field: ODDF
  offset: 29, size: 1, access: 
  Odd frame
  Field: CHINT
  offset: 30, size: 1, access: 
  Channel disable
  Field: CHEN
  offset: 31, size: 1, access: 
  Channel enable
*/
volatile uint32_t HCH7;
volatile uint32_t reserved17;

/** HCHINT7 HCHINT7 (offset: 0x1e8)
  OTG_FS host channel-7 interrupt register (OTG_FS_HCINT7)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPN
  offset: 0, size: 1, access: 
  Transfer completed
  Field: TSFCMPAN
  offset: 1, size: 1, access: 
  Channel halted
  Field: RXSTALL
  offset: 3, size: 1, access: 
  STALL response received interrupt
  Field: RXNAK
  offset: 4, size: 1, access: 
  NAK response received interrupt
  Field: RXTXACK
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt
  Field: TERR
  offset: 7, size: 1, access: 
  Transaction error
  Field: BABBLE
  offset: 8, size: 1, access: 
  Babble error
  Field: FOVR
  offset: 9, size: 1, access: 
  Frame overrun
  Field: DTOG
  offset: 10, size: 1, access: 
  Data toggle error
*/
volatile uint32_t HCHINT7;

/** HCHIMASK7 HCHIMASK7 (offset: 0x1ec)
  OTG_FS host channel-7 mask register (OTG_FS_HCINTMSK7)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPNM
  offset: 0, size: 1, access: 
  Transfer completed mask
  Field: TSFCMPANM
  offset: 1, size: 1, access: 
  Channel halted mask
  Field: RXSTALLM
  offset: 3, size: 1, access: 
  STALL response received interrupt mask
  Field: RXNAKM
  offset: 4, size: 1, access: 
  NAK response received interrupt mask
  Field: RXTXACKM
  offset: 5, size: 1, access: 
  ACK response received/transmitted interrupt mask
  Field: RXNYETM
  offset: 6, size: 1, access: 
  response received interrupt mask
  Field: TERRM
  offset: 7, size: 1, access: 
  Transaction error mask
  Field: BABBLEM
  offset: 8, size: 1, access: 
  Babble error mask
  Field: FOVRM
  offset: 9, size: 1, access: 
  Frame overrun mask
  Field: DTOGM
  offset: 10, size: 1, access: 
  Data toggle error mask
*/
volatile uint32_t HCHIMASK7;

/** HCHTSIZE7 HCHTSIZE7 (offset: 0x1f0)
  OTG_FS host channel-7 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFSIZE
  offset: 0, size: 19, access: 
  Transfer size
  Field: PCKTCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: DATAPID
  offset: 29, size: 2, access: 
  Data PID
*/
volatile uint32_t HCHTSIZE7;
} OTG_FS_HOST_type;

#define OTG_FS_HOST ((OTG_FS_HOST_type *) 0x50000400)

#endif // HW_OTG_FS_HOST_H
