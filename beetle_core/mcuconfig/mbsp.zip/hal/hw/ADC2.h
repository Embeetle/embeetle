#ifndef HW_ADC2_H
#define HW_ADC2_H
/** Analog-to-digital converter */
/** Memory Block starting at 0x40012400 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define ADC2_STS_OVRFLG_OFFSET                             5
#define ADC2_STS_OVRFLG_MASK                               0x20

#define ADC2_STS_REGCSFLG_OFFSET                           4
#define ADC2_STS_REGCSFLG_MASK                             0x10

#define ADC2_STS_INJCSFLG_OFFSET                           3
#define ADC2_STS_INJCSFLG_MASK                             8

#define ADC2_STS_INJEOCFLG_OFFSET                          2
#define ADC2_STS_INJEOCFLG_MASK                            4

#define ADC2_STS_EOCFLG_OFFSET                             1
#define ADC2_STS_EOCFLG_MASK                               2

#define ADC2_STS_AWDFLG_OFFSET                             0
#define ADC2_STS_AWDFLG_MASK                               1

#define ADC2_CTRL1_OVRIEN_OFFSET                           26
#define ADC2_CTRL1_OVRIEN_MASK                             0x4000000

#define ADC2_CTRL1_RESSEL_OFFSET                           24
#define ADC2_CTRL1_RESSEL_MASK                             0x3000000

#define ADC2_CTRL1_REGAWDEN_OFFSET                         23
#define ADC2_CTRL1_REGAWDEN_MASK                           0x800000

#define ADC2_CTRL1_INJAWDEN_OFFSET                         22
#define ADC2_CTRL1_INJAWDEN_MASK                           0x400000

#define ADC2_CTRL1_DISCNUMCFG_OFFSET                       13
#define ADC2_CTRL1_DISCNUMCFG_MASK                         0xe000

#define ADC2_CTRL1_INJDISCEN_OFFSET                        12
#define ADC2_CTRL1_INJDISCEN_MASK                          0x1000

#define ADC2_CTRL1_REGDISCEN_OFFSET                        11
#define ADC2_CTRL1_REGDISCEN_MASK                          0x800

#define ADC2_CTRL1_INJGACEN_OFFSET                         10
#define ADC2_CTRL1_INJGACEN_MASK                           0x400

#define ADC2_CTRL1_AWDSGLEN_OFFSET                         9
#define ADC2_CTRL1_AWDSGLEN_MASK                           0x200

#define ADC2_CTRL1_SCANEN_OFFSET                           8
#define ADC2_CTRL1_SCANEN_MASK                             0x100

#define ADC2_CTRL1_INJEOCIEN_OFFSET                        7
#define ADC2_CTRL1_INJEOCIEN_MASK                          0x80

#define ADC2_CTRL1_AWDIEN_OFFSET                           6
#define ADC2_CTRL1_AWDIEN_MASK                             0x40

#define ADC2_CTRL1_EOCIEN_OFFSET                           5
#define ADC2_CTRL1_EOCIEN_MASK                             0x20

#define ADC2_CTRL1_AWDCHSEL_OFFSET                         0
#define ADC2_CTRL1_AWDCHSEL_MASK                           0x1f

#define ADC2_CTRL2_REGCHSC_OFFSET                          30
#define ADC2_CTRL2_REGCHSC_MASK                            0x40000000

#define ADC2_CTRL2_REGEXTTRGEN_OFFSET                      28
#define ADC2_CTRL2_REGEXTTRGEN_MASK                        0x30000000

#define ADC2_CTRL2_REGEXTTRGSEL_OFFSET                     24
#define ADC2_CTRL2_REGEXTTRGSEL_MASK                       0xf000000

#define ADC2_CTRL2_INJSWSC_OFFSET                          22
#define ADC2_CTRL2_INJSWSC_MASK                            0x400000

#define ADC2_CTRL2_INJEXTTRGEN_OFFSET                      20
#define ADC2_CTRL2_INJEXTTRGEN_MASK                        0x300000

#define ADC2_CTRL2_INJGEXTTRGSEL_OFFSET                    16
#define ADC2_CTRL2_INJGEXTTRGSEL_MASK                      0xf0000

#define ADC2_CTRL2_DALIGNCFG_OFFSET                        11
#define ADC2_CTRL2_DALIGNCFG_MASK                          0x800

#define ADC2_CTRL2_EOCSEL_OFFSET                           10
#define ADC2_CTRL2_EOCSEL_MASK                             0x400

#define ADC2_CTRL2_DMADISSEL_OFFSET                        9
#define ADC2_CTRL2_DMADISSEL_MASK                          0x200

#define ADC2_CTRL2_DMAEN_OFFSET                            8
#define ADC2_CTRL2_DMAEN_MASK                              0x100

#define ADC2_CTRL2_CONTCEN_OFFSET                          1
#define ADC2_CTRL2_CONTCEN_MASK                            2

#define ADC2_CTRL2_ADCEN_OFFSET                            0
#define ADC2_CTRL2_ADCEN_MASK                              1

#define ADC2_SMPTIM1_SMPCYCCFG1_OFFSET                     0
#define ADC2_SMPTIM1_SMPCYCCFG1_MASK                       0x7ffffff

#define ADC2_SMPTIM2_SMPCYCCFG2_OFFSET                     0
#define ADC2_SMPTIM2_SMPCYCCFG2_MASK                       0x3fffffff

#define ADC2_INJDOF1_INJDOF1_OFFSET                        0
#define ADC2_INJDOF1_INJDOF1_MASK                          0xfff

#define ADC2_INJDOF2_INJDOF2_OFFSET                        0
#define ADC2_INJDOF2_INJDOF2_MASK                          0xfff

#define ADC2_INJDOF3_INJDOF3_OFFSET                        0
#define ADC2_INJDOF3_INJDOF3_MASK                          0xfff

#define ADC2_INJDOF4_INJDOF4_OFFSET                        0
#define ADC2_INJDOF4_INJDOF4_MASK                          0xfff

#define ADC2_AWDHT_AWDHT_OFFSET                            0
#define ADC2_AWDHT_AWDHT_MASK                              0xfff

#define ADC2_AWDLT_AWDLT_OFFSET                            0
#define ADC2_AWDLT_AWDLT_MASK                              0xfff

#define ADC2_REGSEQ1_REGSEQLEN_OFFSET                      20
#define ADC2_REGSEQ1_REGSEQLEN_MASK                        0xf00000

#define ADC2_REGSEQ1_REGSEQC16_OFFSET                      15
#define ADC2_REGSEQ1_REGSEQC16_MASK                        0xf8000

#define ADC2_REGSEQ1_REGSEQC15_OFFSET                      10
#define ADC2_REGSEQ1_REGSEQC15_MASK                        0x7c00

#define ADC2_REGSEQ1_REGSEQC14_OFFSET                      5
#define ADC2_REGSEQ1_REGSEQC14_MASK                        0x3e0

#define ADC2_REGSEQ1_REGSEQC13_OFFSET                      0
#define ADC2_REGSEQ1_REGSEQC13_MASK                        0x1f

#define ADC2_REGSEQ2_REGSEQC12_OFFSET                      25
#define ADC2_REGSEQ2_REGSEQC12_MASK                        0x3e000000

#define ADC2_REGSEQ2_REGSEQC11_OFFSET                      20
#define ADC2_REGSEQ2_REGSEQC11_MASK                        0x1f00000

#define ADC2_REGSEQ2_REGSEQC10_OFFSET                      15
#define ADC2_REGSEQ2_REGSEQC10_MASK                        0xf8000

#define ADC2_REGSEQ2_REGSEQC9_OFFSET                       10
#define ADC2_REGSEQ2_REGSEQC9_MASK                         0x7c00

#define ADC2_REGSEQ2_REGSEQC8_OFFSET                       5
#define ADC2_REGSEQ2_REGSEQC8_MASK                         0x3e0

#define ADC2_REGSEQ2_REGSEQC7_OFFSET                       0
#define ADC2_REGSEQ2_REGSEQC7_MASK                         0x1f

#define ADC2_REGSEQ3_REGSEQC6_OFFSET                       25
#define ADC2_REGSEQ3_REGSEQC6_MASK                         0x3e000000

#define ADC2_REGSEQ3_REGSEQC5_OFFSET                       20
#define ADC2_REGSEQ3_REGSEQC5_MASK                         0x1f00000

#define ADC2_REGSEQ3_REGSEQC4_OFFSET                       15
#define ADC2_REGSEQ3_REGSEQC4_MASK                         0xf8000

#define ADC2_REGSEQ3_REGSEQC3_OFFSET                       10
#define ADC2_REGSEQ3_REGSEQC3_MASK                         0x7c00

#define ADC2_REGSEQ3_REGSEQC2_OFFSET                       5
#define ADC2_REGSEQ3_REGSEQC2_MASK                         0x3e0

#define ADC2_REGSEQ3_REGSEQC1_OFFSET                       0
#define ADC2_REGSEQ3_REGSEQC1_MASK                         0x1f

#define ADC2_INJSEQ_INJSEQLEN_OFFSET                       20
#define ADC2_INJSEQ_INJSEQLEN_MASK                         0x300000

#define ADC2_INJSEQ_INJSEQC4_OFFSET                        15
#define ADC2_INJSEQ_INJSEQC4_MASK                          0xf8000

#define ADC2_INJSEQ_INJSEQC3_OFFSET                        10
#define ADC2_INJSEQ_INJSEQC3_MASK                          0x7c00

#define ADC2_INJSEQ_INJSEQC2_OFFSET                        5
#define ADC2_INJSEQ_INJSEQC2_MASK                          0x3e0

#define ADC2_INJSEQ_INJSEQC1_OFFSET                        0
#define ADC2_INJSEQ_INJSEQC1_MASK                          0x1f

#define ADC2_INJDATA1_INJDATA_OFFSET                       0
#define ADC2_INJDATA1_INJDATA_MASK                         0xffff

#define ADC2_INJDATA2_INJDATA_OFFSET                       0
#define ADC2_INJDATA2_INJDATA_MASK                         0xffff

#define ADC2_INJDATA3_INJDATA_OFFSET                       0
#define ADC2_INJDATA3_INJDATA_MASK                         0xffff

#define ADC2_INJDATA4_INJDATA_OFFSET                       0
#define ADC2_INJDATA4_INJDATA_MASK                         0xffff

#define ADC2_REGDATA_REGDATA_OFFSET                        0
#define ADC2_REGDATA_REGDATA_MASK                          0xffff


typedef struct
{

/** STS STS (offset: 0x0)
  status register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OVRFLG
  offset: 5, size: 1, access: 
  Overrun
  Field: REGCSFLG
  offset: 4, size: 1, access: 
  Regular channel start flag
  Field: INJCSFLG
  offset: 3, size: 1, access: 
  Injected channel start flag
  Field: INJEOCFLG
  offset: 2, size: 1, access: 
  Injected channel end of conversion
  Field: EOCFLG
  offset: 1, size: 1, access: 
  Regular channel end of conversion
  Field: AWDFLG
  offset: 0, size: 1, access: 
  Analog watchdog flag
*/
volatile uint32_t STS;

/** CTRL1 CTRL1 (offset: 0x4)
  control register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OVRIEN
  offset: 26, size: 1, access: 
  Overrun interrupt enable
  Field: RESSEL
  offset: 24, size: 2, access: 
  Resolution
  Field: REGAWDEN
  offset: 23, size: 1, access: 
  Analog watchdog enable on regular channels
  Field: INJAWDEN
  offset: 22, size: 1, access: 
  Analog watchdog enable on injected channels
  Field: DISCNUMCFG
  offset: 13, size: 3, access: 
  Discontinuous mode channel count
  Field: INJDISCEN
  offset: 12, size: 1, access: 
  Discontinuous mode on injected channels
  Field: REGDISCEN
  offset: 11, size: 1, access: 
  Discontinuous mode on regular channels
  Field: INJGACEN
  offset: 10, size: 1, access: 
  Automatic injected group conversion
  Field: AWDSGLEN
  offset: 9, size: 1, access: 
  Enable the watchdog on a single channel in scan mode
  Field: SCANEN
  offset: 8, size: 1, access: 
  Scan mode
  Field: INJEOCIEN
  offset: 7, size: 1, access: 
  Interrupt enable for injected channels
  Field: AWDIEN
  offset: 6, size: 1, access: 
  Analog watchdog interrupt enable
  Field: EOCIEN
  offset: 5, size: 1, access: 
  Interrupt enable for EOC
  Field: AWDCHSEL
  offset: 0, size: 5, access: 
  Analog watchdog channel select bits
*/
volatile uint32_t CTRL1;

/** CTRL2 CTRL2 (offset: 0x8)
  control register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: REGCHSC
  offset: 30, size: 1, access: 
  Start conversion of regular channels
  Field: REGEXTTRGEN
  offset: 28, size: 2, access: 
  External trigger enable for regular channels
  Field: REGEXTTRGSEL
  offset: 24, size: 4, access: 
  External event select for regular group
  Field: INJSWSC
  offset: 22, size: 1, access: 
  Start conversion of injected channels
  Field: INJEXTTRGEN
  offset: 20, size: 2, access: 
  External trigger enable for injected channels
  Field: INJGEXTTRGSEL
  offset: 16, size: 4, access: 
  External event select for injected group
  Field: DALIGNCFG
  offset: 11, size: 1, access: 
  Data alignment
  Field: EOCSEL
  offset: 10, size: 1, access: 
  End of conversion selection
  Field: DMADISSEL
  offset: 9, size: 1, access: 
  DMA disable selection (for single ADC mode)
  Field: DMAEN
  offset: 8, size: 1, access: 
  Direct memory access mode (for single ADC mode)
  Field: CONTCEN
  offset: 1, size: 1, access: 
  Continuous conversion
  Field: ADCEN
  offset: 0, size: 1, access: 
  A/D Converter ON / OFF
*/
volatile uint32_t CTRL2;

/** SMPTIM1 SMPTIM1 (offset: 0xc)
  sample time register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SMPCYCCFG1
  offset: 0, size: 27, access: 
  Sample time bits
*/
volatile uint32_t SMPTIM1;

/** SMPTIM2 SMPTIM2 (offset: 0x10)
  sample time register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SMPCYCCFG2
  offset: 0, size: 30, access: 
  Sample time bits
*/
volatile uint32_t SMPTIM2;

/** INJDOF1 INJDOF1 (offset: 0x14)
  injected channel data offset register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INJDOF1
  offset: 0, size: 12, access: 
  Data offset for injected channel 1
*/
volatile uint32_t INJDOF1;

/** INJDOF2 INJDOF2 (offset: 0x18)
  injected channel data offset register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INJDOF2
  offset: 0, size: 12, access: 
  Data offset for injected channel 2
*/
volatile uint32_t INJDOF2;

/** INJDOF3 INJDOF3 (offset: 0x1c)
  injected channel data offset register 3
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INJDOF3
  offset: 0, size: 12, access: 
  Data offset for injected channel 3
*/
volatile uint32_t INJDOF3;

/** INJDOF4 INJDOF4 (offset: 0x20)
  injected channel data offset register 4
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INJDOF4
  offset: 0, size: 12, access: 
  Data offset for injected channel 4
*/
volatile uint32_t INJDOF4;

/** AWDHT AWDHT (offset: 0x24)
  watchdog higher threshold register
  access : read-write
  reset value : 0xFFF
  reset mask : 0xFFFFFFFF
  Field: AWDHT
  offset: 0, size: 12, access: 
  Analog watchdog higher threshold
*/
volatile uint32_t AWDHT;

/** AWDLT AWDLT (offset: 0x28)
  watchdog lower threshold register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: AWDLT
  offset: 0, size: 12, access: 
  Analog watchdog lower threshold
*/
volatile uint32_t AWDLT;

/** REGSEQ1 REGSEQ1 (offset: 0x2c)
  regular sequence register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: REGSEQLEN
  offset: 20, size: 4, access: 
  Regular channel sequence length
  Field: REGSEQC16
  offset: 15, size: 5, access: 
  16th conversion in regular sequence
  Field: REGSEQC15
  offset: 10, size: 5, access: 
  15th conversion in regular sequence
  Field: REGSEQC14
  offset: 5, size: 5, access: 
  14th conversion in regular sequence
  Field: REGSEQC13
  offset: 0, size: 5, access: 
  13th conversion in regular sequence
*/
volatile uint32_t REGSEQ1;

/** REGSEQ2 REGSEQ2 (offset: 0x30)
  regular sequence register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: REGSEQC12
  offset: 25, size: 5, access: 
  12th conversion in regular sequence
  Field: REGSEQC11
  offset: 20, size: 5, access: 
  11th conversion in regular sequence
  Field: REGSEQC10
  offset: 15, size: 5, access: 
  10th conversion in regular sequence
  Field: REGSEQC9
  offset: 10, size: 5, access: 
  9th conversion in regular sequence
  Field: REGSEQC8
  offset: 5, size: 5, access: 
  8th conversion in regular sequence
  Field: REGSEQC7
  offset: 0, size: 5, access: 
  7th conversion in regular sequence
*/
volatile uint32_t REGSEQ2;

/** REGSEQ3 REGSEQ3 (offset: 0x34)
  regular sequence register 3
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: REGSEQC6
  offset: 25, size: 5, access: 
  6th conversion in regular sequence
  Field: REGSEQC5
  offset: 20, size: 5, access: 
  5th conversion in regular sequence
  Field: REGSEQC4
  offset: 15, size: 5, access: 
  4th conversion in regular sequence
  Field: REGSEQC3
  offset: 10, size: 5, access: 
  3rd conversion in regular sequence
  Field: REGSEQC2
  offset: 5, size: 5, access: 
  2nd conversion in regular sequence
  Field: REGSEQC1
  offset: 0, size: 5, access: 
  1st conversion in regular sequence
*/
volatile uint32_t REGSEQ3;

/** INJSEQ INJSEQ (offset: 0x38)
  injected sequence register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INJSEQLEN
  offset: 20, size: 2, access: 
  Injected sequence length
  Field: INJSEQC4
  offset: 15, size: 5, access: 
  4th conversion in injected sequence
  Field: INJSEQC3
  offset: 10, size: 5, access: 
  3rd conversion in injected sequence
  Field: INJSEQC2
  offset: 5, size: 5, access: 
  2nd conversion in injected sequence
  Field: INJSEQC1
  offset: 0, size: 5, access: 
  1st conversion in injected sequence
*/
volatile uint32_t INJSEQ;

/** INJDATA1 INJDATA1 (offset: 0x3c)
  injected data register x
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INJDATA
  offset: 0, size: 16, access: 
  Injected data
*/
volatile uint32_t INJDATA1;

/** INJDATA2 INJDATA2 (offset: 0x40)
  injected data register x
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INJDATA
  offset: 0, size: 16, access: 
  Injected data
*/
volatile uint32_t INJDATA2;

/** INJDATA3 INJDATA3 (offset: 0x44)
  injected data register x
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INJDATA
  offset: 0, size: 16, access: 
  Injected data
*/
volatile uint32_t INJDATA3;

/** INJDATA4 INJDATA4 (offset: 0x48)
  injected data register x
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INJDATA
  offset: 0, size: 16, access: 
  Injected data
*/
volatile uint32_t INJDATA4;

/** REGDATA REGDATA (offset: 0x4c)
  regular data register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: REGDATA
  offset: 0, size: 16, access: 
  Regular data
*/
volatile uint32_t REGDATA;
} ADC2_type;

#define ADC2 ((ADC2_type *) 0x40012400)

#endif // HW_ADC2_H
