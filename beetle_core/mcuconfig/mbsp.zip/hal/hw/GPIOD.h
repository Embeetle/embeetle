#ifndef HW_GPIOD_H
#define HW_GPIOD_H
/** General-purpose I/Os */
/** Memory Block starting at 0x40020C00 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define GPIOD_MODE_MODE15_OFFSET                           30
#define GPIOD_MODE_MODE15_MASK                             0xc0000000

#define GPIOD_MODE_MODE14_OFFSET                           28
#define GPIOD_MODE_MODE14_MASK                             0x30000000

#define GPIOD_MODE_MODE13_OFFSET                           26
#define GPIOD_MODE_MODE13_MASK                             0xc000000

#define GPIOD_MODE_MODE12_OFFSET                           24
#define GPIOD_MODE_MODE12_MASK                             0x3000000

#define GPIOD_MODE_MODE11_OFFSET                           22
#define GPIOD_MODE_MODE11_MASK                             0xc00000

#define GPIOD_MODE_MODE10_OFFSET                           20
#define GPIOD_MODE_MODE10_MASK                             0x300000

#define GPIOD_MODE_MODE9_OFFSET                            18
#define GPIOD_MODE_MODE9_MASK                              0xc0000

#define GPIOD_MODE_MODE8_OFFSET                            16
#define GPIOD_MODE_MODE8_MASK                              0x30000

#define GPIOD_MODE_MODE7_OFFSET                            14
#define GPIOD_MODE_MODE7_MASK                              0xc000

#define GPIOD_MODE_MODE6_OFFSET                            12
#define GPIOD_MODE_MODE6_MASK                              0x3000

#define GPIOD_MODE_MODE5_OFFSET                            10
#define GPIOD_MODE_MODE5_MASK                              0xc00

#define GPIOD_MODE_MODE4_OFFSET                            8
#define GPIOD_MODE_MODE4_MASK                              0x300

#define GPIOD_MODE_MODE3_OFFSET                            6
#define GPIOD_MODE_MODE3_MASK                              0xc0

#define GPIOD_MODE_MODE2_OFFSET                            4
#define GPIOD_MODE_MODE2_MASK                              0x30

#define GPIOD_MODE_MODE1_OFFSET                            2
#define GPIOD_MODE_MODE1_MASK                              0xc

#define GPIOD_MODE_MODE0_OFFSET                            0
#define GPIOD_MODE_MODE0_MASK                              3

#define GPIOD_OMODE_OMODE15_OFFSET                         15
#define GPIOD_OMODE_OMODE15_MASK                           0x8000

#define GPIOD_OMODE_OMODE14_OFFSET                         14
#define GPIOD_OMODE_OMODE14_MASK                           0x4000

#define GPIOD_OMODE_OMODE13_OFFSET                         13
#define GPIOD_OMODE_OMODE13_MASK                           0x2000

#define GPIOD_OMODE_OMODE12_OFFSET                         12
#define GPIOD_OMODE_OMODE12_MASK                           0x1000

#define GPIOD_OMODE_OMODE11_OFFSET                         11
#define GPIOD_OMODE_OMODE11_MASK                           0x800

#define GPIOD_OMODE_OMODE10_OFFSET                         10
#define GPIOD_OMODE_OMODE10_MASK                           0x400

#define GPIOD_OMODE_OMODE9_OFFSET                          9
#define GPIOD_OMODE_OMODE9_MASK                            0x200

#define GPIOD_OMODE_OMODE8_OFFSET                          8
#define GPIOD_OMODE_OMODE8_MASK                            0x100

#define GPIOD_OMODE_OMODE7_OFFSET                          7
#define GPIOD_OMODE_OMODE7_MASK                            0x80

#define GPIOD_OMODE_OMODE6_OFFSET                          6
#define GPIOD_OMODE_OMODE6_MASK                            0x40

#define GPIOD_OMODE_OMODE5_OFFSET                          5
#define GPIOD_OMODE_OMODE5_MASK                            0x20

#define GPIOD_OMODE_OMODE4_OFFSET                          4
#define GPIOD_OMODE_OMODE4_MASK                            0x10

#define GPIOD_OMODE_OMODE3_OFFSET                          3
#define GPIOD_OMODE_OMODE3_MASK                            8

#define GPIOD_OMODE_OMODE2_OFFSET                          2
#define GPIOD_OMODE_OMODE2_MASK                            4

#define GPIOD_OMODE_OMODE1_OFFSET                          1
#define GPIOD_OMODE_OMODE1_MASK                            2

#define GPIOD_OMODE_OMODE0_OFFSET                          0
#define GPIOD_OMODE_OMODE0_MASK                            1

#define GPIOD_OSSEL_OSSEL15_OFFSET                         30
#define GPIOD_OSSEL_OSSEL15_MASK                           0xc0000000

#define GPIOD_OSSEL_OSSEL14_OFFSET                         28
#define GPIOD_OSSEL_OSSEL14_MASK                           0x30000000

#define GPIOD_OSSEL_OSSEL13_OFFSET                         26
#define GPIOD_OSSEL_OSSEL13_MASK                           0xc000000

#define GPIOD_OSSEL_OSSEL12_OFFSET                         24
#define GPIOD_OSSEL_OSSEL12_MASK                           0x3000000

#define GPIOD_OSSEL_OSSEL11_OFFSET                         22
#define GPIOD_OSSEL_OSSEL11_MASK                           0xc00000

#define GPIOD_OSSEL_OSSEL10_OFFSET                         20
#define GPIOD_OSSEL_OSSEL10_MASK                           0x300000

#define GPIOD_OSSEL_OSSEL9_OFFSET                          18
#define GPIOD_OSSEL_OSSEL9_MASK                            0xc0000

#define GPIOD_OSSEL_OSSEL8_OFFSET                          16
#define GPIOD_OSSEL_OSSEL8_MASK                            0x30000

#define GPIOD_OSSEL_OSSEL7_OFFSET                          14
#define GPIOD_OSSEL_OSSEL7_MASK                            0xc000

#define GPIOD_OSSEL_OSSEL6_OFFSET                          12
#define GPIOD_OSSEL_OSSEL6_MASK                            0x3000

#define GPIOD_OSSEL_OSSEL5_OFFSET                          10
#define GPIOD_OSSEL_OSSEL5_MASK                            0xc00

#define GPIOD_OSSEL_OSSEL4_OFFSET                          8
#define GPIOD_OSSEL_OSSEL4_MASK                            0x300

#define GPIOD_OSSEL_OSSEL3_OFFSET                          6
#define GPIOD_OSSEL_OSSEL3_MASK                            0xc0

#define GPIOD_OSSEL_OSSEL2_OFFSET                          4
#define GPIOD_OSSEL_OSSEL2_MASK                            0x30

#define GPIOD_OSSEL_OSSEL1_OFFSET                          2
#define GPIOD_OSSEL_OSSEL1_MASK                            0xc

#define GPIOD_OSSEL_OSSEL0_OFFSET                          0
#define GPIOD_OSSEL_OSSEL0_MASK                            3

#define GPIOD_PUPD_PUPD15_OFFSET                           30
#define GPIOD_PUPD_PUPD15_MASK                             0xc0000000

#define GPIOD_PUPD_PUPD14_OFFSET                           28
#define GPIOD_PUPD_PUPD14_MASK                             0x30000000

#define GPIOD_PUPD_PUPD13_OFFSET                           26
#define GPIOD_PUPD_PUPD13_MASK                             0xc000000

#define GPIOD_PUPD_PUPD12_OFFSET                           24
#define GPIOD_PUPD_PUPD12_MASK                             0x3000000

#define GPIOD_PUPD_PUPD11_OFFSET                           22
#define GPIOD_PUPD_PUPD11_MASK                             0xc00000

#define GPIOD_PUPD_PUPD10_OFFSET                           20
#define GPIOD_PUPD_PUPD10_MASK                             0x300000

#define GPIOD_PUPD_PUPD9_OFFSET                            18
#define GPIOD_PUPD_PUPD9_MASK                              0xc0000

#define GPIOD_PUPD_PUPD8_OFFSET                            16
#define GPIOD_PUPD_PUPD8_MASK                              0x30000

#define GPIOD_PUPD_PUPD7_OFFSET                            14
#define GPIOD_PUPD_PUPD7_MASK                              0xc000

#define GPIOD_PUPD_PUPD6_OFFSET                            12
#define GPIOD_PUPD_PUPD6_MASK                              0x3000

#define GPIOD_PUPD_PUPD5_OFFSET                            10
#define GPIOD_PUPD_PUPD5_MASK                              0xc00

#define GPIOD_PUPD_PUPD4_OFFSET                            8
#define GPIOD_PUPD_PUPD4_MASK                              0x300

#define GPIOD_PUPD_PUPD3_OFFSET                            6
#define GPIOD_PUPD_PUPD3_MASK                              0xc0

#define GPIOD_PUPD_PUPD2_OFFSET                            4
#define GPIOD_PUPD_PUPD2_MASK                              0x30

#define GPIOD_PUPD_PUPD1_OFFSET                            2
#define GPIOD_PUPD_PUPD1_MASK                              0xc

#define GPIOD_PUPD_PUPD0_OFFSET                            0
#define GPIOD_PUPD_PUPD0_MASK                              3

#define GPIOD_IDATA_IDATA15_OFFSET                         15
#define GPIOD_IDATA_IDATA15_MASK                           0x8000

#define GPIOD_IDATA_IDATA14_OFFSET                         14
#define GPIOD_IDATA_IDATA14_MASK                           0x4000

#define GPIOD_IDATA_IDATA13_OFFSET                         13
#define GPIOD_IDATA_IDATA13_MASK                           0x2000

#define GPIOD_IDATA_IDATA12_OFFSET                         12
#define GPIOD_IDATA_IDATA12_MASK                           0x1000

#define GPIOD_IDATA_IDATA11_OFFSET                         11
#define GPIOD_IDATA_IDATA11_MASK                           0x800

#define GPIOD_IDATA_IDATA10_OFFSET                         10
#define GPIOD_IDATA_IDATA10_MASK                           0x400

#define GPIOD_IDATA_IDATA9_OFFSET                          9
#define GPIOD_IDATA_IDATA9_MASK                            0x200

#define GPIOD_IDATA_IDATA8_OFFSET                          8
#define GPIOD_IDATA_IDATA8_MASK                            0x100

#define GPIOD_IDATA_IDATA7_OFFSET                          7
#define GPIOD_IDATA_IDATA7_MASK                            0x80

#define GPIOD_IDATA_IDATA6_OFFSET                          6
#define GPIOD_IDATA_IDATA6_MASK                            0x40

#define GPIOD_IDATA_IDATA5_OFFSET                          5
#define GPIOD_IDATA_IDATA5_MASK                            0x20

#define GPIOD_IDATA_IDATA4_OFFSET                          4
#define GPIOD_IDATA_IDATA4_MASK                            0x10

#define GPIOD_IDATA_IDATA3_OFFSET                          3
#define GPIOD_IDATA_IDATA3_MASK                            8

#define GPIOD_IDATA_IDATA2_OFFSET                          2
#define GPIOD_IDATA_IDATA2_MASK                            4

#define GPIOD_IDATA_IDATA1_OFFSET                          1
#define GPIOD_IDATA_IDATA1_MASK                            2

#define GPIOD_IDATA_IDATA0_OFFSET                          0
#define GPIOD_IDATA_IDATA0_MASK                            1

#define GPIOD_ODATA_ODATA15_OFFSET                         15
#define GPIOD_ODATA_ODATA15_MASK                           0x8000

#define GPIOD_ODATA_ODATA14_OFFSET                         14
#define GPIOD_ODATA_ODATA14_MASK                           0x4000

#define GPIOD_ODATA_ODATA13_OFFSET                         13
#define GPIOD_ODATA_ODATA13_MASK                           0x2000

#define GPIOD_ODATA_ODATA12_OFFSET                         12
#define GPIOD_ODATA_ODATA12_MASK                           0x1000

#define GPIOD_ODATA_ODATA11_OFFSET                         11
#define GPIOD_ODATA_ODATA11_MASK                           0x800

#define GPIOD_ODATA_ODATA10_OFFSET                         10
#define GPIOD_ODATA_ODATA10_MASK                           0x400

#define GPIOD_ODATA_ODATA9_OFFSET                          9
#define GPIOD_ODATA_ODATA9_MASK                            0x200

#define GPIOD_ODATA_ODATA8_OFFSET                          8
#define GPIOD_ODATA_ODATA8_MASK                            0x100

#define GPIOD_ODATA_ODATA7_OFFSET                          7
#define GPIOD_ODATA_ODATA7_MASK                            0x80

#define GPIOD_ODATA_ODATA6_OFFSET                          6
#define GPIOD_ODATA_ODATA6_MASK                            0x40

#define GPIOD_ODATA_ODATA5_OFFSET                          5
#define GPIOD_ODATA_ODATA5_MASK                            0x20

#define GPIOD_ODATA_ODATA4_OFFSET                          4
#define GPIOD_ODATA_ODATA4_MASK                            0x10

#define GPIOD_ODATA_ODATA3_OFFSET                          3
#define GPIOD_ODATA_ODATA3_MASK                            8

#define GPIOD_ODATA_ODATA2_OFFSET                          2
#define GPIOD_ODATA_ODATA2_MASK                            4

#define GPIOD_ODATA_ODATA1_OFFSET                          1
#define GPIOD_ODATA_ODATA1_MASK                            2

#define GPIOD_ODATA_ODATA0_OFFSET                          0
#define GPIOD_ODATA_ODATA0_MASK                            1

#define GPIOD_BSC_BC15_OFFSET                              31
#define GPIOD_BSC_BC15_MASK                                0x80000000

#define GPIOD_BSC_BC14_OFFSET                              30
#define GPIOD_BSC_BC14_MASK                                0x40000000

#define GPIOD_BSC_BC13_OFFSET                              29
#define GPIOD_BSC_BC13_MASK                                0x20000000

#define GPIOD_BSC_BC12_OFFSET                              28
#define GPIOD_BSC_BC12_MASK                                0x10000000

#define GPIOD_BSC_BC11_OFFSET                              27
#define GPIOD_BSC_BC11_MASK                                0x8000000

#define GPIOD_BSC_BC10_OFFSET                              26
#define GPIOD_BSC_BC10_MASK                                0x4000000

#define GPIOD_BSC_BC9_OFFSET                               25
#define GPIOD_BSC_BC9_MASK                                 0x2000000

#define GPIOD_BSC_BC8_OFFSET                               24
#define GPIOD_BSC_BC8_MASK                                 0x1000000

#define GPIOD_BSC_BC7_OFFSET                               23
#define GPIOD_BSC_BC7_MASK                                 0x800000

#define GPIOD_BSC_BC6_OFFSET                               22
#define GPIOD_BSC_BC6_MASK                                 0x400000

#define GPIOD_BSC_BC5_OFFSET                               21
#define GPIOD_BSC_BC5_MASK                                 0x200000

#define GPIOD_BSC_BC4_OFFSET                               20
#define GPIOD_BSC_BC4_MASK                                 0x100000

#define GPIOD_BSC_BC3_OFFSET                               19
#define GPIOD_BSC_BC3_MASK                                 0x80000

#define GPIOD_BSC_BC2_OFFSET                               18
#define GPIOD_BSC_BC2_MASK                                 0x40000

#define GPIOD_BSC_BC1_OFFSET                               17
#define GPIOD_BSC_BC1_MASK                                 0x20000

#define GPIOD_BSC_BC0_OFFSET                               16
#define GPIOD_BSC_BC0_MASK                                 0x10000

#define GPIOD_BSC_BS15_OFFSET                              15
#define GPIOD_BSC_BS15_MASK                                0x8000

#define GPIOD_BSC_BS14_OFFSET                              14
#define GPIOD_BSC_BS14_MASK                                0x4000

#define GPIOD_BSC_BS13_OFFSET                              13
#define GPIOD_BSC_BS13_MASK                                0x2000

#define GPIOD_BSC_BS12_OFFSET                              12
#define GPIOD_BSC_BS12_MASK                                0x1000

#define GPIOD_BSC_BS11_OFFSET                              11
#define GPIOD_BSC_BS11_MASK                                0x800

#define GPIOD_BSC_BS10_OFFSET                              10
#define GPIOD_BSC_BS10_MASK                                0x400

#define GPIOD_BSC_BS9_OFFSET                               9
#define GPIOD_BSC_BS9_MASK                                 0x200

#define GPIOD_BSC_BS8_OFFSET                               8
#define GPIOD_BSC_BS8_MASK                                 0x100

#define GPIOD_BSC_BS7_OFFSET                               7
#define GPIOD_BSC_BS7_MASK                                 0x80

#define GPIOD_BSC_BS6_OFFSET                               6
#define GPIOD_BSC_BS6_MASK                                 0x40

#define GPIOD_BSC_BS5_OFFSET                               5
#define GPIOD_BSC_BS5_MASK                                 0x20

#define GPIOD_BSC_BS4_OFFSET                               4
#define GPIOD_BSC_BS4_MASK                                 0x10

#define GPIOD_BSC_BS3_OFFSET                               3
#define GPIOD_BSC_BS3_MASK                                 8

#define GPIOD_BSC_BS2_OFFSET                               2
#define GPIOD_BSC_BS2_MASK                                 4

#define GPIOD_BSC_BS1_OFFSET                               1
#define GPIOD_BSC_BS1_MASK                                 2

#define GPIOD_BSC_BS0_OFFSET                               0
#define GPIOD_BSC_BS0_MASK                                 1

#define GPIOD_LOCK_LOCKKEY_OFFSET                          16
#define GPIOD_LOCK_LOCKKEY_MASK                            0x10000

#define GPIOD_LOCK_LOCK15_OFFSET                           15
#define GPIOD_LOCK_LOCK15_MASK                             0x8000

#define GPIOD_LOCK_LOCK14_OFFSET                           14
#define GPIOD_LOCK_LOCK14_MASK                             0x4000

#define GPIOD_LOCK_LOCK13_OFFSET                           13
#define GPIOD_LOCK_LOCK13_MASK                             0x2000

#define GPIOD_LOCK_LOCK12_OFFSET                           12
#define GPIOD_LOCK_LOCK12_MASK                             0x1000

#define GPIOD_LOCK_LOCK11_OFFSET                           11
#define GPIOD_LOCK_LOCK11_MASK                             0x800

#define GPIOD_LOCK_LOCK10_OFFSET                           10
#define GPIOD_LOCK_LOCK10_MASK                             0x400

#define GPIOD_LOCK_LOCK9_OFFSET                            9
#define GPIOD_LOCK_LOCK9_MASK                              0x200

#define GPIOD_LOCK_LOCK8_OFFSET                            8
#define GPIOD_LOCK_LOCK8_MASK                              0x100

#define GPIOD_LOCK_LOCK7_OFFSET                            7
#define GPIOD_LOCK_LOCK7_MASK                              0x80

#define GPIOD_LOCK_LOCK6_OFFSET                            6
#define GPIOD_LOCK_LOCK6_MASK                              0x40

#define GPIOD_LOCK_LOCK5_OFFSET                            5
#define GPIOD_LOCK_LOCK5_MASK                              0x20

#define GPIOD_LOCK_LOCK4_OFFSET                            4
#define GPIOD_LOCK_LOCK4_MASK                              0x10

#define GPIOD_LOCK_LOCK3_OFFSET                            3
#define GPIOD_LOCK_LOCK3_MASK                              8

#define GPIOD_LOCK_LOCK2_OFFSET                            2
#define GPIOD_LOCK_LOCK2_MASK                              4

#define GPIOD_LOCK_LOCK1_OFFSET                            1
#define GPIOD_LOCK_LOCK1_MASK                              2

#define GPIOD_LOCK_LOCK0_OFFSET                            0
#define GPIOD_LOCK_LOCK0_MASK                              1

#define GPIOD_ALFL_ALFSEL7_OFFSET                          28
#define GPIOD_ALFL_ALFSEL7_MASK                            0xf0000000

#define GPIOD_ALFL_ALFSEL6_OFFSET                          24
#define GPIOD_ALFL_ALFSEL6_MASK                            0xf000000

#define GPIOD_ALFL_ALFSEL5_OFFSET                          20
#define GPIOD_ALFL_ALFSEL5_MASK                            0xf00000

#define GPIOD_ALFL_ALFSEL4_OFFSET                          16
#define GPIOD_ALFL_ALFSEL4_MASK                            0xf0000

#define GPIOD_ALFL_ALFSEL3_OFFSET                          12
#define GPIOD_ALFL_ALFSEL3_MASK                            0xf000

#define GPIOD_ALFL_ALFSEL2_OFFSET                          8
#define GPIOD_ALFL_ALFSEL2_MASK                            0xf00

#define GPIOD_ALFL_ALFSEL1_OFFSET                          4
#define GPIOD_ALFL_ALFSEL1_MASK                            0xf0

#define GPIOD_ALFL_ALFSEL0_OFFSET                          0
#define GPIOD_ALFL_ALFSEL0_MASK                            0xf

#define GPIOD_ALFH_ALFSEL15_OFFSET                         28
#define GPIOD_ALFH_ALFSEL15_MASK                           0xf0000000

#define GPIOD_ALFH_ALFSEL14_OFFSET                         24
#define GPIOD_ALFH_ALFSEL14_MASK                           0xf000000

#define GPIOD_ALFH_ALFSEL13_OFFSET                         20
#define GPIOD_ALFH_ALFSEL13_MASK                           0xf00000

#define GPIOD_ALFH_ALFSEL12_OFFSET                         16
#define GPIOD_ALFH_ALFSEL12_MASK                           0xf0000

#define GPIOD_ALFH_ALFSEL11_OFFSET                         12
#define GPIOD_ALFH_ALFSEL11_MASK                           0xf000

#define GPIOD_ALFH_ALFSEL10_OFFSET                         8
#define GPIOD_ALFH_ALFSEL10_MASK                           0xf00

#define GPIOD_ALFH_ALFSEL9_OFFSET                          4
#define GPIOD_ALFH_ALFSEL9_MASK                            0xf0

#define GPIOD_ALFH_ALFSEL8_OFFSET                          0
#define GPIOD_ALFH_ALFSEL8_MASK                            0xf


typedef struct
{

/** MODE MODE (offset: 0x0)
  GPIO port mode register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MODE15
  offset: 30, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE14
  offset: 28, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE13
  offset: 26, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE12
  offset: 24, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE11
  offset: 22, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE10
  offset: 20, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE9
  offset: 18, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE8
  offset: 16, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE7
  offset: 14, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE6
  offset: 12, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE5
  offset: 10, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE4
  offset: 8, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE3
  offset: 6, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE2
  offset: 4, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE1
  offset: 2, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: MODE0
  offset: 0, size: 2, access: 
  Port x configuration bits (y = 0..15)
*/
volatile uint32_t MODE;

/** OMODE OMODE (offset: 0x4)
  GPIO port output type register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OMODE15
  offset: 15, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE14
  offset: 14, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE13
  offset: 13, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE12
  offset: 12, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE11
  offset: 11, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE10
  offset: 10, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE9
  offset: 9, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE8
  offset: 8, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE7
  offset: 7, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE6
  offset: 6, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE5
  offset: 5, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE4
  offset: 4, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE3
  offset: 3, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE2
  offset: 2, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE1
  offset: 1, size: 1, access: 
  Port x configuration bits (y = 0..15)
  Field: OMODE0
  offset: 0, size: 1, access: 
  Port x configuration bits (y = 0..15)
*/
volatile uint32_t OMODE;

/** OSSEL OSSEL (offset: 0x8)
  GPIO port output speed register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OSSEL15
  offset: 30, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL14
  offset: 28, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL13
  offset: 26, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL12
  offset: 24, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL11
  offset: 22, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL10
  offset: 20, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL9
  offset: 18, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL8
  offset: 16, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL7
  offset: 14, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL6
  offset: 12, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL5
  offset: 10, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL4
  offset: 8, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL3
  offset: 6, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL2
  offset: 4, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL1
  offset: 2, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: OSSEL0
  offset: 0, size: 2, access: 
  Port x configuration bits (y = 0..15)
*/
volatile uint32_t OSSEL;

/** PUPD PUPD (offset: 0xc)
  GPIO port pull-up/pull-down register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PUPD15
  offset: 30, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD14
  offset: 28, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD13
  offset: 26, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD12
  offset: 24, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD11
  offset: 22, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD10
  offset: 20, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD9
  offset: 18, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD8
  offset: 16, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD7
  offset: 14, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD6
  offset: 12, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD5
  offset: 10, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD4
  offset: 8, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD3
  offset: 6, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD2
  offset: 4, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD1
  offset: 2, size: 2, access: 
  Port x configuration bits (y = 0..15)
  Field: PUPD0
  offset: 0, size: 2, access: 
  Port x configuration bits (y = 0..15)
*/
volatile uint32_t PUPD;

/** IDATA IDATA (offset: 0x10)
  GPIO port input data register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IDATA15
  offset: 15, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA14
  offset: 14, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA13
  offset: 13, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA12
  offset: 12, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA11
  offset: 11, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA10
  offset: 10, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA9
  offset: 9, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA8
  offset: 8, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA7
  offset: 7, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA6
  offset: 6, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA5
  offset: 5, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA4
  offset: 4, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA3
  offset: 3, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA2
  offset: 2, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA1
  offset: 1, size: 1, access: 
  Port input data (y = 0..15)
  Field: IDATA0
  offset: 0, size: 1, access: 
  Port input data (y = 0..15)
*/
volatile uint32_t IDATA;

/** ODATA ODATA (offset: 0x14)
  GPIO port output data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ODATA15
  offset: 15, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA14
  offset: 14, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA13
  offset: 13, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA12
  offset: 12, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA11
  offset: 11, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA10
  offset: 10, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA9
  offset: 9, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA8
  offset: 8, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA7
  offset: 7, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA6
  offset: 6, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA5
  offset: 5, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA4
  offset: 4, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA3
  offset: 3, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA2
  offset: 2, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA1
  offset: 1, size: 1, access: 
  Port output data (y = 0..15)
  Field: ODATA0
  offset: 0, size: 1, access: 
  Port output data (y = 0..15)
*/
volatile uint32_t ODATA;

/** BSC BSC (offset: 0x18)
  GPIO port bit set/reset register
  access : write-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BC15
  offset: 31, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC14
  offset: 30, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC13
  offset: 29, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC12
  offset: 28, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC11
  offset: 27, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC10
  offset: 26, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC9
  offset: 25, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC8
  offset: 24, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC7
  offset: 23, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC6
  offset: 22, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC5
  offset: 21, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC4
  offset: 20, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC3
  offset: 19, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC2
  offset: 18, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC1
  offset: 17, size: 1, access: 
  Port x reset bit y (y = 0..15)
  Field: BC0
  offset: 16, size: 1, access: 
  Port x reset bit y (y= 0..15)
  Field: BS15
  offset: 15, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS14
  offset: 14, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS13
  offset: 13, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS12
  offset: 12, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS11
  offset: 11, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS10
  offset: 10, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS9
  offset: 9, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS8
  offset: 8, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS7
  offset: 7, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS6
  offset: 6, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS5
  offset: 5, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS4
  offset: 4, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS3
  offset: 3, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS2
  offset: 2, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS1
  offset: 1, size: 1, access: 
  Port x set bit y (y= 0..15)
  Field: BS0
  offset: 0, size: 1, access: 
  Port x set bit y (y= 0..15)
*/
volatile uint32_t BSC;

/** LOCK LOCK (offset: 0x1c)
  GPIO port configuration lock register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: LOCKKEY
  offset: 16, size: 1, access: 
  Lock Key
  Field: LOCK15
  offset: 15, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK14
  offset: 14, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK13
  offset: 13, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK12
  offset: 12, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK11
  offset: 11, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK10
  offset: 10, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK9
  offset: 9, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK8
  offset: 8, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK7
  offset: 7, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK6
  offset: 6, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK5
  offset: 5, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK4
  offset: 4, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK3
  offset: 3, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK2
  offset: 2, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK1
  offset: 1, size: 1, access: 
  Port x lock bit y (y= 0..15)
  Field: LOCK0
  offset: 0, size: 1, access: 
  Port x lock bit y (y= 0..15)
*/
volatile uint32_t LOCK;

/** ALFL ALFL (offset: 0x20)
  GPIO alternate function low register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ALFSEL7
  offset: 28, size: 4, access: 
  Alternate function selection for port x bit y (y = 0..7)
  Field: ALFSEL6
  offset: 24, size: 4, access: 
  Alternate function selection for port x bit y (y = 0..7)
  Field: ALFSEL5
  offset: 20, size: 4, access: 
  Alternate function selection for port x bit y (y = 0..7)
  Field: ALFSEL4
  offset: 16, size: 4, access: 
  Alternate function selection for port x bit y (y = 0..7)
  Field: ALFSEL3
  offset: 12, size: 4, access: 
  Alternate function selection for port x bit y (y = 0..7)
  Field: ALFSEL2
  offset: 8, size: 4, access: 
  Alternate function selection for port x bit y (y = 0..7)
  Field: ALFSEL1
  offset: 4, size: 4, access: 
  Alternate function selection for port x bit y (y = 0..7)
  Field: ALFSEL0
  offset: 0, size: 4, access: 
  Alternate function selection for port x bit y (y = 0..7)
*/
volatile uint32_t ALFL;

/** ALFH ALFH (offset: 0x24)
  GPIO alternate function high register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ALFSEL15
  offset: 28, size: 4, access: 
  Alternate function selection for port x bit y (y = 8..15)
  Field: ALFSEL14
  offset: 24, size: 4, access: 
  Alternate function selection for port x bit y (y = 8..15)
  Field: ALFSEL13
  offset: 20, size: 4, access: 
  Alternate function selection for port x bit y (y = 8..15)
  Field: ALFSEL12
  offset: 16, size: 4, access: 
  Alternate function selection for port x bit y (y = 8..15)
  Field: ALFSEL11
  offset: 12, size: 4, access: 
  Alternate function selection for port x bit y (y = 8..15)
  Field: ALFSEL10
  offset: 8, size: 4, access: 
  Alternate function selection for port x bit y (y = 8..15)
  Field: ALFSEL9
  offset: 4, size: 4, access: 
  Alternate function selection for port x bit y (y = 8..15)
  Field: ALFSEL8
  offset: 0, size: 4, access: 
  Alternate function selection for port x bit y (y = 8..15)
*/
volatile uint32_t ALFH;
} GPIOD_type;

#define GPIOD ((GPIOD_type *) 0x40020C00)

#endif // HW_GPIOD_H
