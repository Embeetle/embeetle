#ifndef HW_WWDT_H
#define HW_WWDT_H
/** Window watchdog */
/** Interrupt : WWDG (Vector: 0) Window Watchdog interrupt */
/** Memory Block starting at 0x40002C00 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define WWDT_CTRL_WWDTEN_OFFSET                            7
#define WWDT_CTRL_WWDTEN_MASK                              0x80

#define WWDT_CTRL_CNT_OFFSET                               0
#define WWDT_CTRL_CNT_MASK                                 0x7f

#define WWDT_CFG_EWIEN_OFFSET                              9
#define WWDT_CFG_EWIEN_MASK                                0x200

#define WWDT_CFG_TBPSC_OFFSET                              7
#define WWDT_CFG_TBPSC_MASK                                0x180

#define WWDT_CFG_WIN_OFFSET                                0
#define WWDT_CFG_WIN_MASK                                  0x7f

#define WWDT_STS_EWIFLG_OFFSET                             0
#define WWDT_STS_EWIFLG_MASK                               1


typedef struct
{

/** CTRL CTRL (offset: 0x0)
  Control register
  access : read-write
  reset value : 0x7F
  reset mask : 0xFFFFFFFF
  Field: WWDTEN
  offset: 7, size: 1, access: 
  Activation bit
  Field: CNT
  offset: 0, size: 7, access: 
  7-bit counter (MSB to LSB)
*/
volatile uint32_t CTRL;

/** CFG CFG (offset: 0x4)
  Configuration register
  access : read-write
  reset value : 0x7F
  reset mask : 0xFFFFFFFF
  Field: EWIEN
  offset: 9, size: 1, access: 
  Early wakeup interrupt
  Field: TBPSC
  offset: 7, size: 2, access: 
  Timer Base Prescaler Factor Configure
  Field: WIN
  offset: 0, size: 7, access: 
  7-bit window value
*/
volatile uint32_t CFG;

/** STS STS (offset: 0x8)
  Status register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EWIFLG
  offset: 0, size: 1, access: 
  Early wakeup interrupt flag
*/
volatile uint32_t STS;
} WWDT_type;

#define WWDT ((WWDT_type *) 0x40002C00)

#endif // HW_WWDT_H
