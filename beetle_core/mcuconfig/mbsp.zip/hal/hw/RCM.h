#ifndef HW_RCM_H
#define HW_RCM_H
/** Reset and clock control */
/** Interrupt : RCM (Vector: 5) RCM global interrupt */
/** Memory Block starting at 0x40023800 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define RCM_CTRL_PLL2RDYFLG_OFFSET                         27
#define RCM_CTRL_PLL2RDYFLG_MASK                           0x8000000

#define RCM_CTRL_PLL2EN_OFFSET                             26
#define RCM_CTRL_PLL2EN_MASK                               0x4000000

#define RCM_CTRL_PLL1RDYFLG_OFFSET                         25
#define RCM_CTRL_PLL1RDYFLG_MASK                           0x2000000

#define RCM_CTRL_PLL1EN_OFFSET                             24
#define RCM_CTRL_PLL1EN_MASK                               0x1000000

#define RCM_CTRL_CSSEN_OFFSET                              19
#define RCM_CTRL_CSSEN_MASK                                0x80000

#define RCM_CTRL_HSEBCFG_OFFSET                            18
#define RCM_CTRL_HSEBCFG_MASK                              0x40000

#define RCM_CTRL_HSERDYFLG_OFFSET                          17
#define RCM_CTRL_HSERDYFLG_MASK                            0x20000

#define RCM_CTRL_HSEEN_OFFSET                              16
#define RCM_CTRL_HSEEN_MASK                                0x10000

#define RCM_CTRL_HSICAL_OFFSET                             8
#define RCM_CTRL_HSICAL_MASK                               0xff00

#define RCM_CTRL_HSITRM_OFFSET                             3
#define RCM_CTRL_HSITRM_MASK                               0xf8

#define RCM_CTRL_HSIRDYFLG_OFFSET                          1
#define RCM_CTRL_HSIRDYFLG_MASK                            2

#define RCM_CTRL_HSIEN_OFFSET                              0
#define RCM_CTRL_HSIEN_MASK                                1

#define RCM_PLL1CFG_PLLD_OFFSET                            24
#define RCM_PLL1CFG_PLLD_MASK                              0xf000000

#define RCM_PLL1CFG_PLL1CLKS_OFFSET                        22
#define RCM_PLL1CFG_PLL1CLKS_MASK                          0x400000

#define RCM_PLL1CFG_PLL1C_OFFSET                           16
#define RCM_PLL1CFG_PLL1C_MASK                             0x30000

#define RCM_PLL1CFG_PLL1A_OFFSET                           6
#define RCM_PLL1CFG_PLL1A_MASK                             0x7fc0

#define RCM_PLL1CFG_PLLB_OFFSET                            0
#define RCM_PLL1CFG_PLLB_MASK                              0x3f

#define RCM_CFG_MCO2SEL_OFFSET                             30
#define RCM_CFG_MCO2SEL_MASK                               0xc0000000

#define RCM_CFG_MCO2PSC_OFFSET                             27
#define RCM_CFG_MCO2PSC_MASK                               0x38000000

#define RCM_CFG_MCO1PSC_OFFSET                             24
#define RCM_CFG_MCO1PSC_MASK                               0x7000000

#define RCM_CFG_I2SSEL_OFFSET                              23
#define RCM_CFG_I2SSEL_MASK                                0x800000

#define RCM_CFG_MCO1SEL_OFFSET                             21
#define RCM_CFG_MCO1SEL_MASK                               0x600000

#define RCM_CFG_RTCPSC_OFFSET                              16
#define RCM_CFG_RTCPSC_MASK                                0x1f0000

#define RCM_CFG_APB2PSC_OFFSET                             13
#define RCM_CFG_APB2PSC_MASK                               0xe000

#define RCM_CFG_APB1PSC_OFFSET                             10
#define RCM_CFG_APB1PSC_MASK                               0x1c00

#define RCM_CFG_SDRAMPSC_OFFSET                            8
#define RCM_CFG_SDRAMPSC_MASK                              0x300

#define RCM_CFG_AHBPSC_OFFSET                              4
#define RCM_CFG_AHBPSC_MASK                                0xf0

#define RCM_CFG_SCLKSWSTS1_OFFSET                          3
#define RCM_CFG_SCLKSWSTS1_MASK                            8

#define RCM_CFG_SCLKSWSTS0_OFFSET                          2
#define RCM_CFG_SCLKSWSTS0_MASK                            4

#define RCM_CFG_SCLKSEL1_OFFSET                            1
#define RCM_CFG_SCLKSEL1_MASK                              2

#define RCM_CFG_SCLKSEL0_OFFSET                            0
#define RCM_CFG_SCLKSEL0_MASK                              1

#define RCM_INT_CSSCLR_OFFSET                              23
#define RCM_INT_CSSCLR_MASK                                0x800000

#define RCM_INT_PLL2RDYCLR_OFFSET                          21
#define RCM_INT_PLL2RDYCLR_MASK                            0x200000

#define RCM_INT_PLL1RDYCLR_OFFSET                          20
#define RCM_INT_PLL1RDYCLR_MASK                            0x100000

#define RCM_INT_HSERDYCLR_OFFSET                           19
#define RCM_INT_HSERDYCLR_MASK                             0x80000

#define RCM_INT_HSIRDYCLR_OFFSET                           18
#define RCM_INT_HSIRDYCLR_MASK                             0x40000

#define RCM_INT_LSERDYCLR_OFFSET                           17
#define RCM_INT_LSERDYCLR_MASK                             0x20000

#define RCM_INT_LSIRDYCLR_OFFSET                           16
#define RCM_INT_LSIRDYCLR_MASK                             0x10000

#define RCM_INT_PLL2RDYEN_OFFSET                           13
#define RCM_INT_PLL2RDYEN_MASK                             0x2000

#define RCM_INT_PLL1RDYEN_OFFSET                           12
#define RCM_INT_PLL1RDYEN_MASK                             0x1000

#define RCM_INT_HSERDYEN_OFFSET                            11
#define RCM_INT_HSERDYEN_MASK                              0x800

#define RCM_INT_HSIRDYEN_OFFSET                            10
#define RCM_INT_HSIRDYEN_MASK                              0x400

#define RCM_INT_LSERDYEN_OFFSET                            9
#define RCM_INT_LSERDYEN_MASK                              0x200

#define RCM_INT_LSIRDYEN_OFFSET                            8
#define RCM_INT_LSIRDYEN_MASK                              0x100

#define RCM_INT_CSSFLG_OFFSET                              7
#define RCM_INT_CSSFLG_MASK                                0x80

#define RCM_INT_PLL2RDYFLG_OFFSET                          5
#define RCM_INT_PLL2RDYFLG_MASK                            0x20

#define RCM_INT_PLL1RDYFLG_OFFSET                          4
#define RCM_INT_PLL1RDYFLG_MASK                            0x10

#define RCM_INT_HSERDYFLG_OFFSET                           3
#define RCM_INT_HSERDYFLG_MASK                             8

#define RCM_INT_HSIRDYFLG_OFFSET                           2
#define RCM_INT_HSIRDYFLG_MASK                             4

#define RCM_INT_LSERDYFLG_OFFSET                           1
#define RCM_INT_LSERDYFLG_MASK                             2

#define RCM_INT_LSIRDYFLG_OFFSET                           0
#define RCM_INT_LSIRDYFLG_MASK                             1

#define RCM_AHB1RST_ENETRST_OFFSET                         25
#define RCM_AHB1RST_ENETRST_MASK                           0x2000000

#define RCM_AHB1RST_DMA2RST_OFFSET                         22
#define RCM_AHB1RST_DMA2RST_MASK                           0x400000

#define RCM_AHB1RST_DMA1RST_OFFSET                         21
#define RCM_AHB1RST_DMA1RST_MASK                           0x200000

#define RCM_AHB1RST_CRCRST_OFFSET                          12
#define RCM_AHB1RST_CRCRST_MASK                            0x1000

#define RCM_AHB1RST_PHRST_OFFSET                           7
#define RCM_AHB1RST_PHRST_MASK                             0x80

#define RCM_AHB1RST_PERST_OFFSET                           4
#define RCM_AHB1RST_PERST_MASK                             0x10

#define RCM_AHB1RST_PDRST_OFFSET                           3
#define RCM_AHB1RST_PDRST_MASK                             8

#define RCM_AHB1RST_PCRST_OFFSET                           2
#define RCM_AHB1RST_PCRST_MASK                             4

#define RCM_AHB1RST_PBRST_OFFSET                           1
#define RCM_AHB1RST_PBRST_MASK                             2

#define RCM_AHB1RST_PARST_OFFSET                           0
#define RCM_AHB1RST_PARST_MASK                             1

#define RCM_AHB2RST_OTGFSRST_OFFSET                        7
#define RCM_AHB2RST_OTGFSRST_MASK                          0x80

#define RCM_AHB2RST_RNGRST_OFFSET                          6
#define RCM_AHB2RST_RNGRST_MASK                            0x40

#define RCM_AHB2RST_QSPIRST_OFFSET                         2
#define RCM_AHB2RST_QSPIRST_MASK                           4

#define RCM_AHB3RST_SMCRST_OFFSET                          0
#define RCM_AHB3RST_SMCRST_MASK                            1

#define RCM_APB1RST_PWRRST_OFFSET                          28
#define RCM_APB1RST_PWRRST_MASK                            0x10000000

#define RCM_APB1RST_CAN2RST_OFFSET                         26
#define RCM_APB1RST_CAN2RST_MASK                           0x4000000

#define RCM_APB1RST_CAN1RST_OFFSET                         25
#define RCM_APB1RST_CAN1RST_MASK                           0x2000000

#define RCM_APB1RST_I2C3RST_OFFSET                         23
#define RCM_APB1RST_I2C3RST_MASK                           0x800000

#define RCM_APB1RST_I2C2RST_OFFSET                         22
#define RCM_APB1RST_I2C2RST_MASK                           0x400000

#define RCM_APB1RST_I2C1RST_OFFSET                         21
#define RCM_APB1RST_I2C1RST_MASK                           0x200000

#define RCM_APB1RST_UART5RST_OFFSET                        20
#define RCM_APB1RST_UART5RST_MASK                          0x100000

#define RCM_APB1RST_UART4RST_OFFSET                        19
#define RCM_APB1RST_UART4RST_MASK                          0x80000

#define RCM_APB1RST_UART3RST_OFFSET                        18
#define RCM_APB1RST_UART3RST_MASK                          0x40000

#define RCM_APB1RST_UART2RST_OFFSET                        17
#define RCM_APB1RST_UART2RST_MASK                          0x20000

#define RCM_APB1RST_SPI3RST_OFFSET                         15
#define RCM_APB1RST_SPI3RST_MASK                           0x8000

#define RCM_APB1RST_SPI2RST_OFFSET                         14
#define RCM_APB1RST_SPI2RST_MASK                           0x4000

#define RCM_APB1RST_WWDTRST_OFFSET                         11
#define RCM_APB1RST_WWDTRST_MASK                           0x800

#define RCM_APB1RST_TMR14RST_OFFSET                        8
#define RCM_APB1RST_TMR14RST_MASK                          0x100

#define RCM_APB1RST_TMR13RST_OFFSET                        7
#define RCM_APB1RST_TMR13RST_MASK                          0x80

#define RCM_APB1RST_TMR12RST_OFFSET                        6
#define RCM_APB1RST_TMR12RST_MASK                          0x40

#define RCM_APB1RST_TMR5RST_OFFSET                         3
#define RCM_APB1RST_TMR5RST_MASK                           8

#define RCM_APB1RST_TMR4RST_OFFSET                         2
#define RCM_APB1RST_TMR4RST_MASK                           4

#define RCM_APB1RST_TMR3RST_OFFSET                         1
#define RCM_APB1RST_TMR3RST_MASK                           2

#define RCM_APB1RST_TMR2RST_OFFSET                         0
#define RCM_APB1RST_TMR2RST_MASK                           1

#define RCM_APB2RST_SPI5RST_OFFSET                         20
#define RCM_APB2RST_SPI5RST_MASK                           0x100000

#define RCM_APB2RST_TMR11RST_OFFSET                        18
#define RCM_APB2RST_TMR11RST_MASK                          0x40000

#define RCM_APB2RST_TMR10RST_OFFSET                        17
#define RCM_APB2RST_TMR10RST_MASK                          0x20000

#define RCM_APB2RST_TMR9RST_OFFSET                         16
#define RCM_APB2RST_TMR9RST_MASK                           0x10000

#define RCM_APB2RST_SYSCFGRST_OFFSET                       14
#define RCM_APB2RST_SYSCFGRST_MASK                         0x4000

#define RCM_APB2RST_SPI4RST_OFFSET                         13
#define RCM_APB2RST_SPI4RST_MASK                           0x2000

#define RCM_APB2RST_SPI1RST_OFFSET                         12
#define RCM_APB2RST_SPI1RST_MASK                           0x1000

#define RCM_APB2RST_SDIORST_OFFSET                         11
#define RCM_APB2RST_SDIORST_MASK                           0x800

#define RCM_APB2RST_ADCRST_OFFSET                          8
#define RCM_APB2RST_ADCRST_MASK                            0x100

#define RCM_APB2RST_USART6RST_OFFSET                       5
#define RCM_APB2RST_USART6RST_MASK                         0x20

#define RCM_APB2RST_USART1RST_OFFSET                       4
#define RCM_APB2RST_USART1RST_MASK                         0x10

#define RCM_APB2RST_TMR8RST_OFFSET                         1
#define RCM_APB2RST_TMR8RST_MASK                           2

#define RCM_APB2RST_TMR1RST_OFFSET                         0
#define RCM_APB2RST_TMR1RST_MASK                           1

#define RCM_AHB1CLKEN_DMA2EN_OFFSET                        22
#define RCM_AHB1CLKEN_DMA2EN_MASK                          0x400000

#define RCM_AHB1CLKEN_DMA1EN_OFFSET                        21
#define RCM_AHB1CLKEN_DMA1EN_MASK                          0x200000

#define RCM_AHB1CLKEN_CRCEN_OFFSET                         12
#define RCM_AHB1CLKEN_CRCEN_MASK                           0x1000

#define RCM_AHB1CLKEN_PHEN_OFFSET                          7
#define RCM_AHB1CLKEN_PHEN_MASK                            0x80

#define RCM_AHB1CLKEN_PEEN_OFFSET                          4
#define RCM_AHB1CLKEN_PEEN_MASK                            0x10

#define RCM_AHB1CLKEN_PDEN_OFFSET                          3
#define RCM_AHB1CLKEN_PDEN_MASK                            8

#define RCM_AHB1CLKEN_PCEN_OFFSET                          2
#define RCM_AHB1CLKEN_PCEN_MASK                            4

#define RCM_AHB1CLKEN_PBEN_OFFSET                          1
#define RCM_AHB1CLKEN_PBEN_MASK                            2

#define RCM_AHB1CLKEN_PAEN_OFFSET                          0
#define RCM_AHB1CLKEN_PAEN_MASK                            1

#define RCM_AHB2CLKEN_OTGFSEN_OFFSET                       7
#define RCM_AHB2CLKEN_OTGFSEN_MASK                         0x80

#define RCM_AHB2CLKEN_RNGEN_OFFSET                         6
#define RCM_AHB2CLKEN_RNGEN_MASK                           0x40

#define RCM_AHB2CLKEN_QSPIEN_OFFSET                        2
#define RCM_AHB2CLKEN_QSPIEN_MASK                          4

#define RCM_AHB3CLKEN_SMCEN_OFFSET                         0
#define RCM_AHB3CLKEN_SMCEN_MASK                           1

#define RCM_APB1CLKEN_PWUEN_OFFSET                         28
#define RCM_APB1CLKEN_PWUEN_MASK                           0x10000000

#define RCM_APB1CLKEN_CAN2EN_OFFSET                        26
#define RCM_APB1CLKEN_CAN2EN_MASK                          0x4000000

#define RCM_APB1CLKEN_CAN1EN_OFFSET                        25
#define RCM_APB1CLKEN_CAN1EN_MASK                          0x2000000

#define RCM_APB1CLKEN_I2C3EN_OFFSET                        23
#define RCM_APB1CLKEN_I2C3EN_MASK                          0x800000

#define RCM_APB1CLKEN_I2C2EN_OFFSET                        22
#define RCM_APB1CLKEN_I2C2EN_MASK                          0x400000

#define RCM_APB1CLKEN_I2C1EN_OFFSET                        21
#define RCM_APB1CLKEN_I2C1EN_MASK                          0x200000

#define RCM_APB1CLKEN_UART5EN_OFFSET                       20
#define RCM_APB1CLKEN_UART5EN_MASK                         0x100000

#define RCM_APB1CLKEN_UART4EN_OFFSET                       19
#define RCM_APB1CLKEN_UART4EN_MASK                         0x80000

#define RCM_APB1CLKEN_USART3EN_OFFSET                      18
#define RCM_APB1CLKEN_USART3EN_MASK                        0x40000

#define RCM_APB1CLKEN_USART2EN_OFFSET                      17
#define RCM_APB1CLKEN_USART2EN_MASK                        0x20000

#define RCM_APB1CLKEN_SPI3EN_OFFSET                        15
#define RCM_APB1CLKEN_SPI3EN_MASK                          0x8000

#define RCM_APB1CLKEN_SPI2EN_OFFSET                        14
#define RCM_APB1CLKEN_SPI2EN_MASK                          0x4000

#define RCM_APB1CLKEN_WWDTEN_OFFSET                        11
#define RCM_APB1CLKEN_WWDTEN_MASK                          0x800

#define RCM_APB1CLKEN_TMR14EN_OFFSET                       8
#define RCM_APB1CLKEN_TMR14EN_MASK                         0x100

#define RCM_APB1CLKEN_TMR13EN_OFFSET                       7
#define RCM_APB1CLKEN_TMR13EN_MASK                         0x80

#define RCM_APB1CLKEN_TMR12EN_OFFSET                       6
#define RCM_APB1CLKEN_TMR12EN_MASK                         0x40

#define RCM_APB1CLKEN_TMR5EN_OFFSET                        3
#define RCM_APB1CLKEN_TMR5EN_MASK                          8

#define RCM_APB1CLKEN_TMR4EN_OFFSET                        2
#define RCM_APB1CLKEN_TMR4EN_MASK                          4

#define RCM_APB1CLKEN_TMR3EN_OFFSET                        1
#define RCM_APB1CLKEN_TMR3EN_MASK                          2

#define RCM_APB1CLKEN_TMR2EN_OFFSET                        0
#define RCM_APB1CLKEN_TMR2EN_MASK                          1

#define RCM_APB2CLKEN_SPI5EN_OFFSET                        20
#define RCM_APB2CLKEN_SPI5EN_MASK                          0x100000

#define RCM_APB2CLKEN_TMR11EN_OFFSET                       18
#define RCM_APB2CLKEN_TMR11EN_MASK                         0x40000

#define RCM_APB2CLKEN_TMR10EN_OFFSET                       17
#define RCM_APB2CLKEN_TMR10EN_MASK                         0x20000

#define RCM_APB2CLKEN_TMR9EN_OFFSET                        16
#define RCM_APB2CLKEN_TMR9EN_MASK                          0x10000

#define RCM_APB2CLKEN_SYSCFGEN_OFFSET                      14
#define RCM_APB2CLKEN_SYSCFGEN_MASK                        0x4000

#define RCM_APB2CLKEN_SPI4EN_OFFSET                        13
#define RCM_APB2CLKEN_SPI4EN_MASK                          0x2000

#define RCM_APB2CLKEN_SPI1EN_OFFSET                        12
#define RCM_APB2CLKEN_SPI1EN_MASK                          0x1000

#define RCM_APB2CLKEN_SDIOEN_OFFSET                        11
#define RCM_APB2CLKEN_SDIOEN_MASK                          0x800

#define RCM_APB2CLKEN_ADC2EN_OFFSET                        9
#define RCM_APB2CLKEN_ADC2EN_MASK                          0x200

#define RCM_APB2CLKEN_ADC1EN_OFFSET                        8
#define RCM_APB2CLKEN_ADC1EN_MASK                          0x100

#define RCM_APB2CLKEN_USART6EN_OFFSET                      5
#define RCM_APB2CLKEN_USART6EN_MASK                        0x20

#define RCM_APB2CLKEN_USART1EN_OFFSET                      4
#define RCM_APB2CLKEN_USART1EN_MASK                        0x10

#define RCM_APB2CLKEN_TMR8EN_OFFSET                        1
#define RCM_APB2CLKEN_TMR8EN_MASK                          2

#define RCM_APB2CLKEN_TMR1EN_OFFSET                        0
#define RCM_APB2CLKEN_TMR1EN_MASK                          1

#define RCM_LPAHB1CLKEN_DMA2EN_OFFSET                      22
#define RCM_LPAHB1CLKEN_DMA2EN_MASK                        0x400000

#define RCM_LPAHB1CLKEN_DMA1EN_OFFSET                      21
#define RCM_LPAHB1CLKEN_DMA1EN_MASK                        0x200000

#define RCM_LPAHB1CLKEN_SRAM1EN_OFFSET                     16
#define RCM_LPAHB1CLKEN_SRAM1EN_MASK                       0x10000

#define RCM_LPAHB1CLKEN_FMCEN_OFFSET                       15
#define RCM_LPAHB1CLKEN_FMCEN_MASK                         0x8000

#define RCM_LPAHB1CLKEN_CRCEN_OFFSET                       12
#define RCM_LPAHB1CLKEN_CRCEN_MASK                         0x1000

#define RCM_LPAHB1CLKEN_PHEN_OFFSET                        7
#define RCM_LPAHB1CLKEN_PHEN_MASK                          0x80

#define RCM_LPAHB1CLKEN_PEEN_OFFSET                        4
#define RCM_LPAHB1CLKEN_PEEN_MASK                          0x10

#define RCM_LPAHB1CLKEN_PDEN_OFFSET                        3
#define RCM_LPAHB1CLKEN_PDEN_MASK                          8

#define RCM_LPAHB1CLKEN_PCEN_OFFSET                        2
#define RCM_LPAHB1CLKEN_PCEN_MASK                          4

#define RCM_LPAHB1CLKEN_PBEN_OFFSET                        1
#define RCM_LPAHB1CLKEN_PBEN_MASK                          2

#define RCM_LPAHB1CLKEN_PAEN_OFFSET                        0
#define RCM_LPAHB1CLKEN_PAEN_MASK                          1

#define RCM_LPAHB2CLKEN_OTGFSEN_OFFSET                     7
#define RCM_LPAHB2CLKEN_OTGFSEN_MASK                       0x80

#define RCM_LPAHB2CLKEN_RNGEN_OFFSET                       6
#define RCM_LPAHB2CLKEN_RNGEN_MASK                         0x40

#define RCM_LPAHB2CLKEN_QSPIEN_OFFSET                      2
#define RCM_LPAHB2CLKEN_QSPIEN_MASK                        4

#define RCM_LPAHB3CLKEN_SMCEN_OFFSET                       0
#define RCM_LPAHB3CLKEN_SMCEN_MASK                         1

#define RCM_LPAPB1CLKEN_PWUEN_OFFSET                       28
#define RCM_LPAPB1CLKEN_PWUEN_MASK                         0x10000000

#define RCM_LPAPB1CLKEN_CAN2EN_OFFSET                      26
#define RCM_LPAPB1CLKEN_CAN2EN_MASK                        0x4000000

#define RCM_LPAPB1CLKEN_CAN1EN_OFFSET                      25
#define RCM_LPAPB1CLKEN_CAN1EN_MASK                        0x2000000

#define RCM_LPAPB1CLKEN_I2C3EN_OFFSET                      23
#define RCM_LPAPB1CLKEN_I2C3EN_MASK                        0x800000

#define RCM_LPAPB1CLKEN_I2C2EN_OFFSET                      22
#define RCM_LPAPB1CLKEN_I2C2EN_MASK                        0x400000

#define RCM_LPAPB1CLKEN_I2C1EN_OFFSET                      21
#define RCM_LPAPB1CLKEN_I2C1EN_MASK                        0x200000

#define RCM_LPAPB1CLKEN_UART5EN_OFFSET                     20
#define RCM_LPAPB1CLKEN_UART5EN_MASK                       0x100000

#define RCM_LPAPB1CLKEN_UART4EN_OFFSET                     19
#define RCM_LPAPB1CLKEN_UART4EN_MASK                       0x80000

#define RCM_LPAPB1CLKEN_USART3EN_OFFSET                    18
#define RCM_LPAPB1CLKEN_USART3EN_MASK                      0x40000

#define RCM_LPAPB1CLKEN_USART2EN_OFFSET                    17
#define RCM_LPAPB1CLKEN_USART2EN_MASK                      0x20000

#define RCM_LPAPB1CLKEN_SPI3EN_OFFSET                      15
#define RCM_LPAPB1CLKEN_SPI3EN_MASK                        0x8000

#define RCM_LPAPB1CLKEN_SPI2EN_OFFSET                      14
#define RCM_LPAPB1CLKEN_SPI2EN_MASK                        0x4000

#define RCM_LPAPB1CLKEN_WWDTEN_OFFSET                      11
#define RCM_LPAPB1CLKEN_WWDTEN_MASK                        0x800

#define RCM_LPAPB1CLKEN_TMR14EN_OFFSET                     8
#define RCM_LPAPB1CLKEN_TMR14EN_MASK                       0x100

#define RCM_LPAPB1CLKEN_TMR13EN_OFFSET                     7
#define RCM_LPAPB1CLKEN_TMR13EN_MASK                       0x80

#define RCM_LPAPB1CLKEN_TMR12EN_OFFSET                     6
#define RCM_LPAPB1CLKEN_TMR12EN_MASK                       0x40

#define RCM_LPAPB1CLKEN_TMR5EN_OFFSET                      3
#define RCM_LPAPB1CLKEN_TMR5EN_MASK                        8

#define RCM_LPAPB1CLKEN_TMR4EN_OFFSET                      2
#define RCM_LPAPB1CLKEN_TMR4EN_MASK                        4

#define RCM_LPAPB1CLKEN_TMR3EN_OFFSET                      1
#define RCM_LPAPB1CLKEN_TMR3EN_MASK                        2

#define RCM_LPAPB1CLKEN_TMR2EN_OFFSET                      0
#define RCM_LPAPB1CLKEN_TMR2EN_MASK                        1

#define RCM_LPAPB2CLKEN_SPI5EN_OFFSET                      20
#define RCM_LPAPB2CLKEN_SPI5EN_MASK                        0x100000

#define RCM_LPAPB2CLKEN_TMR11EN_OFFSET                     18
#define RCM_LPAPB2CLKEN_TMR11EN_MASK                       0x40000

#define RCM_LPAPB2CLKEN_TMR10EN_OFFSET                     17
#define RCM_LPAPB2CLKEN_TMR10EN_MASK                       0x20000

#define RCM_LPAPB2CLKEN_TMR9EN_OFFSET                      16
#define RCM_LPAPB2CLKEN_TMR9EN_MASK                        0x10000

#define RCM_LPAPB2CLKEN_SYSCFGEN_OFFSET                    14
#define RCM_LPAPB2CLKEN_SYSCFGEN_MASK                      0x4000

#define RCM_LPAPB2CLKEN_SPI4EN_OFFSET                      13
#define RCM_LPAPB2CLKEN_SPI4EN_MASK                        0x2000

#define RCM_LPAPB2CLKEN_SPI1EN_OFFSET                      12
#define RCM_LPAPB2CLKEN_SPI1EN_MASK                        0x1000

#define RCM_LPAPB2CLKEN_SDIOEN_OFFSET                      11
#define RCM_LPAPB2CLKEN_SDIOEN_MASK                        0x800

#define RCM_LPAPB2CLKEN_ADC3EN_OFFSET                      10
#define RCM_LPAPB2CLKEN_ADC3EN_MASK                        0x400

#define RCM_LPAPB2CLKEN_ADC2EN_OFFSET                      9
#define RCM_LPAPB2CLKEN_ADC2EN_MASK                        0x200

#define RCM_LPAPB2CLKEN_ADC1EN_OFFSET                      8
#define RCM_LPAPB2CLKEN_ADC1EN_MASK                        0x100

#define RCM_LPAPB2CLKEN_USART6EN_OFFSET                    5
#define RCM_LPAPB2CLKEN_USART6EN_MASK                      0x20

#define RCM_LPAPB2CLKEN_USART1EN_OFFSET                    4
#define RCM_LPAPB2CLKEN_USART1EN_MASK                      0x10

#define RCM_LPAPB2CLKEN_TMR8EN_OFFSET                      1
#define RCM_LPAPB2CLKEN_TMR8EN_MASK                        2

#define RCM_LPAPB2CLKEN_TMR1EN_OFFSET                      0
#define RCM_LPAPB2CLKEN_TMR1EN_MASK                        1

#define RCM_BDCTRL_BDRST_OFFSET                            16
#define RCM_BDCTRL_BDRST_MASK                              0x10000

#define RCM_BDCTRL_RTCCLKEN_OFFSET                         15
#define RCM_BDCTRL_RTCCLKEN_MASK                           0x8000

#define RCM_BDCTRL_RTCSRCSEL_OFFSET                        8
#define RCM_BDCTRL_RTCSRCSEL_MASK                          0x300

#define RCM_BDCTRL_LSESEL_OFFSET                           3
#define RCM_BDCTRL_LSESEL_MASK                             8

#define RCM_BDCTRL_LSEBCFG_OFFSET                          2
#define RCM_BDCTRL_LSEBCFG_MASK                            4

#define RCM_BDCTRL_LSERDYFLG_OFFSET                        1
#define RCM_BDCTRL_LSERDYFLG_MASK                          2

#define RCM_BDCTRL_LSEEN_OFFSET                            0
#define RCM_BDCTRL_LSEEN_MASK                              1

#define RCM_CSTS_LPWRRSTFLG_OFFSET                         31
#define RCM_CSTS_LPWRRSTFLG_MASK                           0x80000000

#define RCM_CSTS_WWDTRSTFLG_OFFSET                         30
#define RCM_CSTS_WWDTRSTFLG_MASK                           0x40000000

#define RCM_CSTS_IWDTRSTFLG_OFFSET                         29
#define RCM_CSTS_IWDTRSTFLG_MASK                           0x20000000

#define RCM_CSTS_SWRSTFLG_OFFSET                           28
#define RCM_CSTS_SWRSTFLG_MASK                             0x10000000

#define RCM_CSTS_PODRSTFLG_OFFSET                          27
#define RCM_CSTS_PODRSTFLG_MASK                            0x8000000

#define RCM_CSTS_PINRSTFLG_OFFSET                          26
#define RCM_CSTS_PINRSTFLG_MASK                            0x4000000

#define RCM_CSTS_BORRSTFLG_OFFSET                          25
#define RCM_CSTS_BORRSTFLG_MASK                            0x2000000

#define RCM_CSTS_RSTFLGCLR_OFFSET                          24
#define RCM_CSTS_RSTFLGCLR_MASK                            0x1000000

#define RCM_CSTS_LSIRDYFLG_OFFSET                          1
#define RCM_CSTS_LSIRDYFLG_MASK                            2

#define RCM_CSTS_LSIEN_OFFSET                              0
#define RCM_CSTS_LSIEN_MASK                                1

#define RCM_SSCCFG_SSEN_OFFSET                             31
#define RCM_SSCCFG_SSEN_MASK                               0x80000000

#define RCM_SSCCFG_SSSEL_OFFSET                            30
#define RCM_SSCCFG_SSSEL_MASK                              0x40000000

#define RCM_SSCCFG_STEP_OFFSET                             13
#define RCM_SSCCFG_STEP_MASK                               0xfffe000

#define RCM_SSCCFG_MODPCFG_OFFSET                          0
#define RCM_SSCCFG_MODPCFG_MASK                            0x1fff

#define RCM_PLL2CFG_PLL2C_OFFSET                           28
#define RCM_PLL2CFG_PLL2C_MASK                             0x70000000

#define RCM_PLL2CFG_PLL2A_OFFSET                           6
#define RCM_PLL2CFG_PLL2A_MASK                             0x7fc0

#define RCM_PLL2CFG_PLL2B_OFFSET                           0
#define RCM_PLL2CFG_PLL2B_MASK                             0x3f

#define RCM_CFGSEL_CLKPSEL_OFFSET                          24
#define RCM_CFGSEL_CLKPSEL_MASK                            0x1000000


typedef struct
{

/** CTRL CTRL (offset: 0x0)
  clock control register
  reset value : 0x81
  reset mask : 0xFFFFFFFF
  Field: PLL2RDYFLG
  offset: 27, size: 1, access: read-only
  PLLI2S clock ready flag
  Field: PLL2EN
  offset: 26, size: 1, access: read-write
  PLLI2S enable
  Field: PLL1RDYFLG
  offset: 25, size: 1, access: read-only
  Main PLL (PLL) clock ready flag
  Field: PLL1EN
  offset: 24, size: 1, access: read-write
  Main PLL (PLL) enable
  Field: CSSEN
  offset: 19, size: 1, access: read-write
  Clock security system enable
  Field: HSEBCFG
  offset: 18, size: 1, access: read-write
  HSE clock bypass
  Field: HSERDYFLG
  offset: 17, size: 1, access: read-only
  HSE clock ready flag
  Field: HSEEN
  offset: 16, size: 1, access: read-write
  HSE clock enable
  Field: HSICAL
  offset: 8, size: 8, access: read-only
  Internal high-speed clock calibration
  Field: HSITRM
  offset: 3, size: 5, access: read-write
  Internal high-speed clock trimming
  Field: HSIRDYFLG
  offset: 1, size: 1, access: read-only
  Internal high-speed clock ready flag
  Field: HSIEN
  offset: 0, size: 1, access: read-write
  Internal high-speed clock enable
*/
volatile uint32_t CTRL;

/** PLL1CFG PLL1CFG (offset: 0x4)
  PLL configuration register
  access : read-write
  reset value : 0x24003010
  reset mask : 0xFFFFFFFF
  Field: PLLD
  offset: 24, size: 4, access: 
  Main PLL (PLL) division factor for USB
 OTG FS, SDIO and random number generator clocks
  Field: PLL1CLKS
  offset: 22, size: 1, access: 
  Main PLL(PLL) and audio PLL (PLLI2S) entry clock source
  Field: PLL1C
  offset: 16, size: 2, access: 
  Main PLL (PLL) division factor for main system clock
  Field: PLL1A
  offset: 6, size: 9, access: 
  Main PLL (PLL) multiplication factor for VCO
  Field: PLLB
  offset: 0, size: 6, access: 
  Division factor for the main PLL (PLL) and audio PLL (PLLI2S) input clock
*/
volatile uint32_t PLL1CFG;

/** CFG CFG (offset: 0x8)
  clock configuration register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MCO2SEL
  offset: 30, size: 2, access: read-write
  Microcontroller clock output 2
  Field: MCO2PSC
  offset: 27, size: 3, access: read-write
  MCO2 prescaler
  Field: MCO1PSC
  offset: 24, size: 3, access: read-write
  MCO1 prescaler
  Field: I2SSEL
  offset: 23, size: 1, access: read-write
  I2S clock selection
  Field: MCO1SEL
  offset: 21, size: 2, access: read-write
  Microcontroller clock output 1
  Field: RTCPSC
  offset: 16, size: 5, access: read-write
  HSE division factor for RTC clock
  Field: APB2PSC
  offset: 13, size: 3, access: read-write
  APB high-speed prescaler (APB2)
  Field: APB1PSC
  offset: 10, size: 3, access: read-write
  APB Low speed prescaler (APB1)
  Field: SDRAMPSC
  offset: 8, size: 2, access: read-write
  SDRAM Clock Prescaler Factor Configure
  Field: AHBPSC
  offset: 4, size: 4, access: read-write
  AHB prescaler
  Field: SCLKSWSTS1
  offset: 3, size: 1, access: read-only
  System clock switch status
  Field: SCLKSWSTS0
  offset: 2, size: 1, access: read-only
  System clock switch status
  Field: SCLKSEL1
  offset: 1, size: 1, access: read-write
  System clock switch
  Field: SCLKSEL0
  offset: 0, size: 1, access: read-write
  System clock switch
*/
volatile uint32_t CFG;

/** INT INT (offset: 0xc)
  clock interrupt register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CSSCLR
  offset: 23, size: 1, access: write-only
  Clock security system interrupt clear
  Field: PLL2RDYCLR
  offset: 21, size: 1, access: write-only
  PLLI2S ready interrupt clear
  Field: PLL1RDYCLR
  offset: 20, size: 1, access: write-only
  Main PLL(PLL) ready interrupt clear
  Field: HSERDYCLR
  offset: 19, size: 1, access: write-only
  HSE ready interrupt clear
  Field: HSIRDYCLR
  offset: 18, size: 1, access: write-only
  HSI ready interrupt clear
  Field: LSERDYCLR
  offset: 17, size: 1, access: write-only
  LSE ready interrupt clear
  Field: LSIRDYCLR
  offset: 16, size: 1, access: write-only
  LSI ready interrupt clear
  Field: PLL2RDYEN
  offset: 13, size: 1, access: read-write
  PLLI2S ready interrupt enable
  Field: PLL1RDYEN
  offset: 12, size: 1, access: read-write
  Main PLL (PLL) ready interrupt enable
  Field: HSERDYEN
  offset: 11, size: 1, access: read-write
  HSE ready interrupt enable
  Field: HSIRDYEN
  offset: 10, size: 1, access: read-write
  HSI ready interrupt enable
  Field: LSERDYEN
  offset: 9, size: 1, access: read-write
  LSE ready interrupt enable
  Field: LSIRDYEN
  offset: 8, size: 1, access: read-write
  LSI ready interrupt enable
  Field: CSSFLG
  offset: 7, size: 1, access: read-only
  Clock security system interrupt flag
  Field: PLL2RDYFLG
  offset: 5, size: 1, access: read-only
  PLLI2S ready interrupt flag
  Field: PLL1RDYFLG
  offset: 4, size: 1, access: read-only
  Main PLL (PLL) ready interrupt flag
  Field: HSERDYFLG
  offset: 3, size: 1, access: read-only
  HSE ready interrupt flag
  Field: HSIRDYFLG
  offset: 2, size: 1, access: read-only
  HSI ready interrupt flag
  Field: LSERDYFLG
  offset: 1, size: 1, access: read-only
  LSE ready interrupt flag
  Field: LSIRDYFLG
  offset: 0, size: 1, access: read-only
  LSI ready interrupt flag
*/
volatile uint32_t INT;

/** AHB1RST AHB1RST (offset: 0x10)
  AHB1 peripheral reset register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ENETRST
  offset: 25, size: 1, access: 
  Ethernet MAC reset
  Field: DMA2RST
  offset: 22, size: 1, access: 
  DMA2 reset
  Field: DMA1RST
  offset: 21, size: 1, access: 
  DMA2 reset
  Field: CRCRST
  offset: 12, size: 1, access: 
  CRC reset
  Field: PHRST
  offset: 7, size: 1, access: 
  IO port H reset
  Field: PERST
  offset: 4, size: 1, access: 
  IO port E reset
  Field: PDRST
  offset: 3, size: 1, access: 
  IO port D reset
  Field: PCRST
  offset: 2, size: 1, access: 
  IO port C reset
  Field: PBRST
  offset: 1, size: 1, access: 
  IO port B reset
  Field: PARST
  offset: 0, size: 1, access: 
  IO port A reset
*/
volatile uint32_t AHB1RST;

/** AHB2RST AHB2RST (offset: 0x14)
  AHB2 peripheral reset register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OTGFSRST
  offset: 7, size: 1, access: 
  USB OTG FS module reset
  Field: RNGRST
  offset: 6, size: 1, access: 
  Random number generator module reset
  Field: QSPIRST
  offset: 2, size: 1, access: 
  QSPI reset
*/
volatile uint32_t AHB2RST;

/** AHB3RST AHB3RST (offset: 0x18)
  AHB3 peripheral reset register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SMCRST
  offset: 0, size: 1, access: 
  Flexible static memory controller module reset
*/
volatile uint32_t AHB3RST;
volatile uint32_t reserved0;

/** APB1RST APB1RST (offset: 0x20)
  APB1 peripheral reset register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PWRRST
  offset: 28, size: 1, access: 
  Power interface reset
  Field: CAN2RST
  offset: 26, size: 1, access: 
  CAN2 reset
  Field: CAN1RST
  offset: 25, size: 1, access: 
  CAN1 reset
  Field: I2C3RST
  offset: 23, size: 1, access: 
  I2C3 reset
  Field: I2C2RST
  offset: 22, size: 1, access: 
  I2C 2 reset
  Field: I2C1RST
  offset: 21, size: 1, access: 
  I2C 1 reset
  Field: UART5RST
  offset: 20, size: 1, access: 
  USART 5 reset
  Field: UART4RST
  offset: 19, size: 1, access: 
  USART 4 reset
  Field: UART3RST
  offset: 18, size: 1, access: 
  USART 3 reset
  Field: UART2RST
  offset: 17, size: 1, access: 
  USART 2 reset
  Field: SPI3RST
  offset: 15, size: 1, access: 
  SPI 3 reset
  Field: SPI2RST
  offset: 14, size: 1, access: 
  SPI 2 reset
  Field: WWDTRST
  offset: 11, size: 1, access: 
  Window watchdog reset
  Field: TMR14RST
  offset: 8, size: 1, access: 
  TMR14 reset
  Field: TMR13RST
  offset: 7, size: 1, access: 
  TMR13 reset
  Field: TMR12RST
  offset: 6, size: 1, access: 
  TMR12 reset
  Field: TMR5RST
  offset: 3, size: 1, access: 
  TMR5 reset
  Field: TMR4RST
  offset: 2, size: 1, access: 
  TMR4 reset
  Field: TMR3RST
  offset: 1, size: 1, access: 
  TMR3 reset
  Field: TMR2RST
  offset: 0, size: 1, access: 
  TMR2 reset
*/
volatile uint32_t APB1RST;

/** APB2RST APB2RST (offset: 0x24)
  APB2 peripheral reset register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SPI5RST
  offset: 20, size: 1, access: 
  SPI5 reset
  Field: TMR11RST
  offset: 18, size: 1, access: 
  TMR11 reset
  Field: TMR10RST
  offset: 17, size: 1, access: 
  TMR10 reset
  Field: TMR9RST
  offset: 16, size: 1, access: 
  TMR9 reset
  Field: SYSCFGRST
  offset: 14, size: 1, access: 
  System configuration controller reset
  Field: SPI4RST
  offset: 13, size: 1, access: 
  SPI 4 reset
  Field: SPI1RST
  offset: 12, size: 1, access: 
  SPI 1 reset
  Field: SDIORST
  offset: 11, size: 1, access: 
  SDIO reset
  Field: ADCRST
  offset: 8, size: 1, access: 
  ADC interface reset (common to all ADCs)
  Field: USART6RST
  offset: 5, size: 1, access: 
  USART6 reset
  Field: USART1RST
  offset: 4, size: 1, access: 
  USART1 reset
  Field: TMR8RST
  offset: 1, size: 1, access: 
  TMR8 reset
  Field: TMR1RST
  offset: 0, size: 1, access: 
  TMR1 reset
*/
volatile uint32_t APB2RST;
volatile uint32_t reserved1[2];

/** AHB1CLKEN AHB1CLKEN (offset: 0x30)
  AHB1 peripheral clock register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DMA2EN
  offset: 22, size: 1, access: 
  DMA2 clock enable
  Field: DMA1EN
  offset: 21, size: 1, access: 
  DMA1 clock enable
  Field: CRCEN
  offset: 12, size: 1, access: 
  CRC clock enable
  Field: PHEN
  offset: 7, size: 1, access: 
  IO port H clock enable
  Field: PEEN
  offset: 4, size: 1, access: 
  IO port E clock enable
  Field: PDEN
  offset: 3, size: 1, access: 
  IO port D clock enable
  Field: PCEN
  offset: 2, size: 1, access: 
  IO port C clock enable
  Field: PBEN
  offset: 1, size: 1, access: 
  IO port B clock enable
  Field: PAEN
  offset: 0, size: 1, access: 
  IO port A clock enable
*/
volatile uint32_t AHB1CLKEN;

/** AHB2CLKEN AHB2CLKEN (offset: 0x34)
  AHB2 peripheral clock enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OTGFSEN
  offset: 7, size: 1, access: 
  USB OTG FS clock enable
  Field: RNGEN
  offset: 6, size: 1, access: 
  Random number generator clock enable
  Field: QSPIEN
  offset: 2, size: 1, access: 
  QSPI enable
*/
volatile uint32_t AHB2CLKEN;

/** AHB3CLKEN AHB3CLKEN (offset: 0x38)
  AHB3 peripheral clock enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SMCEN
  offset: 0, size: 1, access: 
  Flexible static memory controller module clock enable
*/
volatile uint32_t AHB3CLKEN;
volatile uint32_t reserved2;

/** APB1CLKEN APB1CLKEN (offset: 0x40)
  APB1 peripheral clock enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PWUEN
  offset: 28, size: 1, access: 
  Power interface clock enable
  Field: CAN2EN
  offset: 26, size: 1, access: 
  CAN 2 clock enable
  Field: CAN1EN
  offset: 25, size: 1, access: 
  CAN 1 clock enable
  Field: I2C3EN
  offset: 23, size: 1, access: 
  I2C3 clock enable
  Field: I2C2EN
  offset: 22, size: 1, access: 
  I2C2 clock enable
  Field: I2C1EN
  offset: 21, size: 1, access: 
  I2C1 clock enable
  Field: UART5EN
  offset: 20, size: 1, access: 
  UART5 clock enable
  Field: UART4EN
  offset: 19, size: 1, access: 
  UART4 clock enable
  Field: USART3EN
  offset: 18, size: 1, access: 
  USART3 clock enable
  Field: USART2EN
  offset: 17, size: 1, access: 
  USART 2 clock enable
  Field: SPI3EN
  offset: 15, size: 1, access: 
  SPI3 clock enable
  Field: SPI2EN
  offset: 14, size: 1, access: 
  SPI2 clock enable
  Field: WWDTEN
  offset: 11, size: 1, access: 
  Window watchdog clock enable
  Field: TMR14EN
  offset: 8, size: 1, access: 
  TMR14 clock enable
  Field: TMR13EN
  offset: 7, size: 1, access: 
  TMR13 clock enable
  Field: TMR12EN
  offset: 6, size: 1, access: 
  TMR12 clock enable
  Field: TMR5EN
  offset: 3, size: 1, access: 
  TMR5 clock enable
  Field: TMR4EN
  offset: 2, size: 1, access: 
  TMR4 clock enable
  Field: TMR3EN
  offset: 1, size: 1, access: 
  TMR3 clock enable
  Field: TMR2EN
  offset: 0, size: 1, access: 
  TMR2 clock enable
*/
volatile uint32_t APB1CLKEN;

/** APB2CLKEN APB2CLKEN (offset: 0x44)
  APB2 peripheral clock enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SPI5EN
  offset: 20, size: 1, access: 
  SPI5 clock enable
  Field: TMR11EN
  offset: 18, size: 1, access: 
  TMR11 clock enable
  Field: TMR10EN
  offset: 17, size: 1, access: 
  TMR10 clock enable
  Field: TMR9EN
  offset: 16, size: 1, access: 
  TMR9 clock enable
  Field: SYSCFGEN
  offset: 14, size: 1, access: 
  System configuration controller clock enable
  Field: SPI4EN
  offset: 13, size: 1, access: 
  SPI4 clock enable
  Field: SPI1EN
  offset: 12, size: 1, access: 
  SPI1 clock enable
  Field: SDIOEN
  offset: 11, size: 1, access: 
  SDIO clock enable
  Field: ADC2EN
  offset: 9, size: 1, access: 
  ADC2 clock enable
  Field: ADC1EN
  offset: 8, size: 1, access: 
  ADC1 clock enable
  Field: USART6EN
  offset: 5, size: 1, access: 
  USART6 clock enable
  Field: USART1EN
  offset: 4, size: 1, access: 
  USART1 clock enable
  Field: TMR8EN
  offset: 1, size: 1, access: 
  TMR8 clock enable
  Field: TMR1EN
  offset: 0, size: 1, access: 
  TMR1 clock enable
*/
volatile uint32_t APB2CLKEN;
volatile uint32_t reserved3[2];

/** LPAHB1CLKEN LPAHB1CLKEN (offset: 0x50)
  AHB1 peripheral clock enable in low power mode register
  access : read-write
  reset value : 0x61900F
  reset mask : 0xFFFFFFFF
  Field: DMA2EN
  offset: 22, size: 1, access: 
  DMA2 clock enable during Sleep mode
  Field: DMA1EN
  offset: 21, size: 1, access: 
  DMA1 clock enable during Sleep mode
  Field: SRAM1EN
  offset: 16, size: 1, access: 
  SRAM 1interface clock enable during Sleep mode
  Field: FMCEN
  offset: 15, size: 1, access: 
  Flash interface clock enable during Sleep mode
  Field: CRCEN
  offset: 12, size: 1, access: 
  CRC clock enable during Sleep mode
  Field: PHEN
  offset: 7, size: 1, access: 
  IO port H clock enable during Sleep mode
  Field: PEEN
  offset: 4, size: 1, access: 
  IO port E clock enable during Sleep mode
  Field: PDEN
  offset: 3, size: 1, access: 
  IO port D clock enable during Sleep mode
  Field: PCEN
  offset: 2, size: 1, access: 
  IO port C clock enable during Sleep mode
  Field: PBEN
  offset: 1, size: 1, access: 
  IO port B clock enable during Sleep mode
  Field: PAEN
  offset: 0, size: 1, access: 
  IO port A clock enable during sleep mode
*/
volatile uint32_t LPAHB1CLKEN;

/** LPAHB2CLKEN LPAHB2CLKEN (offset: 0x54)
  AHB2 peripheral clock enable in low power mode register
  access : read-write
  reset value : 0x80
  reset mask : 0xFFFFFFFF
  Field: OTGFSEN
  offset: 7, size: 1, access: 
  USB OTG FS clock enable during Sleep mode
  Field: RNGEN
  offset: 6, size: 1, access: 
  Random number generator clock enable during Sleep mode
  Field: QSPIEN
  offset: 2, size: 1, access: 
  QSPI enable during Sleep mode
*/
volatile uint32_t LPAHB2CLKEN;

/** LPAHB3CLKEN LPAHB3CLKEN (offset: 0x58)
  AHB3 peripheral clock enable in low power mode register
  access : read-write
  reset value : 0x1
  reset mask : 0xFFFFFFFF
  Field: SMCEN
  offset: 0, size: 1, access: 
  Flexible static memory controller module clock enable during Sleep mode
*/
volatile uint32_t LPAHB3CLKEN;
volatile uint32_t reserved4;

/** LPAPB1CLKEN LPAPB1CLKEN (offset: 0x60)
  APB1 peripheral clock enable in low power mode register
  access : read-write
  reset value : 0x10E2C80F
  reset mask : 0xFFFFFFFF
  Field: PWUEN
  offset: 28, size: 1, access: 
  Power interface clock enable during Sleep mode
  Field: CAN2EN
  offset: 26, size: 1, access: 
  CAN 2 clock enable during Sleep mode
  Field: CAN1EN
  offset: 25, size: 1, access: 
  CAN 1 clock enable during Sleep mode
  Field: I2C3EN
  offset: 23, size: 1, access: 
  I2C3 clock enable during Sleep mode
  Field: I2C2EN
  offset: 22, size: 1, access: 
  I2C2 clock enable during Sleep mode
  Field: I2C1EN
  offset: 21, size: 1, access: 
  I2C1 clock enable during Sleep mode
  Field: UART5EN
  offset: 20, size: 1, access: 
  UART5 clock enable during Sleep mode
  Field: UART4EN
  offset: 19, size: 1, access: 
  UART4 clock enable during Sleep mode
  Field: USART3EN
  offset: 18, size: 1, access: 
  USART3 clock enable during Sleep mode
  Field: USART2EN
  offset: 17, size: 1, access: 
  USART2 clock enable during Sleep mode
  Field: SPI3EN
  offset: 15, size: 1, access: 
  SPI3 clock enable during Sleep mode
  Field: SPI2EN
  offset: 14, size: 1, access: 
  SPI2 clock enable during Sleep mode
  Field: WWDTEN
  offset: 11, size: 1, access: 
  Window watchdog clock enable during Sleep mode
  Field: TMR14EN
  offset: 8, size: 1, access: 
  TMR14 clock enable during Sleep mode
  Field: TMR13EN
  offset: 7, size: 1, access: 
  TMR13 clock enable during Sleep mode
  Field: TMR12EN
  offset: 6, size: 1, access: 
  TMR12 clock enable during Sleep mode
  Field: TMR5EN
  offset: 3, size: 1, access: 
  TMR5 clock enable during Sleep mode
  Field: TMR4EN
  offset: 2, size: 1, access: 
  TMR4 clock enable during Sleep mode
  Field: TMR3EN
  offset: 1, size: 1, access: 
  TMR3 clock enable during Sleep mode
  Field: TMR2EN
  offset: 0, size: 1, access: 
  TMR2 clock enable during Sleep mode
*/
volatile uint32_t LPAPB1CLKEN;

/** LPAPB2CLKEN LPAPB2CLKEN (offset: 0x64)
  APB2 peripheral clock enabled in low power mode register
  access : read-write
  reset value : 0x77930
  reset mask : 0xFFFFFFFF
  Field: SPI5EN
  offset: 20, size: 1, access: 
  SPI5 clock enable during Sleep mode
  Field: TMR11EN
  offset: 18, size: 1, access: 
  TMR11 clock enable during Sleep mode
  Field: TMR10EN
  offset: 17, size: 1, access: 
  TMR10 clock enable during Sleep mode
  Field: TMR9EN
  offset: 16, size: 1, access: 
  TMR9 clock enable during sleep mode
  Field: SYSCFGEN
  offset: 14, size: 1, access: 
  System configuration controller clock enable during Sleep mode
  Field: SPI4EN
  offset: 13, size: 1, access: 
  SPI 4 clock enable during Sleep mode
  Field: SPI1EN
  offset: 12, size: 1, access: 
  SPI 1 clock enable during Sleep mode
  Field: SDIOEN
  offset: 11, size: 1, access: 
  SDIO clock enable during Sleep mode
  Field: ADC3EN
  offset: 10, size: 1, access: 
  ADC 3 clock enable during Sleep mode
  Field: ADC2EN
  offset: 9, size: 1, access: 
  ADC2 clock enable during Sleep mode
  Field: ADC1EN
  offset: 8, size: 1, access: 
  ADC1 clock enable during Sleep mode
  Field: USART6EN
  offset: 5, size: 1, access: 
  USART6 clock enable during Sleep mode
  Field: USART1EN
  offset: 4, size: 1, access: 
  USART1 clock enable during Sleep mode
  Field: TMR8EN
  offset: 1, size: 1, access: 
  TMR8 clock enable during Sleep mode
  Field: TMR1EN
  offset: 0, size: 1, access: 
  TMR1 clock enable during Sleep mode
*/
volatile uint32_t LPAPB2CLKEN;
volatile uint32_t reserved5[2];

/** BDCTRL BDCTRL (offset: 0x70)
  Backup domain control register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BDRST
  offset: 16, size: 1, access: read-write
  Backup domain software reset
  Field: RTCCLKEN
  offset: 15, size: 1, access: read-write
  RTC clock enable
  Field: RTCSRCSEL
  offset: 8, size: 2, access: read-write
  RTC clock source selection
  Field: LSESEL
  offset: 3, size: 1, access: read-write
  Low-Speed External Clock Bypass Mode Configure
  Field: LSEBCFG
  offset: 2, size: 1, access: read-write
  External low-speed oscillator bypass
  Field: LSERDYFLG
  offset: 1, size: 1, access: read-only
  External low-speed oscillator ready
  Field: LSEEN
  offset: 0, size: 1, access: read-write
  External low-speed oscillator enable
*/
volatile uint32_t BDCTRL;

/** CSTS CSTS (offset: 0x74)
  clock control &amp; status register
  reset value : 0xE000000
  reset mask : 0xFFFFFFFF
  Field: LPWRRSTFLG
  offset: 31, size: 1, access: read-write
  Low-power reset flag
  Field: WWDTRSTFLG
  offset: 30, size: 1, access: read-write
  Window watchdog reset flag
  Field: IWDTRSTFLG
  offset: 29, size: 1, access: read-write
  Independent watchdog reset flag
  Field: SWRSTFLG
  offset: 28, size: 1, access: read-write
  Software reset flag
  Field: PODRSTFLG
  offset: 27, size: 1, access: read-write
  POR/PDR reset flag
  Field: PINRSTFLG
  offset: 26, size: 1, access: read-write
  PIN reset flag
  Field: BORRSTFLG
  offset: 25, size: 1, access: read-write
  BOR reset flag
  Field: RSTFLGCLR
  offset: 24, size: 1, access: read-write
  Remove reset flag
  Field: LSIRDYFLG
  offset: 1, size: 1, access: read-only
  Internal low-speed oscillator ready
  Field: LSIEN
  offset: 0, size: 1, access: read-write
  Internal low-speed oscillator enable
*/
volatile uint32_t CSTS;
volatile uint32_t reserved6[2];

/** SSCCFG SSCCFG (offset: 0x80)
  spread spectrum clock generation register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SSEN
  offset: 31, size: 1, access: 
  Spread spectrum modulation enable
  Field: SSSEL
  offset: 30, size: 1, access: 
  Spread Select
  Field: STEP
  offset: 13, size: 15, access: 
  Incrementation step
  Field: MODPCFG
  offset: 0, size: 13, access: 
  Modulation period
*/
volatile uint32_t SSCCFG;

/** PLL2CFG PLL2CFG (offset: 0x84)
  PLLI2S configuration register
  access : read-write
  reset value : 0x24003000
  reset mask : 0xFFFFFFFF
  Field: PLL2C
  offset: 28, size: 3, access: 
  PLLI2S division factor for I2S clocks
  Field: PLL2A
  offset: 6, size: 9, access: 
  PLLI2S multiplication factor for VCO
  Field: PLL2B
  offset: 0, size: 6, access: 
  PLLI2S division factor for VCO
*/
volatile uint32_t PLL2CFG;
volatile uint32_t reserved7;

/** CFGSEL CFGSEL (offset: 0x8c)
  clock configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CLKPSEL
  offset: 24, size: 1, access: 
  Clock Prescaler Select
*/
volatile uint32_t CFGSEL;
} RCM_type;

#define RCM ((RCM_type *) 0x40023800)

#endif // HW_RCM_H
