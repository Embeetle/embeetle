#ifndef HW_EINT_H
#define HW_EINT_H
/** External interrupt/event controller */
/** Interrupt : TAMP_STAMP (Vector: 2) Tamper and TimeStamp interrupts through the EINTline22 */
/** Interrupt : EINT0 (Vector: 6) EINT Line0 interrupt */
/** Interrupt : EINT1 (Vector: 7) EINT Line1 interrupt */
/** Interrupt : EINT9_5 (Vector: 23) EINT Line[9:5] interrupts */
/** Interrupt : EINT2 (Vector: 8) EINT Line2 interrupt */
/** Interrupt : EINT15_10 (Vector: 40) EINT Line[15:10] interrupts */
/** Interrupt : EINT3 (Vector: 9) EINT Line3 interrupt */
/** Interrupt : EINT4 (Vector: 10) EINT Line4 interrupt */
/** Memory Block starting at 0x40013C00 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define EINT_IMASK_IMASK0_OFFSET                           0
#define EINT_IMASK_IMASK0_MASK                             1

#define EINT_IMASK_IMASK1_OFFSET                           1
#define EINT_IMASK_IMASK1_MASK                             2

#define EINT_IMASK_IMASK2_OFFSET                           2
#define EINT_IMASK_IMASK2_MASK                             4

#define EINT_IMASK_IMASK3_OFFSET                           3
#define EINT_IMASK_IMASK3_MASK                             8

#define EINT_IMASK_IMASK4_OFFSET                           4
#define EINT_IMASK_IMASK4_MASK                             0x10

#define EINT_IMASK_IMASK5_OFFSET                           5
#define EINT_IMASK_IMASK5_MASK                             0x20

#define EINT_IMASK_IMASK6_OFFSET                           6
#define EINT_IMASK_IMASK6_MASK                             0x40

#define EINT_IMASK_IMASK7_OFFSET                           7
#define EINT_IMASK_IMASK7_MASK                             0x80

#define EINT_IMASK_IMASK8_OFFSET                           8
#define EINT_IMASK_IMASK8_MASK                             0x100

#define EINT_IMASK_IMASK9_OFFSET                           9
#define EINT_IMASK_IMASK9_MASK                             0x200

#define EINT_IMASK_IMASK10_OFFSET                          10
#define EINT_IMASK_IMASK10_MASK                            0x400

#define EINT_IMASK_IMASK11_OFFSET                          11
#define EINT_IMASK_IMASK11_MASK                            0x800

#define EINT_IMASK_IMASK12_OFFSET                          12
#define EINT_IMASK_IMASK12_MASK                            0x1000

#define EINT_IMASK_IMASK13_OFFSET                          13
#define EINT_IMASK_IMASK13_MASK                            0x2000

#define EINT_IMASK_IMASK14_OFFSET                          14
#define EINT_IMASK_IMASK14_MASK                            0x4000

#define EINT_IMASK_IMASK15_OFFSET                          15
#define EINT_IMASK_IMASK15_MASK                            0x8000

#define EINT_IMASK_IMASK16_OFFSET                          16
#define EINT_IMASK_IMASK16_MASK                            0x10000

#define EINT_IMASK_IMASK17_OFFSET                          17
#define EINT_IMASK_IMASK17_MASK                            0x20000

#define EINT_IMASK_IMASK18_OFFSET                          18
#define EINT_IMASK_IMASK18_MASK                            0x40000

#define EINT_IMASK_IMASK21_OFFSET                          21
#define EINT_IMASK_IMASK21_MASK                            0x200000

#define EINT_IMASK_IMASK22_OFFSET                          22
#define EINT_IMASK_IMASK22_MASK                            0x400000

#define EINT_EMASK_EMASK0_OFFSET                           0
#define EINT_EMASK_EMASK0_MASK                             1

#define EINT_EMASK_EMASK1_OFFSET                           1
#define EINT_EMASK_EMASK1_MASK                             2

#define EINT_EMASK_EMASK2_OFFSET                           2
#define EINT_EMASK_EMASK2_MASK                             4

#define EINT_EMASK_EMASK3_OFFSET                           3
#define EINT_EMASK_EMASK3_MASK                             8

#define EINT_EMASK_EMASK4_OFFSET                           4
#define EINT_EMASK_EMASK4_MASK                             0x10

#define EINT_EMASK_EMASK5_OFFSET                           5
#define EINT_EMASK_EMASK5_MASK                             0x20

#define EINT_EMASK_EMASK6_OFFSET                           6
#define EINT_EMASK_EMASK6_MASK                             0x40

#define EINT_EMASK_EMASK7_OFFSET                           7
#define EINT_EMASK_EMASK7_MASK                             0x80

#define EINT_EMASK_EMASK8_OFFSET                           8
#define EINT_EMASK_EMASK8_MASK                             0x100

#define EINT_EMASK_EMASK9_OFFSET                           9
#define EINT_EMASK_EMASK9_MASK                             0x200

#define EINT_EMASK_EMASK10_OFFSET                          10
#define EINT_EMASK_EMASK10_MASK                            0x400

#define EINT_EMASK_EMASK11_OFFSET                          11
#define EINT_EMASK_EMASK11_MASK                            0x800

#define EINT_EMASK_EMASK12_OFFSET                          12
#define EINT_EMASK_EMASK12_MASK                            0x1000

#define EINT_EMASK_EMASK13_OFFSET                          13
#define EINT_EMASK_EMASK13_MASK                            0x2000

#define EINT_EMASK_EMASK14_OFFSET                          14
#define EINT_EMASK_EMASK14_MASK                            0x4000

#define EINT_EMASK_EMASK15_OFFSET                          15
#define EINT_EMASK_EMASK15_MASK                            0x8000

#define EINT_EMASK_EMASK16_OFFSET                          16
#define EINT_EMASK_EMASK16_MASK                            0x10000

#define EINT_EMASK_EMASK17_OFFSET                          17
#define EINT_EMASK_EMASK17_MASK                            0x20000

#define EINT_EMASK_EMASK18_OFFSET                          18
#define EINT_EMASK_EMASK18_MASK                            0x40000

#define EINT_EMASK_EMASK21_OFFSET                          21
#define EINT_EMASK_EMASK21_MASK                            0x200000

#define EINT_EMASK_EMASK22_OFFSET                          22
#define EINT_EMASK_EMASK22_MASK                            0x400000

#define EINT_RTEN_RTEN0_OFFSET                             0
#define EINT_RTEN_RTEN0_MASK                               1

#define EINT_RTEN_RTEN1_OFFSET                             1
#define EINT_RTEN_RTEN1_MASK                               2

#define EINT_RTEN_RTEN2_OFFSET                             2
#define EINT_RTEN_RTEN2_MASK                               4

#define EINT_RTEN_RTEN3_OFFSET                             3
#define EINT_RTEN_RTEN3_MASK                               8

#define EINT_RTEN_RTEN4_OFFSET                             4
#define EINT_RTEN_RTEN4_MASK                               0x10

#define EINT_RTEN_RTEN5_OFFSET                             5
#define EINT_RTEN_RTEN5_MASK                               0x20

#define EINT_RTEN_RTEN6_OFFSET                             6
#define EINT_RTEN_RTEN6_MASK                               0x40

#define EINT_RTEN_RTEN7_OFFSET                             7
#define EINT_RTEN_RTEN7_MASK                               0x80

#define EINT_RTEN_RTEN8_OFFSET                             8
#define EINT_RTEN_RTEN8_MASK                               0x100

#define EINT_RTEN_RTEN9_OFFSET                             9
#define EINT_RTEN_RTEN9_MASK                               0x200

#define EINT_RTEN_RTEN10_OFFSET                            10
#define EINT_RTEN_RTEN10_MASK                              0x400

#define EINT_RTEN_RTEN11_OFFSET                            11
#define EINT_RTEN_RTEN11_MASK                              0x800

#define EINT_RTEN_RTEN12_OFFSET                            12
#define EINT_RTEN_RTEN12_MASK                              0x1000

#define EINT_RTEN_RTEN13_OFFSET                            13
#define EINT_RTEN_RTEN13_MASK                              0x2000

#define EINT_RTEN_RTEN14_OFFSET                            14
#define EINT_RTEN_RTEN14_MASK                              0x4000

#define EINT_RTEN_RTEN15_OFFSET                            15
#define EINT_RTEN_RTEN15_MASK                              0x8000

#define EINT_RTEN_RTEN16_OFFSET                            16
#define EINT_RTEN_RTEN16_MASK                              0x10000

#define EINT_RTEN_RTEN17_OFFSET                            17
#define EINT_RTEN_RTEN17_MASK                              0x20000

#define EINT_RTEN_RTEN18_OFFSET                            18
#define EINT_RTEN_RTEN18_MASK                              0x40000

#define EINT_RTEN_RTEN21_OFFSET                            21
#define EINT_RTEN_RTEN21_MASK                              0x200000

#define EINT_RTEN_RTEN22_OFFSET                            22
#define EINT_RTEN_RTEN22_MASK                              0x400000

#define EINT_FTEN_FTEN0_OFFSET                             0
#define EINT_FTEN_FTEN0_MASK                               1

#define EINT_FTEN_FTEN1_OFFSET                             1
#define EINT_FTEN_FTEN1_MASK                               2

#define EINT_FTEN_FTEN2_OFFSET                             2
#define EINT_FTEN_FTEN2_MASK                               4

#define EINT_FTEN_FTEN3_OFFSET                             3
#define EINT_FTEN_FTEN3_MASK                               8

#define EINT_FTEN_FTEN4_OFFSET                             4
#define EINT_FTEN_FTEN4_MASK                               0x10

#define EINT_FTEN_FTEN5_OFFSET                             5
#define EINT_FTEN_FTEN5_MASK                               0x20

#define EINT_FTEN_FTEN6_OFFSET                             6
#define EINT_FTEN_FTEN6_MASK                               0x40

#define EINT_FTEN_FTEN7_OFFSET                             7
#define EINT_FTEN_FTEN7_MASK                               0x80

#define EINT_FTEN_FTEN8_OFFSET                             8
#define EINT_FTEN_FTEN8_MASK                               0x100

#define EINT_FTEN_FTEN9_OFFSET                             9
#define EINT_FTEN_FTEN9_MASK                               0x200

#define EINT_FTEN_FTEN10_OFFSET                            10
#define EINT_FTEN_FTEN10_MASK                              0x400

#define EINT_FTEN_FTEN11_OFFSET                            11
#define EINT_FTEN_FTEN11_MASK                              0x800

#define EINT_FTEN_FTEN12_OFFSET                            12
#define EINT_FTEN_FTEN12_MASK                              0x1000

#define EINT_FTEN_FTEN13_OFFSET                            13
#define EINT_FTEN_FTEN13_MASK                              0x2000

#define EINT_FTEN_FTEN14_OFFSET                            14
#define EINT_FTEN_FTEN14_MASK                              0x4000

#define EINT_FTEN_FTEN15_OFFSET                            15
#define EINT_FTEN_FTEN15_MASK                              0x8000

#define EINT_FTEN_FTEN16_OFFSET                            16
#define EINT_FTEN_FTEN16_MASK                              0x10000

#define EINT_FTEN_FTEN17_OFFSET                            17
#define EINT_FTEN_FTEN17_MASK                              0x20000

#define EINT_FTEN_FTEN18_OFFSET                            18
#define EINT_FTEN_FTEN18_MASK                              0x40000

#define EINT_FTEN_FTEN21_OFFSET                            21
#define EINT_FTEN_FTEN21_MASK                              0x200000

#define EINT_FTEN_FTEN22_OFFSET                            22
#define EINT_FTEN_FTEN22_MASK                              0x400000

#define EINT_SWINTE_SWINTE0_OFFSET                         0
#define EINT_SWINTE_SWINTE0_MASK                           1

#define EINT_SWINTE_SWINTE1_OFFSET                         1
#define EINT_SWINTE_SWINTE1_MASK                           2

#define EINT_SWINTE_SWINTE2_OFFSET                         2
#define EINT_SWINTE_SWINTE2_MASK                           4

#define EINT_SWINTE_SWINTE3_OFFSET                         3
#define EINT_SWINTE_SWINTE3_MASK                           8

#define EINT_SWINTE_SWINTE4_OFFSET                         4
#define EINT_SWINTE_SWINTE4_MASK                           0x10

#define EINT_SWINTE_SWINTE5_OFFSET                         5
#define EINT_SWINTE_SWINTE5_MASK                           0x20

#define EINT_SWINTE_SWINTE6_OFFSET                         6
#define EINT_SWINTE_SWINTE6_MASK                           0x40

#define EINT_SWINTE_SWINTE7_OFFSET                         7
#define EINT_SWINTE_SWINTE7_MASK                           0x80

#define EINT_SWINTE_SWINTE8_OFFSET                         8
#define EINT_SWINTE_SWINTE8_MASK                           0x100

#define EINT_SWINTE_SWINTE9_OFFSET                         9
#define EINT_SWINTE_SWINTE9_MASK                           0x200

#define EINT_SWINTE_SWINTE10_OFFSET                        10
#define EINT_SWINTE_SWINTE10_MASK                          0x400

#define EINT_SWINTE_SWINTE11_OFFSET                        11
#define EINT_SWINTE_SWINTE11_MASK                          0x800

#define EINT_SWINTE_SWINTE12_OFFSET                        12
#define EINT_SWINTE_SWINTE12_MASK                          0x1000

#define EINT_SWINTE_SWINTE13_OFFSET                        13
#define EINT_SWINTE_SWINTE13_MASK                          0x2000

#define EINT_SWINTE_SWINTE14_OFFSET                        14
#define EINT_SWINTE_SWINTE14_MASK                          0x4000

#define EINT_SWINTE_SWINTE15_OFFSET                        15
#define EINT_SWINTE_SWINTE15_MASK                          0x8000

#define EINT_SWINTE_SWINTE16_OFFSET                        16
#define EINT_SWINTE_SWINTE16_MASK                          0x10000

#define EINT_SWINTE_SWINTE17_OFFSET                        17
#define EINT_SWINTE_SWINTE17_MASK                          0x20000

#define EINT_SWINTE_SWINTE18_OFFSET                        18
#define EINT_SWINTE_SWINTE18_MASK                          0x40000

#define EINT_SWINTE_SWINTE21_OFFSET                        21
#define EINT_SWINTE_SWINTE21_MASK                          0x200000

#define EINT_SWINTE_SWINTE22_OFFSET                        22
#define EINT_SWINTE_SWINTE22_MASK                          0x400000

#define EINT_IPEND_IPEND0_OFFSET                           0
#define EINT_IPEND_IPEND0_MASK                             1

#define EINT_IPEND_IPEND1_OFFSET                           1
#define EINT_IPEND_IPEND1_MASK                             2

#define EINT_IPEND_IPEND2_OFFSET                           2
#define EINT_IPEND_IPEND2_MASK                             4

#define EINT_IPEND_IPEND3_OFFSET                           3
#define EINT_IPEND_IPEND3_MASK                             8

#define EINT_IPEND_IPEND4_OFFSET                           4
#define EINT_IPEND_IPEND4_MASK                             0x10

#define EINT_IPEND_IPEND5_OFFSET                           5
#define EINT_IPEND_IPEND5_MASK                             0x20

#define EINT_IPEND_IPEND6_OFFSET                           6
#define EINT_IPEND_IPEND6_MASK                             0x40

#define EINT_IPEND_IPEND7_OFFSET                           7
#define EINT_IPEND_IPEND7_MASK                             0x80

#define EINT_IPEND_IPEND8_OFFSET                           8
#define EINT_IPEND_IPEND8_MASK                             0x100

#define EINT_IPEND_IPEND9_OFFSET                           9
#define EINT_IPEND_IPEND9_MASK                             0x200

#define EINT_IPEND_IPEND10_OFFSET                          10
#define EINT_IPEND_IPEND10_MASK                            0x400

#define EINT_IPEND_IPEND11_OFFSET                          11
#define EINT_IPEND_IPEND11_MASK                            0x800

#define EINT_IPEND_IPEND12_OFFSET                          12
#define EINT_IPEND_IPEND12_MASK                            0x1000

#define EINT_IPEND_IPEND13_OFFSET                          13
#define EINT_IPEND_IPEND13_MASK                            0x2000

#define EINT_IPEND_IPEND14_OFFSET                          14
#define EINT_IPEND_IPEND14_MASK                            0x4000

#define EINT_IPEND_IPEND15_OFFSET                          15
#define EINT_IPEND_IPEND15_MASK                            0x8000

#define EINT_IPEND_IPEND16_OFFSET                          16
#define EINT_IPEND_IPEND16_MASK                            0x10000

#define EINT_IPEND_IPEND17_OFFSET                          17
#define EINT_IPEND_IPEND17_MASK                            0x20000

#define EINT_IPEND_IPEND18_OFFSET                          18
#define EINT_IPEND_IPEND18_MASK                            0x40000

#define EINT_IPEND_IPEND21_OFFSET                          21
#define EINT_IPEND_IPEND21_MASK                            0x200000

#define EINT_IPEND_IPEND22_OFFSET                          22
#define EINT_IPEND_IPEND22_MASK                            0x400000


typedef struct
{

/** IMASK IMASK (offset: 0x0)
  Interrupt mask register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IMASK0
  offset: 0, size: 1, access: 
  Interrupt Mask on line 0
  Field: IMASK1
  offset: 1, size: 1, access: 
  Interrupt Mask on line 1
  Field: IMASK2
  offset: 2, size: 1, access: 
  Interrupt Mask on line 2
  Field: IMASK3
  offset: 3, size: 1, access: 
  Interrupt Mask on line 3
  Field: IMASK4
  offset: 4, size: 1, access: 
  Interrupt Mask on line 4
  Field: IMASK5
  offset: 5, size: 1, access: 
  Interrupt Mask on line 5
  Field: IMASK6
  offset: 6, size: 1, access: 
  Interrupt Mask on line 6
  Field: IMASK7
  offset: 7, size: 1, access: 
  Interrupt Mask on line 7
  Field: IMASK8
  offset: 8, size: 1, access: 
  Interrupt Mask on line 8
  Field: IMASK9
  offset: 9, size: 1, access: 
  Interrupt Mask on line 9
  Field: IMASK10
  offset: 10, size: 1, access: 
  Interrupt Mask on line 10
  Field: IMASK11
  offset: 11, size: 1, access: 
  Interrupt Mask on line 11
  Field: IMASK12
  offset: 12, size: 1, access: 
  Interrupt Mask on line 12
  Field: IMASK13
  offset: 13, size: 1, access: 
  Interrupt Mask on line 13
  Field: IMASK14
  offset: 14, size: 1, access: 
  Interrupt Mask on line 14
  Field: IMASK15
  offset: 15, size: 1, access: 
  Interrupt Mask on line 15
  Field: IMASK16
  offset: 16, size: 1, access: 
  Interrupt Mask on line 16
  Field: IMASK17
  offset: 17, size: 1, access: 
  Interrupt Mask on line 17
  Field: IMASK18
  offset: 18, size: 1, access: 
  Interrupt Mask on line 18
  Field: IMASK21
  offset: 21, size: 1, access: 
  Interrupt Mask on line 21
  Field: IMASK22
  offset: 22, size: 1, access: 
  Interrupt Mask on line 22
*/
volatile uint32_t IMASK;

/** EMASK EMASK (offset: 0x4)
  Event mask register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EMASK0
  offset: 0, size: 1, access: 
  Event Mask on line 0
  Field: EMASK1
  offset: 1, size: 1, access: 
  Event Mask on line 1
  Field: EMASK2
  offset: 2, size: 1, access: 
  Event Mask on line 2
  Field: EMASK3
  offset: 3, size: 1, access: 
  Event Mask on line 3
  Field: EMASK4
  offset: 4, size: 1, access: 
  Event Mask on line 4
  Field: EMASK5
  offset: 5, size: 1, access: 
  Event Mask on line 5
  Field: EMASK6
  offset: 6, size: 1, access: 
  Event Mask on line 6
  Field: EMASK7
  offset: 7, size: 1, access: 
  Event Mask on line 7
  Field: EMASK8
  offset: 8, size: 1, access: 
  Event Mask on line 8
  Field: EMASK9
  offset: 9, size: 1, access: 
  Event Mask on line 9
  Field: EMASK10
  offset: 10, size: 1, access: 
  Event Mask on line 10
  Field: EMASK11
  offset: 11, size: 1, access: 
  Event Mask on line 11
  Field: EMASK12
  offset: 12, size: 1, access: 
  Event Mask on line 12
  Field: EMASK13
  offset: 13, size: 1, access: 
  Event Mask on line 13
  Field: EMASK14
  offset: 14, size: 1, access: 
  Event Mask on line 14
  Field: EMASK15
  offset: 15, size: 1, access: 
  Event Mask on line 15
  Field: EMASK16
  offset: 16, size: 1, access: 
  Event Mask on line 16
  Field: EMASK17
  offset: 17, size: 1, access: 
  Event Mask on line 17
  Field: EMASK18
  offset: 18, size: 1, access: 
  Event Mask on line 18
  Field: EMASK21
  offset: 21, size: 1, access: 
  Event Mask on line 21
  Field: EMASK22
  offset: 22, size: 1, access: 
  Event Mask on line 22
*/
volatile uint32_t EMASK;

/** RTEN RTEN (offset: 0x8)
  Rising Trigger selection register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RTEN0
  offset: 0, size: 1, access: 
  Rising trigger event configuration of line 0
  Field: RTEN1
  offset: 1, size: 1, access: 
  Rising trigger event configuration of line 1
  Field: RTEN2
  offset: 2, size: 1, access: 
  Rising trigger event configuration of line 2
  Field: RTEN3
  offset: 3, size: 1, access: 
  Rising trigger event configuration of line 3
  Field: RTEN4
  offset: 4, size: 1, access: 
  Rising trigger event configuration of line 4
  Field: RTEN5
  offset: 5, size: 1, access: 
  Rising trigger event configuration of line 5
  Field: RTEN6
  offset: 6, size: 1, access: 
  Rising trigger event configuration of line 6
  Field: RTEN7
  offset: 7, size: 1, access: 
  Rising trigger event configuration of line 7
  Field: RTEN8
  offset: 8, size: 1, access: 
  Rising trigger event configuration of line 8
  Field: RTEN9
  offset: 9, size: 1, access: 
  Rising trigger event configuration of line 9
  Field: RTEN10
  offset: 10, size: 1, access: 
  Rising trigger event configuration of line 10
  Field: RTEN11
  offset: 11, size: 1, access: 
  Rising trigger event configuration of line 11
  Field: RTEN12
  offset: 12, size: 1, access: 
  Rising trigger event configuration of line 12
  Field: RTEN13
  offset: 13, size: 1, access: 
  Rising trigger event configuration of line 13
  Field: RTEN14
  offset: 14, size: 1, access: 
  Rising trigger event configuration of line 14
  Field: RTEN15
  offset: 15, size: 1, access: 
  Rising trigger event configuration of line 15
  Field: RTEN16
  offset: 16, size: 1, access: 
  Rising trigger event configuration of line 16
  Field: RTEN17
  offset: 17, size: 1, access: 
  Rising trigger event configuration of line 17
  Field: RTEN18
  offset: 18, size: 1, access: 
  Rising trigger event configuration of line 18
  Field: RTEN21
  offset: 21, size: 1, access: 
  Rising trigger event configuration of line 21
  Field: RTEN22
  offset: 22, size: 1, access: 
  Rising trigger event configuration of line 22
*/
volatile uint32_t RTEN;

/** FTEN FTEN (offset: 0xc)
  Falling Trigger selection register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FTEN0
  offset: 0, size: 1, access: 
  Falling trigger event configuration of line 0
  Field: FTEN1
  offset: 1, size: 1, access: 
  Falling trigger event configuration of line 1
  Field: FTEN2
  offset: 2, size: 1, access: 
  Falling trigger event configuration of line 2
  Field: FTEN3
  offset: 3, size: 1, access: 
  Falling trigger event configuration of line 3
  Field: FTEN4
  offset: 4, size: 1, access: 
  Falling trigger event configuration of line 4
  Field: FTEN5
  offset: 5, size: 1, access: 
  Falling trigger event configuration of line 5
  Field: FTEN6
  offset: 6, size: 1, access: 
  Falling trigger event configuration of line 6
  Field: FTEN7
  offset: 7, size: 1, access: 
  Falling trigger event configuration of line 7
  Field: FTEN8
  offset: 8, size: 1, access: 
  Falling trigger event configuration of line 8
  Field: FTEN9
  offset: 9, size: 1, access: 
  Falling trigger event configuration of line 9
  Field: FTEN10
  offset: 10, size: 1, access: 
  Falling trigger event configuration of line 10
  Field: FTEN11
  offset: 11, size: 1, access: 
  Falling trigger event configuration of line 11
  Field: FTEN12
  offset: 12, size: 1, access: 
  Falling trigger event configuration of line 12
  Field: FTEN13
  offset: 13, size: 1, access: 
  Falling trigger event configuration of line 13
  Field: FTEN14
  offset: 14, size: 1, access: 
  Falling trigger event configuration of line 14
  Field: FTEN15
  offset: 15, size: 1, access: 
  Falling trigger event configuration of line 15
  Field: FTEN16
  offset: 16, size: 1, access: 
  Falling trigger event configuration of line 16
  Field: FTEN17
  offset: 17, size: 1, access: 
  Falling trigger event configuration of line 17
  Field: FTEN18
  offset: 18, size: 1, access: 
  Falling trigger event configuration of line 18
  Field: FTEN21
  offset: 21, size: 1, access: 
  Falling trigger event configuration of line 21
  Field: FTEN22
  offset: 22, size: 1, access: 
  Falling trigger event configuration of line 22
*/
volatile uint32_t FTEN;

/** SWINTE SWINTE (offset: 0x10)
  Software interrupt event register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SWINTE0
  offset: 0, size: 1, access: 
  Software Interrupt on line 0
  Field: SWINTE1
  offset: 1, size: 1, access: 
  Software Interrupt on line 1
  Field: SWINTE2
  offset: 2, size: 1, access: 
  Software Interrupt on line 2
  Field: SWINTE3
  offset: 3, size: 1, access: 
  Software Interrupt on line 3
  Field: SWINTE4
  offset: 4, size: 1, access: 
  Software Interrupt on line 4
  Field: SWINTE5
  offset: 5, size: 1, access: 
  Software Interrupt on line 5
  Field: SWINTE6
  offset: 6, size: 1, access: 
  Software Interrupt on line 6
  Field: SWINTE7
  offset: 7, size: 1, access: 
  Software Interrupt on line 7
  Field: SWINTE8
  offset: 8, size: 1, access: 
  Software Interrupt on line 8
  Field: SWINTE9
  offset: 9, size: 1, access: 
  Software Interrupt on line 9
  Field: SWINTE10
  offset: 10, size: 1, access: 
  Software Interrupt on line 10
  Field: SWINTE11
  offset: 11, size: 1, access: 
  Software Interrupt on line 11
  Field: SWINTE12
  offset: 12, size: 1, access: 
  Software Interrupt on line 12
  Field: SWINTE13
  offset: 13, size: 1, access: 
  Software Interrupt on line 13
  Field: SWINTE14
  offset: 14, size: 1, access: 
  Software Interrupt on line 14
  Field: SWINTE15
  offset: 15, size: 1, access: 
  Software Interrupt on line 15
  Field: SWINTE16
  offset: 16, size: 1, access: 
  Software Interrupt on line 16
  Field: SWINTE17
  offset: 17, size: 1, access: 
  Software Interrupt on line 17
  Field: SWINTE18
  offset: 18, size: 1, access: 
  Software Interrupt on line 18
  Field: SWINTE21
  offset: 21, size: 1, access: 
  Software Interrupt on line 21
  Field: SWINTE22
  offset: 22, size: 1, access: 
  Software Interrupt on line 22
*/
volatile uint32_t SWINTE;

/** IPEND IPEND (offset: 0x14)
  Pending register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPEND0
  offset: 0, size: 1, access: 
  Pending bit 0
  Field: IPEND1
  offset: 1, size: 1, access: 
  Pending bit 1
  Field: IPEND2
  offset: 2, size: 1, access: 
  Pending bit 2
  Field: IPEND3
  offset: 3, size: 1, access: 
  Pending bit 3
  Field: IPEND4
  offset: 4, size: 1, access: 
  Pending bit 4
  Field: IPEND5
  offset: 5, size: 1, access: 
  Pending bit 5
  Field: IPEND6
  offset: 6, size: 1, access: 
  Pending bit 6
  Field: IPEND7
  offset: 7, size: 1, access: 
  Pending bit 7
  Field: IPEND8
  offset: 8, size: 1, access: 
  Pending bit 8
  Field: IPEND9
  offset: 9, size: 1, access: 
  Pending bit 9
  Field: IPEND10
  offset: 10, size: 1, access: 
  Pending bit 10
  Field: IPEND11
  offset: 11, size: 1, access: 
  Pending bit 11
  Field: IPEND12
  offset: 12, size: 1, access: 
  Pending bit 12
  Field: IPEND13
  offset: 13, size: 1, access: 
  Pending bit 13
  Field: IPEND14
  offset: 14, size: 1, access: 
  Pending bit 14
  Field: IPEND15
  offset: 15, size: 1, access: 
  Pending bit 15
  Field: IPEND16
  offset: 16, size: 1, access: 
  Pending bit 16
  Field: IPEND17
  offset: 17, size: 1, access: 
  Pending bit 17
  Field: IPEND18
  offset: 18, size: 1, access: 
  Pending bit 18
  Field: IPEND21
  offset: 21, size: 1, access: 
  Pending bit 21
  Field: IPEND22
  offset: 22, size: 1, access: 
  Pending bit 22
*/
volatile uint32_t IPEND;
} EINT_type;

#define EINT ((EINT_type *) 0x40013C00)

#endif // HW_EINT_H
