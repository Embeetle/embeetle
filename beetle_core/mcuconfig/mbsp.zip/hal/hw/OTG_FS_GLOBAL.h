#ifndef HW_OTG_FS_GLOBAL_H
#define HW_OTG_FS_GLOBAL_H
/** USB on the go full speed */
/** Interrupt : OTG_FS (Vector: 67) USB On The Go FS global interrupt */
/** Interrupt : OTG_FS_WKUP (Vector: 42) USB On-The-Go FS Wakeup through EINT line interrupt */
/** Memory Block starting at 0x50000000 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define OTG_FS_GLOBAL_GCTRLSTS_SREQSUC_OFFSET              0
#define OTG_FS_GLOBAL_GCTRLSTS_SREQSUC_MASK                1

#define OTG_FS_GLOBAL_GCTRLSTS_SREQ_OFFSET                 1
#define OTG_FS_GLOBAL_GCTRLSTS_SREQ_MASK                   2

#define OTG_FS_GLOBAL_GCTRLSTS_HNSUC_OFFSET                8
#define OTG_FS_GLOBAL_GCTRLSTS_HNSUC_MASK                  0x100

#define OTG_FS_GLOBAL_GCTRLSTS_HNPREQ_OFFSET               9
#define OTG_FS_GLOBAL_GCTRLSTS_HNPREQ_MASK                 0x200

#define OTG_FS_GLOBAL_GCTRLSTS_HHNPEN_OFFSET               10
#define OTG_FS_GLOBAL_GCTRLSTS_HHNPEN_MASK                 0x400

#define OTG_FS_GLOBAL_GCTRLSTS_DHNPEN_OFFSET               11
#define OTG_FS_GLOBAL_GCTRLSTS_DHNPEN_MASK                 0x800

#define OTG_FS_GLOBAL_GCTRLSTS_CIDSTS_OFFSET               16
#define OTG_FS_GLOBAL_GCTRLSTS_CIDSTS_MASK                 0x10000

#define OTG_FS_GLOBAL_GCTRLSTS_LSDEBT_OFFSET               17
#define OTG_FS_GLOBAL_GCTRLSTS_LSDEBT_MASK                 0x20000

#define OTG_FS_GLOBAL_GCTRLSTS_ASVD_OFFSET                 18
#define OTG_FS_GLOBAL_GCTRLSTS_ASVD_MASK                   0x40000

#define OTG_FS_GLOBAL_GCTRLSTS_BSVD_OFFSET                 19
#define OTG_FS_GLOBAL_GCTRLSTS_BSVD_MASK                   0x80000

#define OTG_FS_GLOBAL_GINT_SEFLG_OFFSET                    2
#define OTG_FS_GLOBAL_GINT_SEFLG_MASK                      4

#define OTG_FS_GLOBAL_GINT_SREQSUCCHG_OFFSET               8
#define OTG_FS_GLOBAL_GINT_SREQSUCCHG_MASK                 0x100

#define OTG_FS_GLOBAL_GINT_HNSUCCHG_OFFSET                 9
#define OTG_FS_GLOBAL_GINT_HNSUCCHG_MASK                   0x200

#define OTG_FS_GLOBAL_GINT_HNFLG_OFFSET                    17
#define OTG_FS_GLOBAL_GINT_HNFLG_MASK                      0x20000

#define OTG_FS_GLOBAL_GINT_ADTOFLG_OFFSET                  18
#define OTG_FS_GLOBAL_GINT_ADTOFLG_MASK                    0x40000

#define OTG_FS_GLOBAL_GINT_DEBDFLG_OFFSET                  19
#define OTG_FS_GLOBAL_GINT_DEBDFLG_MASK                    0x80000

#define OTG_FS_GLOBAL_GAHBCFG_GINTMASK_OFFSET              0
#define OTG_FS_GLOBAL_GAHBCFG_GINTMASK_MASK                1

#define OTG_FS_GLOBAL_GAHBCFG_TXFEL_OFFSET                 7
#define OTG_FS_GLOBAL_GAHBCFG_TXFEL_MASK                   0x80

#define OTG_FS_GLOBAL_GAHBCFG_PTXFEL_OFFSET                8
#define OTG_FS_GLOBAL_GAHBCFG_PTXFEL_MASK                  0x100

#define OTG_FS_GLOBAL_GUSBCFG_SEFLG_OFFSET                 0
#define OTG_FS_GLOBAL_GUSBCFG_SEFLG_MASK                   7

#define OTG_FS_GLOBAL_GUSBCFG_FSSTSEL_OFFSET               6
#define OTG_FS_GLOBAL_GUSBCFG_FSSTSEL_MASK                 0x40

#define OTG_FS_GLOBAL_GUSBCFG_SRPEN_OFFSET                 8
#define OTG_FS_GLOBAL_GUSBCFG_SRPEN_MASK                   0x100

#define OTG_FS_GLOBAL_GUSBCFG_HNPEN_OFFSET                 9
#define OTG_FS_GLOBAL_GUSBCFG_HNPEN_MASK                   0x200

#define OTG_FS_GLOBAL_GUSBCFG_TRTIM_OFFSET                 10
#define OTG_FS_GLOBAL_GUSBCFG_TRTIM_MASK                   0x3c00

#define OTG_FS_GLOBAL_GUSBCFG_FHMODE_OFFSET                29
#define OTG_FS_GLOBAL_GUSBCFG_FHMODE_MASK                  0x20000000

#define OTG_FS_GLOBAL_GUSBCFG_FDMODE_OFFSET                30
#define OTG_FS_GLOBAL_GUSBCFG_FDMODE_MASK                  0x40000000

#define OTG_FS_GLOBAL_GUSBCFG_CTXP_OFFSET                  31
#define OTG_FS_GLOBAL_GUSBCFG_CTXP_MASK                    0x80000000

#define OTG_FS_GLOBAL_GRSTCTRL_CSRST_OFFSET                0
#define OTG_FS_GLOBAL_GRSTCTRL_CSRST_MASK                  1

#define OTG_FS_GLOBAL_GRSTCTRL_HSRST_OFFSET                1
#define OTG_FS_GLOBAL_GRSTCTRL_HSRST_MASK                  2

#define OTG_FS_GLOBAL_GRSTCTRL_HFCNTRST_OFFSET             2
#define OTG_FS_GLOBAL_GRSTCTRL_HFCNTRST_MASK               4

#define OTG_FS_GLOBAL_GRSTCTRL_RXFFLU_OFFSET               4
#define OTG_FS_GLOBAL_GRSTCTRL_RXFFLU_MASK                 0x10

#define OTG_FS_GLOBAL_GRSTCTRL_TXFFLU_OFFSET               5
#define OTG_FS_GLOBAL_GRSTCTRL_TXFFLU_MASK                 0x20

#define OTG_FS_GLOBAL_GRSTCTRL_TXFNUM_OFFSET               6
#define OTG_FS_GLOBAL_GRSTCTRL_TXFNUM_MASK                 0x7c0

#define OTG_FS_GLOBAL_GRSTCTRL_AHBMIDL_OFFSET              31
#define OTG_FS_GLOBAL_GRSTCTRL_AHBMIDL_MASK                0x80000000

#define OTG_FS_GLOBAL_GCINT_CURMOSEL_OFFSET                0
#define OTG_FS_GLOBAL_GCINT_CURMOSEL_MASK                  1

#define OTG_FS_GLOBAL_GCINT_MMIS_OFFSET                    1
#define OTG_FS_GLOBAL_GCINT_MMIS_MASK                      2

#define OTG_FS_GLOBAL_GCINT_OTG_OFFSET                     2
#define OTG_FS_GLOBAL_GCINT_OTG_MASK                       4

#define OTG_FS_GLOBAL_GCINT_SOF_OFFSET                     3
#define OTG_FS_GLOBAL_GCINT_SOF_MASK                       8

#define OTG_FS_GLOBAL_GCINT_RXFNONE_OFFSET                 4
#define OTG_FS_GLOBAL_GCINT_RXFNONE_MASK                   0x10

#define OTG_FS_GLOBAL_GCINT_NPTXFEM_OFFSET                 5
#define OTG_FS_GLOBAL_GCINT_NPTXFEM_MASK                   0x20

#define OTG_FS_GLOBAL_GCINT_GINNPNAKE_OFFSET               6
#define OTG_FS_GLOBAL_GCINT_GINNPNAKE_MASK                 0x40

#define OTG_FS_GLOBAL_GCINT_GONAKE_OFFSET                  7
#define OTG_FS_GLOBAL_GCINT_GONAKE_MASK                    0x80

#define OTG_FS_GLOBAL_GCINT_ESUS_OFFSET                    10
#define OTG_FS_GLOBAL_GCINT_ESUS_MASK                      0x400

#define OTG_FS_GLOBAL_GCINT_USBSUS_OFFSET                  11
#define OTG_FS_GLOBAL_GCINT_USBSUS_MASK                    0x800

#define OTG_FS_GLOBAL_GCINT_USBRST_OFFSET                  12
#define OTG_FS_GLOBAL_GCINT_USBRST_MASK                    0x1000

#define OTG_FS_GLOBAL_GCINT_ENUMD_OFFSET                   13
#define OTG_FS_GLOBAL_GCINT_ENUMD_MASK                     0x2000

#define OTG_FS_GLOBAL_GCINT_ISOPD_OFFSET                   14
#define OTG_FS_GLOBAL_GCINT_ISOPD_MASK                     0x4000

#define OTG_FS_GLOBAL_GCINT_EOPF_OFFSET                    15
#define OTG_FS_GLOBAL_GCINT_EOPF_MASK                      0x8000

#define OTG_FS_GLOBAL_GCINT_INEP_OFFSET                    18
#define OTG_FS_GLOBAL_GCINT_INEP_MASK                      0x40000

#define OTG_FS_GLOBAL_GCINT_ONEP_OFFSET                    19
#define OTG_FS_GLOBAL_GCINT_ONEP_MASK                      0x80000

#define OTG_FS_GLOBAL_GCINT_IIINTX_OFFSET                  20
#define OTG_FS_GLOBAL_GCINT_IIINTX_MASK                    0x100000

#define OTG_FS_GLOBAL_GCINT_IP_OUTTX_OFFSET                21
#define OTG_FS_GLOBAL_GCINT_IP_OUTTX_MASK                  0x200000

#define OTG_FS_GLOBAL_GCINT_HPORT_OFFSET                   24
#define OTG_FS_GLOBAL_GCINT_HPORT_MASK                     0x1000000

#define OTG_FS_GLOBAL_GCINT_HCHAN_OFFSET                   25
#define OTG_FS_GLOBAL_GCINT_HCHAN_MASK                     0x2000000

#define OTG_FS_GLOBAL_GCINT_PTXFE_OFFSET                   26
#define OTG_FS_GLOBAL_GCINT_PTXFE_MASK                     0x4000000

#define OTG_FS_GLOBAL_GCINT_CINSTSCHG_OFFSET               28
#define OTG_FS_GLOBAL_GCINT_CINSTSCHG_MASK                 0x10000000

#define OTG_FS_GLOBAL_GCINT_DEDIS_OFFSET                   29
#define OTG_FS_GLOBAL_GCINT_DEDIS_MASK                     0x20000000

#define OTG_FS_GLOBAL_GCINT_SREQ_OFFSET                    30
#define OTG_FS_GLOBAL_GCINT_SREQ_MASK                      0x40000000

#define OTG_FS_GLOBAL_GCINT_RWAKE_OFFSET                   31
#define OTG_FS_GLOBAL_GCINT_RWAKE_MASK                     0x80000000

#define OTG_FS_GLOBAL_GINTMASK_MMISM_OFFSET                1
#define OTG_FS_GLOBAL_GINTMASK_MMISM_MASK                  2

#define OTG_FS_GLOBAL_GINTMASK_OTGM_OFFSET                 2
#define OTG_FS_GLOBAL_GINTMASK_OTGM_MASK                   4

#define OTG_FS_GLOBAL_GINTMASK_SOFM_OFFSET                 3
#define OTG_FS_GLOBAL_GINTMASK_SOFM_MASK                   8

#define OTG_FS_GLOBAL_GINTMASK_RXFNONEM_OFFSET             4
#define OTG_FS_GLOBAL_GINTMASK_RXFNONEM_MASK               0x10

#define OTG_FS_GLOBAL_GINTMASK_NPTXFEMM_OFFSET             5
#define OTG_FS_GLOBAL_GINTMASK_NPTXFEMM_MASK               0x20

#define OTG_FS_GLOBAL_GINTMASK_GINNPNAKEM_OFFSET           6
#define OTG_FS_GLOBAL_GINTMASK_GINNPNAKEM_MASK             0x40

#define OTG_FS_GLOBAL_GINTMASK_GONAKEM_OFFSET              7
#define OTG_FS_GLOBAL_GINTMASK_GONAKEM_MASK                0x80

#define OTG_FS_GLOBAL_GINTMASK_ESUSM_OFFSET                10
#define OTG_FS_GLOBAL_GINTMASK_ESUSM_MASK                  0x400

#define OTG_FS_GLOBAL_GINTMASK_USBSUSM_OFFSET              11
#define OTG_FS_GLOBAL_GINTMASK_USBSUSM_MASK                0x800

#define OTG_FS_GLOBAL_GINTMASK_USBRSTM_OFFSET              12
#define OTG_FS_GLOBAL_GINTMASK_USBRSTM_MASK                0x1000

#define OTG_FS_GLOBAL_GINTMASK_ENUMDM_OFFSET               13
#define OTG_FS_GLOBAL_GINTMASK_ENUMDM_MASK                 0x2000

#define OTG_FS_GLOBAL_GINTMASK_ISOPDM_OFFSET               14
#define OTG_FS_GLOBAL_GINTMASK_ISOPDM_MASK                 0x4000

#define OTG_FS_GLOBAL_GINTMASK_EOPFM_OFFSET                15
#define OTG_FS_GLOBAL_GINTMASK_EOPFM_MASK                  0x8000

#define OTG_FS_GLOBAL_GINTMASK_EPMISM_OFFSET               17
#define OTG_FS_GLOBAL_GINTMASK_EPMISM_MASK                 0x20000

#define OTG_FS_GLOBAL_GINTMASK_INEPM_OFFSET                18
#define OTG_FS_GLOBAL_GINTMASK_INEPM_MASK                  0x40000

#define OTG_FS_GLOBAL_GINTMASK_OUTEPM_OFFSET               19
#define OTG_FS_GLOBAL_GINTMASK_OUTEPM_MASK                 0x80000

#define OTG_FS_GLOBAL_GINTMASK_IIINTXM_OFFSET              20
#define OTG_FS_GLOBAL_GINTMASK_IIINTXM_MASK                0x100000

#define OTG_FS_GLOBAL_GINTMASK_IP_OUTTXM_OFFSET            21
#define OTG_FS_GLOBAL_GINTMASK_IP_OUTTXM_MASK              0x200000

#define OTG_FS_GLOBAL_GINTMASK_HPORTM_OFFSET               24
#define OTG_FS_GLOBAL_GINTMASK_HPORTM_MASK                 0x1000000

#define OTG_FS_GLOBAL_GINTMASK_HCHANM_OFFSET               25
#define OTG_FS_GLOBAL_GINTMASK_HCHANM_MASK                 0x2000000

#define OTG_FS_GLOBAL_GINTMASK_PTXFEM_OFFSET               26
#define OTG_FS_GLOBAL_GINTMASK_PTXFEM_MASK                 0x4000000

#define OTG_FS_GLOBAL_GINTMASK_CIDSTSTCM_OFFSET            28
#define OTG_FS_GLOBAL_GINTMASK_CIDSTSTCM_MASK              0x10000000

#define OTG_FS_GLOBAL_GINTMASK_DEDISM_OFFSET               29
#define OTG_FS_GLOBAL_GINTMASK_DEDISM_MASK                 0x20000000

#define OTG_FS_GLOBAL_GINTMASK_SREQM_OFFSET                30
#define OTG_FS_GLOBAL_GINTMASK_SREQM_MASK                  0x40000000

#define OTG_FS_GLOBAL_GINTMASK_RWAKEM_OFFSET               31
#define OTG_FS_GLOBAL_GINTMASK_RWAKEM_MASK                 0x80000000

#define OTG_FS_GLOBAL_GRXSTS_EPNUM_OFFSET                  0
#define OTG_FS_GLOBAL_GRXSTS_EPNUM_MASK                    0xf

#define OTG_FS_GLOBAL_GRXSTS_BCNT_OFFSET                   4
#define OTG_FS_GLOBAL_GRXSTS_BCNT_MASK                     0x7ff0

#define OTG_FS_GLOBAL_GRXSTS_DPID_OFFSET                   15
#define OTG_FS_GLOBAL_GRXSTS_DPID_MASK                     0x18000

#define OTG_FS_GLOBAL_GRXSTS_PSTS_OFFSET                   17
#define OTG_FS_GLOBAL_GRXSTS_PSTS_MASK                     0x1e0000

#define OTG_FS_GLOBAL_GRXSTS_FNUM_OFFSET                   21
#define OTG_FS_GLOBAL_GRXSTS_FNUM_MASK                     0x1e00000

#define OTG_FS_GLOBAL_GRXFIFO_RXFDEP_OFFSET                0
#define OTG_FS_GLOBAL_GRXFIFO_RXFDEP_MASK                  0xffff

#define OTG_FS_GLOBAL_GTXFCFG_EPTXSA_OFFSET                0
#define OTG_FS_GLOBAL_GTXFCFG_EPTXSA_MASK                  0xffff

#define OTG_FS_GLOBAL_GTXFCFG_EPTXFDEP_OFFSET              16
#define OTG_FS_GLOBAL_GTXFCFG_EPTXFDEP_MASK                0xffff0000

#define OTG_FS_GLOBAL_GNPTXFQSTS_NPTXFSA_OFFSET            0
#define OTG_FS_GLOBAL_GNPTXFQSTS_NPTXFSA_MASK              0xffff

#define OTG_FS_GLOBAL_GNPTXFQSTS_NPTXRSA_OFFSET            16
#define OTG_FS_GLOBAL_GNPTXFQSTS_NPTXRSA_MASK              0xff0000

#define OTG_FS_GLOBAL_GNPTXFQSTS_NPTXRQ_OFFSET             24
#define OTG_FS_GLOBAL_GNPTXFQSTS_NPTXRQ_MASK               0x7f000000

#define OTG_FS_GLOBAL_GGCCFG_PWEN_OFFSET                   16
#define OTG_FS_GLOBAL_GGCCFG_PWEN_MASK                     0x10000

#define OTG_FS_GLOBAL_GGCCFG_ADVBSEN_OFFSET                18
#define OTG_FS_GLOBAL_GGCCFG_ADVBSEN_MASK                  0x40000

#define OTG_FS_GLOBAL_GGCCFG_BDVBSEN_OFFSET                19
#define OTG_FS_GLOBAL_GGCCFG_BDVBSEN_MASK                  0x80000

#define OTG_FS_GLOBAL_GGCCFG_SOFPOUT_OFFSET                20
#define OTG_FS_GLOBAL_GGCCFG_SOFPOUT_MASK                  0x100000

#define OTG_FS_GLOBAL_GGCCFG_VBSDIS_OFFSET                 21
#define OTG_FS_GLOBAL_GGCCFG_VBSDIS_MASK                   0x200000

#define OTG_FS_GLOBAL_GCID_PID_OFFSET                      0
#define OTG_FS_GLOBAL_GCID_PID_MASK                        0xffffffff

#define OTG_FS_GLOBAL_GHPTXFSIZE_HPDTXFSA_OFFSET           0
#define OTG_FS_GLOBAL_GHPTXFSIZE_HPDTXFSA_MASK             0xffff

#define OTG_FS_GLOBAL_GHPTXFSIZE_HPDTXFDEP_OFFSET          16
#define OTG_FS_GLOBAL_GHPTXFSIZE_HPDTXFDEP_MASK            0xffff0000

#define OTG_FS_GLOBAL_DTXFIFO1_INEPTXFRSA_OFFSET           0
#define OTG_FS_GLOBAL_DTXFIFO1_INEPTXFRSA_MASK             0xffff

#define OTG_FS_GLOBAL_DTXFIFO1_INEPTXFDEP_OFFSET           16
#define OTG_FS_GLOBAL_DTXFIFO1_INEPTXFDEP_MASK             0xffff0000

#define OTG_FS_GLOBAL_DTXFIFO2_INEPTXFRSA_OFFSET           0
#define OTG_FS_GLOBAL_DTXFIFO2_INEPTXFRSA_MASK             0xffff

#define OTG_FS_GLOBAL_DTXFIFO2_INEPTXFDEP_OFFSET           16
#define OTG_FS_GLOBAL_DTXFIFO2_INEPTXFDEP_MASK             0xffff0000

#define OTG_FS_GLOBAL_DTXFIFO3_INEPTXFRSA_OFFSET           0
#define OTG_FS_GLOBAL_DTXFIFO3_INEPTXFRSA_MASK             0xffff

#define OTG_FS_GLOBAL_DTXFIFO3_INEPTXFDEP_OFFSET           16
#define OTG_FS_GLOBAL_DTXFIFO3_INEPTXFDEP_MASK             0xffff0000


typedef struct
{

/** GCTRLSTS GCTRLSTS (offset: 0x0)
  OTG_FS control and status register (OTG_FS_GOTGCTL)
  reset value : 0x800
  reset mask : 0xFFFFFFFF
  Field: SREQSUC
  offset: 0, size: 1, access: read-only
  Session request success
  Field: SREQ
  offset: 1, size: 1, access: read-write
  Session request
  Field: HNSUC
  offset: 8, size: 1, access: read-only
  Host negotiation success
  Field: HNPREQ
  offset: 9, size: 1, access: read-write
  HNP request
  Field: HHNPEN
  offset: 10, size: 1, access: read-write
  Host set HNP enable
  Field: DHNPEN
  offset: 11, size: 1, access: read-write
  Device HNP enabled
  Field: CIDSTS
  offset: 16, size: 1, access: read-only
  Connector ID status
  Field: LSDEBT
  offset: 17, size: 1, access: read-only
  Long/short debounce time
  Field: ASVD
  offset: 18, size: 1, access: read-only
  A-session valid
  Field: BSVD
  offset: 19, size: 1, access: read-only
  B-session valid
*/
volatile uint32_t GCTRLSTS;

/** GINT GINT (offset: 0x4)
  OTG_FS interrupt register (OTG_FS_GOTGINT)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SEFLG
  offset: 2, size: 1, access: 
  Session end detected
  Field: SREQSUCCHG
  offset: 8, size: 1, access: 
  Session request success status change
  Field: HNSUCCHG
  offset: 9, size: 1, access: 
  Host negotiation success status change
  Field: HNFLG
  offset: 17, size: 1, access: 
  Host negotiation detected
  Field: ADTOFLG
  offset: 18, size: 1, access: 
  A-device timeout change
  Field: DEBDFLG
  offset: 19, size: 1, access: 
  Debounce done
*/
volatile uint32_t GINT;

/** GAHBCFG GAHBCFG (offset: 0x8)
  OTG_FS AHB configuration register (OTG_FS_GAHBCFG)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: GINTMASK
  offset: 0, size: 1, access: 
  Global interrupt mask
  Field: TXFEL
  offset: 7, size: 1, access: 
  TxFIFO empty level
  Field: PTXFEL
  offset: 8, size: 1, access: 
  Periodic TxFIFO empty level
*/
volatile uint32_t GAHBCFG;

/** GUSBCFG GUSBCFG (offset: 0xc)
  OTG_FS USB configuration register (OTG_FS_GUSBCFG)
  reset value : 0xA00
  reset mask : 0xFFFFFFFF
  Field: SEFLG
  offset: 0, size: 3, access: read-write
  FS timeout calibration
  Field: FSSTSEL
  offset: 6, size: 1, access: write-only
  Full Speed serial transceiver select
  Field: SRPEN
  offset: 8, size: 1, access: read-write
  SRP-capable
  Field: HNPEN
  offset: 9, size: 1, access: read-write
  HNP-capable
  Field: TRTIM
  offset: 10, size: 4, access: read-write
  USB turnaround time
  Field: FHMODE
  offset: 29, size: 1, access: read-write
  Force host mode
  Field: FDMODE
  offset: 30, size: 1, access: read-write
  Force device mode
  Field: CTXP
  offset: 31, size: 1, access: read-write
  Corrupt Tx packet
*/
volatile uint32_t GUSBCFG;

/** GRSTCTRL GRSTCTRL (offset: 0x10)
  OTG_FS reset register (OTG_FS_GRSTCTL)
  reset value : 0x20000000
  reset mask : 0xFFFFFFFF
  Field: CSRST
  offset: 0, size: 1, access: read-write
  Core soft reset
  Field: HSRST
  offset: 1, size: 1, access: read-write
  HCLK soft reset
  Field: HFCNTRST
  offset: 2, size: 1, access: read-write
  Host frame counter reset
  Field: RXFFLU
  offset: 4, size: 1, access: read-write
  RxFIFO flush
  Field: TXFFLU
  offset: 5, size: 1, access: read-write
  TxFIFO flush
  Field: TXFNUM
  offset: 6, size: 5, access: read-write
  TxFIFO number
  Field: AHBMIDL
  offset: 31, size: 1, access: read-only
  AHB master idle
*/
volatile uint32_t GRSTCTRL;

/** GCINT GCINT (offset: 0x14)
  OTG_FS core interrupt register (OTG_FS_GINTSTS)
  reset value : 0x4000020
  reset mask : 0xFFFFFFFF
  Field: CURMOSEL
  offset: 0, size: 1, access: read-only
  Current mode of operation
  Field: MMIS
  offset: 1, size: 1, access: read-write
  Mode mismatch interrupt
  Field: OTG
  offset: 2, size: 1, access: read-only
  OTG interrupt
  Field: SOF
  offset: 3, size: 1, access: read-write
  Start of frame
  Field: RXFNONE
  offset: 4, size: 1, access: read-only
  RxFIFO non-empty
  Field: NPTXFEM
  offset: 5, size: 1, access: read-only
  Non-periodic TxFIFO empty
  Field: GINNPNAKE
  offset: 6, size: 1, access: read-only
  Global IN non-periodic NAK effective
  Field: GONAKE
  offset: 7, size: 1, access: read-only
  Global OUT NAK effective
  Field: ESUS
  offset: 10, size: 1, access: read-write
  Early suspend
  Field: USBSUS
  offset: 11, size: 1, access: read-write
  USB suspend
  Field: USBRST
  offset: 12, size: 1, access: read-write
  USB reset
  Field: ENUMD
  offset: 13, size: 1, access: read-write
  Enumeration done
  Field: ISOPD
  offset: 14, size: 1, access: read-write
  Isochronous OUT packet dropped interrupt
  Field: EOPF
  offset: 15, size: 1, access: read-write
  End of periodic frame interrupt
  Field: INEP
  offset: 18, size: 1, access: read-only
  IN endpoint interrupt
  Field: ONEP
  offset: 19, size: 1, access: read-only
  OUT endpoint interrupt
  Field: IIINTX
  offset: 20, size: 1, access: read-write
  Incomplete isochronous IN transfer
  Field: IP_OUTTX
  offset: 21, size: 1, access: read-write
  Incomplete periodic transfer(Host
 mode)/Incomplete isochronous OUT transfer(Device mode)
  Field: HPORT
  offset: 24, size: 1, access: read-only
  Host port interrupt
  Field: HCHAN
  offset: 25, size: 1, access: read-only
  Host channels interrupt
  Field: PTXFE
  offset: 26, size: 1, access: read-only
  Periodic TxFIFO empty
  Field: CINSTSCHG
  offset: 28, size: 1, access: read-write
  Connector ID status change
  Field: DEDIS
  offset: 29, size: 1, access: read-write
  Disconnect detected interrupt
  Field: SREQ
  offset: 30, size: 1, access: read-write
  Session request/new session detected interrupt
  Field: RWAKE
  offset: 31, size: 1, access: read-write
  Resume/remote wakeup detected interrupt
*/
volatile uint32_t GCINT;

/** GINTMASK GINTMASK (offset: 0x18)
  OTG_FS interrupt mask register (OTG_FS_GINTMSK)
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MMISM
  offset: 1, size: 1, access: read-write
  Mode mismatch interrupt mask
  Field: OTGM
  offset: 2, size: 1, access: read-write
  OTG interrupt mask
  Field: SOFM
  offset: 3, size: 1, access: read-write
  Start of frame mask
  Field: RXFNONEM
  offset: 4, size: 1, access: read-write
  Receive FIFO non-empty mask
  Field: NPTXFEMM
  offset: 5, size: 1, access: read-write
  Non-periodic TxFIFO empty mask
  Field: GINNPNAKEM
  offset: 6, size: 1, access: read-write
  Global non-periodic IN NAK effective mask
  Field: GONAKEM
  offset: 7, size: 1, access: read-write
  Global OUT NAK effective mask
  Field: ESUSM
  offset: 10, size: 1, access: read-write
  Early suspend mask
  Field: USBSUSM
  offset: 11, size: 1, access: read-write
  USB suspend mask
  Field: USBRSTM
  offset: 12, size: 1, access: read-write
  USB reset mask
  Field: ENUMDM
  offset: 13, size: 1, access: read-write
  Enumeration done mask
  Field: ISOPDM
  offset: 14, size: 1, access: read-write
  Isochronous OUT packet dropped interrupt mask
  Field: EOPFM
  offset: 15, size: 1, access: read-write
  End of periodic frame interrupt mask
  Field: EPMISM
  offset: 17, size: 1, access: read-write
  Endpoint mismatch interrupt mask
  Field: INEPM
  offset: 18, size: 1, access: read-write
  IN endpoints interrupt mask
  Field: OUTEPM
  offset: 19, size: 1, access: read-write
  OUT endpoints interrupt mask
  Field: IIINTXM
  offset: 20, size: 1, access: read-write
  Incomplete isochronous IN transfer mask
  Field: IP_OUTTXM
  offset: 21, size: 1, access: read-write
  Incomplete periodic transfer mask(Host
 mode)/Incomplete isochronous OUT transfer mask(Device mode)
  Field: HPORTM
  offset: 24, size: 1, access: read-only
  Host port interrupt mask
  Field: HCHANM
  offset: 25, size: 1, access: read-write
  Host channels interrupt mask
  Field: PTXFEM
  offset: 26, size: 1, access: read-write
  Periodic TxFIFO empty mask
  Field: CIDSTSTCM
  offset: 28, size: 1, access: read-write
  Connector ID status change mask
  Field: DEDISM
  offset: 29, size: 1, access: read-write
  Disconnect detected interrupt mask
  Field: SREQM
  offset: 30, size: 1, access: read-write
  Session request/new session detected interrupt mask
  Field: RWAKEM
  offset: 31, size: 1, access: read-write
  Resume/remote wakeup detected interrupt mask
*/
volatile uint32_t GINTMASK;

/** GRXSTS GRXSTS (offset: 0x1c)
  OTG_FS Receive status debug read(Device mode)
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EPNUM
  offset: 0, size: 4, access: 
  Endpoint number
  Field: BCNT
  offset: 4, size: 11, access: 
  Byte count
  Field: DPID
  offset: 15, size: 2, access: 
  Data PID
  Field: PSTS
  offset: 17, size: 4, access: 
  Packet status
  Field: FNUM
  offset: 21, size: 4, access: 
  Frame number
*/
volatile uint32_t GRXSTS;
volatile uint32_t reserved0;

/** GRXFIFO GRXFIFO (offset: 0x24)
  OTG_FS Receive FIFO size register (OTG_FS_GRXFSIZ)
  access : read-write
  reset value : 0x200
  reset mask : 0xFFFFFFFF
  Field: RXFDEP
  offset: 0, size: 16, access: 
  RxFIFO depth
*/
volatile uint32_t GRXFIFO;

/** GTXFCFG GTXFCFG (offset: 0x28)
  OTG_FS non-periodic transmit FIFO size register (Device mode)
  access : read-write
  reset value : 0x200
  reset mask : 0xFFFFFFFF
  Field: EPTXSA
  offset: 0, size: 16, access: 
  Endpoint 0 transmit RAM start address
  Field: EPTXFDEP
  offset: 16, size: 16, access: 
  Endpoint 0 TxFIFO depth
*/
volatile uint32_t GTXFCFG;

/** GNPTXFQSTS GNPTXFQSTS (offset: 0x2c)
  OTG_FS non-periodic transmit FIFO/queue statusregister (OTG_FS_GNPTXFQSTS)
  access : read-only
  reset value : 0x80200
  reset mask : 0xFFFFFFFF
  Field: NPTXFSA
  offset: 0, size: 16, access: 
  Non-periodic TxFIFO space available
  Field: NPTXRSA
  offset: 16, size: 8, access: 
  Non-periodic transmit request queue space available
  Field: NPTXRQ
  offset: 24, size: 7, access: 
  Top of the non-periodic transmit request queue
*/
volatile uint32_t GNPTXFQSTS;
volatile uint32_t reserved1[2];

/** GGCCFG GGCCFG (offset: 0x38)
  OTG_FS general core configuration register (OTG_FS_GCCFG)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PWEN
  offset: 16, size: 1, access: 
  Power down
  Field: ADVBSEN
  offset: 18, size: 1, access: 
  Enable the VBUS sensing device
  Field: BDVBSEN
  offset: 19, size: 1, access: 
  Enable the VBUS sensing device
  Field: SOFPOUT
  offset: 20, size: 1, access: 
  SOF output enable
  Field: VBSDIS
  offset: 21, size: 1, access: 
  VBUS Sensing Disable
*/
volatile uint32_t GGCCFG;

/** GCID GCID (offset: 0x3c)
  core ID register
  access : read-write
  reset value : 0x1000
  reset mask : 0xFFFFFFFF
  Field: PID
  offset: 0, size: 32, access: 
  Product ID field
*/
volatile uint32_t GCID;
volatile uint32_t reserved2[48];

/** GHPTXFSIZE GHPTXFSIZE (offset: 0x100)
  OTG_FS Host periodic transmit FIFO size register(OTG_FS_GHPTXFSIZE)
  access : read-write
  reset value : 0x2000600
  reset mask : 0xFFFFFFFF
  Field: HPDTXFSA
  offset: 0, size: 16, access: 
  Host periodic TxFIFO start address
  Field: HPDTXFDEP
  offset: 16, size: 16, access: 
  Host periodic TxFIFO depth
*/
volatile uint32_t GHPTXFSIZE;

/** DTXFIFO1 DTXFIFO1 (offset: 0x104)
  OTG_FS device IN endpoint transmit FIFO size register(OTG_FS_DTXFIFO1)
  access : read-write
  reset value : 0x2000400
  reset mask : 0xFFFFFFFF
  Field: INEPTXFRSA
  offset: 0, size: 16, access: 
  IN endpoint FIFO2 transmit RAM start address
  Field: INEPTXFDEP
  offset: 16, size: 16, access: 
  IN endpoint TxFIFO depth
*/
volatile uint32_t DTXFIFO1;

/** DTXFIFO2 DTXFIFO2 (offset: 0x108)
  OTG_FS device IN endpoint transmit FIFO size register(OTG_FS_DTXFIFO2)
  access : read-write
  reset value : 0x2000400
  reset mask : 0xFFFFFFFF
  Field: INEPTXFRSA
  offset: 0, size: 16, access: 
  IN endpoint FIFO3 transmit RAM start address
  Field: INEPTXFDEP
  offset: 16, size: 16, access: 
  IN endpoint TxFIFO depth
*/
volatile uint32_t DTXFIFO2;

/** DTXFIFO3 DTXFIFO3 (offset: 0x10c)
  OTG_FS device IN endpoint transmit FIFO size register(OTG_FS_DTXFIFO3)
  access : read-write
  reset value : 0x2000400
  reset mask : 0xFFFFFFFF
  Field: INEPTXFRSA
  offset: 0, size: 16, access: 
  IN endpoint FIFO4 transmit RAM start address
  Field: INEPTXFDEP
  offset: 16, size: 16, access: 
  IN endpoint TxFIFO depth
*/
volatile uint32_t DTXFIFO3;
} OTG_FS_GLOBAL_type;

#define OTG_FS_GLOBAL ((OTG_FS_GLOBAL_type *) 0x50000000)

#endif // HW_OTG_FS_GLOBAL_H
