#ifndef HW_COMP1_H
#define HW_COMP1_H
/** Comparator */
/** Memory Block starting at 0x40013818 + 0x0 is 0x4 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define COMP1_CSTS_EN_OFFSET                               0
#define COMP1_CSTS_EN_MASK                                 1

#define COMP1_CSTS_INMCCFG_OFFSET                          4
#define COMP1_CSTS_INMCCFG_MASK                            0x30

#define COMP1_CSTS_WMODESEL_OFFSET                         8
#define COMP1_CSTS_WMODESEL_MASK                           0x100

#define COMP1_CSTS_OUTSEL_OFFSET                           11
#define COMP1_CSTS_OUTSEL_MASK                             0x7800

#define COMP1_CSTS_POLCFG_OFFSET                           15
#define COMP1_CSTS_POLCFG_MASK                             0x8000

#define COMP1_CSTS_OUTVAL_OFFSET                           30
#define COMP1_CSTS_OUTVAL_MASK                             0x40000000

#define COMP1_CSTS_LOCK_OFFSET                             31
#define COMP1_CSTS_LOCK_MASK                               0x80000000


typedef struct
{

/** CSTS CSTS (offset: 0x0)
  control and status register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EN
  offset: 0, size: 1, access: read-write
  Comparator 1 enable
  Field: INMCCFG
  offset: 4, size: 2, access: read-write
  Comparator 1 Input Minus Connection Configure
  Field: WMODESEL
  offset: 8, size: 1, access: read-write
  Comparator 1 Window Mode Select
  Field: OUTSEL
  offset: 11, size: 4, access: read-write
  Comparator 1 output Selest
  Field: POLCFG
  offset: 15, size: 1, access: read-write
  Comparator 1 Polarity Configure
  Field: OUTVAL
  offset: 30, size: 1, access: read-write
  Comparator 1 output status
  Field: LOCK
  offset: 31, size: 1, access: read-write
  COMP CSTS Register Lock
*/
volatile uint32_t CSTS;
} COMP1_type;

#define COMP1 ((COMP1_type *) 0x40013818)

#endif // HW_COMP1_H
