#ifndef HW_PMU_H
#define HW_PMU_H
/** Power control */
/** Interrupt : PVD (Vector: 1) PVD through EINT line 16 detection interrupt */
/** Memory Block starting at 0x40007000 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define PMU_CTRL_FLASHEN_OFFSET                            21
#define PMU_CTRL_FLASHEN_MASK                              0x200000

#define PMU_CTRL_FSMODE_OFFSET                             20
#define PMU_CTRL_FSMODE_MASK                               0x100000

#define PMU_CTRL_VOSSEL_OFFSET                             14
#define PMU_CTRL_VOSSEL_MASK                               0xc000

#define PMU_CTRL_ADC01EN_OFFSET                            13
#define PMU_CTRL_ADC01EN_MASK                              0x2000

#define PMU_CTRL_MRLV_OFFSET                               11
#define PMU_CTRL_MRLV_MASK                                 0x800

#define PMU_CTRL_LPRLV_OFFSET                              10
#define PMU_CTRL_LPRLV_MASK                                0x400

#define PMU_CTRL_FPDSM_OFFSET                              9
#define PMU_CTRL_FPDSM_MASK                                0x200

#define PMU_CTRL_BPWEN_OFFSET                              8
#define PMU_CTRL_BPWEN_MASK                                0x100

#define PMU_CTRL_PLSEL_OFFSET                              5
#define PMU_CTRL_PLSEL_MASK                                0xe0

#define PMU_CTRL_PVDEN_OFFSET                              4
#define PMU_CTRL_PVDEN_MASK                                0x10

#define PMU_CTRL_SBFLGCLR_OFFSET                           3
#define PMU_CTRL_SBFLGCLR_MASK                             8

#define PMU_CTRL_WUFLGCLR_OFFSET                           2
#define PMU_CTRL_WUFLGCLR_MASK                             4

#define PMU_CTRL_PDDSCFG_OFFSET                            1
#define PMU_CTRL_PDDSCFG_MASK                              2

#define PMU_CTRL_LPDSCFG_OFFSET                            0
#define PMU_CTRL_LPDSCFG_MASK                              1

#define PMU_CSTS_WUEFLG_OFFSET                             0
#define PMU_CSTS_WUEFLG_MASK                               1

#define PMU_CSTS_SBFLG_OFFSET                              1
#define PMU_CSTS_SBFLG_MASK                                2

#define PMU_CSTS_PVDOFLG_OFFSET                            2
#define PMU_CSTS_PVDOFLG_MASK                              4

#define PMU_CSTS_BKPRFLG_OFFSET                            3
#define PMU_CSTS_BKPRFLG_MASK                              8

#define PMU_CSTS_WKUPCFG_OFFSET                            8
#define PMU_CSTS_WKUPCFG_MASK                              0x100

#define PMU_CSTS_BKPREN_OFFSET                             9
#define PMU_CSTS_BKPREN_MASK                               0x200

#define PMU_CSTS_VOSRFLG_OFFSET                            14
#define PMU_CSTS_VOSRFLG_MASK                              0x4000


typedef struct
{

/** CTRL CTRL (offset: 0x0)
  power control register
  access : read-write
  reset value : 0x8000
  reset mask : 0xFFFFFFFF
  Field: FLASHEN
  offset: 21, size: 1, access: 
  Flash Interface Enable
  Field: FSMODE
  offset: 20, size: 1, access: 
  Force Flash Sleep Mode
  Field: VOSSEL
  offset: 14, size: 2, access: 
  Regulator Voltage Scaling Output Selection
  Field: ADC01EN
  offset: 13, size: 1, access: 
  ADC Option 1 Enable
  Field: MRLV
  offset: 11, size: 1, access: 
  Main Regulator Low Voltage in Stop Mode
  Field: LPRLV
  offset: 10, size: 1, access: 
  Low Power Regulator Low Voltage in Stop Mode
  Field: FPDSM
  offset: 9, size: 1, access: 
  Flash power down in Stop mode
  Field: BPWEN
  offset: 8, size: 1, access: 
  Backup Domain Write Access Enable
  Field: PLSEL
  offset: 5, size: 3, access: 
  PVD level selection
  Field: PVDEN
  offset: 4, size: 1, access: 
  Power voltage detector enable
  Field: SBFLGCLR
  offset: 3, size: 1, access: 
  Clear standby flag
  Field: WUFLGCLR
  offset: 2, size: 1, access: 
  Clear wakeup flag
  Field: PDDSCFG
  offset: 1, size: 1, access: 
  Power down deepsleep
  Field: LPDSCFG
  offset: 0, size: 1, access: 
  Low-power deep sleep
*/
volatile uint32_t CTRL;

/** CSTS CSTS (offset: 0x4)
  power control/status register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: WUEFLG
  offset: 0, size: 1, access: read-only
  Wakeup flag
  Field: SBFLG
  offset: 1, size: 1, access: read-only
  Standby flag
  Field: PVDOFLG
  offset: 2, size: 1, access: read-only
  PVD output
  Field: BKPRFLG
  offset: 3, size: 1, access: read-only
  Backup regulator ready
  Field: WKUPCFG
  offset: 8, size: 1, access: read-write
  Enable WKUP pin
  Field: BKPREN
  offset: 9, size: 1, access: read-write
  Backup regulator enable
  Field: VOSRFLG
  offset: 14, size: 1, access: read-write
  Regulator voltage scaling output selection ready bit
*/
volatile uint32_t CSTS;
} PMU_type;

#define PMU ((PMU_type *) 0x40007000)

#endif // HW_PMU_H
