#ifndef HW_SDIO_H
#define HW_SDIO_H
/** Secure digital input/output interface */
/** Interrupt : SDIO (Vector: 49) SDIO global interrupt */
/** Memory Block starting at 0x40012C00 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define SDIO_PWRCTRL_PWRCTRL_OFFSET                        0
#define SDIO_PWRCTRL_PWRCTRL_MASK                          3

#define SDIO_CLKCTRL_HFCEN_OFFSET                          14
#define SDIO_CLKCTRL_HFCEN_MASK                            0x4000

#define SDIO_CLKCTRL_DEPSEL_OFFSET                         13
#define SDIO_CLKCTRL_DEPSEL_MASK                           0x2000

#define SDIO_CLKCTRL_WBSEL_OFFSET                          11
#define SDIO_CLKCTRL_WBSEL_MASK                            0x1800

#define SDIO_CLKCTRL_BYPASSEN_OFFSET                       10
#define SDIO_CLKCTRL_BYPASSEN_MASK                         0x400

#define SDIO_CLKCTRL_PWRSAV_OFFSET                         9
#define SDIO_CLKCTRL_PWRSAV_MASK                           0x200

#define SDIO_CLKCTRL_CLKEN_OFFSET                          8
#define SDIO_CLKCTRL_CLKEN_MASK                            0x100

#define SDIO_CLKCTRL_CLKDIV_OFFSET                         0
#define SDIO_CLKCTRL_CLKDIV_MASK                           0xff

#define SDIO_ARG_CMDARG_OFFSET                             0
#define SDIO_ARG_CMDARG_MASK                               0xffffffff

#define SDIO_CMD_ATACMD_OFFSET                             14
#define SDIO_CMD_ATACMD_MASK                               0x4000

#define SDIO_CMD_INTEN_OFFSET                              13
#define SDIO_CMD_INTEN_MASK                                0x2000

#define SDIO_CMD_CMDCPEN_OFFSET                            12
#define SDIO_CMD_CMDCPEN_MASK                              0x1000

#define SDIO_CMD_SDIOSC_OFFSET                             11
#define SDIO_CMD_SDIOSC_MASK                               0x800

#define SDIO_CMD_CPSMEN_OFFSET                             10
#define SDIO_CMD_CPSMEN_MASK                               0x400

#define SDIO_CMD_WENDDATA_OFFSET                           9
#define SDIO_CMD_WENDDATA_MASK                             0x200

#define SDIO_CMD_WAITINT_OFFSET                            8
#define SDIO_CMD_WAITINT_MASK                              0x100

#define SDIO_CMD_WAITRES_OFFSET                            6
#define SDIO_CMD_WAITRES_MASK                              0xc0

#define SDIO_CMD_CMDINDEX_OFFSET                           0
#define SDIO_CMD_CMDINDEX_MASK                             0x3f

#define SDIO_CMDRES_CMDRES_OFFSET                          0
#define SDIO_CMDRES_CMDRES_MASK                            0x3f

#define SDIO_RES1_CARDSTS1_OFFSET                          0
#define SDIO_RES1_CARDSTS1_MASK                            0xffffffff

#define SDIO_RES2_CARDSTS2_OFFSET                          0
#define SDIO_RES2_CARDSTS2_MASK                            0xffffffff

#define SDIO_RES3_CARDSTS3_OFFSET                          0
#define SDIO_RES3_CARDSTS3_MASK                            0xffffffff

#define SDIO_RES4_CARDSTS4_OFFSET                          0
#define SDIO_RES4_CARDSTS4_MASK                            0xffffffff

#define SDIO_DATATIME_DATATIME_OFFSET                      0
#define SDIO_DATATIME_DATATIME_MASK                        0xffffffff

#define SDIO_DATALEN_DATALEN_OFFSET                        0
#define SDIO_DATALEN_DATALEN_MASK                          0x1ffffff

#define SDIO_DCTRL_SDIOF_OFFSET                            11
#define SDIO_DCTRL_SDIOF_MASK                              0x800

#define SDIO_DCTRL_RDWAIT_OFFSET                           10
#define SDIO_DCTRL_RDWAIT_MASK                             0x400

#define SDIO_DCTRL_RWSTOP_OFFSET                           9
#define SDIO_DCTRL_RWSTOP_MASK                             0x200

#define SDIO_DCTRL_RWSTR_OFFSET                            8
#define SDIO_DCTRL_RWSTR_MASK                              0x100

#define SDIO_DCTRL_DBSIZE_OFFSET                           4
#define SDIO_DCTRL_DBSIZE_MASK                             0xf0

#define SDIO_DCTRL_DMAEN_OFFSET                            3
#define SDIO_DCTRL_DMAEN_MASK                              8

#define SDIO_DCTRL_DTSEL_OFFSET                            2
#define SDIO_DCTRL_DTSEL_MASK                              4

#define SDIO_DCTRL_DTDRCFG_OFFSET                          1
#define SDIO_DCTRL_DTDRCFG_MASK                            2

#define SDIO_DCTRL_DTEN_OFFSET                             0
#define SDIO_DCTRL_DTEN_MASK                               1

#define SDIO_DCNT_DATACNT_OFFSET                           0
#define SDIO_DCNT_DATACNT_MASK                             0x1ffffff

#define SDIO_STS_ATAEND_OFFSET                             23
#define SDIO_STS_ATAEND_MASK                               0x800000

#define SDIO_STS_SDIOINT_OFFSET                            22
#define SDIO_STS_SDIOINT_MASK                              0x400000

#define SDIO_STS_RXDA_OFFSET                               21
#define SDIO_STS_RXDA_MASK                                 0x200000

#define SDIO_STS_TXDA_OFFSET                               20
#define SDIO_STS_TXDA_MASK                                 0x100000

#define SDIO_STS_RXFE_OFFSET                               19
#define SDIO_STS_RXFE_MASK                                 0x80000

#define SDIO_STS_TXFE_OFFSET                               18
#define SDIO_STS_TXFE_MASK                                 0x40000

#define SDIO_STS_RXFF_OFFSET                               17
#define SDIO_STS_RXFF_MASK                                 0x20000

#define SDIO_STS_TXFF_OFFSET                               16
#define SDIO_STS_TXFF_MASK                                 0x10000

#define SDIO_STS_RXFHF_OFFSET                              15
#define SDIO_STS_RXFHF_MASK                                0x8000

#define SDIO_STS_TXFHF_OFFSET                              14
#define SDIO_STS_TXFHF_MASK                                0x4000

#define SDIO_STS_RXACT_OFFSET                              13
#define SDIO_STS_RXACT_MASK                                0x2000

#define SDIO_STS_TXACT_OFFSET                              12
#define SDIO_STS_TXACT_MASK                                0x1000

#define SDIO_STS_CMDACT_OFFSET                             11
#define SDIO_STS_CMDACT_MASK                               0x800

#define SDIO_STS_DBCP_OFFSET                               10
#define SDIO_STS_DBCP_MASK                                 0x400

#define SDIO_STS_SBE_OFFSET                                9
#define SDIO_STS_SBE_MASK                                  0x200

#define SDIO_STS_DATAEND_OFFSET                            8
#define SDIO_STS_DATAEND_MASK                              0x100

#define SDIO_STS_CMDSENT_OFFSET                            7
#define SDIO_STS_CMDSENT_MASK                              0x80

#define SDIO_STS_CMDRES_OFFSET                             6
#define SDIO_STS_CMDRES_MASK                               0x40

#define SDIO_STS_RXOVRER_OFFSET                            5
#define SDIO_STS_RXOVRER_MASK                              0x20

#define SDIO_STS_TXUDRER_OFFSET                            4
#define SDIO_STS_TXUDRER_MASK                              0x10

#define SDIO_STS_DATATO_OFFSET                             3
#define SDIO_STS_DATATO_MASK                               8

#define SDIO_STS_CMDRESTO_OFFSET                           2
#define SDIO_STS_CMDRESTO_MASK                             4

#define SDIO_STS_DBDR_OFFSET                               1
#define SDIO_STS_DBDR_MASK                                 2

#define SDIO_STS_COMRESP_OFFSET                            0
#define SDIO_STS_COMRESP_MASK                              1

#define SDIO_ICF_ATAEND_OFFSET                             23
#define SDIO_ICF_ATAEND_MASK                               0x800000

#define SDIO_ICF_SDIOIT_OFFSET                             22
#define SDIO_ICF_SDIOIT_MASK                               0x400000

#define SDIO_ICF_DBCP_OFFSET                               10
#define SDIO_ICF_DBCP_MASK                                 0x400

#define SDIO_ICF_SBE_OFFSET                                9
#define SDIO_ICF_SBE_MASK                                  0x200

#define SDIO_ICF_DATAEND_OFFSET                            8
#define SDIO_ICF_DATAEND_MASK                              0x100

#define SDIO_ICF_CMDSENT_OFFSET                            7
#define SDIO_ICF_CMDSENT_MASK                              0x80

#define SDIO_ICF_CMDRES_OFFSET                             6
#define SDIO_ICF_CMDRES_MASK                               0x40

#define SDIO_ICF_RXFOE_OFFSET                              5
#define SDIO_ICF_RXFOE_MASK                                0x20

#define SDIO_ICF_TXFUE_OFFSET                              4
#define SDIO_ICF_TXFUE_MASK                                0x10

#define SDIO_ICF_DTO_OFFSET                                3
#define SDIO_ICF_DTO_MASK                                  8

#define SDIO_ICF_CRTO_OFFSET                               2
#define SDIO_ICF_CRTO_MASK                                 4

#define SDIO_ICF_DBCE_OFFSET                               1
#define SDIO_ICF_DBCE_MASK                                 2

#define SDIO_ICF_CRCE_OFFSET                               0
#define SDIO_ICF_CRCE_MASK                                 1

#define SDIO_MASK_ATACLPREC_OFFSET                         23
#define SDIO_MASK_ATACLPREC_MASK                           0x800000

#define SDIO_MASK_SDIOINTREC_OFFSET                        22
#define SDIO_MASK_SDIOINTREC_MASK                          0x400000

#define SDIO_MASK_RXDAVB_OFFSET                            21
#define SDIO_MASK_RXDAVB_MASK                              0x200000

#define SDIO_MASK_TXDAVB_OFFSET                            20
#define SDIO_MASK_TXDAVB_MASK                              0x100000

#define SDIO_MASK_RXFEIE_OFFSET                            19
#define SDIO_MASK_RXFEIE_MASK                              0x80000

#define SDIO_MASK_TXEPT_OFFSET                             18
#define SDIO_MASK_TXEPT_MASK                               0x40000

#define SDIO_MASK_RXFUL_OFFSET                             17
#define SDIO_MASK_RXFUL_MASK                               0x20000

#define SDIO_MASK_TXFUL_OFFSET                             16
#define SDIO_MASK_TXFUL_MASK                               0x10000

#define SDIO_MASK_RXHFFUL_OFFSET                           15
#define SDIO_MASK_RXHFFUL_MASK                             0x8000

#define SDIO_MASK_TXHFERT_OFFSET                           14
#define SDIO_MASK_TXHFERT_MASK                             0x4000

#define SDIO_MASK_RXACT_OFFSET                             13
#define SDIO_MASK_RXACT_MASK                               0x2000

#define SDIO_MASK_TXACT_OFFSET                             12
#define SDIO_MASK_TXACT_MASK                               0x1000

#define SDIO_MASK_CMDACT_OFFSET                            11
#define SDIO_MASK_CMDACT_MASK                              0x800

#define SDIO_MASK_DBEND_OFFSET                             10
#define SDIO_MASK_DBEND_MASK                               0x400

#define SDIO_MASK_STRTER_OFFSET                            9
#define SDIO_MASK_STRTER_MASK                              0x200

#define SDIO_MASK_DATAEND_OFFSET                           8
#define SDIO_MASK_DATAEND_MASK                             0x100

#define SDIO_MASK_CMDSENT_OFFSET                           7
#define SDIO_MASK_CMDSENT_MASK                             0x80

#define SDIO_MASK_CMDRESRC_OFFSET                          6
#define SDIO_MASK_CMDRESRC_MASK                            0x40

#define SDIO_MASK_RXORER_OFFSET                            5
#define SDIO_MASK_RXORER_MASK                              0x20

#define SDIO_MASK_TXURER_OFFSET                            4
#define SDIO_MASK_TXURER_MASK                              0x10

#define SDIO_MASK_DATATO_OFFSET                            3
#define SDIO_MASK_DATATO_MASK                              8

#define SDIO_MASK_CMDTO_OFFSET                             2
#define SDIO_MASK_CMDTO_MASK                               4

#define SDIO_MASK_DCRCFAIL_OFFSET                          1
#define SDIO_MASK_DCRCFAIL_MASK                            2

#define SDIO_MASK_CCRCFAIL_OFFSET                          0
#define SDIO_MASK_CCRCFAIL_MASK                            1

#define SDIO_FIFOCNT_FIFOCNT_OFFSET                        0
#define SDIO_FIFOCNT_FIFOCNT_MASK                          0xffffff

#define SDIO_FIFODATA_DATA_OFFSET                          0
#define SDIO_FIFODATA_DATA_MASK                            0xffffffff


typedef struct
{

/** PWRCTRL PWRCTRL (offset: 0x0)
  power control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PWRCTRL
  offset: 0, size: 2, access: 
  Power Supply Control
*/
volatile uint32_t PWRCTRL;

/** CLKCTRL CLKCTRL (offset: 0x4)
  SDI clock control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: HFCEN
  offset: 14, size: 1, access: 
  HW Flow Control enable
  Field: DEPSEL
  offset: 13, size: 1, access: 
  SDIO_CK dephasing selection bit
  Field: WBSEL
  offset: 11, size: 2, access: 
  Wide bus mode enable bit
  Field: BYPASSEN
  offset: 10, size: 1, access: 
  Clock divider bypass enable bit
  Field: PWRSAV
  offset: 9, size: 1, access: 
  Power saving configuration bit
  Field: CLKEN
  offset: 8, size: 1, access: 
  Clock enable bit
  Field: CLKDIV
  offset: 0, size: 8, access: 
  Clock divide factor
*/
volatile uint32_t CLKCTRL;

/** ARG ARG (offset: 0x8)
  argument register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CMDARG
  offset: 0, size: 32, access: 
  Command argument
*/
volatile uint32_t ARG;

/** CMD CMD (offset: 0xc)
  command register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ATACMD
  offset: 14, size: 1, access: 
  CE-ATA command
  Field: INTEN
  offset: 13, size: 1, access: 
  not Interrupt Enable
  Field: CMDCPEN
  offset: 12, size: 1, access: 
  Enable CMD completion
  Field: SDIOSC
  offset: 11, size: 1, access: 
  SD I/O suspend command
  Field: CPSMEN
  offset: 10, size: 1, access: 
  Command path state machine (CPSM) Enable bit
  Field: WENDDATA
  offset: 9, size: 1, access: 
  CPSM Waits for ends of data transfer (CmdPend internal signal).
  Field: WAITINT
  offset: 8, size: 1, access: 
  CPSM waits for interrupt request
  Field: WAITRES
  offset: 6, size: 2, access: 
  Wait for response bits
  Field: CMDINDEX
  offset: 0, size: 6, access: 
  Command index
*/
volatile uint32_t CMD;

/** CMDRES CMDRES (offset: 0x10)
  command response register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CMDRES
  offset: 0, size: 6, access: 
  Response command index
*/
volatile uint32_t CMDRES;

/** RES1 RES1 (offset: 0x14)
  response 1 register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CARDSTS1
  offset: 0, size: 32, access: 
  Card status
*/
volatile uint32_t RES1;

/** RES2 RES2 (offset: 0x18)
  response 2 register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CARDSTS2
  offset: 0, size: 32, access: 
  Card status
*/
volatile uint32_t RES2;

/** RES3 RES3 (offset: 0x1c)
  response 3 register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CARDSTS3
  offset: 0, size: 32, access: 
  Card status
*/
volatile uint32_t RES3;

/** RES4 RES4 (offset: 0x20)
  response 4 register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CARDSTS4
  offset: 0, size: 32, access: 
  Card status
*/
volatile uint32_t RES4;

/** DATATIME DATATIME (offset: 0x24)
  data timer register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATATIME
  offset: 0, size: 32, access: 
  Data timeout period
*/
volatile uint32_t DATATIME;

/** DATALEN DATALEN (offset: 0x28)
  data length register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATALEN
  offset: 0, size: 25, access: 
  Data length value
*/
volatile uint32_t DATALEN;

/** DCTRL DCTRL (offset: 0x2c)
  data control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SDIOF
  offset: 11, size: 1, access: 
  SD I/O enable functions
  Field: RDWAIT
  offset: 10, size: 1, access: 
  Read wait mode
  Field: RWSTOP
  offset: 9, size: 1, access: 
  Read wait stop
  Field: RWSTR
  offset: 8, size: 1, access: 
  Read wait start
  Field: DBSIZE
  offset: 4, size: 4, access: 
  Data block size
  Field: DMAEN
  offset: 3, size: 1, access: 
  DMA enable bit
  Field: DTSEL
  offset: 2, size: 1, access: 
  Data transfer mode selection 1: Stream or SDIO multibyte data transfer.
  Field: DTDRCFG
  offset: 1, size: 1, access: 
  Data transfer direction selection
  Field: DTEN
  offset: 0, size: 1, access: 
  Data Transfer Enabled
*/
volatile uint32_t DCTRL;

/** DCNT DCNT (offset: 0x30)
  data counter register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATACNT
  offset: 0, size: 25, access: 
  Data count value
*/
volatile uint32_t DCNT;

/** STS STS (offset: 0x34)
  status register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ATAEND
  offset: 23, size: 1, access: 
  CE-ATA command completion signal received for CMD61
  Field: SDIOINT
  offset: 22, size: 1, access: 
  SDIO interrupt received
  Field: RXDA
  offset: 21, size: 1, access: 
  Data available in receive FIFO
  Field: TXDA
  offset: 20, size: 1, access: 
  Data available in transmit FIFO
  Field: RXFE
  offset: 19, size: 1, access: 
  Receive FIFO empty
  Field: TXFE
  offset: 18, size: 1, access: 
  Transmit FIFO empty
  Field: RXFF
  offset: 17, size: 1, access: 
  Receive FIFO full
  Field: TXFF
  offset: 16, size: 1, access: 
  Transmit FIFO full
  Field: RXFHF
  offset: 15, size: 1, access: 
  Receive FIFO half full: there are at least 8 words in the FIFO
  Field: TXFHF
  offset: 14, size: 1, access: 
  Transmit FIFO half empty: at least 8 words can be written into the FIFO
  Field: RXACT
  offset: 13, size: 1, access: 
  Data receive in progress
  Field: TXACT
  offset: 12, size: 1, access: 
  Data transmit in progress
  Field: CMDACT
  offset: 11, size: 1, access: 
  Command transfer in progress
  Field: DBCP
  offset: 10, size: 1, access: 
  Data block sent/received (CRC check passed)
  Field: SBE
  offset: 9, size: 1, access: 
  Start bit not detected on all data signals in wide bus mode
  Field: DATAEND
  offset: 8, size: 1, access: 
  Data end (data counter, SDIDCOUNT, is zero)
  Field: CMDSENT
  offset: 7, size: 1, access: 
  Command sent (no response required)
  Field: CMDRES
  offset: 6, size: 1, access: 
  Command response received (CRC check passed)
  Field: RXOVRER
  offset: 5, size: 1, access: 
  Received FIFO overrun error
  Field: TXUDRER
  offset: 4, size: 1, access: 
  Transmit FIFO underrun error
  Field: DATATO
  offset: 3, size: 1, access: 
  Data timeout
  Field: CMDRESTO
  offset: 2, size: 1, access: 
  Command response timeout
  Field: DBDR
  offset: 1, size: 1, access: 
  Data block sent/received (CRC check failed)
  Field: COMRESP
  offset: 0, size: 1, access: 
  Command response received (CRC check failed)
*/
volatile uint32_t STS;

/** ICF ICF (offset: 0x38)
  interrupt clear register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ATAEND
  offset: 23, size: 1, access: 
  ATAEND flag clear bit
  Field: SDIOIT
  offset: 22, size: 1, access: 
  SDIOIT flag clear bit
  Field: DBCP
  offset: 10, size: 1, access: 
  DBCP flag clear bit
  Field: SBE
  offset: 9, size: 1, access: 
  SBE flag clear bit
  Field: DATAEND
  offset: 8, size: 1, access: 
  DATAEND flag clear bit
  Field: CMDSENT
  offset: 7, size: 1, access: 
  CMDSENT flag clear bit
  Field: CMDRES
  offset: 6, size: 1, access: 
  CMDRES flag clear bit
  Field: RXFOE
  offset: 5, size: 1, access: 
  RXFOE flag clear bit
  Field: TXFUE
  offset: 4, size: 1, access: 
  TXFUE flag clear bit
  Field: DTO
  offset: 3, size: 1, access: 
  DTO flag clear bit
  Field: CRTO
  offset: 2, size: 1, access: 
  CRTO flag clear bit
  Field: DBCE
  offset: 1, size: 1, access: 
  DBDR flag clear bit
  Field: CRCE
  offset: 0, size: 1, access: 
  COMRESP flag clear bit
*/
volatile uint32_t ICF;

/** MASK MASK (offset: 0x3c)
  mask register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ATACLPREC
  offset: 23, size: 1, access: 
  CE-ATA command completion signal received interrupt enable
  Field: SDIOINTREC
  offset: 22, size: 1, access: 
  SDIO mode interrupt received interrupt enable
  Field: RXDAVB
  offset: 21, size: 1, access: 
  Data available in Rx FIFO interrupt enable
  Field: TXDAVB
  offset: 20, size: 1, access: 
  Data available in Tx FIFO interrupt enable
  Field: RXFEIE
  offset: 19, size: 1, access: 
  Rx FIFO empty interrupt enable
  Field: TXEPT
  offset: 18, size: 1, access: 
  Tx FIFO empty interrupt enable
  Field: RXFUL
  offset: 17, size: 1, access: 
  Rx FIFO full interrupt enable
  Field: TXFUL
  offset: 16, size: 1, access: 
  Tx FIFO full interrupt enable
  Field: RXHFFUL
  offset: 15, size: 1, access: 
  Rx FIFO half full interrupt enable
  Field: TXHFERT
  offset: 14, size: 1, access: 
  Tx FIFO half empty interrupt enable
  Field: RXACT
  offset: 13, size: 1, access: 
  Data receive acting interrupt enable
  Field: TXACT
  offset: 12, size: 1, access: 
  Data transmit acting interrupt enable
  Field: CMDACT
  offset: 11, size: 1, access: 
  Command acting interrupt enable
  Field: DBEND
  offset: 10, size: 1, access: 
  Data block end interrupt enable
  Field: STRTER
  offset: 9, size: 1, access: 
  Start bit error interrupt enable
  Field: DATAEND
  offset: 8, size: 1, access: 
  Data end interrupt enable
  Field: CMDSENT
  offset: 7, size: 1, access: 
  Command sent interrupt enable
  Field: CMDRESRC
  offset: 6, size: 1, access: 
  Command response received interrupt enable
  Field: RXORER
  offset: 5, size: 1, access: 
  Rx FIFO overrun error interrupt enable
  Field: TXURER
  offset: 4, size: 1, access: 
  Tx FIFO underrun error interrupt enable
  Field: DATATO
  offset: 3, size: 1, access: 
  Data timeout interrupt enable
  Field: CMDTO
  offset: 2, size: 1, access: 
  Command timeout interrupt enable
  Field: DCRCFAIL
  offset: 1, size: 1, access: 
  Data CRC fail interrupt enable
  Field: CCRCFAIL
  offset: 0, size: 1, access: 
  Command CRC fail interrupt enable
*/
volatile uint32_t MASK;
volatile uint32_t reserved0[2];

/** FIFOCNT FIFOCNT (offset: 0x48)
  FIFO counter register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FIFOCNT
  offset: 0, size: 24, access: 
  Remaining number of words to be written to or read from the FIFO.
*/
volatile uint32_t FIFOCNT;
volatile uint32_t reserved1[13];

/** FIFODATA FIFODATA (offset: 0x80)
  data FIFO register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATA
  offset: 0, size: 32, access: 
  Receive and transmit FIFO data
*/
volatile uint32_t FIFODATA;
} SDIO_type;

#define SDIO ((SDIO_type *) 0x40012C00)

#endif // HW_SDIO_H
