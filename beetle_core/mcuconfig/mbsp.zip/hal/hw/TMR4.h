#ifndef HW_TMR4_H
#define HW_TMR4_H
/** General purpose timers */
/** Interrupt : TMR4 (Vector: 30) TMR4 global interrupt */
/** Memory Block starting at 0x40000800 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define TMR4_CTRL1_CLKDIV_OFFSET                           8
#define TMR4_CTRL1_CLKDIV_MASK                             0x300

#define TMR4_CTRL1_ARPEN_OFFSET                            7
#define TMR4_CTRL1_ARPEN_MASK                              0x80

#define TMR4_CTRL1_CAMSEL_OFFSET                           5
#define TMR4_CTRL1_CAMSEL_MASK                             0x60

#define TMR4_CTRL1_CNTDIR_OFFSET                           4
#define TMR4_CTRL1_CNTDIR_MASK                             0x10

#define TMR4_CTRL1_SPMEN_OFFSET                            3
#define TMR4_CTRL1_SPMEN_MASK                              8

#define TMR4_CTRL1_URSSEL_OFFSET                           2
#define TMR4_CTRL1_URSSEL_MASK                             4

#define TMR4_CTRL1_UD_OFFSET                               1
#define TMR4_CTRL1_UD_MASK                                 2

#define TMR4_CTRL1_CNTEN_OFFSET                            0
#define TMR4_CTRL1_CNTEN_MASK                              1

#define TMR4_CTRL2_TI1SEL_OFFSET                           7
#define TMR4_CTRL2_TI1SEL_MASK                             0x80

#define TMR4_CTRL2_MMSEL_OFFSET                            4
#define TMR4_CTRL2_MMSEL_MASK                              0x70

#define TMR4_CTRL2_CCDSEL_OFFSET                           3
#define TMR4_CTRL2_CCDSEL_MASK                             8

#define TMR4_SMCTRL_ETPOL_OFFSET                           15
#define TMR4_SMCTRL_ETPOL_MASK                             0x8000

#define TMR4_SMCTRL_ECEN_OFFSET                            14
#define TMR4_SMCTRL_ECEN_MASK                              0x4000

#define TMR4_SMCTRL_ETPCFG_OFFSET                          12
#define TMR4_SMCTRL_ETPCFG_MASK                            0x3000

#define TMR4_SMCTRL_ETFCFG_OFFSET                          8
#define TMR4_SMCTRL_ETFCFG_MASK                            0xf00

#define TMR4_SMCTRL_MSMEN_OFFSET                           7
#define TMR4_SMCTRL_MSMEN_MASK                             0x80

#define TMR4_SMCTRL_TRGSEL_OFFSET                          4
#define TMR4_SMCTRL_TRGSEL_MASK                            0x70

#define TMR4_SMCTRL_SMFSEL_OFFSET                          0
#define TMR4_SMCTRL_SMFSEL_MASK                            7

#define TMR4_DIEN_TRGDEN_OFFSET                            14
#define TMR4_DIEN_TRGDEN_MASK                              0x4000

#define TMR4_DIEN_CC4DEN_OFFSET                            12
#define TMR4_DIEN_CC4DEN_MASK                              0x1000

#define TMR4_DIEN_CC3DEN_OFFSET                            11
#define TMR4_DIEN_CC3DEN_MASK                              0x800

#define TMR4_DIEN_CC2DEN_OFFSET                            10
#define TMR4_DIEN_CC2DEN_MASK                              0x400

#define TMR4_DIEN_CC1DEN_OFFSET                            9
#define TMR4_DIEN_CC1DEN_MASK                              0x200

#define TMR4_DIEN_UDIEN_OFFSET                             8
#define TMR4_DIEN_UDIEN_MASK                               0x100

#define TMR4_DIEN_TRGIEN_OFFSET                            6
#define TMR4_DIEN_TRGIEN_MASK                              0x40

#define TMR4_DIEN_CC4IEN_OFFSET                            4
#define TMR4_DIEN_CC4IEN_MASK                              0x10

#define TMR4_DIEN_CC3IEN_OFFSET                            3
#define TMR4_DIEN_CC3IEN_MASK                              8

#define TMR4_DIEN_CC2IEN_OFFSET                            2
#define TMR4_DIEN_CC2IEN_MASK                              4

#define TMR4_DIEN_CC1IEN_OFFSET                            1
#define TMR4_DIEN_CC1IEN_MASK                              2

#define TMR4_DIEN_UIEN_OFFSET                              0
#define TMR4_DIEN_UIEN_MASK                                1

#define TMR4_STS_CC4RCFLG_OFFSET                           12
#define TMR4_STS_CC4RCFLG_MASK                             0x1000

#define TMR4_STS_CC3RCFLG_OFFSET                           11
#define TMR4_STS_CC3RCFLG_MASK                             0x800

#define TMR4_STS_CC2RCFLG_OFFSET                           10
#define TMR4_STS_CC2RCFLG_MASK                             0x400

#define TMR4_STS_CC1RCFLG_OFFSET                           9
#define TMR4_STS_CC1RCFLG_MASK                             0x200

#define TMR4_STS_TRGIFLG_OFFSET                            6
#define TMR4_STS_TRGIFLG_MASK                              0x40

#define TMR4_STS_CC4IFLG_OFFSET                            4
#define TMR4_STS_CC4IFLG_MASK                              0x10

#define TMR4_STS_CC3IFLG_OFFSET                            3
#define TMR4_STS_CC3IFLG_MASK                              8

#define TMR4_STS_CC2IFLG_OFFSET                            2
#define TMR4_STS_CC2IFLG_MASK                              4

#define TMR4_STS_CC1IFLG_OFFSET                            1
#define TMR4_STS_CC1IFLG_MASK                              2

#define TMR4_STS_UIFLG_OFFSET                              0
#define TMR4_STS_UIFLG_MASK                                1

#define TMR4_CFG_TEG_OFFSET                                6
#define TMR4_CFG_TEG_MASK                                  0x40

#define TMR4_CFG_CC4EG_OFFSET                              4
#define TMR4_CFG_CC4EG_MASK                                0x10

#define TMR4_CFG_CC3EG_OFFSET                              3
#define TMR4_CFG_CC3EG_MASK                                8

#define TMR4_CFG_CC2EG_OFFSET                              2
#define TMR4_CFG_CC2EG_MASK                                4

#define TMR4_CFG_CC1EG_OFFSET                              1
#define TMR4_CFG_CC1EG_MASK                                2

#define TMR4_CFG_UEG_OFFSET                                0
#define TMR4_CFG_UEG_MASK                                  1

#define TMR4_CCM1_COMPARE_OC2CEN_OFFSET                    15
#define TMR4_CCM1_COMPARE_OC2CEN_MASK                      0x8000

#define TMR4_CCM1_COMPARE_OC2MOD_OFFSET                    12
#define TMR4_CCM1_COMPARE_OC2MOD_MASK                      0x7000

#define TMR4_CCM1_COMPARE_OC2PEN_OFFSET                    11
#define TMR4_CCM1_COMPARE_OC2PEN_MASK                      0x800

#define TMR4_CCM1_COMPARE_OC2FEN_OFFSET                    10
#define TMR4_CCM1_COMPARE_OC2FEN_MASK                      0x400

#define TMR4_CCM1_COMPARE_CC2SEL_OFFSET                    8
#define TMR4_CCM1_COMPARE_CC2SEL_MASK                      0x300

#define TMR4_CCM1_COMPARE_OC1CEN_OFFSET                    7
#define TMR4_CCM1_COMPARE_OC1CEN_MASK                      0x80

#define TMR4_CCM1_COMPARE_OC1MOD_OFFSET                    4
#define TMR4_CCM1_COMPARE_OC1MOD_MASK                      0x70

#define TMR4_CCM1_COMPARE_OC1PEN_OFFSET                    3
#define TMR4_CCM1_COMPARE_OC1PEN_MASK                      8

#define TMR4_CCM1_COMPARE_OC1FEN_OFFSET                    2
#define TMR4_CCM1_COMPARE_OC1FEN_MASK                      4

#define TMR4_CCM1_COMPARE_CC1SEL_OFFSET                    0
#define TMR4_CCM1_COMPARE_CC1SEL_MASK                      3

#define TMR4_CCM2_COMPARE_OC4CEN_OFFSET                    15
#define TMR4_CCM2_COMPARE_OC4CEN_MASK                      0x8000

#define TMR4_CCM2_COMPARE_OC4MOD_OFFSET                    12
#define TMR4_CCM2_COMPARE_OC4MOD_MASK                      0x7000

#define TMR4_CCM2_COMPARE_OC4PEN_OFFSET                    11
#define TMR4_CCM2_COMPARE_OC4PEN_MASK                      0x800

#define TMR4_CCM2_COMPARE_OC4FEN_OFFSET                    10
#define TMR4_CCM2_COMPARE_OC4FEN_MASK                      0x400

#define TMR4_CCM2_COMPARE_CC4SEL_OFFSET                    8
#define TMR4_CCM2_COMPARE_CC4SEL_MASK                      0x300

#define TMR4_CCM2_COMPARE_OC3CEN_OFFSET                    7
#define TMR4_CCM2_COMPARE_OC3CEN_MASK                      0x80

#define TMR4_CCM2_COMPARE_OC3MOD_OFFSET                    4
#define TMR4_CCM2_COMPARE_OC3MOD_MASK                      0x70

#define TMR4_CCM2_COMPARE_OC3PEN_OFFSET                    3
#define TMR4_CCM2_COMPARE_OC3PEN_MASK                      8

#define TMR4_CCM2_COMPARE_OC3FEN_OFFSET                    2
#define TMR4_CCM2_COMPARE_OC3FEN_MASK                      4

#define TMR4_CCM2_COMPARE_CC3SEL_OFFSET                    0
#define TMR4_CCM2_COMPARE_CC3SEL_MASK                      3

#define TMR4_CCEN_CC4NPOL_OFFSET                           15
#define TMR4_CCEN_CC4NPOL_MASK                             0x8000

#define TMR4_CCEN_CC4POL_OFFSET                            13
#define TMR4_CCEN_CC4POL_MASK                              0x2000

#define TMR4_CCEN_CC4EN_OFFSET                             12
#define TMR4_CCEN_CC4EN_MASK                               0x1000

#define TMR4_CCEN_CC3NPOL_OFFSET                           11
#define TMR4_CCEN_CC3NPOL_MASK                             0x800

#define TMR4_CCEN_CC3POL_OFFSET                            9
#define TMR4_CCEN_CC3POL_MASK                              0x200

#define TMR4_CCEN_CC3EN_OFFSET                             8
#define TMR4_CCEN_CC3EN_MASK                               0x100

#define TMR4_CCEN_CC2NPOL_OFFSET                           7
#define TMR4_CCEN_CC2NPOL_MASK                             0x80

#define TMR4_CCEN_CC2POL_OFFSET                            5
#define TMR4_CCEN_CC2POL_MASK                              0x20

#define TMR4_CCEN_CC2EN_OFFSET                             4
#define TMR4_CCEN_CC2EN_MASK                               0x10

#define TMR4_CCEN_CC1NPOL_OFFSET                           3
#define TMR4_CCEN_CC1NPOL_MASK                             8

#define TMR4_CCEN_CC1POL_OFFSET                            1
#define TMR4_CCEN_CC1POL_MASK                              2

#define TMR4_CCEN_CC1EN_OFFSET                             0
#define TMR4_CCEN_CC1EN_MASK                               1

#define TMR4_CNT_CNT_OFFSET                                0
#define TMR4_CNT_CNT_MASK                                  0xffff

#define TMR4_PSC_PSC_OFFSET                                0
#define TMR4_PSC_PSC_MASK                                  0xffff

#define TMR4_AUTORLD_AUTORLD_OFFSET                        0
#define TMR4_AUTORLD_AUTORLD_MASK                          0xffff

#define TMR4_CC1_CC1_L_OFFSET                              0
#define TMR4_CC1_CC1_L_MASK                                0xffff

#define TMR4_CC2_CC2_L_OFFSET                              0
#define TMR4_CC2_CC2_L_MASK                                0xffff

#define TMR4_CC3_CC3_L_OFFSET                              0
#define TMR4_CC3_CC3_L_MASK                                0xffff

#define TMR4_CC4_CC4_L_OFFSET                              0
#define TMR4_CC4_CC4_L_MASK                                0xffff

#define TMR4_DCTRL_DBLEN_OFFSET                            8
#define TMR4_DCTRL_DBLEN_MASK                              0x1f00

#define TMR4_DCTRL_DBADDR_OFFSET                           0
#define TMR4_DCTRL_DBADDR_MASK                             0x1f

#define TMR4_DMADDR_DMADDR_OFFSET                          0
#define TMR4_DMADDR_DMADDR_MASK                            0xffff


typedef struct
{

/** CTRL1 CTRL1 (offset: 0x0)
  control register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CLKDIV
  offset: 8, size: 2, access: 
  Clock division
  Field: ARPEN
  offset: 7, size: 1, access: 
  Auto-reload preload enable
  Field: CAMSEL
  offset: 5, size: 2, access: 
  Center-aligned mode selection
  Field: CNTDIR
  offset: 4, size: 1, access: 
  Direction
  Field: SPMEN
  offset: 3, size: 1, access: 
  One-pulse mode
  Field: URSSEL
  offset: 2, size: 1, access: 
  Update request source
  Field: UD
  offset: 1, size: 1, access: 
  Update disable
  Field: CNTEN
  offset: 0, size: 1, access: 
  Counter enable
*/
volatile uint32_t CTRL1;

/** CTRL2 CTRL2 (offset: 0x4)
  control register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TI1SEL
  offset: 7, size: 1, access: 
  TI1 selection
  Field: MMSEL
  offset: 4, size: 3, access: 
  Master mode selection
  Field: CCDSEL
  offset: 3, size: 1, access: 
  Capture/compare DMA selection
*/
volatile uint32_t CTRL2;

/** SMCTRL SMCTRL (offset: 0x8)
  slave mode control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ETPOL
  offset: 15, size: 1, access: 
  External trigger polarity
  Field: ECEN
  offset: 14, size: 1, access: 
  External clock enable
  Field: ETPCFG
  offset: 12, size: 2, access: 
  External trigger prescaler
  Field: ETFCFG
  offset: 8, size: 4, access: 
  External trigger filter
  Field: MSMEN
  offset: 7, size: 1, access: 
  Master/Slave mode
  Field: TRGSEL
  offset: 4, size: 3, access: 
  Trigger selection
  Field: SMFSEL
  offset: 0, size: 3, access: 
  Slave mode selection
*/
volatile uint32_t SMCTRL;

/** DIEN DIEN (offset: 0xc)
  DMA/Interrupt enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TRGDEN
  offset: 14, size: 1, access: 
  Trigger DMA request enable
  Field: CC4DEN
  offset: 12, size: 1, access: 
  Capture/Compare 4 DMA request enable
  Field: CC3DEN
  offset: 11, size: 1, access: 
  Capture/Compare 3 DMA request enable
  Field: CC2DEN
  offset: 10, size: 1, access: 
  Capture/Compare 2 DMA request enable
  Field: CC1DEN
  offset: 9, size: 1, access: 
  Capture/Compare 1 DMA request enable
  Field: UDIEN
  offset: 8, size: 1, access: 
  Update DMA request enable
  Field: TRGIEN
  offset: 6, size: 1, access: 
  Trigger interrupt enable
  Field: CC4IEN
  offset: 4, size: 1, access: 
  Capture/Compare 4 interrupt enable
  Field: CC3IEN
  offset: 3, size: 1, access: 
  Capture/Compare 3 interrupt enable
  Field: CC2IEN
  offset: 2, size: 1, access: 
  Capture/Compare 2 interrupt enable
  Field: CC1IEN
  offset: 1, size: 1, access: 
  Capture/Compare 1 interrupt enable
  Field: UIEN
  offset: 0, size: 1, access: 
  Update interrupt enable
*/
volatile uint32_t DIEN;

/** STS STS (offset: 0x10)
  status register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC4RCFLG
  offset: 12, size: 1, access: 
  Capture/Compare 4 overcapture flag
  Field: CC3RCFLG
  offset: 11, size: 1, access: 
  Capture/Compare 3 overcapture flag
  Field: CC2RCFLG
  offset: 10, size: 1, access: 
  Capture/compare 2 overcapture flag
  Field: CC1RCFLG
  offset: 9, size: 1, access: 
  Capture/Compare 1 overcapture flag
  Field: TRGIFLG
  offset: 6, size: 1, access: 
  Trigger interrupt flag
  Field: CC4IFLG
  offset: 4, size: 1, access: 
  Capture/Compare 4 interrupt flag
  Field: CC3IFLG
  offset: 3, size: 1, access: 
  Capture/Compare 3 interrupt flag
  Field: CC2IFLG
  offset: 2, size: 1, access: 
  Capture/Compare 2 interrupt flag
  Field: CC1IFLG
  offset: 1, size: 1, access: 
  Capture/compare 1 interrupt flag
  Field: UIFLG
  offset: 0, size: 1, access: 
  Update interrupt flag
*/
volatile uint32_t STS;

/** CFG CFG (offset: 0x14)
  event generation register
  access : write-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TEG
  offset: 6, size: 1, access: 
  Trigger generation
  Field: CC4EG
  offset: 4, size: 1, access: 
  Capture/compare 4 generation
  Field: CC3EG
  offset: 3, size: 1, access: 
  Capture/compare 3 generation
  Field: CC2EG
  offset: 2, size: 1, access: 
  Capture/compare 2 generation
  Field: CC1EG
  offset: 1, size: 1, access: 
  Capture/compare 1 generation
  Field: UEG
  offset: 0, size: 1, access: 
  Update generation
*/
volatile uint32_t CFG;

/** CCM1_COMPARE CCM1_COMPARE (offset: 0x18)
  capture/compare mode register 1 (output mode)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OC2CEN
  offset: 15, size: 1, access: 
  Output Compare 2 clear enable
  Field: OC2MOD
  offset: 12, size: 3, access: 
  Output Compare 2 mode
  Field: OC2PEN
  offset: 11, size: 1, access: 
  Output Compare 2 preload enable
  Field: OC2FEN
  offset: 10, size: 1, access: 
  Output Compare 2 fast enable
  Field: CC2SEL
  offset: 8, size: 2, access: 
  Capture/Compare 2 selection
  Field: OC1CEN
  offset: 7, size: 1, access: 
  Output Compare 1 clear enable
  Field: OC1MOD
  offset: 4, size: 3, access: 
  Output Compare 1 mode
  Field: OC1PEN
  offset: 3, size: 1, access: 
  Output Compare 1 preload enable
  Field: OC1FEN
  offset: 2, size: 1, access: 
  Output Compare 1 fast enable
  Field: CC1SEL
  offset: 0, size: 2, access: 
  Capture/Compare 1 selection
*/
volatile uint32_t CCM1_COMPARE;

/** CCM2_COMPARE CCM2_COMPARE (offset: 0x1c)
  capture/compare mode register 2 (output mode)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OC4CEN
  offset: 15, size: 1, access: 
  Output compare 4 clear enable
  Field: OC4MOD
  offset: 12, size: 3, access: 
  Output compare 4 mode
  Field: OC4PEN
  offset: 11, size: 1, access: 
  Output compare 4 preload enable
  Field: OC4FEN
  offset: 10, size: 1, access: 
  Output compare 4 fast enable
  Field: CC4SEL
  offset: 8, size: 2, access: 
  Capture/Compare 4 selection
  Field: OC3CEN
  offset: 7, size: 1, access: 
  Output compare 3 clear enable
  Field: OC3MOD
  offset: 4, size: 3, access: 
  Output compare 3 mode
  Field: OC3PEN
  offset: 3, size: 1, access: 
  Output compare 3 preload enable
  Field: OC3FEN
  offset: 2, size: 1, access: 
  Output compare 3 fast enable
  Field: CC3SEL
  offset: 0, size: 2, access: 
  Capture/Compare 3 selection
*/
volatile uint32_t CCM2_COMPARE;

/** CCEN CCEN (offset: 0x20)
  capture/compare enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC4NPOL
  offset: 15, size: 1, access: 
  Capture/Compare 4 output Polarity
  Field: CC4POL
  offset: 13, size: 1, access: 
  Capture/Compare 3 output Polarity
  Field: CC4EN
  offset: 12, size: 1, access: 
  Capture/Compare 4 output enable
  Field: CC3NPOL
  offset: 11, size: 1, access: 
  Capture/Compare 3 output Polarity
  Field: CC3POL
  offset: 9, size: 1, access: 
  Capture/Compare 3 output Polarity
  Field: CC3EN
  offset: 8, size: 1, access: 
  Capture/Compare 3 output enable
  Field: CC2NPOL
  offset: 7, size: 1, access: 
  Capture/Compare 2 output Polarity
  Field: CC2POL
  offset: 5, size: 1, access: 
  Capture/Compare 2 output Polarity
  Field: CC2EN
  offset: 4, size: 1, access: 
  Capture/Compare 2 output enable
  Field: CC1NPOL
  offset: 3, size: 1, access: 
  Capture/Compare 1 output Polarity
  Field: CC1POL
  offset: 1, size: 1, access: 
  Capture/Compare 1 output Polarity
  Field: CC1EN
  offset: 0, size: 1, access: 
  Capture/Compare 1 output enable
*/
volatile uint32_t CCEN;

/** CNT CNT (offset: 0x24)
  counter
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CNT
  offset: 0, size: 16, access: 
  Counter value
*/
volatile uint32_t CNT;

/** PSC PSC (offset: 0x28)
  prescaler
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PSC
  offset: 0, size: 16, access: 
  Prescaler value
*/
volatile uint32_t PSC;

/** AUTORLD AUTORLD (offset: 0x2c)
  auto-reload register
  access : read-write
  reset value : 0xFFFF
  reset mask : 0xFFFFFFFF
  Field: AUTORLD
  offset: 0, size: 16, access: 
  Auto-reload value
*/
volatile uint32_t AUTORLD;
volatile uint32_t reserved0;

/** CC1 CC1 (offset: 0x34)
  capture/compare register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC1_L
  offset: 0, size: 16, access: 
  Low Capture/Compare 1 value
*/
volatile uint32_t CC1;

/** CC2 CC2 (offset: 0x38)
  capture/compare register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC2_L
  offset: 0, size: 16, access: 
  Low Capture/Compare 2 value
*/
volatile uint32_t CC2;

/** CC3 CC3 (offset: 0x3c)
  capture/compare register 3
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC3_L
  offset: 0, size: 16, access: 
  Low Capture/Compare value
*/
volatile uint32_t CC3;

/** CC4 CC4 (offset: 0x40)
  capture/compare register 4
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC4_L
  offset: 0, size: 16, access: 
  Low Capture/Compare value
*/
volatile uint32_t CC4;
volatile uint32_t reserved1;

/** DCTRL DCTRL (offset: 0x48)
  DMA control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DBLEN
  offset: 8, size: 5, access: 
  DMA burst length
  Field: DBADDR
  offset: 0, size: 5, access: 
  DMA base address
*/
volatile uint32_t DCTRL;

/** DMADDR DMADDR (offset: 0x4c)
  DMA address for full transfer
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DMADDR
  offset: 0, size: 16, access: 
  DMA register for burst accesses
*/
volatile uint32_t DMADDR;
} TMR4_type;

#define TMR4 ((TMR4_type *) 0x40000800)

#endif // HW_TMR4_H
