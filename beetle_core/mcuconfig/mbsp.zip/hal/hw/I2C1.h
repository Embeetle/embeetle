#ifndef HW_I2C1_H
#define HW_I2C1_H
/** Inter-integrated circuit */
/** Interrupt : I2C1_ER (Vector: 32) I2C1 error interrupt */
/** Interrupt : I2C1_EV (Vector: 31) I2C1 event interrupt */
/** Memory Block starting at 0x40005400 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define I2C1_CTRL1_SWRST_OFFSET                            15
#define I2C1_CTRL1_SWRST_MASK                              0x8000

#define I2C1_CTRL1_ALERTEN_OFFSET                          13
#define I2C1_CTRL1_ALERTEN_MASK                            0x2000

#define I2C1_CTRL1_PEC_OFFSET                              12
#define I2C1_CTRL1_PEC_MASK                                0x1000

#define I2C1_CTRL1_ACKPOS_OFFSET                           11
#define I2C1_CTRL1_ACKPOS_MASK                             0x800

#define I2C1_CTRL1_ACKEN_OFFSET                            10
#define I2C1_CTRL1_ACKEN_MASK                              0x400

#define I2C1_CTRL1_STOP_OFFSET                             9
#define I2C1_CTRL1_STOP_MASK                               0x200

#define I2C1_CTRL1_START_OFFSET                            8
#define I2C1_CTRL1_START_MASK                              0x100

#define I2C1_CTRL1_CLKSTRETCHD_OFFSET                      7
#define I2C1_CTRL1_CLKSTRETCHD_MASK                        0x80

#define I2C1_CTRL1_SRBEN_OFFSET                            6
#define I2C1_CTRL1_SRBEN_MASK                              0x40

#define I2C1_CTRL1_PECEN_OFFSET                            5
#define I2C1_CTRL1_PECEN_MASK                              0x20

#define I2C1_CTRL1_ARPEN_OFFSET                            4
#define I2C1_CTRL1_ARPEN_MASK                              0x10

#define I2C1_CTRL1_SMBTCFG_OFFSET                          3
#define I2C1_CTRL1_SMBTCFG_MASK                            8

#define I2C1_CTRL1_SMBEN_OFFSET                            1
#define I2C1_CTRL1_SMBEN_MASK                              2

#define I2C1_CTRL1_I2CEN_OFFSET                            0
#define I2C1_CTRL1_I2CEN_MASK                              1

#define I2C1_CTRL2_LTCFG_OFFSET                            12
#define I2C1_CTRL2_LTCFG_MASK                              0x1000

#define I2C1_CTRL2_DMAEN_OFFSET                            11
#define I2C1_CTRL2_DMAEN_MASK                              0x800

#define I2C1_CTRL2_BUFIEN_OFFSET                           10
#define I2C1_CTRL2_BUFIEN_MASK                             0x400

#define I2C1_CTRL2_EVIEN_OFFSET                            9
#define I2C1_CTRL2_EVIEN_MASK                              0x200

#define I2C1_CTRL2_ERRIEN_OFFSET                           8
#define I2C1_CTRL2_ERRIEN_MASK                             0x100

#define I2C1_CTRL2_CLKFCFG_OFFSET                          0
#define I2C1_CTRL2_CLKFCFG_MASK                            0x3f

#define I2C1_SADDR1_ADDRLEN_OFFSET                         15
#define I2C1_SADDR1_ADDRLEN_MASK                           0x8000

#define I2C1_SADDR1_ADDR10_OFFSET                          8
#define I2C1_SADDR1_ADDR10_MASK                            0x300

#define I2C1_SADDR1_ADDR7_OFFSET                           1
#define I2C1_SADDR1_ADDR7_MASK                             0xfe

#define I2C1_SADDR1_ADDR0_OFFSET                           0
#define I2C1_SADDR1_ADDR0_MASK                             1

#define I2C1_SADDR2_ADDR2_OFFSET                           1
#define I2C1_SADDR2_ADDR2_MASK                             0xfe

#define I2C1_SADDR2_ADDRNUM_OFFSET                         0
#define I2C1_SADDR2_ADDRNUM_MASK                           1

#define I2C1_DATA_DATA_OFFSET                              0
#define I2C1_DATA_DATA_MASK                                0xff

#define I2C1_STS1_SMBALTFLG_OFFSET                         15
#define I2C1_STS1_SMBALTFLG_MASK                           0x8000

#define I2C1_STS1_TTEFLG_OFFSET                            14
#define I2C1_STS1_TTEFLG_MASK                              0x4000

#define I2C1_STS1_PECEFLG_OFFSET                           12
#define I2C1_STS1_PECEFLG_MASK                             0x1000

#define I2C1_STS1_OVRURFLG_OFFSET                          11
#define I2C1_STS1_OVRURFLG_MASK                            0x800

#define I2C1_STS1_AEFLG_OFFSET                             10
#define I2C1_STS1_AEFLG_MASK                               0x400

#define I2C1_STS1_ALFLG_OFFSET                             9
#define I2C1_STS1_ALFLG_MASK                               0x200

#define I2C1_STS1_BERRFLG_OFFSET                           8
#define I2C1_STS1_BERRFLG_MASK                             0x100

#define I2C1_STS1_TXBEFLG_OFFSET                           7
#define I2C1_STS1_TXBEFLG_MASK                             0x80

#define I2C1_STS1_RXBNEFLG_OFFSET                          6
#define I2C1_STS1_RXBNEFLG_MASK                            0x40

#define I2C1_STS1_STOPFLG_OFFSET                           4
#define I2C1_STS1_STOPFLG_MASK                             0x10

#define I2C1_STS1_ADDR10FLG_OFFSET                         3
#define I2C1_STS1_ADDR10FLG_MASK                           8

#define I2C1_STS1_BTCFLG_OFFSET                            2
#define I2C1_STS1_BTCFLG_MASK                              4

#define I2C1_STS1_ADDRFLG_OFFSET                           1
#define I2C1_STS1_ADDRFLG_MASK                             2

#define I2C1_STS1_STARTFLG_OFFSET                          0
#define I2C1_STS1_STARTFLG_MASK                            1

#define I2C1_STS2_PECVALUE_OFFSET                          8
#define I2C1_STS2_PECVALUE_MASK                            0xff00

#define I2C1_STS2_DUALADDRFLG_OFFSET                       7
#define I2C1_STS2_DUALADDRFLG_MASK                         0x80

#define I2C1_STS2_SMMHADDR_OFFSET                          6
#define I2C1_STS2_SMMHADDR_MASK                            0x40

#define I2C1_STS2_SMBDADDRFLG_OFFSET                       5
#define I2C1_STS2_SMBDADDRFLG_MASK                         0x20

#define I2C1_STS2_GENCALLFLG_OFFSET                        4
#define I2C1_STS2_GENCALLFLG_MASK                          0x10

#define I2C1_STS2_TRFLG_OFFSET                             2
#define I2C1_STS2_TRFLG_MASK                               4

#define I2C1_STS2_BUSBSYFLG_OFFSET                         1
#define I2C1_STS2_BUSBSYFLG_MASK                           2

#define I2C1_STS2_MSFLG_OFFSET                             0
#define I2C1_STS2_MSFLG_MASK                               1

#define I2C1_CLKCTRL_SPEEDCFG_OFFSET                       15
#define I2C1_CLKCTRL_SPEEDCFG_MASK                         0x8000

#define I2C1_CLKCTRL_FDUTYCFG_OFFSET                       14
#define I2C1_CLKCTRL_FDUTYCFG_MASK                         0x4000

#define I2C1_CLKCTRL_CLKS_OFFSET                           0
#define I2C1_CLKCTRL_CLKS_MASK                             0xfff

#define I2C1_RISETMAX_RISETMAX_OFFSET                      0
#define I2C1_RISETMAX_RISETMAX_MASK                        0x3f

#define I2C1_FILTER_DNFCFG_OFFSET                          0
#define I2C1_FILTER_DNFCFG_MASK                            0xf

#define I2C1_FILTER_RISETMAX_OFFSET                        4
#define I2C1_FILTER_RISETMAX_MASK                          0x10


typedef struct
{

/** CTRL1 CTRL1 (offset: 0x0)
  Control register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SWRST
  offset: 15, size: 1, access: 
  Software reset
  Field: ALERTEN
  offset: 13, size: 1, access: 
  SMBus alert
  Field: PEC
  offset: 12, size: 1, access: 
  Packet error checking
  Field: ACKPOS
  offset: 11, size: 1, access: 
  Acknowledge/PEC Position (for data reception)
  Field: ACKEN
  offset: 10, size: 1, access: 
  Acknowledge enable
  Field: STOP
  offset: 9, size: 1, access: 
  Stop generation
  Field: START
  offset: 8, size: 1, access: 
  Start generation
  Field: CLKSTRETCHD
  offset: 7, size: 1, access: 
  Clock stretching disable (Slave mode)
  Field: SRBEN
  offset: 6, size: 1, access: 
  General call enable
  Field: PECEN
  offset: 5, size: 1, access: 
  PEC enable
  Field: ARPEN
  offset: 4, size: 1, access: 
  ARP enable
  Field: SMBTCFG
  offset: 3, size: 1, access: 
  SMBus type
  Field: SMBEN
  offset: 1, size: 1, access: 
  SMBus mode
  Field: I2CEN
  offset: 0, size: 1, access: 
  I2C enable
*/
volatile uint32_t CTRL1;

/** CTRL2 CTRL2 (offset: 0x4)
  Control register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: LTCFG
  offset: 12, size: 1, access: 
  DMA last transfer
  Field: DMAEN
  offset: 11, size: 1, access: 
  DMA requests enable
  Field: BUFIEN
  offset: 10, size: 1, access: 
  Buffer interrupt enable
  Field: EVIEN
  offset: 9, size: 1, access: 
  Event interrupt enable
  Field: ERRIEN
  offset: 8, size: 1, access: 
  Error interrupt enable
  Field: CLKFCFG
  offset: 0, size: 6, access: 
  I2C clock frequency
*/
volatile uint32_t CTRL2;

/** SADDR1 SADDR1 (offset: 0x8)
  Own address register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ADDRLEN
  offset: 15, size: 1, access: 
  Addressing mode (slave mode)
  Field: ADDR10
  offset: 8, size: 2, access: 
  Interface address
  Field: ADDR7
  offset: 1, size: 7, access: 
  Interface address
  Field: ADDR0
  offset: 0, size: 1, access: 
  Interface address
*/
volatile uint32_t SADDR1;

/** SADDR2 SADDR2 (offset: 0xc)
  Own address register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ADDR2
  offset: 1, size: 7, access: 
  Interface address
  Field: ADDRNUM
  offset: 0, size: 1, access: 
  Slave Address Number Configure
*/
volatile uint32_t SADDR2;

/** DATA DATA (offset: 0x10)
  Data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATA
  offset: 0, size: 8, access: 
  8-bit data register
*/
volatile uint32_t DATA;

/** STS1 STS1 (offset: 0x14)
  Status register 1
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SMBALTFLG
  offset: 15, size: 1, access: read-write
  SMBus alert
  Field: TTEFLG
  offset: 14, size: 1, access: read-write
  Timeout or Tlow error
  Field: PECEFLG
  offset: 12, size: 1, access: read-write
  PEC Error in reception
  Field: OVRURFLG
  offset: 11, size: 1, access: read-write
  Overrun/Underrun
  Field: AEFLG
  offset: 10, size: 1, access: read-write
  Acknowledge failure
  Field: ALFLG
  offset: 9, size: 1, access: read-write
  Arbitration lost (master mode)
  Field: BERRFLG
  offset: 8, size: 1, access: read-write
  Bus error
  Field: TXBEFLG
  offset: 7, size: 1, access: read-only
  Data register empty (transmitters)
  Field: RXBNEFLG
  offset: 6, size: 1, access: read-only
  Data register not empty (receivers)
  Field: STOPFLG
  offset: 4, size: 1, access: read-only
  Stop detection (slave mode)
  Field: ADDR10FLG
  offset: 3, size: 1, access: read-only
  10-bit header sent (Master mode)
  Field: BTCFLG
  offset: 2, size: 1, access: read-only
  Byte transfer finished
  Field: ADDRFLG
  offset: 1, size: 1, access: read-only
  Address sent (master mode)/matched (slavemode)
  Field: STARTFLG
  offset: 0, size: 1, access: read-only
  Start bit (Master mode)
*/
volatile uint32_t STS1;

/** STS2 STS2 (offset: 0x18)
  Status register 2
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PECVALUE
  offset: 8, size: 8, access: 
  Save Packet Error Checking Value
  Field: DUALADDRFLG
  offset: 7, size: 1, access: 
  Dual flag (Slave mode)
  Field: SMMHADDR
  offset: 6, size: 1, access: 
  SMBus host header (Slave mode)
  Field: SMBDADDRFLG
  offset: 5, size: 1, access: 
  SMBus device default address (Slave mode)
  Field: GENCALLFLG
  offset: 4, size: 1, access: 
  General call address (Slave mode)
  Field: TRFLG
  offset: 2, size: 1, access: 
  Transmitter/receiver
  Field: BUSBSYFLG
  offset: 1, size: 1, access: 
  Bus busy
  Field: MSFLG
  offset: 0, size: 1, access: 
  Master Slave Mode Flag
*/
volatile uint32_t STS2;

/** CLKCTRL CLKCTRL (offset: 0x1c)
  Clock control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SPEEDCFG
  offset: 15, size: 1, access: 
  Master Mode Speed Configure
  Field: FDUTYCFG
  offset: 14, size: 1, access: 
  Fast mode duty cycle
  Field: CLKS
  offset: 0, size: 12, access: 
  Clock control register in Fast/Standard mode(Master mode)
*/
volatile uint32_t CLKCTRL;

/** RISETMAX RISETMAX (offset: 0x20)
  Maximum Rise Time register
  access : read-write
  reset value : 0x2
  reset mask : 0xFFFFFFFF
  Field: RISETMAX
  offset: 0, size: 6, access: 
  Maximum rise time in Fast/Standard mode (Master mode)
*/
volatile uint32_t RISETMAX;

/** FILTER FILTER (offset: 0x24)
  Filter control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DNFCFG
  offset: 0, size: 4, access: 
  Digitial Noise Filter Filtering Capabitity Configure
  Field: RISETMAX
  offset: 4, size: 1, access: 
  Analog Noise Filter Disable
*/
volatile uint32_t FILTER;
} I2C1_type;

#define I2C1 ((I2C1_type *) 0x40005400)

#endif // HW_I2C1_H
