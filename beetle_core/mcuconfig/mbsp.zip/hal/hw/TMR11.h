#ifndef HW_TMR11_H
#define HW_TMR11_H
/** General-purpose-timers */
/** Interrupt : TMR1_TRG_COM_TMR11 (Vector: 26) TMR1 Trigger and Commutation interrupts and TMR11 global interrupt */
/** Memory Block starting at 0x40014800 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define TMR11_CTRL1_CLKDIV_OFFSET                          8
#define TMR11_CTRL1_CLKDIV_MASK                            0x300

#define TMR11_CTRL1_ARPEN_OFFSET                           7
#define TMR11_CTRL1_ARPEN_MASK                             0x80

#define TMR11_CTRL1_SPMEN_OFFSET                           3
#define TMR11_CTRL1_SPMEN_MASK                             8

#define TMR11_CTRL1_URSSEL_OFFSET                          2
#define TMR11_CTRL1_URSSEL_MASK                            4

#define TMR11_CTRL1_UD_OFFSET                              1
#define TMR11_CTRL1_UD_MASK                                2

#define TMR11_CTRL1_CNTEN_OFFSET                           0
#define TMR11_CTRL1_CNTEN_MASK                             1

#define TMR11_DIEN_CC1IEN_OFFSET                           1
#define TMR11_DIEN_CC1IEN_MASK                             2

#define TMR11_DIEN_UIEN_OFFSET                             0
#define TMR11_DIEN_UIEN_MASK                               1

#define TMR11_STS_CC1RCFLG_OFFSET                          9
#define TMR11_STS_CC1RCFLG_MASK                            0x200

#define TMR11_STS_CC1IFLG_OFFSET                           1
#define TMR11_STS_CC1IFLG_MASK                             2

#define TMR11_STS_UIFLG_OFFSET                             0
#define TMR11_STS_UIFLG_MASK                               1

#define TMR11_CEG_CC1EG_OFFSET                             1
#define TMR11_CEG_CC1EG_MASK                               2

#define TMR11_CEG_UEG_OFFSET                               0
#define TMR11_CEG_UEG_MASK                                 1

#define TMR11_CCM1_COMPARE_OC1MOD_OFFSET                   4
#define TMR11_CCM1_COMPARE_OC1MOD_MASK                     0x70

#define TMR11_CCM1_COMPARE_OC1PEN_OFFSET                   3
#define TMR11_CCM1_COMPARE_OC1PEN_MASK                     8

#define TMR11_CCM1_COMPARE_OC1FEN_OFFSET                   2
#define TMR11_CCM1_COMPARE_OC1FEN_MASK                     4

#define TMR11_CCM1_COMPARE_CC1SEL_OFFSET                   0
#define TMR11_CCM1_COMPARE_CC1SEL_MASK                     3

#define TMR11_CCEN_CC1NPOL_OFFSET                          3
#define TMR11_CCEN_CC1NPOL_MASK                            8

#define TMR11_CCEN_CC1POL_OFFSET                           1
#define TMR11_CCEN_CC1POL_MASK                             2

#define TMR11_CCEN_CC1EN_OFFSET                            0
#define TMR11_CCEN_CC1EN_MASK                              1

#define TMR11_CNT_CNT_OFFSET                               0
#define TMR11_CNT_CNT_MASK                                 0xffff

#define TMR11_PSC_PSC_OFFSET                               0
#define TMR11_PSC_PSC_MASK                                 0xffff

#define TMR11_AUTORLD_AUTORLD_OFFSET                       0
#define TMR11_AUTORLD_AUTORLD_MASK                         0xffff

#define TMR11_CC1_CC1_OFFSET                               0
#define TMR11_CC1_CC1_MASK                                 0xffff

#define TMR11_OPT_RMPSEL_OFFSET                            0
#define TMR11_OPT_RMPSEL_MASK                              3


typedef struct
{

/** CTRL1 CTRL1 (offset: 0x0)
  control register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CLKDIV
  offset: 8, size: 2, access: 
  Clock division
  Field: ARPEN
  offset: 7, size: 1, access: 
  Auto-reload preload enable
  Field: SPMEN
  offset: 3, size: 1, access: 
  Single Pulse Mode Enable
  Field: URSSEL
  offset: 2, size: 1, access: 
  Update request source
  Field: UD
  offset: 1, size: 1, access: 
  Update disable
  Field: CNTEN
  offset: 0, size: 1, access: 
  Counter enable
*/
volatile uint32_t CTRL1;
volatile uint32_t reserved0[2];

/** DIEN DIEN (offset: 0xc)
  DMA/Interrupt enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC1IEN
  offset: 1, size: 1, access: 
  Capture/Compare 1 interrupt enable
  Field: UIEN
  offset: 0, size: 1, access: 
  Update interrupt enable
*/
volatile uint32_t DIEN;

/** STS STS (offset: 0x10)
  status register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC1RCFLG
  offset: 9, size: 1, access: 
  Capture/Compare 1 overcapture flag
  Field: CC1IFLG
  offset: 1, size: 1, access: 
  Capture/compare 1 interrupt flag
  Field: UIFLG
  offset: 0, size: 1, access: 
  Update interrupt flag
*/
volatile uint32_t STS;

/** CEG CEG (offset: 0x14)
  control event generation register
  access : write-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC1EG
  offset: 1, size: 1, access: 
  Capture/compare 1 generation
  Field: UEG
  offset: 0, size: 1, access: 
  Update generation
*/
volatile uint32_t CEG;

/** CCM1_COMPARE CCM1_COMPARE (offset: 0x18)
  capture/compare mode register 1 (output mode)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OC1MOD
  offset: 4, size: 3, access: 
  Output Compare 1 mode
  Field: OC1PEN
  offset: 3, size: 1, access: 
  Output Compare 1 preload enable
  Field: OC1FEN
  offset: 2, size: 1, access: 
  Output Compare 1 fast enable
  Field: CC1SEL
  offset: 0, size: 2, access: 
  Capture/Compare 1 selection
*/
volatile uint32_t CCM1_COMPARE;
volatile uint32_t reserved1;

/** CCEN CCEN (offset: 0x20)
  capture/compare enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC1NPOL
  offset: 3, size: 1, access: 
  Capture/Compare 1 output Polarity
  Field: CC1POL
  offset: 1, size: 1, access: 
  Capture/Compare 1 output Polarity
  Field: CC1EN
  offset: 0, size: 1, access: 
  Capture/Compare 1 output enable
*/
volatile uint32_t CCEN;

/** CNT CNT (offset: 0x24)
  counter
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CNT
  offset: 0, size: 16, access: 
  counter value
*/
volatile uint32_t CNT;

/** PSC PSC (offset: 0x28)
  prescaler
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PSC
  offset: 0, size: 16, access: 
  Prescaler value
*/
volatile uint32_t PSC;

/** AUTORLD AUTORLD (offset: 0x2c)
  auto-reload register
  access : read-write
  reset value : 0xFFFF
  reset mask : 0xFFFFFFFF
  Field: AUTORLD
  offset: 0, size: 16, access: 
  Auto-reload value
*/
volatile uint32_t AUTORLD;
volatile uint32_t reserved2;

/** CC1 CC1 (offset: 0x34)
  capture/compare register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC1
  offset: 0, size: 16, access: 
  Capture/Compare 1 value
*/
volatile uint32_t CC1;
volatile uint32_t reserved3[6];

/** OPT OPT (offset: 0x50)
  option register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RMPSEL
  offset: 0, size: 2, access: 
  Input 1 remapping capability
*/
volatile uint32_t OPT;
} TMR11_type;

#define TMR11 ((TMR11_type *) 0x40014800)

#endif // HW_TMR11_H
