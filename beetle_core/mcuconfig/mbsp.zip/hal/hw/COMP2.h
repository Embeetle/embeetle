#ifndef HW_COMP2_H
#define HW_COMP2_H
/** Comparator */
/** Memory Block starting at 0x4001381C + 0x0 is 0x4 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define COMP2_CSTS_EN_OFFSET                               0
#define COMP2_CSTS_EN_MASK                                 1

#define COMP2_CSTS_SPEEDM_OFFSET                           3
#define COMP2_CSTS_SPEEDM_MASK                             8

#define COMP2_CSTS_INMCCFG_OFFSET                          4
#define COMP2_CSTS_INMCCFG_MASK                            0x70

#define COMP2_CSTS_INPCCFG_OFFSET                          8
#define COMP2_CSTS_INPCCFG_MASK                            0x700

#define COMP2_CSTS_OUTSEL_OFFSET                           11
#define COMP2_CSTS_OUTSEL_MASK                             0x7800

#define COMP2_CSTS_POLCFG_OFFSET                           15
#define COMP2_CSTS_POLCFG_MASK                             0x8000

#define COMP2_CSTS_OUTVAL_OFFSET                           30
#define COMP2_CSTS_OUTVAL_MASK                             0x40000000

#define COMP2_CSTS_LOCK_OFFSET                             31
#define COMP2_CSTS_LOCK_MASK                               0x80000000


typedef struct
{

/** CSTS CSTS (offset: 0x0)
  control and status register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EN
  offset: 0, size: 1, access: read-write
  Comparator enable
  Field: SPEEDM
  offset: 3, size: 1, access: read-write
  Comparator Speed Mode Select
  Field: INMCCFG
  offset: 4, size: 3, access: read-write
  Comparator Input Minus Connection Configure
  Field: INPCCFG
  offset: 8, size: 3, access: read-write
  Comparator Input Plus Connection Configure
  Field: OUTSEL
  offset: 11, size: 4, access: read-write
  Comparator output Selest
  Field: POLCFG
  offset: 15, size: 1, access: read-write
  Comparator Polarity Configure
  Field: OUTVAL
  offset: 30, size: 1, access: read-write
  Comparator output status
  Field: LOCK
  offset: 31, size: 1, access: read-write
  COMP CSTS Register Lock
*/
volatile uint32_t CSTS;
} COMP2_type;

#define COMP2 ((COMP2_type *) 0x4001381C)

#endif // HW_COMP2_H
