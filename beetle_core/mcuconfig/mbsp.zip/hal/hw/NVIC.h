#ifndef HW_NVIC_H
#define HW_NVIC_H
/** Nested Vectored Interrupt Controller */
/** Memory Block starting at 0xE000E100 + 0x0 is 0x351 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define NVIC_ISER0_SETENA_OFFSET                           0
#define NVIC_ISER0_SETENA_MASK                             0xffffffff

#define NVIC_ISER1_SETENA_OFFSET                           0
#define NVIC_ISER1_SETENA_MASK                             0xffffffff

#define NVIC_ISER2_SETENA_OFFSET                           0
#define NVIC_ISER2_SETENA_MASK                             0xffffffff

#define NVIC_ICER0_CLRENA_OFFSET                           0
#define NVIC_ICER0_CLRENA_MASK                             0xffffffff

#define NVIC_ICER1_CLRENA_OFFSET                           0
#define NVIC_ICER1_CLRENA_MASK                             0xffffffff

#define NVIC_ICER2_CLRENA_OFFSET                           0
#define NVIC_ICER2_CLRENA_MASK                             0xffffffff

#define NVIC_ISPR0_SETPEND_OFFSET                          0
#define NVIC_ISPR0_SETPEND_MASK                            0xffffffff

#define NVIC_ISPR1_SETPEND_OFFSET                          0
#define NVIC_ISPR1_SETPEND_MASK                            0xffffffff

#define NVIC_ISPR2_SETPEND_OFFSET                          0
#define NVIC_ISPR2_SETPEND_MASK                            0xffffffff

#define NVIC_ICPR0_CLRPEND_OFFSET                          0
#define NVIC_ICPR0_CLRPEND_MASK                            0xffffffff

#define NVIC_ICPR1_CLRPEND_OFFSET                          0
#define NVIC_ICPR1_CLRPEND_MASK                            0xffffffff

#define NVIC_ICPR2_CLRPEND_OFFSET                          0
#define NVIC_ICPR2_CLRPEND_MASK                            0xffffffff

#define NVIC_IABR0_ACTIVE_OFFSET                           0
#define NVIC_IABR0_ACTIVE_MASK                             0xffffffff

#define NVIC_IABR1_ACTIVE_OFFSET                           0
#define NVIC_IABR1_ACTIVE_MASK                             0xffffffff

#define NVIC_IABR2_ACTIVE_OFFSET                           0
#define NVIC_IABR2_ACTIVE_MASK                             0xffffffff

#define NVIC_IPR0_IPR_N0_OFFSET                            0
#define NVIC_IPR0_IPR_N0_MASK                              0xff

#define NVIC_IPR0_IPR_N1_OFFSET                            8
#define NVIC_IPR0_IPR_N1_MASK                              0xff00

#define NVIC_IPR0_IPR_N2_OFFSET                            16
#define NVIC_IPR0_IPR_N2_MASK                              0xff0000

#define NVIC_IPR0_IPR_N3_OFFSET                            24
#define NVIC_IPR0_IPR_N3_MASK                              0xff000000

#define NVIC_IPR1_IPR_N0_OFFSET                            0
#define NVIC_IPR1_IPR_N0_MASK                              0xff

#define NVIC_IPR1_IPR_N1_OFFSET                            8
#define NVIC_IPR1_IPR_N1_MASK                              0xff00

#define NVIC_IPR1_IPR_N2_OFFSET                            16
#define NVIC_IPR1_IPR_N2_MASK                              0xff0000

#define NVIC_IPR1_IPR_N3_OFFSET                            24
#define NVIC_IPR1_IPR_N3_MASK                              0xff000000

#define NVIC_IPR2_IPR_N0_OFFSET                            0
#define NVIC_IPR2_IPR_N0_MASK                              0xff

#define NVIC_IPR2_IPR_N1_OFFSET                            8
#define NVIC_IPR2_IPR_N1_MASK                              0xff00

#define NVIC_IPR2_IPR_N2_OFFSET                            16
#define NVIC_IPR2_IPR_N2_MASK                              0xff0000

#define NVIC_IPR2_IPR_N3_OFFSET                            24
#define NVIC_IPR2_IPR_N3_MASK                              0xff000000

#define NVIC_IPR3_IPR_N0_OFFSET                            0
#define NVIC_IPR3_IPR_N0_MASK                              0xff

#define NVIC_IPR3_IPR_N1_OFFSET                            8
#define NVIC_IPR3_IPR_N1_MASK                              0xff00

#define NVIC_IPR3_IPR_N2_OFFSET                            16
#define NVIC_IPR3_IPR_N2_MASK                              0xff0000

#define NVIC_IPR3_IPR_N3_OFFSET                            24
#define NVIC_IPR3_IPR_N3_MASK                              0xff000000

#define NVIC_IPR4_IPR_N0_OFFSET                            0
#define NVIC_IPR4_IPR_N0_MASK                              0xff

#define NVIC_IPR4_IPR_N1_OFFSET                            8
#define NVIC_IPR4_IPR_N1_MASK                              0xff00

#define NVIC_IPR4_IPR_N2_OFFSET                            16
#define NVIC_IPR4_IPR_N2_MASK                              0xff0000

#define NVIC_IPR4_IPR_N3_OFFSET                            24
#define NVIC_IPR4_IPR_N3_MASK                              0xff000000

#define NVIC_IPR5_IPR_N0_OFFSET                            0
#define NVIC_IPR5_IPR_N0_MASK                              0xff

#define NVIC_IPR5_IPR_N1_OFFSET                            8
#define NVIC_IPR5_IPR_N1_MASK                              0xff00

#define NVIC_IPR5_IPR_N2_OFFSET                            16
#define NVIC_IPR5_IPR_N2_MASK                              0xff0000

#define NVIC_IPR5_IPR_N3_OFFSET                            24
#define NVIC_IPR5_IPR_N3_MASK                              0xff000000

#define NVIC_IPR6_IPR_N0_OFFSET                            0
#define NVIC_IPR6_IPR_N0_MASK                              0xff

#define NVIC_IPR6_IPR_N1_OFFSET                            8
#define NVIC_IPR6_IPR_N1_MASK                              0xff00

#define NVIC_IPR6_IPR_N2_OFFSET                            16
#define NVIC_IPR6_IPR_N2_MASK                              0xff0000

#define NVIC_IPR6_IPR_N3_OFFSET                            24
#define NVIC_IPR6_IPR_N3_MASK                              0xff000000

#define NVIC_IPR7_IPR_N0_OFFSET                            0
#define NVIC_IPR7_IPR_N0_MASK                              0xff

#define NVIC_IPR7_IPR_N1_OFFSET                            8
#define NVIC_IPR7_IPR_N1_MASK                              0xff00

#define NVIC_IPR7_IPR_N2_OFFSET                            16
#define NVIC_IPR7_IPR_N2_MASK                              0xff0000

#define NVIC_IPR7_IPR_N3_OFFSET                            24
#define NVIC_IPR7_IPR_N3_MASK                              0xff000000

#define NVIC_IPR8_IPR_N0_OFFSET                            0
#define NVIC_IPR8_IPR_N0_MASK                              0xff

#define NVIC_IPR8_IPR_N1_OFFSET                            8
#define NVIC_IPR8_IPR_N1_MASK                              0xff00

#define NVIC_IPR8_IPR_N2_OFFSET                            16
#define NVIC_IPR8_IPR_N2_MASK                              0xff0000

#define NVIC_IPR8_IPR_N3_OFFSET                            24
#define NVIC_IPR8_IPR_N3_MASK                              0xff000000

#define NVIC_IPR9_IPR_N0_OFFSET                            0
#define NVIC_IPR9_IPR_N0_MASK                              0xff

#define NVIC_IPR9_IPR_N1_OFFSET                            8
#define NVIC_IPR9_IPR_N1_MASK                              0xff00

#define NVIC_IPR9_IPR_N2_OFFSET                            16
#define NVIC_IPR9_IPR_N2_MASK                              0xff0000

#define NVIC_IPR9_IPR_N3_OFFSET                            24
#define NVIC_IPR9_IPR_N3_MASK                              0xff000000

#define NVIC_IPR10_IPR_N0_OFFSET                           0
#define NVIC_IPR10_IPR_N0_MASK                             0xff

#define NVIC_IPR10_IPR_N1_OFFSET                           8
#define NVIC_IPR10_IPR_N1_MASK                             0xff00

#define NVIC_IPR10_IPR_N2_OFFSET                           16
#define NVIC_IPR10_IPR_N2_MASK                             0xff0000

#define NVIC_IPR10_IPR_N3_OFFSET                           24
#define NVIC_IPR10_IPR_N3_MASK                             0xff000000

#define NVIC_IPR11_IPR_N0_OFFSET                           0
#define NVIC_IPR11_IPR_N0_MASK                             0xff

#define NVIC_IPR11_IPR_N1_OFFSET                           8
#define NVIC_IPR11_IPR_N1_MASK                             0xff00

#define NVIC_IPR11_IPR_N2_OFFSET                           16
#define NVIC_IPR11_IPR_N2_MASK                             0xff0000

#define NVIC_IPR11_IPR_N3_OFFSET                           24
#define NVIC_IPR11_IPR_N3_MASK                             0xff000000

#define NVIC_IPR12_IPR_N0_OFFSET                           0
#define NVIC_IPR12_IPR_N0_MASK                             0xff

#define NVIC_IPR12_IPR_N1_OFFSET                           8
#define NVIC_IPR12_IPR_N1_MASK                             0xff00

#define NVIC_IPR12_IPR_N2_OFFSET                           16
#define NVIC_IPR12_IPR_N2_MASK                             0xff0000

#define NVIC_IPR12_IPR_N3_OFFSET                           24
#define NVIC_IPR12_IPR_N3_MASK                             0xff000000

#define NVIC_IPR13_IPR_N0_OFFSET                           0
#define NVIC_IPR13_IPR_N0_MASK                             0xff

#define NVIC_IPR13_IPR_N1_OFFSET                           8
#define NVIC_IPR13_IPR_N1_MASK                             0xff00

#define NVIC_IPR13_IPR_N2_OFFSET                           16
#define NVIC_IPR13_IPR_N2_MASK                             0xff0000

#define NVIC_IPR13_IPR_N3_OFFSET                           24
#define NVIC_IPR13_IPR_N3_MASK                             0xff000000

#define NVIC_IPR14_IPR_N0_OFFSET                           0
#define NVIC_IPR14_IPR_N0_MASK                             0xff

#define NVIC_IPR14_IPR_N1_OFFSET                           8
#define NVIC_IPR14_IPR_N1_MASK                             0xff00

#define NVIC_IPR14_IPR_N2_OFFSET                           16
#define NVIC_IPR14_IPR_N2_MASK                             0xff0000

#define NVIC_IPR14_IPR_N3_OFFSET                           24
#define NVIC_IPR14_IPR_N3_MASK                             0xff000000

#define NVIC_IPR15_IPR_N0_OFFSET                           0
#define NVIC_IPR15_IPR_N0_MASK                             0xff

#define NVIC_IPR15_IPR_N1_OFFSET                           8
#define NVIC_IPR15_IPR_N1_MASK                             0xff00

#define NVIC_IPR15_IPR_N2_OFFSET                           16
#define NVIC_IPR15_IPR_N2_MASK                             0xff0000

#define NVIC_IPR15_IPR_N3_OFFSET                           24
#define NVIC_IPR15_IPR_N3_MASK                             0xff000000

#define NVIC_IPR16_IPR_N0_OFFSET                           0
#define NVIC_IPR16_IPR_N0_MASK                             0xff

#define NVIC_IPR16_IPR_N1_OFFSET                           8
#define NVIC_IPR16_IPR_N1_MASK                             0xff00

#define NVIC_IPR16_IPR_N2_OFFSET                           16
#define NVIC_IPR16_IPR_N2_MASK                             0xff0000

#define NVIC_IPR16_IPR_N3_OFFSET                           24
#define NVIC_IPR16_IPR_N3_MASK                             0xff000000

#define NVIC_IPR17_IPR_N0_OFFSET                           0
#define NVIC_IPR17_IPR_N0_MASK                             0xff

#define NVIC_IPR17_IPR_N1_OFFSET                           8
#define NVIC_IPR17_IPR_N1_MASK                             0xff00

#define NVIC_IPR17_IPR_N2_OFFSET                           16
#define NVIC_IPR17_IPR_N2_MASK                             0xff0000

#define NVIC_IPR17_IPR_N3_OFFSET                           24
#define NVIC_IPR17_IPR_N3_MASK                             0xff000000

#define NVIC_IPR18_IPR_N0_OFFSET                           0
#define NVIC_IPR18_IPR_N0_MASK                             0xff

#define NVIC_IPR18_IPR_N1_OFFSET                           8
#define NVIC_IPR18_IPR_N1_MASK                             0xff00

#define NVIC_IPR18_IPR_N2_OFFSET                           16
#define NVIC_IPR18_IPR_N2_MASK                             0xff0000

#define NVIC_IPR18_IPR_N3_OFFSET                           24
#define NVIC_IPR18_IPR_N3_MASK                             0xff000000

#define NVIC_IPR19_IPR_N0_OFFSET                           0
#define NVIC_IPR19_IPR_N0_MASK                             0xff

#define NVIC_IPR19_IPR_N1_OFFSET                           8
#define NVIC_IPR19_IPR_N1_MASK                             0xff00

#define NVIC_IPR19_IPR_N2_OFFSET                           16
#define NVIC_IPR19_IPR_N2_MASK                             0xff0000

#define NVIC_IPR19_IPR_N3_OFFSET                           24
#define NVIC_IPR19_IPR_N3_MASK                             0xff000000


typedef struct
{

/** ISER0 ISER0 (offset: 0x0)
  Interrupt Set-Enable Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SETENA
  offset: 0, size: 32, access: 
  SETENA
*/
volatile uint32_t ISER0;

/** ISER1 ISER1 (offset: 0x4)
  Interrupt Set-Enable Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SETENA
  offset: 0, size: 32, access: 
  SETENA
*/
volatile uint32_t ISER1;

/** ISER2 ISER2 (offset: 0x8)
  Interrupt Set-Enable Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SETENA
  offset: 0, size: 32, access: 
  SETENA
*/
volatile uint32_t ISER2;
volatile uint32_t reserved0[29];

/** ICER0 ICER0 (offset: 0x80)
  Interrupt Clear-Enable Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CLRENA
  offset: 0, size: 32, access: 
  CLRENA
*/
volatile uint32_t ICER0;

/** ICER1 ICER1 (offset: 0x84)
  Interrupt Clear-Enable Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CLRENA
  offset: 0, size: 32, access: 
  CLRENA
*/
volatile uint32_t ICER1;

/** ICER2 ICER2 (offset: 0x88)
  Interrupt Clear-Enable Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CLRENA
  offset: 0, size: 32, access: 
  CLRENA
*/
volatile uint32_t ICER2;
volatile uint32_t reserved1[29];

/** ISPR0 ISPR0 (offset: 0x100)
  Interrupt Set-Pending Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SETPEND
  offset: 0, size: 32, access: 
  SETPEND
*/
volatile uint32_t ISPR0;

/** ISPR1 ISPR1 (offset: 0x104)
  Interrupt Set-Pending Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SETPEND
  offset: 0, size: 32, access: 
  SETPEND
*/
volatile uint32_t ISPR1;

/** ISPR2 ISPR2 (offset: 0x108)
  Interrupt Set-Pending Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SETPEND
  offset: 0, size: 32, access: 
  SETPEND
*/
volatile uint32_t ISPR2;
volatile uint32_t reserved2[29];

/** ICPR0 ICPR0 (offset: 0x180)
  Interrupt Clear-Pending Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CLRPEND
  offset: 0, size: 32, access: 
  CLRPEND
*/
volatile uint32_t ICPR0;

/** ICPR1 ICPR1 (offset: 0x184)
  Interrupt Clear-Pending Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CLRPEND
  offset: 0, size: 32, access: 
  CLRPEND
*/
volatile uint32_t ICPR1;

/** ICPR2 ICPR2 (offset: 0x188)
  Interrupt Clear-Pending Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CLRPEND
  offset: 0, size: 32, access: 
  CLRPEND
*/
volatile uint32_t ICPR2;
volatile uint32_t reserved3[29];

/** IABR0 IABR0 (offset: 0x200)
  Interrupt Active Bit Register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ACTIVE
  offset: 0, size: 32, access: 
  ACTIVE
*/
volatile uint32_t IABR0;

/** IABR1 IABR1 (offset: 0x204)
  Interrupt Active Bit Register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ACTIVE
  offset: 0, size: 32, access: 
  ACTIVE
*/
volatile uint32_t IABR1;

/** IABR2 IABR2 (offset: 0x208)
  Interrupt Active Bit Register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ACTIVE
  offset: 0, size: 32, access: 
  ACTIVE
*/
volatile uint32_t IABR2;
volatile uint32_t reserved4[61];

/** IPR0 IPR0 (offset: 0x300)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR0;

/** IPR1 IPR1 (offset: 0x304)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR1;

/** IPR2 IPR2 (offset: 0x308)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR2;

/** IPR3 IPR3 (offset: 0x30c)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR3;

/** IPR4 IPR4 (offset: 0x310)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR4;

/** IPR5 IPR5 (offset: 0x314)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR5;

/** IPR6 IPR6 (offset: 0x318)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR6;

/** IPR7 IPR7 (offset: 0x31c)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR7;

/** IPR8 IPR8 (offset: 0x320)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR8;

/** IPR9 IPR9 (offset: 0x324)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR9;

/** IPR10 IPR10 (offset: 0x328)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR10;

/** IPR11 IPR11 (offset: 0x32c)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR11;

/** IPR12 IPR12 (offset: 0x330)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR12;

/** IPR13 IPR13 (offset: 0x334)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR13;

/** IPR14 IPR14 (offset: 0x338)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR14;

/** IPR15 IPR15 (offset: 0x33c)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR15;

/** IPR16 IPR16 (offset: 0x340)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR16;

/** IPR17 IPR17 (offset: 0x344)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR17;

/** IPR18 IPR18 (offset: 0x348)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR18;

/** IPR19 IPR19 (offset: 0x34c)
  Interrupt Priority Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IPR_N0
  offset: 0, size: 8, access: 
  IPR_N0
  Field: IPR_N1
  offset: 8, size: 8, access: 
  IPR_N1
  Field: IPR_N2
  offset: 16, size: 8, access: 
  IPR_N2
  Field: IPR_N3
  offset: 24, size: 8, access: 
  IPR_N3
*/
volatile uint32_t IPR19;
} NVIC_type;

#define NVIC ((NVIC_type *) 0xE000E100)

#endif // HW_NVIC_H
