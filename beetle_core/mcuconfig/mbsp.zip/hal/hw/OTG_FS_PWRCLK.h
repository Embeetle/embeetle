#ifndef HW_OTG_FS_PWRCLK_H
#define HW_OTG_FS_PWRCLK_H
/** USB on the go full speed */
/** Memory Block starting at 0x50000E00 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define OTG_FS_PWRCLK_FS_PCGCCTL_PCLKSTOP_OFFSET           0
#define OTG_FS_PWRCLK_FS_PCGCCTL_PCLKSTOP_MASK             1

#define OTG_FS_PWRCLK_FS_PCGCCTL_GCLK_OFFSET               1
#define OTG_FS_PWRCLK_FS_PCGCCTL_GCLK_MASK                 2

#define OTG_FS_PWRCLK_FS_PCGCCTL_PHYSUS_OFFSET             4
#define OTG_FS_PWRCLK_FS_PCGCCTL_PHYSUS_MASK               0x10


typedef struct
{

/** FS_PCGCCTL FS_PCGCCTL (offset: 0x0)
  OTG_FS power and clock gating control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PCLKSTOP
  offset: 0, size: 1, access: 
  Stop PHY clock
  Field: GCLK
  offset: 1, size: 1, access: 
  Gate HCLK
  Field: PHYSUS
  offset: 4, size: 1, access: 
  PHY Suspended
*/
volatile uint32_t FS_PCGCCTL;
} OTG_FS_PWRCLK_type;

#define OTG_FS_PWRCLK ((OTG_FS_PWRCLK_type *) 0x50000E00)

#endif // HW_OTG_FS_PWRCLK_H
