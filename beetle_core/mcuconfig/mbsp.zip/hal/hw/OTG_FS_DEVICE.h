#ifndef HW_OTG_FS_DEVICE_H
#define HW_OTG_FS_DEVICE_H
/** USB on the go full speed */
/** Memory Block starting at 0x50000800 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define OTG_FS_DEVICE_DCFG_DSPDSEL_OFFSET                  0
#define OTG_FS_DEVICE_DCFG_DSPDSEL_MASK                    3

#define OTG_FS_DEVICE_DCFG_SENDOUT_OFFSET                  2
#define OTG_FS_DEVICE_DCFG_SENDOUT_MASK                    4

#define OTG_FS_DEVICE_DCFG_DADDR_OFFSET                    4
#define OTG_FS_DEVICE_DCFG_DADDR_MASK                      0x7f0

#define OTG_FS_DEVICE_DCFG_PFITV_OFFSET                    11
#define OTG_FS_DEVICE_DCFG_PFITV_MASK                      0x1800

#define OTG_FS_DEVICE_DCTRL_RWKUPS_OFFSET                  0
#define OTG_FS_DEVICE_DCTRL_RWKUPS_MASK                    1

#define OTG_FS_DEVICE_DCTRL_SDCNNT_OFFSET                  1
#define OTG_FS_DEVICE_DCTRL_SDCNNT_MASK                    2

#define OTG_FS_DEVICE_DCTRL_GINAKSTS_OFFSET                2
#define OTG_FS_DEVICE_DCTRL_GINAKSTS_MASK                  4

#define OTG_FS_DEVICE_DCTRL_GONAKSTS_OFFSET                3
#define OTG_FS_DEVICE_DCTRL_GONAKSTS_MASK                  8

#define OTG_FS_DEVICE_DCTRL_TESTSEL_OFFSET                 4
#define OTG_FS_DEVICE_DCTRL_TESTSEL_MASK                   0x70

#define OTG_FS_DEVICE_DCTRL_GINAKSET_OFFSET                7
#define OTG_FS_DEVICE_DCTRL_GINAKSET_MASK                  0x80

#define OTG_FS_DEVICE_DCTRL_GINAKCLR_OFFSET                8
#define OTG_FS_DEVICE_DCTRL_GINAKCLR_MASK                  0x100

#define OTG_FS_DEVICE_DCTRL_GONAKSET_OFFSET                9
#define OTG_FS_DEVICE_DCTRL_GONAKSET_MASK                  0x200

#define OTG_FS_DEVICE_DCTRL_GONAKCLR_OFFSET                10
#define OTG_FS_DEVICE_DCTRL_GONAKCLR_MASK                  0x400

#define OTG_FS_DEVICE_DCTRL_POPROGCMP_OFFSET               11
#define OTG_FS_DEVICE_DCTRL_POPROGCMP_MASK                 0x800

#define OTG_FS_DEVICE_DSTS_SUSSTS_OFFSET                   0
#define OTG_FS_DEVICE_DSTS_SUSSTS_MASK                     1

#define OTG_FS_DEVICE_DSTS_ENUMSPD_OFFSET                  1
#define OTG_FS_DEVICE_DSTS_ENUMSPD_MASK                    6

#define OTG_FS_DEVICE_DSTS_ERTERR_OFFSET                   3
#define OTG_FS_DEVICE_DSTS_ERTERR_MASK                     8

#define OTG_FS_DEVICE_DSTS_SOFNUM_OFFSET                   8
#define OTG_FS_DEVICE_DSTS_SOFNUM_MASK                     0x3fff00

#define OTG_FS_DEVICE_DINIMASK_TSFCMPM_OFFSET              0
#define OTG_FS_DEVICE_DINIMASK_TSFCMPM_MASK                1

#define OTG_FS_DEVICE_DINIMASK_EPDISM_OFFSET               1
#define OTG_FS_DEVICE_DINIMASK_EPDISM_MASK                 2

#define OTG_FS_DEVICE_DINIMASK_TOM_OFFSET                  3
#define OTG_FS_DEVICE_DINIMASK_TOM_MASK                    8

#define OTG_FS_DEVICE_DINIMASK_ITXEMPM_OFFSET              4
#define OTG_FS_DEVICE_DINIMASK_ITXEMPM_MASK                0x10

#define OTG_FS_DEVICE_DINIMASK_IEPMMM_OFFSET               5
#define OTG_FS_DEVICE_DINIMASK_IEPMMM_MASK                 0x20

#define OTG_FS_DEVICE_DINIMASK_IEPNAKEM_OFFSET             6
#define OTG_FS_DEVICE_DINIMASK_IEPNAKEM_MASK               0x40

#define OTG_FS_DEVICE_DINIMASK_NAKM_OFFSET                 13
#define OTG_FS_DEVICE_DINIMASK_NAKM_MASK                   0x2000

#define OTG_FS_DEVICE_DOUTIMASK_TSFCMPM_OFFSET             0
#define OTG_FS_DEVICE_DOUTIMASK_TSFCMPM_MASK               1

#define OTG_FS_DEVICE_DOUTIMASK_EPDISM_OFFSET              1
#define OTG_FS_DEVICE_DOUTIMASK_EPDISM_MASK                2

#define OTG_FS_DEVICE_DOUTIMASK_SETPCMPM_OFFSET            3
#define OTG_FS_DEVICE_DOUTIMASK_SETPCMPM_MASK              8

#define OTG_FS_DEVICE_DOUTIMASK_OTXEMPM_OFFSET             4
#define OTG_FS_DEVICE_DOUTIMASK_OTXEMPM_MASK               0x10

#define OTG_FS_DEVICE_DOUTIMASK_RXIWCTRLM_OFFSET           5
#define OTG_FS_DEVICE_DOUTIMASK_RXIWCTRLM_MASK             0x20

#define OTG_FS_DEVICE_DOUTIMASK_OUTPM_OFFSET               8
#define OTG_FS_DEVICE_DOUTIMASK_OUTPM_MASK                 0x100

#define OTG_FS_DEVICE_DOUTIMASK_BABBLEM_OFFSET             12
#define OTG_FS_DEVICE_DOUTIMASK_BABBLEM_MASK               0x1000

#define OTG_FS_DEVICE_DOUTIMASK_NAKM_OFFSET                13
#define OTG_FS_DEVICE_DOUTIMASK_NAKM_MASK                  0x2000

#define OTG_FS_DEVICE_DAEPINT_INEPINT_OFFSET               0
#define OTG_FS_DEVICE_DAEPINT_INEPINT_MASK                 0xffff

#define OTG_FS_DEVICE_DAEPINT_OUTEPINT_OFFSET              16
#define OTG_FS_DEVICE_DAEPINT_OUTEPINT_MASK                0xffff0000

#define OTG_FS_DEVICE_DAEPIMASK_AINM_OFFSET                0
#define OTG_FS_DEVICE_DAEPIMASK_AINM_MASK                  0xffff

#define OTG_FS_DEVICE_DAEPIMASK_AOUTM_OFFSET               16
#define OTG_FS_DEVICE_DAEPIMASK_AOUTM_MASK                 0xffff0000

#define OTG_FS_DEVICE_DVBUSDTIM_VBUSDTIM_OFFSET            0
#define OTG_FS_DEVICE_DVBUSDTIM_VBUSDTIM_MASK              0xffff

#define OTG_FS_DEVICE_DVBUSPTIM_VBUSPTIM_OFFSET            0
#define OTG_FS_DEVICE_DVBUSPTIM_VBUSPTIM_MASK              0xfff

#define OTG_FS_DEVICE_DIEIMASK_INEM_OFFSET                 0
#define OTG_FS_DEVICE_DIEIMASK_INEM_MASK                   0xffff

#define OTG_FS_DEVICE_DIEPCTRL0_MAXPS_OFFSET               0
#define OTG_FS_DEVICE_DIEPCTRL0_MAXPS_MASK                 3

#define OTG_FS_DEVICE_DIEPCTRL0_USBAEP_OFFSET              15
#define OTG_FS_DEVICE_DIEPCTRL0_USBAEP_MASK                0x8000

#define OTG_FS_DEVICE_DIEPCTRL0_NAKSTST_OFFSET             17
#define OTG_FS_DEVICE_DIEPCTRL0_NAKSTST_MASK               0x20000

#define OTG_FS_DEVICE_DIEPCTRL0_EPTYPE_OFFSET              18
#define OTG_FS_DEVICE_DIEPCTRL0_EPTYPE_MASK                0xc0000

#define OTG_FS_DEVICE_DIEPCTRL0_STALLH_OFFSET              21
#define OTG_FS_DEVICE_DIEPCTRL0_STALLH_MASK                0x200000

#define OTG_FS_DEVICE_DIEPCTRL0_TXFNUM_OFFSET              22
#define OTG_FS_DEVICE_DIEPCTRL0_TXFNUM_MASK                0x3c00000

#define OTG_FS_DEVICE_DIEPCTRL0_NAKCLR_OFFSET              26
#define OTG_FS_DEVICE_DIEPCTRL0_NAKCLR_MASK                0x4000000

#define OTG_FS_DEVICE_DIEPCTRL0_NAKSET_OFFSET              27
#define OTG_FS_DEVICE_DIEPCTRL0_NAKSET_MASK                0x8000000

#define OTG_FS_DEVICE_DIEPCTRL0_EPDIS_OFFSET               30
#define OTG_FS_DEVICE_DIEPCTRL0_EPDIS_MASK                 0x40000000

#define OTG_FS_DEVICE_DIEPCTRL0_EPEN_OFFSET                31
#define OTG_FS_DEVICE_DIEPCTRL0_EPEN_MASK                  0x80000000

#define OTG_FS_DEVICE_DIEPINT0_INNAK_OFFSET                13
#define OTG_FS_DEVICE_DIEPINT0_INNAK_MASK                  0x2000

#define OTG_FS_DEVICE_DIEPINT0_PDSTS_OFFSET                11
#define OTG_FS_DEVICE_DIEPINT0_PDSTS_MASK                  0x800

#define OTG_FS_DEVICE_DIEPINT0_TXFE_OFFSET                 7
#define OTG_FS_DEVICE_DIEPINT0_TXFE_MASK                   0x80

#define OTG_FS_DEVICE_DIEPINT0_IEPNAKE_OFFSET              6
#define OTG_FS_DEVICE_DIEPINT0_IEPNAKE_MASK                0x40

#define OTG_FS_DEVICE_DIEPINT0_ITXEMP_OFFSET               4
#define OTG_FS_DEVICE_DIEPINT0_ITXEMP_MASK                 0x10

#define OTG_FS_DEVICE_DIEPINT0_TO_OFFSET                   3
#define OTG_FS_DEVICE_DIEPINT0_TO_MASK                     8

#define OTG_FS_DEVICE_DIEPINT0_EPDIS_OFFSET                1
#define OTG_FS_DEVICE_DIEPINT0_EPDIS_MASK                  2

#define OTG_FS_DEVICE_DIEPINT0_TSFCMP_OFFSET               0
#define OTG_FS_DEVICE_DIEPINT0_TSFCMP_MASK                 1

#define OTG_FS_DEVICE_DIEPTRS0_EPPCNT_OFFSET               19
#define OTG_FS_DEVICE_DIEPTRS0_EPPCNT_MASK                 0x180000

#define OTG_FS_DEVICE_DIEPTRS0_EPTRS_OFFSET                0
#define OTG_FS_DEVICE_DIEPTRS0_EPTRS_MASK                  0x7f

#define OTG_FS_DEVICE_DITXFSTS0_INEPTXFSASEL_OFFSET        0
#define OTG_FS_DEVICE_DITXFSTS0_INEPTXFSASEL_MASK          0xffff

#define OTG_FS_DEVICE_DIEPCTRL1_EPEN_OFFSET                31
#define OTG_FS_DEVICE_DIEPCTRL1_EPEN_MASK                  0x80000000

#define OTG_FS_DEVICE_DIEPCTRL1_EPDIS_OFFSET               30
#define OTG_FS_DEVICE_DIEPCTRL1_EPDIS_MASK                 0x40000000

#define OTG_FS_DEVICE_DIEPCTRL1_OFSET_OFFSET               29
#define OTG_FS_DEVICE_DIEPCTRL1_OFSET_MASK                 0x20000000

#define OTG_FS_DEVICE_DIEPCTRL1_DPIDSET_OFFSET             28
#define OTG_FS_DEVICE_DIEPCTRL1_DPIDSET_MASK               0x10000000

#define OTG_FS_DEVICE_DIEPCTRL1_NAKSET_OFFSET              27
#define OTG_FS_DEVICE_DIEPCTRL1_NAKSET_MASK                0x8000000

#define OTG_FS_DEVICE_DIEPCTRL1_NAKCLR_OFFSET              26
#define OTG_FS_DEVICE_DIEPCTRL1_NAKCLR_MASK                0x4000000

#define OTG_FS_DEVICE_DIEPCTRL1_TXFNUM_OFFSET              22
#define OTG_FS_DEVICE_DIEPCTRL1_TXFNUM_MASK                0x3c00000

#define OTG_FS_DEVICE_DIEPCTRL1_STALLH_OFFSET              21
#define OTG_FS_DEVICE_DIEPCTRL1_STALLH_MASK                0x200000

#define OTG_FS_DEVICE_DIEPCTRL1_EPTYPE_OFFSET              18
#define OTG_FS_DEVICE_DIEPCTRL1_EPTYPE_MASK                0xc0000

#define OTG_FS_DEVICE_DIEPCTRL1_NAKSTS_OFFSET              17
#define OTG_FS_DEVICE_DIEPCTRL1_NAKSTS_MASK                0x20000

#define OTG_FS_DEVICE_DIEPCTRL1_EOF_OFFSET                 16
#define OTG_FS_DEVICE_DIEPCTRL1_EOF_MASK                   0x10000

#define OTG_FS_DEVICE_DIEPCTRL1_USBAEP_OFFSET              15
#define OTG_FS_DEVICE_DIEPCTRL1_USBAEP_MASK                0x8000

#define OTG_FS_DEVICE_DIEPCTRL1_MAXPS_OFFSET               0
#define OTG_FS_DEVICE_DIEPCTRL1_MAXPS_MASK                 0x7ff

#define OTG_FS_DEVICE_DIEPINT1_INNAK_OFFSET                13
#define OTG_FS_DEVICE_DIEPINT1_INNAK_MASK                  0x2000

#define OTG_FS_DEVICE_DIEPINT1_PDSTS_OFFSET                11
#define OTG_FS_DEVICE_DIEPINT1_PDSTS_MASK                  0x800

#define OTG_FS_DEVICE_DIEPINT1_TXFE_OFFSET                 7
#define OTG_FS_DEVICE_DIEPINT1_TXFE_MASK                   0x80

#define OTG_FS_DEVICE_DIEPINT1_IEPNAKE_OFFSET              6
#define OTG_FS_DEVICE_DIEPINT1_IEPNAKE_MASK                0x40

#define OTG_FS_DEVICE_DIEPINT1_ITXEMP_OFFSET               4
#define OTG_FS_DEVICE_DIEPINT1_ITXEMP_MASK                 0x10

#define OTG_FS_DEVICE_DIEPINT1_TO_OFFSET                   3
#define OTG_FS_DEVICE_DIEPINT1_TO_MASK                     8

#define OTG_FS_DEVICE_DIEPINT1_EPDIS_OFFSET                1
#define OTG_FS_DEVICE_DIEPINT1_EPDIS_MASK                  2

#define OTG_FS_DEVICE_DIEPINT1_TSFCMP_OFFSET               0
#define OTG_FS_DEVICE_DIEPINT1_TSFCMP_MASK                 1

#define OTG_FS_DEVICE_DIEPTRS1_EPPCNT_OFFSET               19
#define OTG_FS_DEVICE_DIEPTRS1_EPPCNT_MASK                 0x1ff80000

#define OTG_FS_DEVICE_DIEPTRS1_EPTRS_OFFSET                0
#define OTG_FS_DEVICE_DIEPTRS1_EPTRS_MASK                  0x7ffff

#define OTG_FS_DEVICE_DITXFSTS1_INEPTXFSASEL_OFFSET        0
#define OTG_FS_DEVICE_DITXFSTS1_INEPTXFSASEL_MASK          0xffff

#define OTG_FS_DEVICE_DIEPCTRL2_EPEN_OFFSET                31
#define OTG_FS_DEVICE_DIEPCTRL2_EPEN_MASK                  0x80000000

#define OTG_FS_DEVICE_DIEPCTRL2_EPDIS_OFFSET               30
#define OTG_FS_DEVICE_DIEPCTRL2_EPDIS_MASK                 0x40000000

#define OTG_FS_DEVICE_DIEPCTRL2_OFSET_OFFSET               29
#define OTG_FS_DEVICE_DIEPCTRL2_OFSET_MASK                 0x20000000

#define OTG_FS_DEVICE_DIEPCTRL2_DPIDSET_OFFSET             28
#define OTG_FS_DEVICE_DIEPCTRL2_DPIDSET_MASK               0x10000000

#define OTG_FS_DEVICE_DIEPCTRL2_NAKSET_OFFSET              27
#define OTG_FS_DEVICE_DIEPCTRL2_NAKSET_MASK                0x8000000

#define OTG_FS_DEVICE_DIEPCTRL2_NAKCLR_OFFSET              26
#define OTG_FS_DEVICE_DIEPCTRL2_NAKCLR_MASK                0x4000000

#define OTG_FS_DEVICE_DIEPCTRL2_TXFNUM_OFFSET              22
#define OTG_FS_DEVICE_DIEPCTRL2_TXFNUM_MASK                0x3c00000

#define OTG_FS_DEVICE_DIEPCTRL2_STALLH_OFFSET              21
#define OTG_FS_DEVICE_DIEPCTRL2_STALLH_MASK                0x200000

#define OTG_FS_DEVICE_DIEPCTRL2_EPTYPE_OFFSET              18
#define OTG_FS_DEVICE_DIEPCTRL2_EPTYPE_MASK                0xc0000

#define OTG_FS_DEVICE_DIEPCTRL2_NAKSTS_OFFSET              17
#define OTG_FS_DEVICE_DIEPCTRL2_NAKSTS_MASK                0x20000

#define OTG_FS_DEVICE_DIEPCTRL2_EOF_OFFSET                 16
#define OTG_FS_DEVICE_DIEPCTRL2_EOF_MASK                   0x10000

#define OTG_FS_DEVICE_DIEPCTRL2_USBAEP_OFFSET              15
#define OTG_FS_DEVICE_DIEPCTRL2_USBAEP_MASK                0x8000

#define OTG_FS_DEVICE_DIEPCTRL2_MAXPS_OFFSET               0
#define OTG_FS_DEVICE_DIEPCTRL2_MAXPS_MASK                 0x7ff

#define OTG_FS_DEVICE_DIEPINT2_INNAK_OFFSET                13
#define OTG_FS_DEVICE_DIEPINT2_INNAK_MASK                  0x2000

#define OTG_FS_DEVICE_DIEPINT2_PDSTS_OFFSET                11
#define OTG_FS_DEVICE_DIEPINT2_PDSTS_MASK                  0x800

#define OTG_FS_DEVICE_DIEPINT2_TXFE_OFFSET                 7
#define OTG_FS_DEVICE_DIEPINT2_TXFE_MASK                   0x80

#define OTG_FS_DEVICE_DIEPINT2_IEPNAKE_OFFSET              6
#define OTG_FS_DEVICE_DIEPINT2_IEPNAKE_MASK                0x40

#define OTG_FS_DEVICE_DIEPINT2_ITXEMP_OFFSET               4
#define OTG_FS_DEVICE_DIEPINT2_ITXEMP_MASK                 0x10

#define OTG_FS_DEVICE_DIEPINT2_TO_OFFSET                   3
#define OTG_FS_DEVICE_DIEPINT2_TO_MASK                     8

#define OTG_FS_DEVICE_DIEPINT2_EPDIS_OFFSET                1
#define OTG_FS_DEVICE_DIEPINT2_EPDIS_MASK                  2

#define OTG_FS_DEVICE_DIEPINT2_TSFCMP_OFFSET               0
#define OTG_FS_DEVICE_DIEPINT2_TSFCMP_MASK                 1

#define OTG_FS_DEVICE_DIEPTRS2_EPPCNT_OFFSET               19
#define OTG_FS_DEVICE_DIEPTRS2_EPPCNT_MASK                 0x1ff80000

#define OTG_FS_DEVICE_DIEPTRS2_EPTRS_OFFSET                0
#define OTG_FS_DEVICE_DIEPTRS2_EPTRS_MASK                  0x7ffff

#define OTG_FS_DEVICE_DITXFSTS2_INEPTXFSASEL_OFFSET        0
#define OTG_FS_DEVICE_DITXFSTS2_INEPTXFSASEL_MASK          0xffff

#define OTG_FS_DEVICE_DIEPCTRL3_EPEN_OFFSET                31
#define OTG_FS_DEVICE_DIEPCTRL3_EPEN_MASK                  0x80000000

#define OTG_FS_DEVICE_DIEPCTRL3_EPDIS_OFFSET               30
#define OTG_FS_DEVICE_DIEPCTRL3_EPDIS_MASK                 0x40000000

#define OTG_FS_DEVICE_DIEPCTRL3_OFSET_OFFSET               29
#define OTG_FS_DEVICE_DIEPCTRL3_OFSET_MASK                 0x20000000

#define OTG_FS_DEVICE_DIEPCTRL3_DPIDSET_OFFSET             28
#define OTG_FS_DEVICE_DIEPCTRL3_DPIDSET_MASK               0x10000000

#define OTG_FS_DEVICE_DIEPCTRL3_NAKSET_OFFSET              27
#define OTG_FS_DEVICE_DIEPCTRL3_NAKSET_MASK                0x8000000

#define OTG_FS_DEVICE_DIEPCTRL3_NAKCLR_OFFSET              26
#define OTG_FS_DEVICE_DIEPCTRL3_NAKCLR_MASK                0x4000000

#define OTG_FS_DEVICE_DIEPCTRL3_TXFNUM_OFFSET              22
#define OTG_FS_DEVICE_DIEPCTRL3_TXFNUM_MASK                0x3c00000

#define OTG_FS_DEVICE_DIEPCTRL3_STALLH_OFFSET              21
#define OTG_FS_DEVICE_DIEPCTRL3_STALLH_MASK                0x200000

#define OTG_FS_DEVICE_DIEPCTRL3_EPTYPE_OFFSET              18
#define OTG_FS_DEVICE_DIEPCTRL3_EPTYPE_MASK                0xc0000

#define OTG_FS_DEVICE_DIEPCTRL3_NAKSTS_OFFSET              17
#define OTG_FS_DEVICE_DIEPCTRL3_NAKSTS_MASK                0x20000

#define OTG_FS_DEVICE_DIEPCTRL3_EOF_OFFSET                 16
#define OTG_FS_DEVICE_DIEPCTRL3_EOF_MASK                   0x10000

#define OTG_FS_DEVICE_DIEPCTRL3_USBAEP_OFFSET              15
#define OTG_FS_DEVICE_DIEPCTRL3_USBAEP_MASK                0x8000

#define OTG_FS_DEVICE_DIEPCTRL3_MAXPS_OFFSET               0
#define OTG_FS_DEVICE_DIEPCTRL3_MAXPS_MASK                 0x7ff

#define OTG_FS_DEVICE_DIEPINT3_INNAK_OFFSET                13
#define OTG_FS_DEVICE_DIEPINT3_INNAK_MASK                  0x2000

#define OTG_FS_DEVICE_DIEPINT3_PDSTS_OFFSET                11
#define OTG_FS_DEVICE_DIEPINT3_PDSTS_MASK                  0x800

#define OTG_FS_DEVICE_DIEPINT3_TXFE_OFFSET                 7
#define OTG_FS_DEVICE_DIEPINT3_TXFE_MASK                   0x80

#define OTG_FS_DEVICE_DIEPINT3_IEPNAKE_OFFSET              6
#define OTG_FS_DEVICE_DIEPINT3_IEPNAKE_MASK                0x40

#define OTG_FS_DEVICE_DIEPINT3_ITXEMP_OFFSET               4
#define OTG_FS_DEVICE_DIEPINT3_ITXEMP_MASK                 0x10

#define OTG_FS_DEVICE_DIEPINT3_TO_OFFSET                   3
#define OTG_FS_DEVICE_DIEPINT3_TO_MASK                     8

#define OTG_FS_DEVICE_DIEPINT3_EPDIS_OFFSET                1
#define OTG_FS_DEVICE_DIEPINT3_EPDIS_MASK                  2

#define OTG_FS_DEVICE_DIEPINT3_TSFCMP_OFFSET               0
#define OTG_FS_DEVICE_DIEPINT3_TSFCMP_MASK                 1

#define OTG_FS_DEVICE_DIEPTRS3_EPPCNT_OFFSET               19
#define OTG_FS_DEVICE_DIEPTRS3_EPPCNT_MASK                 0x1ff80000

#define OTG_FS_DEVICE_DIEPTRS3_EPTRS_OFFSET                0
#define OTG_FS_DEVICE_DIEPTRS3_EPTRS_MASK                  0x7ffff

#define OTG_FS_DEVICE_DITXFSTS3_INEPTXFSASEL_OFFSET        0
#define OTG_FS_DEVICE_DITXFSTS3_INEPTXFSASEL_MASK          0xffff

#define OTG_FS_DEVICE_DOEPCTRL0_EPEN_OFFSET                31
#define OTG_FS_DEVICE_DOEPCTRL0_EPEN_MASK                  0x80000000

#define OTG_FS_DEVICE_DOEPCTRL0_EPDIS_OFFSET               30
#define OTG_FS_DEVICE_DOEPCTRL0_EPDIS_MASK                 0x40000000

#define OTG_FS_DEVICE_DOEPCTRL0_NAKSET_OFFSET              27
#define OTG_FS_DEVICE_DOEPCTRL0_NAKSET_MASK                0x8000000

#define OTG_FS_DEVICE_DOEPCTRL0_NAKCLR_OFFSET              26
#define OTG_FS_DEVICE_DOEPCTRL0_NAKCLR_MASK                0x4000000

#define OTG_FS_DEVICE_DOEPCTRL0_STALLH_OFFSET              21
#define OTG_FS_DEVICE_DOEPCTRL0_STALLH_MASK                0x200000

#define OTG_FS_DEVICE_DOEPCTRL0_SNMEN_OFFSET               20
#define OTG_FS_DEVICE_DOEPCTRL0_SNMEN_MASK                 0x100000

#define OTG_FS_DEVICE_DOEPCTRL0_EPTYPE_OFFSET              18
#define OTG_FS_DEVICE_DOEPCTRL0_EPTYPE_MASK                0xc0000

#define OTG_FS_DEVICE_DOEPCTRL0_NAKSTS_OFFSET              17
#define OTG_FS_DEVICE_DOEPCTRL0_NAKSTS_MASK                0x20000

#define OTG_FS_DEVICE_DOEPCTRL0_USBAEP_OFFSET              15
#define OTG_FS_DEVICE_DOEPCTRL0_USBAEP_MASK                0x8000

#define OTG_FS_DEVICE_DOEPCTRL0_MAXPS_OFFSET               0
#define OTG_FS_DEVICE_DOEPCTRL0_MAXPS_MASK                 3

#define OTG_FS_DEVICE_DOEPINT0_INNAK_OFFSET                13
#define OTG_FS_DEVICE_DOEPINT0_INNAK_MASK                  0x2000

#define OTG_FS_DEVICE_DOEPINT0_BABBLE_OFFSET               12
#define OTG_FS_DEVICE_DOEPINT0_BABBLE_MASK                 0x1000

#define OTG_FS_DEVICE_DOEPINT0_OUTPERR_OFFSET              8
#define OTG_FS_DEVICE_DOEPINT0_OUTPERR_MASK                0x100

#define OTG_FS_DEVICE_DOEPINT0_RXSTSM_OFFSET               5
#define OTG_FS_DEVICE_DOEPINT0_RXSTSM_MASK                 0x20

#define OTG_FS_DEVICE_DOEPINT0_RXOTDIS_OFFSET              4
#define OTG_FS_DEVICE_DOEPINT0_RXOTDIS_MASK                0x10

#define OTG_FS_DEVICE_DOEPINT0_SETPCMP_OFFSET              3
#define OTG_FS_DEVICE_DOEPINT0_SETPCMP_MASK                8

#define OTG_FS_DEVICE_DOEPINT0_EPDIS_OFFSET                1
#define OTG_FS_DEVICE_DOEPINT0_EPDIS_MASK                  2

#define OTG_FS_DEVICE_DOEPINT0_TSFCMP_OFFSET               0
#define OTG_FS_DEVICE_DOEPINT0_TSFCMP_MASK                 1

#define OTG_FS_DEVICE_DOEPTRS0_SPCNT_OFFSET                29
#define OTG_FS_DEVICE_DOEPTRS0_SPCNT_MASK                  0x60000000

#define OTG_FS_DEVICE_DOEPTRS0_EPPCNT_OFFSET               19
#define OTG_FS_DEVICE_DOEPTRS0_EPPCNT_MASK                 0x80000

#define OTG_FS_DEVICE_DOEPTRS0_EPTRS_OFFSET                0
#define OTG_FS_DEVICE_DOEPTRS0_EPTRS_MASK                  0x7f

#define OTG_FS_DEVICE_DOEPCTRL1_EPEN_OFFSET                31
#define OTG_FS_DEVICE_DOEPCTRL1_EPEN_MASK                  0x80000000

#define OTG_FS_DEVICE_DOEPCTRL1_EPDIS_OFFSET               30
#define OTG_FS_DEVICE_DOEPCTRL1_EPDIS_MASK                 0x40000000

#define OTG_FS_DEVICE_DOEPCTRL1_OFSET_OFFSET               29
#define OTG_FS_DEVICE_DOEPCTRL1_OFSET_MASK                 0x20000000

#define OTG_FS_DEVICE_DOEPCTRL1_DPIDSET_OFFSET             28
#define OTG_FS_DEVICE_DOEPCTRL1_DPIDSET_MASK               0x10000000

#define OTG_FS_DEVICE_DOEPCTRL1_NAKSET_OFFSET              27
#define OTG_FS_DEVICE_DOEPCTRL1_NAKSET_MASK                0x8000000

#define OTG_FS_DEVICE_DOEPCTRL1_NAKCLR_OFFSET              26
#define OTG_FS_DEVICE_DOEPCTRL1_NAKCLR_MASK                0x4000000

#define OTG_FS_DEVICE_DOEPCTRL1_STALLH_OFFSET              21
#define OTG_FS_DEVICE_DOEPCTRL1_STALLH_MASK                0x200000

#define OTG_FS_DEVICE_DOEPCTRL1_EPTYPE_OFFSET              18
#define OTG_FS_DEVICE_DOEPCTRL1_EPTYPE_MASK                0xc0000

#define OTG_FS_DEVICE_DOEPCTRL1_NAKSTS_OFFSET              17
#define OTG_FS_DEVICE_DOEPCTRL1_NAKSTS_MASK                0x20000

#define OTG_FS_DEVICE_DOEPCTRL1_EOF_OFFSET                 16
#define OTG_FS_DEVICE_DOEPCTRL1_EOF_MASK                   0x10000

#define OTG_FS_DEVICE_DOEPCTRL1_USBAEP_OFFSET              15
#define OTG_FS_DEVICE_DOEPCTRL1_USBAEP_MASK                0x8000

#define OTG_FS_DEVICE_DOEPCTRL1_MAXPS_OFFSET               0
#define OTG_FS_DEVICE_DOEPCTRL1_MAXPS_MASK                 0x7ff

#define OTG_FS_DEVICE_DOEPINT1_INNAK_OFFSET                13
#define OTG_FS_DEVICE_DOEPINT1_INNAK_MASK                  0x2000

#define OTG_FS_DEVICE_DOEPINT1_BABBLE_OFFSET               12
#define OTG_FS_DEVICE_DOEPINT1_BABBLE_MASK                 0x1000

#define OTG_FS_DEVICE_DOEPINT1_OUTPERR_OFFSET              8
#define OTG_FS_DEVICE_DOEPINT1_OUTPERR_MASK                0x100

#define OTG_FS_DEVICE_DOEPINT1_RXSTSM_OFFSET               5
#define OTG_FS_DEVICE_DOEPINT1_RXSTSM_MASK                 0x20

#define OTG_FS_DEVICE_DOEPINT1_RXOTDIS_OFFSET              4
#define OTG_FS_DEVICE_DOEPINT1_RXOTDIS_MASK                0x10

#define OTG_FS_DEVICE_DOEPINT1_SETPCMP_OFFSET              3
#define OTG_FS_DEVICE_DOEPINT1_SETPCMP_MASK                8

#define OTG_FS_DEVICE_DOEPINT1_EPDIS_OFFSET                1
#define OTG_FS_DEVICE_DOEPINT1_EPDIS_MASK                  2

#define OTG_FS_DEVICE_DOEPINT1_TSFCMP_OFFSET               0
#define OTG_FS_DEVICE_DOEPINT1_TSFCMP_MASK                 1

#define OTG_FS_DEVICE_DOEPTRS1_PID_SPCNT_OFFSET            29
#define OTG_FS_DEVICE_DOEPTRS1_PID_SPCNT_MASK              0x60000000

#define OTG_FS_DEVICE_DOEPTRS1_EPPCNT_OFFSET               19
#define OTG_FS_DEVICE_DOEPTRS1_EPPCNT_MASK                 0x1ff80000

#define OTG_FS_DEVICE_DOEPTRS1_EPTRS_OFFSET                0
#define OTG_FS_DEVICE_DOEPTRS1_EPTRS_MASK                  0x7ffff

#define OTG_FS_DEVICE_DOEPCTRL2_EPEN_OFFSET                31
#define OTG_FS_DEVICE_DOEPCTRL2_EPEN_MASK                  0x80000000

#define OTG_FS_DEVICE_DOEPCTRL2_EPDIS_OFFSET               30
#define OTG_FS_DEVICE_DOEPCTRL2_EPDIS_MASK                 0x40000000

#define OTG_FS_DEVICE_DOEPCTRL2_OFSET_OFFSET               29
#define OTG_FS_DEVICE_DOEPCTRL2_OFSET_MASK                 0x20000000

#define OTG_FS_DEVICE_DOEPCTRL2_DPIDSET_OFFSET             28
#define OTG_FS_DEVICE_DOEPCTRL2_DPIDSET_MASK               0x10000000

#define OTG_FS_DEVICE_DOEPCTRL2_NAKSET_OFFSET              27
#define OTG_FS_DEVICE_DOEPCTRL2_NAKSET_MASK                0x8000000

#define OTG_FS_DEVICE_DOEPCTRL2_NAKCLR_OFFSET              26
#define OTG_FS_DEVICE_DOEPCTRL2_NAKCLR_MASK                0x4000000

#define OTG_FS_DEVICE_DOEPCTRL2_STALLH_OFFSET              21
#define OTG_FS_DEVICE_DOEPCTRL2_STALLH_MASK                0x200000

#define OTG_FS_DEVICE_DOEPCTRL2_EPTYPE_OFFSET              18
#define OTG_FS_DEVICE_DOEPCTRL2_EPTYPE_MASK                0xc0000

#define OTG_FS_DEVICE_DOEPCTRL2_NAKSTS_OFFSET              17
#define OTG_FS_DEVICE_DOEPCTRL2_NAKSTS_MASK                0x20000

#define OTG_FS_DEVICE_DOEPCTRL2_EOF_OFFSET                 16
#define OTG_FS_DEVICE_DOEPCTRL2_EOF_MASK                   0x10000

#define OTG_FS_DEVICE_DOEPCTRL2_USBAEP_OFFSET              15
#define OTG_FS_DEVICE_DOEPCTRL2_USBAEP_MASK                0x8000

#define OTG_FS_DEVICE_DOEPCTRL2_MAXPS_OFFSET               0
#define OTG_FS_DEVICE_DOEPCTRL2_MAXPS_MASK                 0x7ff

#define OTG_FS_DEVICE_DOEPINT2_INNAK_OFFSET                13
#define OTG_FS_DEVICE_DOEPINT2_INNAK_MASK                  0x2000

#define OTG_FS_DEVICE_DOEPINT2_BABBLE_OFFSET               12
#define OTG_FS_DEVICE_DOEPINT2_BABBLE_MASK                 0x1000

#define OTG_FS_DEVICE_DOEPINT2_OUTPERR_OFFSET              8
#define OTG_FS_DEVICE_DOEPINT2_OUTPERR_MASK                0x100

#define OTG_FS_DEVICE_DOEPINT2_RXSTSM_OFFSET               5
#define OTG_FS_DEVICE_DOEPINT2_RXSTSM_MASK                 0x20

#define OTG_FS_DEVICE_DOEPINT2_RXOTDIS_OFFSET              4
#define OTG_FS_DEVICE_DOEPINT2_RXOTDIS_MASK                0x10

#define OTG_FS_DEVICE_DOEPINT2_SETPCMP_OFFSET              3
#define OTG_FS_DEVICE_DOEPINT2_SETPCMP_MASK                8

#define OTG_FS_DEVICE_DOEPINT2_EPDIS_OFFSET                1
#define OTG_FS_DEVICE_DOEPINT2_EPDIS_MASK                  2

#define OTG_FS_DEVICE_DOEPINT2_TSFCMP_OFFSET               0
#define OTG_FS_DEVICE_DOEPINT2_TSFCMP_MASK                 1

#define OTG_FS_DEVICE_DOEPTRS2_PID_SPCNT_OFFSET            29
#define OTG_FS_DEVICE_DOEPTRS2_PID_SPCNT_MASK              0x60000000

#define OTG_FS_DEVICE_DOEPTRS2_EPPCNT_OFFSET               19
#define OTG_FS_DEVICE_DOEPTRS2_EPPCNT_MASK                 0x1ff80000

#define OTG_FS_DEVICE_DOEPTRS2_EPTRS_OFFSET                0
#define OTG_FS_DEVICE_DOEPTRS2_EPTRS_MASK                  0x7ffff

#define OTG_FS_DEVICE_DOEPCTRL3_EPEN_OFFSET                31
#define OTG_FS_DEVICE_DOEPCTRL3_EPEN_MASK                  0x80000000

#define OTG_FS_DEVICE_DOEPCTRL3_EPDIS_OFFSET               30
#define OTG_FS_DEVICE_DOEPCTRL3_EPDIS_MASK                 0x40000000

#define OTG_FS_DEVICE_DOEPCTRL3_OFSET_OFFSET               29
#define OTG_FS_DEVICE_DOEPCTRL3_OFSET_MASK                 0x20000000

#define OTG_FS_DEVICE_DOEPCTRL3_DPIDSET_OFFSET             28
#define OTG_FS_DEVICE_DOEPCTRL3_DPIDSET_MASK               0x10000000

#define OTG_FS_DEVICE_DOEPCTRL3_NAKSET_OFFSET              27
#define OTG_FS_DEVICE_DOEPCTRL3_NAKSET_MASK                0x8000000

#define OTG_FS_DEVICE_DOEPCTRL3_NAKCLR_OFFSET              26
#define OTG_FS_DEVICE_DOEPCTRL3_NAKCLR_MASK                0x4000000

#define OTG_FS_DEVICE_DOEPCTRL3_STALLH_OFFSET              21
#define OTG_FS_DEVICE_DOEPCTRL3_STALLH_MASK                0x200000

#define OTG_FS_DEVICE_DOEPCTRL3_EPTYPE_OFFSET              18
#define OTG_FS_DEVICE_DOEPCTRL3_EPTYPE_MASK                0xc0000

#define OTG_FS_DEVICE_DOEPCTRL3_NAKSTS_OFFSET              17
#define OTG_FS_DEVICE_DOEPCTRL3_NAKSTS_MASK                0x20000

#define OTG_FS_DEVICE_DOEPCTRL3_EOF_OFFSET                 16
#define OTG_FS_DEVICE_DOEPCTRL3_EOF_MASK                   0x10000

#define OTG_FS_DEVICE_DOEPCTRL3_USBAEP_OFFSET              15
#define OTG_FS_DEVICE_DOEPCTRL3_USBAEP_MASK                0x8000

#define OTG_FS_DEVICE_DOEPCTRL3_MAXPS_OFFSET               0
#define OTG_FS_DEVICE_DOEPCTRL3_MAXPS_MASK                 0x7ff

#define OTG_FS_DEVICE_DOEPINT3_INNAK_OFFSET                13
#define OTG_FS_DEVICE_DOEPINT3_INNAK_MASK                  0x2000

#define OTG_FS_DEVICE_DOEPINT3_BABBLE_OFFSET               12
#define OTG_FS_DEVICE_DOEPINT3_BABBLE_MASK                 0x1000

#define OTG_FS_DEVICE_DOEPINT3_OUTPERR_OFFSET              8
#define OTG_FS_DEVICE_DOEPINT3_OUTPERR_MASK                0x100

#define OTG_FS_DEVICE_DOEPINT3_RXSTSM_OFFSET               5
#define OTG_FS_DEVICE_DOEPINT3_RXSTSM_MASK                 0x20

#define OTG_FS_DEVICE_DOEPINT3_RXOTDIS_OFFSET              4
#define OTG_FS_DEVICE_DOEPINT3_RXOTDIS_MASK                0x10

#define OTG_FS_DEVICE_DOEPINT3_SETPCMP_OFFSET              3
#define OTG_FS_DEVICE_DOEPINT3_SETPCMP_MASK                8

#define OTG_FS_DEVICE_DOEPINT3_EPDIS_OFFSET                1
#define OTG_FS_DEVICE_DOEPINT3_EPDIS_MASK                  2

#define OTG_FS_DEVICE_DOEPINT3_TSFCMP_OFFSET               0
#define OTG_FS_DEVICE_DOEPINT3_TSFCMP_MASK                 1

#define OTG_FS_DEVICE_DOEPTRS3_PID_SPCNT_OFFSET            29
#define OTG_FS_DEVICE_DOEPTRS3_PID_SPCNT_MASK              0x60000000

#define OTG_FS_DEVICE_DOEPTRS3_EPPCNT_OFFSET               19
#define OTG_FS_DEVICE_DOEPTRS3_EPPCNT_MASK                 0x1ff80000

#define OTG_FS_DEVICE_DOEPTRS3_EPTRS_OFFSET                0
#define OTG_FS_DEVICE_DOEPTRS3_EPTRS_MASK                  0x7ffff


typedef struct
{

/** DCFG DCFG (offset: 0x0)
  OTG_FS device configuration register (OTG_FS_DCFG)
  access : read-write
  reset value : 0x2200000
  reset mask : 0xFFFFFFFF
  Field: DSPDSEL
  offset: 0, size: 2, access: 
  Device speed
  Field: SENDOUT
  offset: 2, size: 1, access: 
  Non-zero-length status OUT handshake
  Field: DADDR
  offset: 4, size: 7, access: 
  Device address
  Field: PFITV
  offset: 11, size: 2, access: 
  Periodic frame interval
*/
volatile uint32_t DCFG;

/** DCTRL DCTRL (offset: 0x4)
  OTG_FS device control register (OTG_FS_DCTL)
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RWKUPS
  offset: 0, size: 1, access: read-write
  Remote wakeup signaling
  Field: SDCNNT
  offset: 1, size: 1, access: read-write
  Soft disconnect
  Field: GINAKSTS
  offset: 2, size: 1, access: read-only
  Global IN NAK status
  Field: GONAKSTS
  offset: 3, size: 1, access: read-only
  Global OUT NAK status
  Field: TESTSEL
  offset: 4, size: 3, access: read-write
  Test control
  Field: GINAKSET
  offset: 7, size: 1, access: read-write
  Set global IN NAK
  Field: GINAKCLR
  offset: 8, size: 1, access: read-write
  Clear global IN NAK
  Field: GONAKSET
  offset: 9, size: 1, access: read-write
  Set global OUT NAK
  Field: GONAKCLR
  offset: 10, size: 1, access: read-write
  Clear global OUT NAK
  Field: POPROGCMP
  offset: 11, size: 1, access: read-write
  Power-on programming done
*/
volatile uint32_t DCTRL;

/** DSTS DSTS (offset: 0x8)
  OTG_FS device status register (OTG_FS_DSTS)
  access : read-only
  reset value : 0x10
  reset mask : 0xFFFFFFFF
  Field: SUSSTS
  offset: 0, size: 1, access: 
  Suspend status
  Field: ENUMSPD
  offset: 1, size: 2, access: 
  Enumerated speed
  Field: ERTERR
  offset: 3, size: 1, access: 
  Erratic error
  Field: SOFNUM
  offset: 8, size: 14, access: 
  Frame number of the received SOF
*/
volatile uint32_t DSTS;
volatile uint32_t reserved0;

/** DINIMASK DINIMASK (offset: 0x10)
  OTG_FS device IN endpoint common interrupt mask register (OTG_FS_DIEPMSK)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPM
  offset: 0, size: 1, access: 
  Transfer completed interrupt mask
  Field: EPDISM
  offset: 1, size: 1, access: 
  Endpoint disabled interrupt mask
  Field: TOM
  offset: 3, size: 1, access: 
  Timeout condition mask (Non-isochronous endpoints)
  Field: ITXEMPM
  offset: 4, size: 1, access: 
  IN token received when TxFIFO empty mask
  Field: IEPMMM
  offset: 5, size: 1, access: 
  IN token received with EP mismatch mask
  Field: IEPNAKEM
  offset: 6, size: 1, access: 
  IN endpoint NAK effective mask
  Field: NAKM
  offset: 13, size: 1, access: 
  NAK Interrupt Mask
*/
volatile uint32_t DINIMASK;

/** DOUTIMASK DOUTIMASK (offset: 0x14)
  OTG_FS device OUT endpoint common interrupt mask register (OTG_FS_DOEPMSK)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TSFCMPM
  offset: 0, size: 1, access: 
  Transfer completed interrupt mask
  Field: EPDISM
  offset: 1, size: 1, access: 
  Endpoint disabled interrupt mask
  Field: SETPCMPM
  offset: 3, size: 1, access: 
  SETUP phase done mask
  Field: OTXEMPM
  offset: 4, size: 1, access: 
  OUT token received when endpoint disabled mask
  Field: RXIWCTRLM
  offset: 5, size: 1, access: 
  Receive Interrupt when Control Mask
  Field: OUTPM
  offset: 8, size: 1, access: 
  OUT Packet Error Interrupt Mask
  Field: BABBLEM
  offset: 12, size: 1, access: 
  Babble Error Interrupt Mask
  Field: NAKM
  offset: 13, size: 1, access: 
  NAK Interrupt Mask
*/
volatile uint32_t DOUTIMASK;

/** DAEPINT DAEPINT (offset: 0x18)
  OTG_FS device all endpoints interrupt register (OTG_FS_DAINT)
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INEPINT
  offset: 0, size: 16, access: 
  IN endpoint interrupt bits
  Field: OUTEPINT
  offset: 16, size: 16, access: 
  OUT endpoint interrupt bits
*/
volatile uint32_t DAEPINT;

/** DAEPIMASK DAEPIMASK (offset: 0x1c)
  OTG_FS all endpoints interrupt mask register (OTG_FS_DAINTMSK)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: AINM
  offset: 0, size: 16, access: 
  IN EP interrupt mask bits
  Field: AOUTM
  offset: 16, size: 16, access: 
  OUT endpoint interrupt bits
*/
volatile uint32_t DAEPIMASK;
volatile uint32_t reserved1[2];

/** DVBUSDTIM DVBUSDTIM (offset: 0x28)
  OTG_FS device VBUS discharge time register
  access : read-write
  reset value : 0x17D7
  reset mask : 0xFFFFFFFF
  Field: VBUSDTIM
  offset: 0, size: 16, access: 
  Device VBUS discharge time
*/
volatile uint32_t DVBUSDTIM;

/** DVBUSPTIM DVBUSPTIM (offset: 0x2c)
  OTG_FS device VBUS pulsing time register
  access : read-write
  reset value : 0x5B8
  reset mask : 0xFFFFFFFF
  Field: VBUSPTIM
  offset: 0, size: 12, access: 
  Device VBUS pulsing time
*/
volatile uint32_t DVBUSPTIM;
volatile uint32_t reserved2;

/** DIEIMASK DIEIMASK (offset: 0x34)
  OTG_FS device IN endpoint FIFO empty interrupt mask register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INEM
  offset: 0, size: 16, access: 
  IN EP Tx FIFO empty interrupt mask bits
*/
volatile uint32_t DIEIMASK;
volatile uint32_t reserved3[50];

/** DIEPCTRL0 DIEPCTRL0 (offset: 0x100)
  OTG_FS device control IN endpoint 0 control register (OTG_FS_DIEPCTL0)
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MAXPS
  offset: 0, size: 2, access: read-write
  Maximum packet size
  Field: USBAEP
  offset: 15, size: 1, access: read-only
  USB active endpoint
  Field: NAKSTST
  offset: 17, size: 1, access: read-only
  NAK status
  Field: EPTYPE
  offset: 18, size: 2, access: read-only
  Endpoint type
  Field: STALLH
  offset: 21, size: 1, access: read-write
  STALL handshake
  Field: TXFNUM
  offset: 22, size: 4, access: read-write
  TxFIFO number
  Field: NAKCLR
  offset: 26, size: 1, access: write-only
  Clear NAK
  Field: NAKSET
  offset: 27, size: 1, access: write-only
  Set NAK
  Field: EPDIS
  offset: 30, size: 1, access: read-only
  Endpoint disable
  Field: EPEN
  offset: 31, size: 1, access: read-only
  Endpoint enable
*/
volatile uint32_t DIEPCTRL0;
volatile uint32_t reserved4;

/** DIEPINT0 DIEPINT0 (offset: 0x108)
  device endpoint-x interrupt register
  reset value : 0x80
  reset mask : 0xFFFFFFFF
  Field: INNAK
  offset: 13, size: 1, access: read-write
  Input NAK Interrupt
  Field: PDSTS
  offset: 11, size: 1, access: read-write
  Packet Dropped Status
  Field: TXFE
  offset: 7, size: 1, access: read-only
  TXFIFO Empty Interrupt
  Field: IEPNAKE
  offset: 6, size: 1, access: read-write
  IN Endpoint NAK Effective
  Field: ITXEMP
  offset: 4, size: 1, access: read-write
  Receive IN Token Interrupt
  Field: TO
  offset: 3, size: 1, access: read-write
  Timeout Interrupt
  Field: EPDIS
  offset: 1, size: 1, access: read-write
  Endpoint Interrupt Disable
  Field: TSFCMP
  offset: 0, size: 1, access: read-write
  Transfer Complete Interrupt
*/
volatile uint32_t DIEPINT0;
volatile uint32_t reserved5;

/** DIEPTRS0 DIEPTRS0 (offset: 0x110)
  device endpoint-0 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EPPCNT
  offset: 19, size: 2, access: 
  Packet count
  Field: EPTRS
  offset: 0, size: 7, access: 
  Transfer size
*/
volatile uint32_t DIEPTRS0;
volatile uint32_t reserved6;

/** DITXFSTS0 DITXFSTS0 (offset: 0x118)
  OTG_FS device IN endpoint transmit FIFO status register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INEPTXFSASEL
  offset: 0, size: 16, access: 
  IN endpoint TxFIFO space available
*/
volatile uint32_t DITXFSTS0;
volatile uint32_t reserved7;

/** DIEPCTRL1 DIEPCTRL1 (offset: 0x120)
  OTG device endpoint-1 control register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EPEN
  offset: 31, size: 1, access: read-write
  Endpoint Enable
  Field: EPDIS
  offset: 30, size: 1, access: read-write
  Endpoint Disable
  Field: OFSET
  offset: 29, size: 1, access: write-only
  Odd Frame Set
  Field: DPIDSET
  offset: 28, size: 1, access: write-only
  DATA0 PID Set
  Field: NAKSET
  offset: 27, size: 1, access: write-only
  NAK Set
  Field: NAKCLR
  offset: 26, size: 1, access: write-only
  NAK Clear
  Field: TXFNUM
  offset: 22, size: 4, access: read-write
  TXFIFO Number
  Field: STALLH
  offset: 21, size: 1, access: read-write
  STALL Handshake
  Field: EPTYPE
  offset: 18, size: 2, access: read-write
  Endpoint Type
  Field: NAKSTS
  offset: 17, size: 1, access: read-only
  NAK Status Configure
  Field: EOF
  offset: 16, size: 1, access: read-only
  Even Odd Frame Select
  Field: USBAEP
  offset: 15, size: 1, access: read-write
  USB Active Endpoint
  Field: MAXPS
  offset: 0, size: 11, access: read-write
  Maximum Packet Size
*/
volatile uint32_t DIEPCTRL1;
volatile uint32_t reserved8;

/** DIEPINT1 DIEPINT1 (offset: 0x128)
  device endpoint-1 interrupt register
  reset value : 0x80
  reset mask : 0xFFFFFFFF
  Field: INNAK
  offset: 13, size: 1, access: read-write
  Input NAK Interrupt
  Field: PDSTS
  offset: 11, size: 1, access: read-write
  Packet Dropped Status
  Field: TXFE
  offset: 7, size: 1, access: read-only
  TXFIFO Empty Interrupt
  Field: IEPNAKE
  offset: 6, size: 1, access: read-write
  IN Endpoint NAK Effective
  Field: ITXEMP
  offset: 4, size: 1, access: read-write
  Receive IN Token Interrupt
  Field: TO
  offset: 3, size: 1, access: read-write
  Timeout Interrupt
  Field: EPDIS
  offset: 1, size: 1, access: read-write
  Endpoint Interrupt Disable
  Field: TSFCMP
  offset: 0, size: 1, access: read-write
  Transfer Complete Interrupt
*/
volatile uint32_t DIEPINT1;
volatile uint32_t reserved9;

/** DIEPTRS1 DIEPTRS1 (offset: 0x130)
  device endpoint-1 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EPPCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: EPTRS
  offset: 0, size: 19, access: 
  Transfer size
*/
volatile uint32_t DIEPTRS1;
volatile uint32_t reserved10;

/** DITXFSTS1 DITXFSTS1 (offset: 0x138)
  OTG_FS device IN endpoint transmit FIFO status register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INEPTXFSASEL
  offset: 0, size: 16, access: 
  IN endpoint TxFIFO space available
*/
volatile uint32_t DITXFSTS1;
volatile uint32_t reserved11;

/** DIEPCTRL2 DIEPCTRL2 (offset: 0x140)
  OTG device endpoint-2 control register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EPEN
  offset: 31, size: 1, access: read-write
  Endpoint Enable
  Field: EPDIS
  offset: 30, size: 1, access: read-write
  Endpoint Disable
  Field: OFSET
  offset: 29, size: 1, access: write-only
  Odd Frame Set
  Field: DPIDSET
  offset: 28, size: 1, access: write-only
  DATA0 PID Set
  Field: NAKSET
  offset: 27, size: 1, access: write-only
  NAK Set
  Field: NAKCLR
  offset: 26, size: 1, access: write-only
  NAK Clear
  Field: TXFNUM
  offset: 22, size: 4, access: read-write
  TXFIFO Number
  Field: STALLH
  offset: 21, size: 1, access: read-write
  STALL Handshake
  Field: EPTYPE
  offset: 18, size: 2, access: read-write
  Endpoint Type
  Field: NAKSTS
  offset: 17, size: 1, access: read-only
  NAK Status Configure
  Field: EOF
  offset: 16, size: 1, access: read-only
  Even Odd Frame Select
  Field: USBAEP
  offset: 15, size: 1, access: read-write
  USB Active Endpoint
  Field: MAXPS
  offset: 0, size: 11, access: read-write
  Maximum Packet Size
*/
volatile uint32_t DIEPCTRL2;
volatile uint32_t reserved12;

/** DIEPINT2 DIEPINT2 (offset: 0x148)
  device endpoint-2 interrupt register
  reset value : 0x80
  reset mask : 0xFFFFFFFF
  Field: INNAK
  offset: 13, size: 1, access: read-write
  Input NAK Interrupt
  Field: PDSTS
  offset: 11, size: 1, access: read-write
  Packet Dropped Status
  Field: TXFE
  offset: 7, size: 1, access: read-only
  TXFIFO Empty Interrupt
  Field: IEPNAKE
  offset: 6, size: 1, access: read-write
  IN Endpoint NAK Effective
  Field: ITXEMP
  offset: 4, size: 1, access: read-write
  Receive IN Token Interrupt
  Field: TO
  offset: 3, size: 1, access: read-write
  Timeout Interrupt
  Field: EPDIS
  offset: 1, size: 1, access: read-write
  Endpoint Interrupt Disable
  Field: TSFCMP
  offset: 0, size: 1, access: read-write
  Transfer Complete Interrupt
*/
volatile uint32_t DIEPINT2;
volatile uint32_t reserved13;

/** DIEPTRS2 DIEPTRS2 (offset: 0x150)
  device endpoint-2 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EPPCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: EPTRS
  offset: 0, size: 19, access: 
  Transfer size
*/
volatile uint32_t DIEPTRS2;
volatile uint32_t reserved14;

/** DITXFSTS2 DITXFSTS2 (offset: 0x158)
  OTG_FS device IN endpoint transmit FIFO status register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INEPTXFSASEL
  offset: 0, size: 16, access: 
  IN endpoint TxFIFO space available
*/
volatile uint32_t DITXFSTS2;
volatile uint32_t reserved15;

/** DIEPCTRL3 DIEPCTRL3 (offset: 0x160)
  OTG device endpoint-3 control register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EPEN
  offset: 31, size: 1, access: read-write
  Endpoint Enable
  Field: EPDIS
  offset: 30, size: 1, access: read-write
  Endpoint Disable
  Field: OFSET
  offset: 29, size: 1, access: write-only
  Odd Frame Set
  Field: DPIDSET
  offset: 28, size: 1, access: write-only
  DATA0 PID Set
  Field: NAKSET
  offset: 27, size: 1, access: write-only
  NAK Set
  Field: NAKCLR
  offset: 26, size: 1, access: write-only
  NAK Clear
  Field: TXFNUM
  offset: 22, size: 4, access: read-write
  TXFIFO Number
  Field: STALLH
  offset: 21, size: 1, access: read-write
  STALL Handshake
  Field: EPTYPE
  offset: 18, size: 2, access: read-write
  Endpoint Type
  Field: NAKSTS
  offset: 17, size: 1, access: read-only
  NAK Status Configure
  Field: EOF
  offset: 16, size: 1, access: read-only
  Even Odd Frame Select
  Field: USBAEP
  offset: 15, size: 1, access: read-write
  USB Active Endpoint
  Field: MAXPS
  offset: 0, size: 11, access: read-write
  Maximum Packet Size
*/
volatile uint32_t DIEPCTRL3;
volatile uint32_t reserved16;

/** DIEPINT3 DIEPINT3 (offset: 0x168)
  device endpoint-3 interrupt register
  reset value : 0x80
  reset mask : 0xFFFFFFFF
  Field: INNAK
  offset: 13, size: 1, access: read-write
  Input NAK Interrupt
  Field: PDSTS
  offset: 11, size: 1, access: read-write
  Packet Dropped Status
  Field: TXFE
  offset: 7, size: 1, access: read-only
  TXFIFO Empty Interrupt
  Field: IEPNAKE
  offset: 6, size: 1, access: read-write
  IN Endpoint NAK Effective
  Field: ITXEMP
  offset: 4, size: 1, access: read-write
  Receive IN Token Interrupt
  Field: TO
  offset: 3, size: 1, access: read-write
  Timeout Interrupt
  Field: EPDIS
  offset: 1, size: 1, access: read-write
  Endpoint Interrupt Disable
  Field: TSFCMP
  offset: 0, size: 1, access: read-write
  Transfer Complete Interrupt
*/
volatile uint32_t DIEPINT3;
volatile uint32_t reserved17;

/** DIEPTRS3 DIEPTRS3 (offset: 0x170)
  device endpoint-3 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EPPCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: EPTRS
  offset: 0, size: 19, access: 
  Transfer size
*/
volatile uint32_t DIEPTRS3;
volatile uint32_t reserved18;

/** DITXFSTS3 DITXFSTS3 (offset: 0x178)
  OTG_FS device IN endpoint transmit FIFO status register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INEPTXFSASEL
  offset: 0, size: 16, access: 
  IN endpoint TxFIFO space available
*/
volatile uint32_t DITXFSTS3;
volatile uint32_t reserved19[97];

/** DOEPCTRL0 DOEPCTRL0 (offset: 0x300)
  device endpoint-0 control register
  reset value : 0x8000
  reset mask : 0xFFFFFFFF
  Field: EPEN
  offset: 31, size: 1, access: write-only
  Endpoint Enable
  Field: EPDIS
  offset: 30, size: 1, access: read-only
  Endpoint Disable
  Field: NAKSET
  offset: 27, size: 1, access: write-only
  NAK Set
  Field: NAKCLR
  offset: 26, size: 1, access: write-only
  NAK Clear
  Field: STALLH
  offset: 21, size: 1, access: read-write
  STALL Handshake
  Field: SNMEN
  offset: 20, size: 1, access: read-write
  Snoop Mode Enable
  Field: EPTYPE
  offset: 18, size: 2, access: read-only
  Endpoint Type
  Field: NAKSTS
  offset: 17, size: 1, access: read-only
  NAK Status Configure
  Field: USBAEP
  offset: 15, size: 1, access: read-only
  USB Active Endpoint
  Field: MAXPS
  offset: 0, size: 2, access: read-only
  Maximum Packet Size
*/
volatile uint32_t DOEPCTRL0;
volatile uint32_t reserved20;

/** DOEPINT0 DOEPINT0 (offset: 0x308)
  device endpoint-0 interrupt register
  access : read-write
  reset value : 0x80
  reset mask : 0xFFFFFFFF
  Field: INNAK
  offset: 13, size: 1, access: 
  Input NAK Interrupt
  Field: BABBLE
  offset: 12, size: 1, access: 
  Babble Error Interrupt
  Field: OUTPERR
  offset: 8, size: 1, access: 
  OUT Packet Error Interrupt Mask
  Field: RXSTSM
  offset: 5, size: 1, access: 
  Receive Interrupt Status when Write Control Mask
  Field: RXOTDIS
  offset: 4, size: 1, access: 
  Receive OUT Token Disable Interrupt
  Field: SETPCMP
  offset: 3, size: 1, access: 
  SETUP Phase Complete Interrupt
  Field: EPDIS
  offset: 1, size: 1, access: 
  Endpoint Interrupt Disable
  Field: TSFCMP
  offset: 0, size: 1, access: 
  Transfer Complete Interrupt
*/
volatile uint32_t DOEPINT0;
volatile uint32_t reserved21;

/** DOEPTRS0 DOEPTRS0 (offset: 0x310)
  device OUT endpoint-0 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SPCNT
  offset: 29, size: 2, access: 
  SETUP packet count
  Field: EPPCNT
  offset: 19, size: 1, access: 
  Packet count
  Field: EPTRS
  offset: 0, size: 7, access: 
  Transfer size
*/
volatile uint32_t DOEPTRS0;
volatile uint32_t reserved22[3];

/** DOEPCTRL1 DOEPCTRL1 (offset: 0x320)
  device endpoint-1 control register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EPEN
  offset: 31, size: 1, access: read-write
  Endpoint Enable
  Field: EPDIS
  offset: 30, size: 1, access: read-write
  Endpoint Disable
  Field: OFSET
  offset: 29, size: 1, access: write-only
  Odd Frame Set
  Field: DPIDSET
  offset: 28, size: 1, access: write-only
  DATA0 PID Set
  Field: NAKSET
  offset: 27, size: 1, access: write-only
  NAK Set
  Field: NAKCLR
  offset: 26, size: 1, access: write-only
  NAK Clear
  Field: STALLH
  offset: 21, size: 1, access: read-write
  STALL Handshake
  Field: EPTYPE
  offset: 18, size: 2, access: read-write
  Endpoint Type
  Field: NAKSTS
  offset: 17, size: 1, access: read-only
  NAK Status Configure
  Field: EOF
  offset: 16, size: 1, access: read-only
  Even Odd Frame Select
  Field: USBAEP
  offset: 15, size: 1, access: read-write
  USB Active Endpoint
  Field: MAXPS
  offset: 0, size: 11, access: read-write
  Maximum Packet Size
*/
volatile uint32_t DOEPCTRL1;
volatile uint32_t reserved23;

/** DOEPINT1 DOEPINT1 (offset: 0x328)
  device endpoint-1 interrupt register
  access : read-write
  reset value : 0x80
  reset mask : 0xFFFFFFFF
  Field: INNAK
  offset: 13, size: 1, access: 
  Input NAK Interrupt
  Field: BABBLE
  offset: 12, size: 1, access: 
  Babble Error Interrupt
  Field: OUTPERR
  offset: 8, size: 1, access: 
  OUT Packet Error Interrupt Mask
  Field: RXSTSM
  offset: 5, size: 1, access: 
  Receive Interrupt Status when Write Control Mask
  Field: RXOTDIS
  offset: 4, size: 1, access: 
  Receive OUT Token Disable Interrupt
  Field: SETPCMP
  offset: 3, size: 1, access: 
  SETUP Phase Complete Interrupt
  Field: EPDIS
  offset: 1, size: 1, access: 
  Endpoint Interrupt Disable
  Field: TSFCMP
  offset: 0, size: 1, access: 
  Transfer Complete Interrupt
*/
volatile uint32_t DOEPINT1;
volatile uint32_t reserved24;

/** DOEPTRS1 DOEPTRS1 (offset: 0x330)
  device OUT endpoint-1 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PID_SPCNT
  offset: 29, size: 2, access: 
  Received data PID/SETUP packet count
  Field: EPPCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: EPTRS
  offset: 0, size: 19, access: 
  Transfer size
*/
volatile uint32_t DOEPTRS1;
volatile uint32_t reserved25[3];

/** DOEPCTRL2 DOEPCTRL2 (offset: 0x340)
  device endpoint-2 control register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EPEN
  offset: 31, size: 1, access: read-write
  Endpoint Enable
  Field: EPDIS
  offset: 30, size: 1, access: read-write
  Endpoint Disable
  Field: OFSET
  offset: 29, size: 1, access: write-only
  Odd Frame Set
  Field: DPIDSET
  offset: 28, size: 1, access: write-only
  DATA0 PID Set
  Field: NAKSET
  offset: 27, size: 1, access: write-only
  NAK Set
  Field: NAKCLR
  offset: 26, size: 1, access: write-only
  NAK Clear
  Field: STALLH
  offset: 21, size: 1, access: read-write
  STALL Handshake
  Field: EPTYPE
  offset: 18, size: 2, access: read-write
  Endpoint Type
  Field: NAKSTS
  offset: 17, size: 1, access: read-only
  NAK Status Configure
  Field: EOF
  offset: 16, size: 1, access: read-only
  Even Odd Frame Select
  Field: USBAEP
  offset: 15, size: 1, access: read-write
  USB Active Endpoint
  Field: MAXPS
  offset: 0, size: 11, access: read-write
  Maximum Packet Size
*/
volatile uint32_t DOEPCTRL2;
volatile uint32_t reserved26;

/** DOEPINT2 DOEPINT2 (offset: 0x348)
  device endpoint-2 interrupt register
  access : read-write
  reset value : 0x80
  reset mask : 0xFFFFFFFF
  Field: INNAK
  offset: 13, size: 1, access: 
  Input NAK Interrupt
  Field: BABBLE
  offset: 12, size: 1, access: 
  Babble Error Interrupt
  Field: OUTPERR
  offset: 8, size: 1, access: 
  OUT Packet Error Interrupt Mask
  Field: RXSTSM
  offset: 5, size: 1, access: 
  Receive Interrupt Status when Write Control Mask
  Field: RXOTDIS
  offset: 4, size: 1, access: 
  Receive OUT Token Disable Interrupt
  Field: SETPCMP
  offset: 3, size: 1, access: 
  SETUP Phase Complete Interrupt
  Field: EPDIS
  offset: 1, size: 1, access: 
  Endpoint Interrupt Disable
  Field: TSFCMP
  offset: 0, size: 1, access: 
  Transfer Complete Interrupt
*/
volatile uint32_t DOEPINT2;
volatile uint32_t reserved27;

/** DOEPTRS2 DOEPTRS2 (offset: 0x350)
  device OUT endpoint-2 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PID_SPCNT
  offset: 29, size: 2, access: 
  Received data PID/SETUP packet count
  Field: EPPCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: EPTRS
  offset: 0, size: 19, access: 
  Transfer size
*/
volatile uint32_t DOEPTRS2;
volatile uint32_t reserved28[3];

/** DOEPCTRL3 DOEPCTRL3 (offset: 0x360)
  device endpoint-3 control register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EPEN
  offset: 31, size: 1, access: read-write
  Endpoint Enable
  Field: EPDIS
  offset: 30, size: 1, access: read-write
  Endpoint Disable
  Field: OFSET
  offset: 29, size: 1, access: write-only
  Odd Frame Set
  Field: DPIDSET
  offset: 28, size: 1, access: write-only
  DATA0 PID Set
  Field: NAKSET
  offset: 27, size: 1, access: write-only
  NAK Set
  Field: NAKCLR
  offset: 26, size: 1, access: write-only
  NAK Clear
  Field: STALLH
  offset: 21, size: 1, access: read-write
  STALL Handshake
  Field: EPTYPE
  offset: 18, size: 2, access: read-write
  Endpoint Type
  Field: NAKSTS
  offset: 17, size: 1, access: read-only
  NAK Status Configure
  Field: EOF
  offset: 16, size: 1, access: read-only
  Even Odd Frame Select
  Field: USBAEP
  offset: 15, size: 1, access: read-write
  USB Active Endpoint
  Field: MAXPS
  offset: 0, size: 11, access: read-write
  Maximum Packet Size
*/
volatile uint32_t DOEPCTRL3;
volatile uint32_t reserved29;

/** DOEPINT3 DOEPINT3 (offset: 0x368)
  device endpoint-3 interrupt register
  access : read-write
  reset value : 0x80
  reset mask : 0xFFFFFFFF
  Field: INNAK
  offset: 13, size: 1, access: 
  Input NAK Interrupt
  Field: BABBLE
  offset: 12, size: 1, access: 
  Babble Error Interrupt
  Field: OUTPERR
  offset: 8, size: 1, access: 
  OUT Packet Error Interrupt Mask
  Field: RXSTSM
  offset: 5, size: 1, access: 
  Receive Interrupt Status when Write Control Mask
  Field: RXOTDIS
  offset: 4, size: 1, access: 
  Receive OUT Token Disable Interrupt
  Field: SETPCMP
  offset: 3, size: 1, access: 
  SETUP Phase Complete Interrupt
  Field: EPDIS
  offset: 1, size: 1, access: 
  Endpoint Interrupt Disable
  Field: TSFCMP
  offset: 0, size: 1, access: 
  Transfer Complete Interrupt
*/
volatile uint32_t DOEPINT3;
volatile uint32_t reserved30;

/** DOEPTRS3 DOEPTRS3 (offset: 0x370)
  device OUT endpoint-3 transfer size register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PID_SPCNT
  offset: 29, size: 2, access: 
  Received data PID/SETUP packet count
  Field: EPPCNT
  offset: 19, size: 10, access: 
  Packet count
  Field: EPTRS
  offset: 0, size: 19, access: 
  Transfer size
*/
volatile uint32_t DOEPTRS3;
} OTG_FS_DEVICE_type;

#define OTG_FS_DEVICE ((OTG_FS_DEVICE_type *) 0x50000800)

#endif // HW_OTG_FS_DEVICE_H
