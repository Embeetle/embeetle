#ifndef HW_SPI1_H
#define HW_SPI1_H
/** Serial peripheral interface */
/** Interrupt : SPI1 (Vector: 35) SPI1 global interrupt */
/** Memory Block starting at 0x40013000 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define SPI1_CTRL1_BMEN_OFFSET                             15
#define SPI1_CTRL1_BMEN_MASK                               0x8000

#define SPI1_CTRL1_BMOEN_OFFSET                            14
#define SPI1_CTRL1_BMOEN_MASK                              0x4000

#define SPI1_CTRL1_CRCEN_OFFSET                            13
#define SPI1_CTRL1_CRCEN_MASK                              0x2000

#define SPI1_CTRL1_CRCNXT_OFFSET                           12
#define SPI1_CTRL1_CRCNXT_MASK                             0x1000

#define SPI1_CTRL1_DFLSEL_OFFSET                           11
#define SPI1_CTRL1_DFLSEL_MASK                             0x800

#define SPI1_CTRL1_RXOMEN_OFFSET                           10
#define SPI1_CTRL1_RXOMEN_MASK                             0x400

#define SPI1_CTRL1_SSEN_OFFSET                             9
#define SPI1_CTRL1_SSEN_MASK                               0x200

#define SPI1_CTRL1_ISSEL_OFFSET                            8
#define SPI1_CTRL1_ISSEL_MASK                              0x100

#define SPI1_CTRL1_LSBSEL_OFFSET                           7
#define SPI1_CTRL1_LSBSEL_MASK                             0x80

#define SPI1_CTRL1_SPIEN_OFFSET                            6
#define SPI1_CTRL1_SPIEN_MASK                              0x40

#define SPI1_CTRL1_BRSEL_OFFSET                            3
#define SPI1_CTRL1_BRSEL_MASK                              0x38

#define SPI1_CTRL1_MSMCFG_OFFSET                           2
#define SPI1_CTRL1_MSMCFG_MASK                             4

#define SPI1_CTRL1_CPOL_OFFSET                             1
#define SPI1_CTRL1_CPOL_MASK                               2

#define SPI1_CTRL1_CPHA_OFFSET                             0
#define SPI1_CTRL1_CPHA_MASK                               1

#define SPI1_CTRL2_TXBEIEN_OFFSET                          7
#define SPI1_CTRL2_TXBEIEN_MASK                            0x80

#define SPI1_CTRL2_RXBNEIEN_OFFSET                         6
#define SPI1_CTRL2_RXBNEIEN_MASK                           0x40

#define SPI1_CTRL2_ERRIEN_OFFSET                           5
#define SPI1_CTRL2_ERRIEN_MASK                             0x20

#define SPI1_CTRL2_FRFCFG_OFFSET                           4
#define SPI1_CTRL2_FRFCFG_MASK                             0x10

#define SPI1_CTRL2_SSOEN_OFFSET                            2
#define SPI1_CTRL2_SSOEN_MASK                              4

#define SPI1_CTRL2_TXDEN_OFFSET                            1
#define SPI1_CTRL2_TXDEN_MASK                              2

#define SPI1_CTRL2_RXDEN_OFFSET                            0
#define SPI1_CTRL2_RXDEN_MASK                              1

#define SPI1_STS_FFERR_OFFSET                              8
#define SPI1_STS_FFERR_MASK                                0x100

#define SPI1_STS_BSYFLG_OFFSET                             7
#define SPI1_STS_BSYFLG_MASK                               0x80

#define SPI1_STS_OVRFLG_OFFSET                             6
#define SPI1_STS_OVRFLG_MASK                               0x40

#define SPI1_STS_MEFLG_OFFSET                              5
#define SPI1_STS_MEFLG_MASK                                0x20

#define SPI1_STS_CRCEFLG_OFFSET                            4
#define SPI1_STS_CRCEFLG_MASK                              0x10

#define SPI1_STS_UDRFLG_OFFSET                             3
#define SPI1_STS_UDRFLG_MASK                               8

#define SPI1_STS_SCHDIR_OFFSET                             2
#define SPI1_STS_SCHDIR_MASK                               4

#define SPI1_STS_TXBEFLG_OFFSET                            1
#define SPI1_STS_TXBEFLG_MASK                              2

#define SPI1_STS_RXBNEFLG_OFFSET                           0
#define SPI1_STS_RXBNEFLG_MASK                             1

#define SPI1_DATA_DATA_OFFSET                              0
#define SPI1_DATA_DATA_MASK                                0xffff

#define SPI1_CRCPOLY_CRCPOLY_OFFSET                        0
#define SPI1_CRCPOLY_CRCPOLY_MASK                          0xffff

#define SPI1_RXCRC_RXCRC_OFFSET                            0
#define SPI1_RXCRC_RXCRC_MASK                              0xffff

#define SPI1_TXCRC_TXCRC_OFFSET                            0
#define SPI1_TXCRC_TXCRC_MASK                              0xffff

#define SPI1_I2SCFG_MODESEL_OFFSET                         11
#define SPI1_I2SCFG_MODESEL_MASK                           0x800

#define SPI1_I2SCFG_I2SEN_OFFSET                           10
#define SPI1_I2SCFG_I2SEN_MASK                             0x400

#define SPI1_I2SCFG_I2SMOD_OFFSET                          8
#define SPI1_I2SCFG_I2SMOD_MASK                            0x300

#define SPI1_I2SCFG_PFSSEL_OFFSET                          7
#define SPI1_I2SCFG_PFSSEL_MASK                            0x80

#define SPI1_I2SCFG_I2SSSEL_OFFSET                         4
#define SPI1_I2SCFG_I2SSSEL_MASK                           0x30

#define SPI1_I2SCFG_CPOL_OFFSET                            3
#define SPI1_I2SCFG_CPOL_MASK                              8

#define SPI1_I2SCFG_DATALEN_OFFSET                         1
#define SPI1_I2SCFG_DATALEN_MASK                           6

#define SPI1_I2SCFG_CHLEN_OFFSET                           0
#define SPI1_I2SCFG_CHLEN_MASK                             1

#define SPI1_I2SPSC_MCOEN_OFFSET                           9
#define SPI1_I2SPSC_MCOEN_MASK                             0x200

#define SPI1_I2SPSC_ODDPSC_OFFSET                          8
#define SPI1_I2SPSC_ODDPSC_MASK                            0x100

#define SPI1_I2SPSC_I2SPSC_OFFSET                          0
#define SPI1_I2SPSC_I2SPSC_MASK                            0xff


typedef struct
{

/** CTRL1 CTRL1 (offset: 0x0)
  control register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BMEN
  offset: 15, size: 1, access: 
  Bidirectional data mode enable
  Field: BMOEN
  offset: 14, size: 1, access: 
  Output enable in bidirectional mode
  Field: CRCEN
  offset: 13, size: 1, access: 
  Hardware CRC calculation enable
  Field: CRCNXT
  offset: 12, size: 1, access: 
  CRC transfer next
  Field: DFLSEL
  offset: 11, size: 1, access: 
  Data frame format
  Field: RXOMEN
  offset: 10, size: 1, access: 
  Receive only
  Field: SSEN
  offset: 9, size: 1, access: 
  Software slave management
  Field: ISSEL
  offset: 8, size: 1, access: 
  Internal slave select
  Field: LSBSEL
  offset: 7, size: 1, access: 
  Frame format
  Field: SPIEN
  offset: 6, size: 1, access: 
  SPI enable
  Field: BRSEL
  offset: 3, size: 3, access: 
  Baud rate control
  Field: MSMCFG
  offset: 2, size: 1, access: 
  Master selection
  Field: CPOL
  offset: 1, size: 1, access: 
  Clock polarity
  Field: CPHA
  offset: 0, size: 1, access: 
  Clock phase
*/
volatile uint32_t CTRL1;

/** CTRL2 CTRL2 (offset: 0x4)
  control register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TXBEIEN
  offset: 7, size: 1, access: 
  Tx buffer empty interrupt enable
  Field: RXBNEIEN
  offset: 6, size: 1, access: 
  RX buffer not empty interrupt enable
  Field: ERRIEN
  offset: 5, size: 1, access: 
  Error interrupt enable
  Field: FRFCFG
  offset: 4, size: 1, access: 
  Frame Format Configure
  Field: SSOEN
  offset: 2, size: 1, access: 
  SS output enable
  Field: TXDEN
  offset: 1, size: 1, access: 
  Tx buffer DMA enable
  Field: RXDEN
  offset: 0, size: 1, access: 
  Rx buffer DMA enable
*/
volatile uint32_t CTRL2;

/** STS STS (offset: 0x8)
  status register
  reset value : 0x2
  reset mask : 0xFFFFFFFF
  Field: FFERR
  offset: 8, size: 1, access: read-only
  TI frame format error
  Field: BSYFLG
  offset: 7, size: 1, access: read-only
  Busy flag
  Field: OVRFLG
  offset: 6, size: 1, access: read-only
  Overrun flag
  Field: MEFLG
  offset: 5, size: 1, access: read-only
  Mode fault
  Field: CRCEFLG
  offset: 4, size: 1, access: read-write
  CRC error flag
  Field: UDRFLG
  offset: 3, size: 1, access: read-only
  Underrun flag
  Field: SCHDIR
  offset: 2, size: 1, access: read-only
  Channel side
  Field: TXBEFLG
  offset: 1, size: 1, access: read-only
  Transmit buffer empty
  Field: RXBNEFLG
  offset: 0, size: 1, access: read-only
  Receive buffer not empty
*/
volatile uint32_t STS;

/** DATA DATA (offset: 0xc)
  data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATA
  offset: 0, size: 16, access: 
  Data register
*/
volatile uint32_t DATA;

/** CRCPOLY CRCPOLY (offset: 0x10)
  CRC polynomial register
  access : read-write
  reset value : 0x7
  reset mask : 0xFFFFFFFF
  Field: CRCPOLY
  offset: 0, size: 16, access: 
  CRC polynomial register
*/
volatile uint32_t CRCPOLY;

/** RXCRC RXCRC (offset: 0x14)
  RX CRC register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RXCRC
  offset: 0, size: 16, access: 
  Rx CRC register
*/
volatile uint32_t RXCRC;

/** TXCRC TXCRC (offset: 0x18)
  TX CRC register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TXCRC
  offset: 0, size: 16, access: 
  Tx CRC register
*/
volatile uint32_t TXCRC;

/** I2SCFG I2SCFG (offset: 0x1c)
  I2S configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MODESEL
  offset: 11, size: 1, access: 
  I2S mode selection
  Field: I2SEN
  offset: 10, size: 1, access: 
  I2S Enable
  Field: I2SMOD
  offset: 8, size: 2, access: 
  I2S configuration mode
  Field: PFSSEL
  offset: 7, size: 1, access: 
  PCM frame synchronization
  Field: I2SSSEL
  offset: 4, size: 2, access: 
  I2S standard selection
  Field: CPOL
  offset: 3, size: 1, access: 
  Steady state clock polarity
  Field: DATALEN
  offset: 1, size: 2, access: 
  Data length to be transferred
  Field: CHLEN
  offset: 0, size: 1, access: 
  Channel length (number of bits per audio channel)
*/
volatile uint32_t I2SCFG;

/** I2SPSC I2SPSC (offset: 0x20)
  I2S prescaler register
  access : read-write
  reset value : 0xA
  reset mask : 0xFFFFFFFF
  Field: MCOEN
  offset: 9, size: 1, access: 
  Master clock output enable
  Field: ODDPSC
  offset: 8, size: 1, access: 
  Odd factor for the prescaler
  Field: I2SPSC
  offset: 0, size: 8, access: 
  I2S Linear prescaler
*/
volatile uint32_t I2SPSC;
} SPI1_type;

#define SPI1 ((SPI1_type *) 0x40013000)

#endif // HW_SPI1_H
