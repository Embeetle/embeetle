#ifndef HW_SMC_H
#define HW_SMC_H
/** Static memory controller */
/** Interrupt : SMC (Vector: 48) SMC global interrupt */
/** Memory Block starting at 0xA0000000 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define SMC_CSCTRL1_WRBURSTEN_OFFSET                       19
#define SMC_CSCTRL1_WRBURSTEN_MASK                         0x80000

#define SMC_CSCTRL1_CRAMPSIZECFG_OFFSET                    16
#define SMC_CSCTRL1_CRAMPSIZECFG_MASK                      0x70000

#define SMC_CSCTRL1_WSASYNCEN_OFFSET                       15
#define SMC_CSCTRL1_WSASYNCEN_MASK                         0x8000

#define SMC_CSCTRL1_EXTMODEEN_OFFSET                       14
#define SMC_CSCTRL1_EXTMODEEN_MASK                         0x4000

#define SMC_CSCTRL1_WAITEN_OFFSET                          13
#define SMC_CSCTRL1_WAITEN_MASK                            0x2000

#define SMC_CSCTRL1_WREN_OFFSET                            12
#define SMC_CSCTRL1_WREN_MASK                              0x1000

#define SMC_CSCTRL1_WTIMCFG_OFFSET                         11
#define SMC_CSCTRL1_WTIMCFG_MASK                           0x800

#define SMC_CSCTRL1_WRAPBEN_OFFSET                         10
#define SMC_CSCTRL1_WRAPBEN_MASK                           0x400

#define SMC_CSCTRL1_WSPOLCFG_OFFSET                        9
#define SMC_CSCTRL1_WSPOLCFG_MASK                          0x200

#define SMC_CSCTRL1_BURSTEN_OFFSET                         8
#define SMC_CSCTRL1_BURSTEN_MASK                           0x100

#define SMC_CSCTRL1_NORFMACCEN_OFFSET                      6
#define SMC_CSCTRL1_NORFMACCEN_MASK                        0x40

#define SMC_CSCTRL1_MDBWIDCFG_OFFSET                       4
#define SMC_CSCTRL1_MDBWIDCFG_MASK                         0x30

#define SMC_CSCTRL1_MTYPECFG_OFFSET                        2
#define SMC_CSCTRL1_MTYPECFG_MASK                          0xc

#define SMC_CSCTRL1_ADMUXEN_OFFSET                         1
#define SMC_CSCTRL1_ADMUXEN_MASK                           2

#define SMC_CSCTRL1_MBKEN_OFFSET                           0
#define SMC_CSCTRL1_MBKEN_MASK                             1

#define SMC_CSTIM1_ASYNCACCCFG_OFFSET                      28
#define SMC_CSTIM1_ASYNCACCCFG_MASK                        0x30000000

#define SMC_CSTIM1_DATALATCFG_OFFSET                       24
#define SMC_CSTIM1_DATALATCFG_MASK                         0xf000000

#define SMC_CSTIM1_CLKDIVCFG_OFFSET                        20
#define SMC_CSTIM1_CLKDIVCFG_MASK                          0xf00000

#define SMC_CSTIM1_BUSTURNCFG_OFFSET                       16
#define SMC_CSTIM1_BUSTURNCFG_MASK                         0xf0000

#define SMC_CSTIM1_DATASETCFG_OFFSET                       8
#define SMC_CSTIM1_DATASETCFG_MASK                         0xff00

#define SMC_CSTIM1_ADDRHLDCFG_OFFSET                       4
#define SMC_CSTIM1_ADDRHLDCFG_MASK                         0xf0

#define SMC_CSTIM1_ADDRSETCFG_OFFSET                       0
#define SMC_CSTIM1_ADDRSETCFG_MASK                         0xf

#define SMC_CSCTRL2_WRBURSTEN_OFFSET                       19
#define SMC_CSCTRL2_WRBURSTEN_MASK                         0x80000

#define SMC_CSCTRL2_CRAMPSIZECFG_OFFSET                    16
#define SMC_CSCTRL2_CRAMPSIZECFG_MASK                      0x70000

#define SMC_CSCTRL2_WSASYNCEN_OFFSET                       15
#define SMC_CSCTRL2_WSASYNCEN_MASK                         0x8000

#define SMC_CSCTRL2_EXTMODEEN_OFFSET                       14
#define SMC_CSCTRL2_EXTMODEEN_MASK                         0x4000

#define SMC_CSCTRL2_WAITEN_OFFSET                          13
#define SMC_CSCTRL2_WAITEN_MASK                            0x2000

#define SMC_CSCTRL2_WREN_OFFSET                            12
#define SMC_CSCTRL2_WREN_MASK                              0x1000

#define SMC_CSCTRL2_WTIMCFG_OFFSET                         11
#define SMC_CSCTRL2_WTIMCFG_MASK                           0x800

#define SMC_CSCTRL2_WRAPBEN_OFFSET                         10
#define SMC_CSCTRL2_WRAPBEN_MASK                           0x400

#define SMC_CSCTRL2_WSPOLCFG_OFFSET                        9
#define SMC_CSCTRL2_WSPOLCFG_MASK                          0x200

#define SMC_CSCTRL2_BURSTEN_OFFSET                         8
#define SMC_CSCTRL2_BURSTEN_MASK                           0x100

#define SMC_CSCTRL2_NORFMACCEN_OFFSET                      6
#define SMC_CSCTRL2_NORFMACCEN_MASK                        0x40

#define SMC_CSCTRL2_MDBWIDCFG_OFFSET                       4
#define SMC_CSCTRL2_MDBWIDCFG_MASK                         0x30

#define SMC_CSCTRL2_MTYPECFG_OFFSET                        2
#define SMC_CSCTRL2_MTYPECFG_MASK                          0xc

#define SMC_CSCTRL2_ADMUXEN_OFFSET                         1
#define SMC_CSCTRL2_ADMUXEN_MASK                           2

#define SMC_CSCTRL2_MBKEN_OFFSET                           0
#define SMC_CSCTRL2_MBKEN_MASK                             1

#define SMC_CSTIM2_ASYNCACCCFG_OFFSET                      28
#define SMC_CSTIM2_ASYNCACCCFG_MASK                        0x30000000

#define SMC_CSTIM2_DATALATCFG_OFFSET                       24
#define SMC_CSTIM2_DATALATCFG_MASK                         0xf000000

#define SMC_CSTIM2_CLKDIVCFG_OFFSET                        20
#define SMC_CSTIM2_CLKDIVCFG_MASK                          0xf00000

#define SMC_CSTIM2_BUSTURNCFG_OFFSET                       16
#define SMC_CSTIM2_BUSTURNCFG_MASK                         0xf0000

#define SMC_CSTIM2_DATASETCFG_OFFSET                       8
#define SMC_CSTIM2_DATASETCFG_MASK                         0xff00

#define SMC_CSTIM2_ADDRHLDCFG_OFFSET                       4
#define SMC_CSTIM2_ADDRHLDCFG_MASK                         0xf0

#define SMC_CSTIM2_ADDRSETCFG_OFFSET                       0
#define SMC_CSTIM2_ADDRSETCFG_MASK                         0xf

#define SMC_CSCTRL3_WRBURSTEN_OFFSET                       19
#define SMC_CSCTRL3_WRBURSTEN_MASK                         0x80000

#define SMC_CSCTRL3_CRAMPSIZECFG_OFFSET                    16
#define SMC_CSCTRL3_CRAMPSIZECFG_MASK                      0x70000

#define SMC_CSCTRL3_WSASYNCEN_OFFSET                       15
#define SMC_CSCTRL3_WSASYNCEN_MASK                         0x8000

#define SMC_CSCTRL3_EXTMODEEN_OFFSET                       14
#define SMC_CSCTRL3_EXTMODEEN_MASK                         0x4000

#define SMC_CSCTRL3_WAITEN_OFFSET                          13
#define SMC_CSCTRL3_WAITEN_MASK                            0x2000

#define SMC_CSCTRL3_WREN_OFFSET                            12
#define SMC_CSCTRL3_WREN_MASK                              0x1000

#define SMC_CSCTRL3_WTIMCFG_OFFSET                         11
#define SMC_CSCTRL3_WTIMCFG_MASK                           0x800

#define SMC_CSCTRL3_WRAPBEN_OFFSET                         10
#define SMC_CSCTRL3_WRAPBEN_MASK                           0x400

#define SMC_CSCTRL3_WSPOLCFG_OFFSET                        9
#define SMC_CSCTRL3_WSPOLCFG_MASK                          0x200

#define SMC_CSCTRL3_BURSTEN_OFFSET                         8
#define SMC_CSCTRL3_BURSTEN_MASK                           0x100

#define SMC_CSCTRL3_NORFMACCEN_OFFSET                      6
#define SMC_CSCTRL3_NORFMACCEN_MASK                        0x40

#define SMC_CSCTRL3_MDBWIDCFG_OFFSET                       4
#define SMC_CSCTRL3_MDBWIDCFG_MASK                         0x30

#define SMC_CSCTRL3_MTYPECFG_OFFSET                        2
#define SMC_CSCTRL3_MTYPECFG_MASK                          0xc

#define SMC_CSCTRL3_ADMUXEN_OFFSET                         1
#define SMC_CSCTRL3_ADMUXEN_MASK                           2

#define SMC_CSCTRL3_MBKEN_OFFSET                           0
#define SMC_CSCTRL3_MBKEN_MASK                             1

#define SMC_CSTIM3_ASYNCACCCFG_OFFSET                      28
#define SMC_CSTIM3_ASYNCACCCFG_MASK                        0x30000000

#define SMC_CSTIM3_DATALATCFG_OFFSET                       24
#define SMC_CSTIM3_DATALATCFG_MASK                         0xf000000

#define SMC_CSTIM3_CLKDIVCFG_OFFSET                        20
#define SMC_CSTIM3_CLKDIVCFG_MASK                          0xf00000

#define SMC_CSTIM3_BUSTURNCFG_OFFSET                       16
#define SMC_CSTIM3_BUSTURNCFG_MASK                         0xf0000

#define SMC_CSTIM3_DATASETCFG_OFFSET                       8
#define SMC_CSTIM3_DATASETCFG_MASK                         0xff00

#define SMC_CSTIM3_ADDRHLDCFG_OFFSET                       4
#define SMC_CSTIM3_ADDRHLDCFG_MASK                         0xf0

#define SMC_CSTIM3_ADDRSETCFG_OFFSET                       0
#define SMC_CSTIM3_ADDRSETCFG_MASK                         0xf

#define SMC_CSCTRL4_WRBURSTEN_OFFSET                       19
#define SMC_CSCTRL4_WRBURSTEN_MASK                         0x80000

#define SMC_CSCTRL4_CRAMPSIZECFG_OFFSET                    16
#define SMC_CSCTRL4_CRAMPSIZECFG_MASK                      0x70000

#define SMC_CSCTRL4_WSASYNCEN_OFFSET                       15
#define SMC_CSCTRL4_WSASYNCEN_MASK                         0x8000

#define SMC_CSCTRL4_EXTMODEEN_OFFSET                       14
#define SMC_CSCTRL4_EXTMODEEN_MASK                         0x4000

#define SMC_CSCTRL4_WAITEN_OFFSET                          13
#define SMC_CSCTRL4_WAITEN_MASK                            0x2000

#define SMC_CSCTRL4_WREN_OFFSET                            12
#define SMC_CSCTRL4_WREN_MASK                              0x1000

#define SMC_CSCTRL4_WTIMCFG_OFFSET                         11
#define SMC_CSCTRL4_WTIMCFG_MASK                           0x800

#define SMC_CSCTRL4_WRAPBEN_OFFSET                         10
#define SMC_CSCTRL4_WRAPBEN_MASK                           0x400

#define SMC_CSCTRL4_WSPOLCFG_OFFSET                        9
#define SMC_CSCTRL4_WSPOLCFG_MASK                          0x200

#define SMC_CSCTRL4_BURSTEN_OFFSET                         8
#define SMC_CSCTRL4_BURSTEN_MASK                           0x100

#define SMC_CSCTRL4_NORFMACCEN_OFFSET                      6
#define SMC_CSCTRL4_NORFMACCEN_MASK                        0x40

#define SMC_CSCTRL4_MDBWIDCFG_OFFSET                       4
#define SMC_CSCTRL4_MDBWIDCFG_MASK                         0x30

#define SMC_CSCTRL4_MTYPECFG_OFFSET                        2
#define SMC_CSCTRL4_MTYPECFG_MASK                          0xc

#define SMC_CSCTRL4_ADMUXEN_OFFSET                         1
#define SMC_CSCTRL4_ADMUXEN_MASK                           2

#define SMC_CSCTRL4_MBKEN_OFFSET                           0
#define SMC_CSCTRL4_MBKEN_MASK                             1

#define SMC_CSTIM4_ASYNCACCCFG_OFFSET                      28
#define SMC_CSTIM4_ASYNCACCCFG_MASK                        0x30000000

#define SMC_CSTIM4_DATALATCFG_OFFSET                       24
#define SMC_CSTIM4_DATALATCFG_MASK                         0xf000000

#define SMC_CSTIM4_CLKDIVCFG_OFFSET                        20
#define SMC_CSTIM4_CLKDIVCFG_MASK                          0xf00000

#define SMC_CSTIM4_BUSTURNCFG_OFFSET                       16
#define SMC_CSTIM4_BUSTURNCFG_MASK                         0xf0000

#define SMC_CSTIM4_DATASETCFG_OFFSET                       8
#define SMC_CSTIM4_DATASETCFG_MASK                         0xff00

#define SMC_CSTIM4_ADDRHLDCFG_OFFSET                       4
#define SMC_CSTIM4_ADDRHLDCFG_MASK                         0xf0

#define SMC_CSTIM4_ADDRSETCFG_OFFSET                       0
#define SMC_CSTIM4_ADDRSETCFG_MASK                         0xf

#define SMC_CTRL2_ECCPSCFG_OFFSET                          17
#define SMC_CTRL2_ECCPSCFG_MASK                            0xe0000

#define SMC_CTRL2_A2RDCFG_OFFSET                           13
#define SMC_CTRL2_A2RDCFG_MASK                             0x1e000

#define SMC_CTRL2_C2RDCFG_OFFSET                           9
#define SMC_CTRL2_C2RDCFG_MASK                             0x1e00

#define SMC_CTRL2_ECCEN_OFFSET                             6
#define SMC_CTRL2_ECCEN_MASK                               0x40

#define SMC_CTRL2_DBWIDCFG_OFFSET                          4
#define SMC_CTRL2_DBWIDCFG_MASK                            0x30

#define SMC_CTRL2_MTYPECFG_OFFSET                          3
#define SMC_CTRL2_MTYPECFG_MASK                            8

#define SMC_CTRL2_MBKEN_OFFSET                             2
#define SMC_CTRL2_MBKEN_MASK                               4

#define SMC_CTRL2_WAITFEN_OFFSET                           1
#define SMC_CTRL2_WAITFEN_MASK                             2

#define SMC_STSINT2_FEFLG_OFFSET                           6
#define SMC_STSINT2_FEFLG_MASK                             0x40

#define SMC_STSINT2_IFEDEN_OFFSET                          5
#define SMC_STSINT2_IFEDEN_MASK                            0x20

#define SMC_STSINT2_IHLDEN_OFFSET                          4
#define SMC_STSINT2_IHLDEN_MASK                            0x10

#define SMC_STSINT2_IREDEN_OFFSET                          3
#define SMC_STSINT2_IREDEN_MASK                            8

#define SMC_STSINT2_IFEFLG_OFFSET                          2
#define SMC_STSINT2_IFEFLG_MASK                            4

#define SMC_STSINT2_IHLFLG_OFFSET                          1
#define SMC_STSINT2_IHLFLG_MASK                            2

#define SMC_STSINT2_IREFLG_OFFSET                          0
#define SMC_STSINT2_IREFLG_MASK                            1

#define SMC_CMSTIM2_HIZX_OFFSET                            24
#define SMC_CMSTIM2_HIZX_MASK                              0xff000000

#define SMC_CMSTIM2_HLDX_OFFSET                            16
#define SMC_CMSTIM2_HLDX_MASK                              0xff0000

#define SMC_CMSTIM2_WAITX_OFFSET                           8
#define SMC_CMSTIM2_WAITX_MASK                             0xff00

#define SMC_CMSTIM2_SETX_OFFSET                            0
#define SMC_CMSTIM2_SETX_MASK                              0xff

#define SMC_AMSTIM2_HIZX_OFFSET                            24
#define SMC_AMSTIM2_HIZX_MASK                              0xff000000

#define SMC_AMSTIM2_HLDX_OFFSET                            16
#define SMC_AMSTIM2_HLDX_MASK                              0xff0000

#define SMC_AMSTIM2_WAITX_OFFSET                           8
#define SMC_AMSTIM2_WAITX_MASK                             0xff00

#define SMC_AMSTIM2_SETX_OFFSET                            0
#define SMC_AMSTIM2_SETX_MASK                              0xff

#define SMC_ECCRS2_ECCRS_OFFSET                            0
#define SMC_ECCRS2_ECCRS_MASK                              0xffffffff

#define SMC_CTRL3_ECCPSCFG_OFFSET                          17
#define SMC_CTRL3_ECCPSCFG_MASK                            0xe0000

#define SMC_CTRL3_A2RDCFG_OFFSET                           13
#define SMC_CTRL3_A2RDCFG_MASK                             0x1e000

#define SMC_CTRL3_C2RDCFG_OFFSET                           9
#define SMC_CTRL3_C2RDCFG_MASK                             0x1e00

#define SMC_CTRL3_ECCEN_OFFSET                             6
#define SMC_CTRL3_ECCEN_MASK                               0x40

#define SMC_CTRL3_DBWIDCFG_OFFSET                          4
#define SMC_CTRL3_DBWIDCFG_MASK                            0x30

#define SMC_CTRL3_MTYPECFG_OFFSET                          3
#define SMC_CTRL3_MTYPECFG_MASK                            8

#define SMC_CTRL3_MBKEN_OFFSET                             2
#define SMC_CTRL3_MBKEN_MASK                               4

#define SMC_CTRL3_WAITFEN_OFFSET                           1
#define SMC_CTRL3_WAITFEN_MASK                             2

#define SMC_STSINT3_FEFLG_OFFSET                           6
#define SMC_STSINT3_FEFLG_MASK                             0x40

#define SMC_STSINT3_IFEDEN_OFFSET                          5
#define SMC_STSINT3_IFEDEN_MASK                            0x20

#define SMC_STSINT3_IHLDEN_OFFSET                          4
#define SMC_STSINT3_IHLDEN_MASK                            0x10

#define SMC_STSINT3_IREDEN_OFFSET                          3
#define SMC_STSINT3_IREDEN_MASK                            8

#define SMC_STSINT3_IFEFLG_OFFSET                          2
#define SMC_STSINT3_IFEFLG_MASK                            4

#define SMC_STSINT3_IHLFLG_OFFSET                          1
#define SMC_STSINT3_IHLFLG_MASK                            2

#define SMC_STSINT3_IREFLG_OFFSET                          0
#define SMC_STSINT3_IREFLG_MASK                            1

#define SMC_CMSTIM3_HIZX_OFFSET                            24
#define SMC_CMSTIM3_HIZX_MASK                              0xff000000

#define SMC_CMSTIM3_HLDX_OFFSET                            16
#define SMC_CMSTIM3_HLDX_MASK                              0xff0000

#define SMC_CMSTIM3_WAITX_OFFSET                           8
#define SMC_CMSTIM3_WAITX_MASK                             0xff00

#define SMC_CMSTIM3_SETX_OFFSET                            0
#define SMC_CMSTIM3_SETX_MASK                              0xff

#define SMC_AMSTIM3_HIZX_OFFSET                            24
#define SMC_AMSTIM3_HIZX_MASK                              0xff000000

#define SMC_AMSTIM3_HLDX_OFFSET                            16
#define SMC_AMSTIM3_HLDX_MASK                              0xff0000

#define SMC_AMSTIM3_WAITX_OFFSET                           8
#define SMC_AMSTIM3_WAITX_MASK                             0xff00

#define SMC_AMSTIM3_SETX_OFFSET                            0
#define SMC_AMSTIM3_SETX_MASK                              0xff

#define SMC_ECCRS3_ECCRS_OFFSET                            0
#define SMC_ECCRS3_ECCRS_MASK                              0xffffffff

#define SMC_CTRL4_ECCPSCFG_OFFSET                          17
#define SMC_CTRL4_ECCPSCFG_MASK                            0xe0000

#define SMC_CTRL4_A2RDCFG_OFFSET                           13
#define SMC_CTRL4_A2RDCFG_MASK                             0x1e000

#define SMC_CTRL4_C2RDCFG_OFFSET                           9
#define SMC_CTRL4_C2RDCFG_MASK                             0x1e00

#define SMC_CTRL4_ECCEN_OFFSET                             6
#define SMC_CTRL4_ECCEN_MASK                               0x40

#define SMC_CTRL4_DBWIDCFG_OFFSET                          4
#define SMC_CTRL4_DBWIDCFG_MASK                            0x30

#define SMC_CTRL4_MTYPECFG_OFFSET                          3
#define SMC_CTRL4_MTYPECFG_MASK                            8

#define SMC_CTRL4_MBKEN_OFFSET                             2
#define SMC_CTRL4_MBKEN_MASK                               4

#define SMC_CTRL4_WAITFEN_OFFSET                           1
#define SMC_CTRL4_WAITFEN_MASK                             2

#define SMC_STSINT4_FEFLG_OFFSET                           6
#define SMC_STSINT4_FEFLG_MASK                             0x40

#define SMC_STSINT4_IFEDEN_OFFSET                          5
#define SMC_STSINT4_IFEDEN_MASK                            0x20

#define SMC_STSINT4_IHLDEN_OFFSET                          4
#define SMC_STSINT4_IHLDEN_MASK                            0x10

#define SMC_STSINT4_IREDEN_OFFSET                          3
#define SMC_STSINT4_IREDEN_MASK                            8

#define SMC_STSINT4_IFEFLG_OFFSET                          2
#define SMC_STSINT4_IFEFLG_MASK                            4

#define SMC_STSINT4_IHLFLG_OFFSET                          1
#define SMC_STSINT4_IHLFLG_MASK                            2

#define SMC_STSINT4_IREFLG_OFFSET                          0
#define SMC_STSINT4_IREFLG_MASK                            1

#define SMC_CMSTIM4_HIZX_OFFSET                            24
#define SMC_CMSTIM4_HIZX_MASK                              0xff000000

#define SMC_CMSTIM4_HLDX_OFFSET                            16
#define SMC_CMSTIM4_HLDX_MASK                              0xff0000

#define SMC_CMSTIM4_WAITX_OFFSET                           8
#define SMC_CMSTIM4_WAITX_MASK                             0xff00

#define SMC_CMSTIM4_SETX_OFFSET                            0
#define SMC_CMSTIM4_SETX_MASK                              0xff

#define SMC_AMSTIM4_HIZX_OFFSET                            24
#define SMC_AMSTIM4_HIZX_MASK                              0xff000000

#define SMC_AMSTIM4_HLDX_OFFSET                            16
#define SMC_AMSTIM4_HLDX_MASK                              0xff0000

#define SMC_AMSTIM4_WAITX_OFFSET                           8
#define SMC_AMSTIM4_WAITX_MASK                             0xff00

#define SMC_AMSTIM4_SETX_OFFSET                            0
#define SMC_AMSTIM4_SETX_MASK                              0xff

#define SMC_IOSTIM4_HIZ_OFFSET                             24
#define SMC_IOSTIM4_HIZ_MASK                               0xff000000

#define SMC_IOSTIM4_HLD_OFFSET                             16
#define SMC_IOSTIM4_HLD_MASK                               0xff0000

#define SMC_IOSTIM4_WAIT_OFFSET                            8
#define SMC_IOSTIM4_WAIT_MASK                              0xff00

#define SMC_IOSTIM4_SET_OFFSET                             0
#define SMC_IOSTIM4_SET_MASK                               0xff

#define SMC_WRTTIM1_ASYNCACCCFG_OFFSET                     28
#define SMC_WRTTIM1_ASYNCACCCFG_MASK                       0x30000000

#define SMC_WRTTIM1_BUSTURNCFG_OFFSET                      16
#define SMC_WRTTIM1_BUSTURNCFG_MASK                        0xf0000

#define SMC_WRTTIM1_DATASETCFG_OFFSET                      8
#define SMC_WRTTIM1_DATASETCFG_MASK                        0xff00

#define SMC_WRTTIM1_ADDRHLDCFG_OFFSET                      4
#define SMC_WRTTIM1_ADDRHLDCFG_MASK                        0xf0

#define SMC_WRTTIM1_ADDRSETCFG_OFFSET                      0
#define SMC_WRTTIM1_ADDRSETCFG_MASK                        0xf

#define SMC_WRTTIM2_ASYNCACCCFG_OFFSET                     28
#define SMC_WRTTIM2_ASYNCACCCFG_MASK                       0x30000000

#define SMC_WRTTIM2_BUSTURNCFG_OFFSET                      16
#define SMC_WRTTIM2_BUSTURNCFG_MASK                        0xf0000

#define SMC_WRTTIM2_DATASETCFG_OFFSET                      8
#define SMC_WRTTIM2_DATASETCFG_MASK                        0xff00

#define SMC_WRTTIM2_ADDRHLDCFG_OFFSET                      4
#define SMC_WRTTIM2_ADDRHLDCFG_MASK                        0xf0

#define SMC_WRTTIM2_ADDRSETCFG_OFFSET                      0
#define SMC_WRTTIM2_ADDRSETCFG_MASK                        0xf

#define SMC_WRTTIM3_ASYNCACCCFG_OFFSET                     28
#define SMC_WRTTIM3_ASYNCACCCFG_MASK                       0x30000000

#define SMC_WRTTIM3_BUSTURNCFG_OFFSET                      16
#define SMC_WRTTIM3_BUSTURNCFG_MASK                        0xf0000

#define SMC_WRTTIM3_DATASETCFG_OFFSET                      8
#define SMC_WRTTIM3_DATASETCFG_MASK                        0xff00

#define SMC_WRTTIM3_ADDRHLDCFG_OFFSET                      4
#define SMC_WRTTIM3_ADDRHLDCFG_MASK                        0xf0

#define SMC_WRTTIM3_ADDRSETCFG_OFFSET                      0
#define SMC_WRTTIM3_ADDRSETCFG_MASK                        0xf

#define SMC_WRTTIM4_ASYNCACCCFG_OFFSET                     28
#define SMC_WRTTIM4_ASYNCACCCFG_MASK                       0x30000000

#define SMC_WRTTIM4_BUSTURNCFG_OFFSET                      16
#define SMC_WRTTIM4_BUSTURNCFG_MASK                        0xf0000

#define SMC_WRTTIM4_DATASETCFG_OFFSET                      8
#define SMC_WRTTIM4_DATASETCFG_MASK                        0xff00

#define SMC_WRTTIM4_ADDRHLDCFG_OFFSET                      4
#define SMC_WRTTIM4_ADDRHLDCFG_MASK                        0xf0

#define SMC_WRTTIM4_ADDRSETCFG_OFFSET                      0
#define SMC_WRTTIM4_ADDRSETCFG_MASK                        0xf


typedef struct
{

/** CSCTRL1 CSCTRL1 (offset: 0x0)
  SRAM/NOR-Flash chip-select control register 1
  access : read-write
  reset value : 0x30D0
  reset mask : 0xFFFFFFFF
  Field: WRBURSTEN
  offset: 19, size: 1, access: 
  Write PSRAM Burst Enable
  Field: CRAMPSIZECFG
  offset: 16, size: 3, access: 
  CRAM Page Size Configure
  Field: WSASYNCEN
  offset: 15, size: 1, access: 
  Wait Signal During Asynchronous Transfers Enable
  Field: EXTMODEEN
  offset: 14, size: 1, access: 
  Extended Mode Enable
  Field: WAITEN
  offset: 13, size: 1, access: 
  Wait Enable
  Field: WREN
  offset: 12, size: 1, access: 
  Write Memory Enable
  Field: WTIMCFG
  offset: 11, size: 1, access: 
  Wait Timing Configure
  Field: WRAPBEN
  offset: 10, size: 1, access: 
  Wrapped Burst Mode Enable
  Field: WSPOLCFG
  offset: 9, size: 1, access: 
  Wait Signal Polarity Configure
  Field: BURSTEN
  offset: 8, size: 1, access: 
  Burst Mode Enable
  Field: NORFMACCEN
  offset: 6, size: 1, access: 
  NORFlash Memory Access Enable
  Field: MDBWIDCFG
  offset: 4, size: 2, access: 
  Memory Data Bus Width Configure
  Field: MTYPECFG
  offset: 2, size: 2, access: 
  Memory Type Configure
  Field: ADMUXEN
  offset: 1, size: 1, access: 
  Address/Data Multiplexing Enable
  Field: MBKEN
  offset: 0, size: 1, access: 
  Enable the Corresponding Memory Bank
*/
volatile uint32_t CSCTRL1;

/** CSTIM1 CSTIM1 (offset: 0x4)
  SRAM/NOR-Flash chip-select timing register 1
  access : read-write
  reset value : 0xFFFFFFFF
  reset mask : 0xFFFFFFFF
  Field: ASYNCACCCFG
  offset: 28, size: 2, access: 
  Asynchronous Access Mode Configure
  Field: DATALATCFG
  offset: 24, size: 4, access: 
  Data Latency Configure
  Field: CLKDIVCFG
  offset: 20, size: 4, access: 
  Clock Divide Factor Configure
  Field: BUSTURNCFG
  offset: 16, size: 4, access: 
  Bus Turnaround Phase Duration Configure
  Field: DATASETCFG
  offset: 8, size: 8, access: 
  Data Setup Time Configure
  Field: ADDRHLDCFG
  offset: 4, size: 4, access: 
  Address-Hold Time Configure
  Field: ADDRSETCFG
  offset: 0, size: 4, access: 
  Address Setup Time Configure
*/
volatile uint32_t CSTIM1;

/** CSCTRL2 CSCTRL2 (offset: 0x8)
  SRAM/NOR-Flash chip-select control register 2
  access : read-write
  reset value : 0x30D0
  reset mask : 0xFFFFFFFF
  Field: WRBURSTEN
  offset: 19, size: 1, access: 
  Write PSRAM Burst Enable
  Field: CRAMPSIZECFG
  offset: 16, size: 3, access: 
  CRAM Page Size Configure
  Field: WSASYNCEN
  offset: 15, size: 1, access: 
  Wait Signal During Asynchronous Transfers Enable
  Field: EXTMODEEN
  offset: 14, size: 1, access: 
  Extended Mode Enable
  Field: WAITEN
  offset: 13, size: 1, access: 
  Wait Enable
  Field: WREN
  offset: 12, size: 1, access: 
  Write Memory Enable
  Field: WTIMCFG
  offset: 11, size: 1, access: 
  Wait Timing Configure
  Field: WRAPBEN
  offset: 10, size: 1, access: 
  Wrapped Burst Mode Enable
  Field: WSPOLCFG
  offset: 9, size: 1, access: 
  Wait Signal Polarity Configure
  Field: BURSTEN
  offset: 8, size: 1, access: 
  Burst Mode Enable
  Field: NORFMACCEN
  offset: 6, size: 1, access: 
  NORFlash Memory Access Enable
  Field: MDBWIDCFG
  offset: 4, size: 2, access: 
  Memory Data Bus Width Configure
  Field: MTYPECFG
  offset: 2, size: 2, access: 
  Memory Type Configure
  Field: ADMUXEN
  offset: 1, size: 1, access: 
  Address/Data Multiplexing Enable
  Field: MBKEN
  offset: 0, size: 1, access: 
  Enable the Corresponding Memory Bank
*/
volatile uint32_t CSCTRL2;

/** CSTIM2 CSTIM2 (offset: 0xc)
  SRAM/NOR-Flash chip-select timing register 2
  access : read-write
  reset value : 0xFFFFFFFF
  reset mask : 0xFFFFFFFF
  Field: ASYNCACCCFG
  offset: 28, size: 2, access: 
  Asynchronous Access Mode Configure
  Field: DATALATCFG
  offset: 24, size: 4, access: 
  Data Latency Configure
  Field: CLKDIVCFG
  offset: 20, size: 4, access: 
  Clock Divide Factor Configure
  Field: BUSTURNCFG
  offset: 16, size: 4, access: 
  Bus Turnaround Phase Duration Configure
  Field: DATASETCFG
  offset: 8, size: 8, access: 
  Data Setup Time Configure
  Field: ADDRHLDCFG
  offset: 4, size: 4, access: 
  Address-Hold Time Configure
  Field: ADDRSETCFG
  offset: 0, size: 4, access: 
  Address Setup Time Configure
*/
volatile uint32_t CSTIM2;

/** CSCTRL3 CSCTRL3 (offset: 0x10)
  SRAM/NOR-Flash chip-select control register 3
  access : read-write
  reset value : 0x30D0
  reset mask : 0xFFFFFFFF
  Field: WRBURSTEN
  offset: 19, size: 1, access: 
  Write PSRAM Burst Enable
  Field: CRAMPSIZECFG
  offset: 16, size: 3, access: 
  CRAM Page Size Configure
  Field: WSASYNCEN
  offset: 15, size: 1, access: 
  Wait Signal During Asynchronous Transfers Enable
  Field: EXTMODEEN
  offset: 14, size: 1, access: 
  Extended Mode Enable
  Field: WAITEN
  offset: 13, size: 1, access: 
  Wait Enable
  Field: WREN
  offset: 12, size: 1, access: 
  Write Memory Enable
  Field: WTIMCFG
  offset: 11, size: 1, access: 
  Wait Timing Configure
  Field: WRAPBEN
  offset: 10, size: 1, access: 
  Wrapped Burst Mode Enable
  Field: WSPOLCFG
  offset: 9, size: 1, access: 
  Wait Signal Polarity Configure
  Field: BURSTEN
  offset: 8, size: 1, access: 
  Burst Mode Enable
  Field: NORFMACCEN
  offset: 6, size: 1, access: 
  NORFlash Memory Access Enable
  Field: MDBWIDCFG
  offset: 4, size: 2, access: 
  Memory Data Bus Width Configure
  Field: MTYPECFG
  offset: 2, size: 2, access: 
  Memory Type Configure
  Field: ADMUXEN
  offset: 1, size: 1, access: 
  Address/Data Multiplexing Enable
  Field: MBKEN
  offset: 0, size: 1, access: 
  Enable the Corresponding Memory Bank
*/
volatile uint32_t CSCTRL3;

/** CSTIM3 CSTIM3 (offset: 0x14)
  SRAM/NOR-Flash chip-select timing register 3
  access : read-write
  reset value : 0xFFFFFFFF
  reset mask : 0xFFFFFFFF
  Field: ASYNCACCCFG
  offset: 28, size: 2, access: 
  Asynchronous Access Mode Configure
  Field: DATALATCFG
  offset: 24, size: 4, access: 
  Data Latency Configure
  Field: CLKDIVCFG
  offset: 20, size: 4, access: 
  Clock Divide Factor Configure
  Field: BUSTURNCFG
  offset: 16, size: 4, access: 
  Bus Turnaround Phase Duration Configure
  Field: DATASETCFG
  offset: 8, size: 8, access: 
  Data Setup Time Configure
  Field: ADDRHLDCFG
  offset: 4, size: 4, access: 
  Address-Hold Time Configure
  Field: ADDRSETCFG
  offset: 0, size: 4, access: 
  Address Setup Time Configure
*/
volatile uint32_t CSTIM3;

/** CSCTRL4 CSCTRL4 (offset: 0x18)
  SRAM/NOR-Flash chip-select control register 4
  access : read-write
  reset value : 0x30D0
  reset mask : 0xFFFFFFFF
  Field: WRBURSTEN
  offset: 19, size: 1, access: 
  Write PSRAM Burst Enable
  Field: CRAMPSIZECFG
  offset: 16, size: 3, access: 
  CRAM Page Size Configure
  Field: WSASYNCEN
  offset: 15, size: 1, access: 
  Wait Signal During Asynchronous Transfers Enable
  Field: EXTMODEEN
  offset: 14, size: 1, access: 
  Extended Mode Enable
  Field: WAITEN
  offset: 13, size: 1, access: 
  Wait Enable
  Field: WREN
  offset: 12, size: 1, access: 
  Write Memory Enable
  Field: WTIMCFG
  offset: 11, size: 1, access: 
  Wait Timing Configure
  Field: WRAPBEN
  offset: 10, size: 1, access: 
  Wrapped Burst Mode Enable
  Field: WSPOLCFG
  offset: 9, size: 1, access: 
  Wait Signal Polarity Configure
  Field: BURSTEN
  offset: 8, size: 1, access: 
  Burst Mode Enable
  Field: NORFMACCEN
  offset: 6, size: 1, access: 
  NORFlash Memory Access Enable
  Field: MDBWIDCFG
  offset: 4, size: 2, access: 
  Memory Data Bus Width Configure
  Field: MTYPECFG
  offset: 2, size: 2, access: 
  Memory Type Configure
  Field: ADMUXEN
  offset: 1, size: 1, access: 
  Address/Data Multiplexing Enable
  Field: MBKEN
  offset: 0, size: 1, access: 
  Enable the Corresponding Memory Bank
*/
volatile uint32_t CSCTRL4;

/** CSTIM4 CSTIM4 (offset: 0x1c)
  SRAM/NOR-Flash chip-select timing register 4
  access : read-write
  reset value : 0xFFFFFFFF
  reset mask : 0xFFFFFFFF
  Field: ASYNCACCCFG
  offset: 28, size: 2, access: 
  Asynchronous Access Mode Configure
  Field: DATALATCFG
  offset: 24, size: 4, access: 
  Data Latency Configure
  Field: CLKDIVCFG
  offset: 20, size: 4, access: 
  Clock Divide Factor Configure
  Field: BUSTURNCFG
  offset: 16, size: 4, access: 
  Bus Turnaround Phase Duration Configure
  Field: DATASETCFG
  offset: 8, size: 8, access: 
  Data Setup Time Configure
  Field: ADDRHLDCFG
  offset: 4, size: 4, access: 
  Address-Hold Time Configure
  Field: ADDRSETCFG
  offset: 0, size: 4, access: 
  Address Setup Time Configure
*/
volatile uint32_t CSTIM4;
volatile uint32_t reserved0[16];

/** CTRL2 CTRL2 (offset: 0x60)
  PC Card/NAND Flash control register 2
  access : read-write
  reset value : 0x18
  reset mask : 0xFFFFFFFF
  Field: ECCPSCFG
  offset: 17, size: 3, access: 
  ECC Page Size Configure
  Field: A2RDCFG
  offset: 13, size: 4, access: 
  ALE To RE Delay Configure
  Field: C2RDCFG
  offset: 9, size: 4, access: 
  CLE To RE Delay Configure
  Field: ECCEN
  offset: 6, size: 1, access: 
  ECC Computation Logic Enable
  Field: DBWIDCFG
  offset: 4, size: 2, access: 
  Databus Width Configure
  Field: MTYPECFG
  offset: 3, size: 1, access: 
  Memory Type Configure
  Field: MBKEN
  offset: 2, size: 1, access: 
  PC Card/NAND Flash Memory Bank Enable
  Field: WAITFEN
  offset: 1, size: 1, access: 
  PC Card/NANDFlash Wait Feature Enable
*/
volatile uint32_t CTRL2;

/** STSINT2 STSINT2 (offset: 0x64)
  FIFO status and interrupt register 2
  reset value : 0x40
  reset mask : 0xFFFFFFFF
  Field: FEFLG
  offset: 6, size: 1, access: read-only
  FIFO Empty Flag
  Field: IFEDEN
  offset: 5, size: 1, access: read-write
  Interrupt Falling Edge Detection Enable
  Field: IHLDEN
  offset: 4, size: 1, access: read-write
  Interrupt High-Level Detection Enable
  Field: IREDEN
  offset: 3, size: 1, access: read-write
  Interrupt Rising Edge Detection Enable
  Field: IFEFLG
  offset: 2, size: 1, access: read-write
  Interrupt Falling Edge Generate Flag
  Field: IHLFLG
  offset: 1, size: 1, access: read-write
  Interrupt High-Level Generate Flag
  Field: IREFLG
  offset: 0, size: 1, access: read-write
  Interrupt Rising Edge Generate Flag
*/
volatile uint32_t STSINT2;

/** CMSTIM2 CMSTIM2 (offset: 0x68)
  Common memory space timing register 2
  access : read-write
  reset value : 0xFCFCFCFC
  reset mask : 0xFFFFFFFF
  Field: HIZx
  offset: 24, size: 8, access: 
  Common Memory x Databus Hiz Time Configure
  Field: HLDx
  offset: 16, size: 8, access: 
  Common Memory x Hold Time Configure
  Field: WAITx
  offset: 8, size: 8, access: 
  Common Memory x Wait Time Configure
  Field: SETx
  offset: 0, size: 8, access: 
  Common Memory x Setup Time Configure
*/
volatile uint32_t CMSTIM2;

/** AMSTIM2 AMSTIM2 (offset: 0x6c)
  Attribute memory space timing register 2
  access : read-write
  reset value : 0xFCFCFCFC
  reset mask : 0xFFFFFFFF
  Field: HIZx
  offset: 24, size: 8, access: 
  Attribute Memory x Databus Hiz Time Configure
  Field: HLDx
  offset: 16, size: 8, access: 
  Attribute Memory x Hold Time Configure
  Field: WAITx
  offset: 8, size: 8, access: 
  Attribute Memory x Wait Time Configure
  Field: SETx
  offset: 0, size: 8, access: 
  Attribute Memory x Setup Time Configure
*/
volatile uint32_t AMSTIM2;
volatile uint32_t reserved1;

/** ECCRS2 ECCRS2 (offset: 0x74)
  ECC result register 2
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ECCRS
  offset: 0, size: 32, access: 
  ECC result
*/
volatile uint32_t ECCRS2;
volatile uint32_t reserved2[2];

/** CTRL3 CTRL3 (offset: 0x80)
  PC Card/NAND Flash control register 3
  access : read-write
  reset value : 0x18
  reset mask : 0xFFFFFFFF
  Field: ECCPSCFG
  offset: 17, size: 3, access: 
  ECC Page Size Configure
  Field: A2RDCFG
  offset: 13, size: 4, access: 
  ALE To RE Delay Configure
  Field: C2RDCFG
  offset: 9, size: 4, access: 
  CLE To RE Delay Configure
  Field: ECCEN
  offset: 6, size: 1, access: 
  ECC Computation Logic Enable
  Field: DBWIDCFG
  offset: 4, size: 2, access: 
  Databus Width Configure
  Field: MTYPECFG
  offset: 3, size: 1, access: 
  Memory Type Configure
  Field: MBKEN
  offset: 2, size: 1, access: 
  PC Card/NAND Flash Memory Bank Enable
  Field: WAITFEN
  offset: 1, size: 1, access: 
  PC Card/NANDFlash Wait Feature Enable
*/
volatile uint32_t CTRL3;

/** STSINT3 STSINT3 (offset: 0x84)
  FIFO status and interrupt register 3
  reset value : 0x40
  reset mask : 0xFFFFFFFF
  Field: FEFLG
  offset: 6, size: 1, access: read-only
  FIFO Empty Flag
  Field: IFEDEN
  offset: 5, size: 1, access: read-write
  Interrupt Falling Edge Detection Enable
  Field: IHLDEN
  offset: 4, size: 1, access: read-write
  Interrupt High-Level Detection Enable
  Field: IREDEN
  offset: 3, size: 1, access: read-write
  Interrupt Rising Edge Detection Enable
  Field: IFEFLG
  offset: 2, size: 1, access: read-write
  Interrupt Falling Edge Generate Flag
  Field: IHLFLG
  offset: 1, size: 1, access: read-write
  Interrupt High-Level Generate Flag
  Field: IREFLG
  offset: 0, size: 1, access: read-write
  Interrupt Rising Edge Generate Flag
*/
volatile uint32_t STSINT3;

/** CMSTIM3 CMSTIM3 (offset: 0x88)
  Common memory space timing register 3
  access : read-write
  reset value : 0xFCFCFCFC
  reset mask : 0xFFFFFFFF
  Field: HIZx
  offset: 24, size: 8, access: 
  Common Memory x Databus Hiz Time Configure
  Field: HLDx
  offset: 16, size: 8, access: 
  Common Memory x Hold Time Configure
  Field: WAITx
  offset: 8, size: 8, access: 
  Common Memory x Wait Time Configure
  Field: SETx
  offset: 0, size: 8, access: 
  Common Memory x Setup Time Configure
*/
volatile uint32_t CMSTIM3;

/** AMSTIM3 AMSTIM3 (offset: 0x8c)
  Attribute memory space timing register 3
  access : read-write
  reset value : 0xFCFCFCFC
  reset mask : 0xFFFFFFFF
  Field: HIZx
  offset: 24, size: 8, access: 
  Attribute Memory x Databus Hiz Time Configure
  Field: HLDx
  offset: 16, size: 8, access: 
  Attribute Memory x Hold Time Configure
  Field: WAITx
  offset: 8, size: 8, access: 
  Attribute Memory x Wait Time Configure
  Field: SETx
  offset: 0, size: 8, access: 
  Attribute Memory x Setup Time Configure
*/
volatile uint32_t AMSTIM3;
volatile uint32_t reserved3;

/** ECCRS3 ECCRS3 (offset: 0x94)
  ECC result register 3
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ECCRS
  offset: 0, size: 32, access: 
  ECC result
*/
volatile uint32_t ECCRS3;
volatile uint32_t reserved4[2];

/** CTRL4 CTRL4 (offset: 0xa0)
  PC Card/NAND Flash control register 4
  access : read-write
  reset value : 0x18
  reset mask : 0xFFFFFFFF
  Field: ECCPSCFG
  offset: 17, size: 3, access: 
  ECC Page Size Configure
  Field: A2RDCFG
  offset: 13, size: 4, access: 
  ALE To RE Delay Configure
  Field: C2RDCFG
  offset: 9, size: 4, access: 
  CLE To RE Delay Configure
  Field: ECCEN
  offset: 6, size: 1, access: 
  ECC Computation Logic Enable
  Field: DBWIDCFG
  offset: 4, size: 2, access: 
  Databus Width Configure
  Field: MTYPECFG
  offset: 3, size: 1, access: 
  Memory Type Configure
  Field: MBKEN
  offset: 2, size: 1, access: 
  PC Card/NAND Flash Memory Bank Enable
  Field: WAITFEN
  offset: 1, size: 1, access: 
  PC Card/NANDFlash Wait Feature Enable
*/
volatile uint32_t CTRL4;

/** STSINT4 STSINT4 (offset: 0xa4)
  FIFO status and interrupt register 4
  reset value : 0x40
  reset mask : 0xFFFFFFFF
  Field: FEFLG
  offset: 6, size: 1, access: read-only
  FIFO Empty Flag
  Field: IFEDEN
  offset: 5, size: 1, access: read-write
  Interrupt Falling Edge Detection Enable
  Field: IHLDEN
  offset: 4, size: 1, access: read-write
  Interrupt High-Level Detection Enable
  Field: IREDEN
  offset: 3, size: 1, access: read-write
  Interrupt Rising Edge Detection Enable
  Field: IFEFLG
  offset: 2, size: 1, access: read-write
  Interrupt Falling Edge Generate Flag
  Field: IHLFLG
  offset: 1, size: 1, access: read-write
  Interrupt High-Level Generate Flag
  Field: IREFLG
  offset: 0, size: 1, access: read-write
  Interrupt Rising Edge Generate Flag
*/
volatile uint32_t STSINT4;

/** CMSTIM4 CMSTIM4 (offset: 0xa8)
  Common memory space timing register 4
  access : read-write
  reset value : 0xFCFCFCFC
  reset mask : 0xFFFFFFFF
  Field: HIZx
  offset: 24, size: 8, access: 
  Common Memory x Databus Hiz Time Configure
  Field: HLDx
  offset: 16, size: 8, access: 
  Common Memory x Hold Time Configure
  Field: WAITx
  offset: 8, size: 8, access: 
  Common Memory x Wait Time Configure
  Field: SETx
  offset: 0, size: 8, access: 
  Common Memory x Setup Time Configure
*/
volatile uint32_t CMSTIM4;

/** AMSTIM4 AMSTIM4 (offset: 0xac)
  Attribute memory space timing register 4
  access : read-write
  reset value : 0xFCFCFCFC
  reset mask : 0xFFFFFFFF
  Field: HIZx
  offset: 24, size: 8, access: 
  Attribute Memory x Databus Hiz Time Configure
  Field: HLDx
  offset: 16, size: 8, access: 
  Attribute Memory x Hold Time Configure
  Field: WAITx
  offset: 8, size: 8, access: 
  Attribute Memory x Wait Time Configure
  Field: SETx
  offset: 0, size: 8, access: 
  Attribute Memory x Setup Time Configure
*/
volatile uint32_t AMSTIM4;

/** IOSTIM4 IOSTIM4 (offset: 0xb0)
  I/O space timing register 4
  access : read-write
  reset value : 0xFCFCFCFC
  reset mask : 0xFFFFFFFF
  Field: HIZ
  offset: 24, size: 8, access: 
  I/O x Databus Hiz Time Configure
  Field: HLD
  offset: 16, size: 8, access: 
  I/O x Hold Time Configure
  Field: WAIT
  offset: 8, size: 8, access: 
  I/O x Wait Time Configure
  Field: SET
  offset: 0, size: 8, access: 
  I/O x Setup Time Configure
*/
volatile uint32_t IOSTIM4;
volatile uint32_t reserved5[20];

/** WRTTIM1 WRTTIM1 (offset: 0x104)
  SRAM/NOR-Flash write timing registers 1
  access : read-write
  reset value : 0xFFFFFFF
  reset mask : 0xFFFFFFFF
  Field: ASYNCACCCFG
  offset: 28, size: 2, access: 
  Asynchronous Access Mode Configure
  Field: BUSTURNCFG
  offset: 16, size: 4, access: 
  Bus Turnaround Phase Duration Configure
  Field: DATASETCFG
  offset: 8, size: 8, access: 
  Data-Setup Time Configure
  Field: ADDRHLDCFG
  offset: 4, size: 4, access: 
  Address-Hold Time Configure
  Field: ADDRSETCFG
  offset: 0, size: 4, access: 
  Address Setup Time Configure
*/
volatile uint32_t WRTTIM1;
volatile uint32_t reserved6;

/** WRTTIM2 WRTTIM2 (offset: 0x10c)
  SRAM/NOR-Flash write timing registers 2
  access : read-write
  reset value : 0xFFFFFFF
  reset mask : 0xFFFFFFFF
  Field: ASYNCACCCFG
  offset: 28, size: 2, access: 
  Asynchronous Access Mode Configure
  Field: BUSTURNCFG
  offset: 16, size: 4, access: 
  Bus Turnaround Phase Duration Configure
  Field: DATASETCFG
  offset: 8, size: 8, access: 
  Data-Setup Time Configure
  Field: ADDRHLDCFG
  offset: 4, size: 4, access: 
  Address-Hold Time Configure
  Field: ADDRSETCFG
  offset: 0, size: 4, access: 
  Address Setup Time Configure
*/
volatile uint32_t WRTTIM2;
volatile uint32_t reserved7;

/** WRTTIM3 WRTTIM3 (offset: 0x114)
  SRAM/NOR-Flash write timing registers 3
  access : read-write
  reset value : 0xFFFFFFF
  reset mask : 0xFFFFFFFF
  Field: ASYNCACCCFG
  offset: 28, size: 2, access: 
  Asynchronous Access Mode Configure
  Field: BUSTURNCFG
  offset: 16, size: 4, access: 
  Bus Turnaround Phase Duration Configure
  Field: DATASETCFG
  offset: 8, size: 8, access: 
  Data-Setup Time Configure
  Field: ADDRHLDCFG
  offset: 4, size: 4, access: 
  Address-Hold Time Configure
  Field: ADDRSETCFG
  offset: 0, size: 4, access: 
  Address Setup Time Configure
*/
volatile uint32_t WRTTIM3;
volatile uint32_t reserved8;

/** WRTTIM4 WRTTIM4 (offset: 0x11c)
  SRAM/NOR-Flash write timing registers 4
  access : read-write
  reset value : 0xFFFFFFF
  reset mask : 0xFFFFFFFF
  Field: ASYNCACCCFG
  offset: 28, size: 2, access: 
  Asynchronous Access Mode Configure
  Field: BUSTURNCFG
  offset: 16, size: 4, access: 
  Bus Turnaround Phase Duration Configure
  Field: DATASETCFG
  offset: 8, size: 8, access: 
  Data-Setup Time Configure
  Field: ADDRHLDCFG
  offset: 4, size: 4, access: 
  Address-Hold Time Configure
  Field: ADDRSETCFG
  offset: 0, size: 4, access: 
  Address Setup Time Configure
*/
volatile uint32_t WRTTIM4;
} SMC_type;

#define SMC ((SMC_type *) 0xA0000000)

#endif // HW_SMC_H
