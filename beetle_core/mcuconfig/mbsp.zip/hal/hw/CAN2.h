#ifndef HW_CAN2_H
#define HW_CAN2_H
/** Controller area network */
/** Interrupt : CAN2_RX0 (Vector: 64) CAN2 RX0 interrupts */
/** Interrupt : CAN2_RX1 (Vector: 65) CAN2 RX1 interrupts */
/** Interrupt : CAN2_SCE (Vector: 66) CAN2 SCE interrupt */
/** Interrupt : CAN2_TX (Vector: 63) CAN2 TX interrupts */
/** Memory Block starting at 0x40006800 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define CAN2_MCTRL_INITREQ_OFFSET                          0
#define CAN2_MCTRL_INITREQ_MASK                            1

#define CAN2_MCTRL_SLEEPREQ_OFFSET                         1
#define CAN2_MCTRL_SLEEPREQ_MASK                           2

#define CAN2_MCTRL_TXFPCFG_OFFSET                          2
#define CAN2_MCTRL_TXFPCFG_MASK                            4

#define CAN2_MCTRL_RXFLOCK_OFFSET                          3
#define CAN2_MCTRL_RXFLOCK_MASK                            8

#define CAN2_MCTRL_ARTXMD_OFFSET                           4
#define CAN2_MCTRL_ARTXMD_MASK                             0x10

#define CAN2_MCTRL_AWUPCFG_OFFSET                          5
#define CAN2_MCTRL_AWUPCFG_MASK                            0x20

#define CAN2_MCTRL_ALBOFFM_OFFSET                          6
#define CAN2_MCTRL_ALBOFFM_MASK                            0x40

#define CAN2_MCTRL_SWRST_OFFSET                            15
#define CAN2_MCTRL_SWRST_MASK                              0x8000

#define CAN2_MCTRL_DBGFRZE_OFFSET                          16
#define CAN2_MCTRL_DBGFRZE_MASK                            0x10000

#define CAN2_MSTS_INITFLG_OFFSET                           0
#define CAN2_MSTS_INITFLG_MASK                             1

#define CAN2_MSTS_SLEEPFLG_OFFSET                          1
#define CAN2_MSTS_SLEEPFLG_MASK                            2

#define CAN2_MSTS_ERRIFLG_OFFSET                           2
#define CAN2_MSTS_ERRIFLG_MASK                             4

#define CAN2_MSTS_WUPIFLG_OFFSET                           3
#define CAN2_MSTS_WUPIFLG_MASK                             8

#define CAN2_MSTS_SLEEPIFLG_OFFSET                         4
#define CAN2_MSTS_SLEEPIFLG_MASK                           0x10

#define CAN2_MSTS_TXMFLG_OFFSET                            8
#define CAN2_MSTS_TXMFLG_MASK                              0x100

#define CAN2_MSTS_RXMFLG_OFFSET                            9
#define CAN2_MSTS_RXMFLG_MASK                              0x200

#define CAN2_MSTS_LSAMVALUE_OFFSET                         10
#define CAN2_MSTS_LSAMVALUE_MASK                           0x400

#define CAN2_MSTS_RXSIGL_OFFSET                            11
#define CAN2_MSTS_RXSIGL_MASK                              0x800

#define CAN2_TXSTS_REQCFLG0_OFFSET                         0
#define CAN2_TXSTS_REQCFLG0_MASK                           1

#define CAN2_TXSTS_TXSUSFLG0_OFFSET                        1
#define CAN2_TXSTS_TXSUSFLG0_MASK                          2

#define CAN2_TXSTS_ARBLSTFLG0_OFFSET                       2
#define CAN2_TXSTS_ARBLSTFLG0_MASK                         4

#define CAN2_TXSTS_TXERRFLG0_OFFSET                        3
#define CAN2_TXSTS_TXERRFLG0_MASK                          8

#define CAN2_TXSTS_ABREQFLG0_OFFSET                        7
#define CAN2_TXSTS_ABREQFLG0_MASK                          0x80

#define CAN2_TXSTS_REQCFLG1_OFFSET                         8
#define CAN2_TXSTS_REQCFLG1_MASK                           0x100

#define CAN2_TXSTS_TXSUSFLG1_OFFSET                        9
#define CAN2_TXSTS_TXSUSFLG1_MASK                          0x200

#define CAN2_TXSTS_ARBLSTFLG1_OFFSET                       10
#define CAN2_TXSTS_ARBLSTFLG1_MASK                         0x400

#define CAN2_TXSTS_TXERRFLG1_OFFSET                        11
#define CAN2_TXSTS_TXERRFLG1_MASK                          0x800

#define CAN2_TXSTS_ABREQFLG1_OFFSET                        15
#define CAN2_TXSTS_ABREQFLG1_MASK                          0x8000

#define CAN2_TXSTS_REQCFLG2_OFFSET                         16
#define CAN2_TXSTS_REQCFLG2_MASK                           0x10000

#define CAN2_TXSTS_TXSUSFLG2_OFFSET                        17
#define CAN2_TXSTS_TXSUSFLG2_MASK                          0x20000

#define CAN2_TXSTS_ARBLSTFLG2_OFFSET                       18
#define CAN2_TXSTS_ARBLSTFLG2_MASK                         0x40000

#define CAN2_TXSTS_TXERRFLG2_OFFSET                        19
#define CAN2_TXSTS_TXERRFLG2_MASK                          0x80000

#define CAN2_TXSTS_ABREQFLG2_OFFSET                        23
#define CAN2_TXSTS_ABREQFLG2_MASK                          0x800000

#define CAN2_TXSTS_EMNUM_OFFSET                            24
#define CAN2_TXSTS_EMNUM_MASK                              0x3000000

#define CAN2_TXSTS_TXMEFLG0_OFFSET                         26
#define CAN2_TXSTS_TXMEFLG0_MASK                           0x4000000

#define CAN2_TXSTS_TXMEFLG1_OFFSET                         27
#define CAN2_TXSTS_TXMEFLG1_MASK                           0x8000000

#define CAN2_TXSTS_TXMEFLG2_OFFSET                         28
#define CAN2_TXSTS_TXMEFLG2_MASK                           0x10000000

#define CAN2_TXSTS_LOWESTP0_OFFSET                         29
#define CAN2_TXSTS_LOWESTP0_MASK                           0x20000000

#define CAN2_TXSTS_LOWESTP1_OFFSET                         30
#define CAN2_TXSTS_LOWESTP1_MASK                           0x40000000

#define CAN2_TXSTS_LOWESTP2_OFFSET                         31
#define CAN2_TXSTS_LOWESTP2_MASK                           0x80000000

#define CAN2_RXF0_FMNUM0_OFFSET                            0
#define CAN2_RXF0_FMNUM0_MASK                              3

#define CAN2_RXF0_FFULLFLG0_OFFSET                         3
#define CAN2_RXF0_FFULLFLG0_MASK                           8

#define CAN2_RXF0_FOVRFLG0_OFFSET                          4
#define CAN2_RXF0_FOVRFLG0_MASK                            0x10

#define CAN2_RXF0_RFOM0_OFFSET                             5
#define CAN2_RXF0_RFOM0_MASK                               0x20

#define CAN2_RXF1_FMNUM1_OFFSET                            0
#define CAN2_RXF1_FMNUM1_MASK                              3

#define CAN2_RXF1_FFULLFLG1_OFFSET                         3
#define CAN2_RXF1_FFULLFLG1_MASK                           8

#define CAN2_RXF1_FOVRFLG1_OFFSET                          4
#define CAN2_RXF1_FOVRFLG1_MASK                            0x10

#define CAN2_RXF1_RFOM1_OFFSET                             5
#define CAN2_RXF1_RFOM1_MASK                               0x20

#define CAN2_INTEN_TXMEIEN_OFFSET                          0
#define CAN2_INTEN_TXMEIEN_MASK                            1

#define CAN2_INTEN_FMIEN0_OFFSET                           1
#define CAN2_INTEN_FMIEN0_MASK                             2

#define CAN2_INTEN_FFULLIEN0_OFFSET                        2
#define CAN2_INTEN_FFULLIEN0_MASK                          4

#define CAN2_INTEN_FOVRIEN0_OFFSET                         3
#define CAN2_INTEN_FOVRIEN0_MASK                           8

#define CAN2_INTEN_FMIEN1_OFFSET                           4
#define CAN2_INTEN_FMIEN1_MASK                             0x10

#define CAN2_INTEN_FFULLIEN1_OFFSET                        5
#define CAN2_INTEN_FFULLIEN1_MASK                          0x20

#define CAN2_INTEN_FOVRIEN1_OFFSET                         6
#define CAN2_INTEN_FOVRIEN1_MASK                           0x40

#define CAN2_INTEN_ERRWIEN_OFFSET                          8
#define CAN2_INTEN_ERRWIEN_MASK                            0x100

#define CAN2_INTEN_ERRPIEN_OFFSET                          9
#define CAN2_INTEN_ERRPIEN_MASK                            0x200

#define CAN2_INTEN_BOFFIEN_OFFSET                          10
#define CAN2_INTEN_BOFFIEN_MASK                            0x400

#define CAN2_INTEN_LECIEN_OFFSET                           11
#define CAN2_INTEN_LECIEN_MASK                             0x800

#define CAN2_INTEN_ERRIEN_OFFSET                           15
#define CAN2_INTEN_ERRIEN_MASK                             0x8000

#define CAN2_INTEN_WUPIEN_OFFSET                           16
#define CAN2_INTEN_WUPIEN_MASK                             0x10000

#define CAN2_INTEN_SLEEPIEN_OFFSET                         17
#define CAN2_INTEN_SLEEPIEN_MASK                           0x20000

#define CAN2_ERRSTS_ERRWFLG_OFFSET                         0
#define CAN2_ERRSTS_ERRWFLG_MASK                           1

#define CAN2_ERRSTS_ERRPFLG_OFFSET                         1
#define CAN2_ERRSTS_ERRPFLG_MASK                           2

#define CAN2_ERRSTS_BOFLG_OFFSET                           2
#define CAN2_ERRSTS_BOFLG_MASK                             4

#define CAN2_ERRSTS_LERRC_OFFSET                           4
#define CAN2_ERRSTS_LERRC_MASK                             0x70

#define CAN2_ERRSTS_TXERRCNT_OFFSET                        16
#define CAN2_ERRSTS_TXERRCNT_MASK                          0xff0000

#define CAN2_ERRSTS_RXERRCNT_OFFSET                        24
#define CAN2_ERRSTS_RXERRCNT_MASK                          0xff000000

#define CAN2_BITTIM_BRPSC_OFFSET                           0
#define CAN2_BITTIM_BRPSC_MASK                             0x3ff

#define CAN2_BITTIM_TIMSEG1_OFFSET                         16
#define CAN2_BITTIM_TIMSEG1_MASK                           0xf0000

#define CAN2_BITTIM_TIMSEG2_OFFSET                         20
#define CAN2_BITTIM_TIMSEG2_MASK                           0x700000

#define CAN2_BITTIM_RSYNJW_OFFSET                          24
#define CAN2_BITTIM_RSYNJW_MASK                            0x3000000

#define CAN2_BITTIM_LBKMEN_OFFSET                          30
#define CAN2_BITTIM_LBKMEN_MASK                            0x40000000

#define CAN2_BITTIM_SILMEN_OFFSET                          31
#define CAN2_BITTIM_SILMEN_MASK                            0x80000000

#define CAN2_TXMID0_TXMREQ_OFFSET                          0
#define CAN2_TXMID0_TXMREQ_MASK                            1

#define CAN2_TXMID0_TXRFREQ_OFFSET                         1
#define CAN2_TXMID0_TXRFREQ_MASK                           2

#define CAN2_TXMID0_IDTYPESEL_OFFSET                       2
#define CAN2_TXMID0_IDTYPESEL_MASK                         4

#define CAN2_TXMID0_EXTID_OFFSET                           3
#define CAN2_TXMID0_EXTID_MASK                             0x1ffff8

#define CAN2_TXMID0_STDID_OFFSET                           21
#define CAN2_TXMID0_STDID_MASK                             0xffe00000

#define CAN2_TXDLEN0_DLCODE_OFFSET                         0
#define CAN2_TXDLEN0_DLCODE_MASK                           0xf

#define CAN2_TXMDL0_DATABYTE0_OFFSET                       0
#define CAN2_TXMDL0_DATABYTE0_MASK                         0xff

#define CAN2_TXMDL0_DATABYTE1_OFFSET                       8
#define CAN2_TXMDL0_DATABYTE1_MASK                         0xff00

#define CAN2_TXMDL0_DATABYTE2_OFFSET                       16
#define CAN2_TXMDL0_DATABYTE2_MASK                         0xff0000

#define CAN2_TXMDL0_DATABYTE3_OFFSET                       24
#define CAN2_TXMDL0_DATABYTE3_MASK                         0xff000000

#define CAN2_TXMDH0_DATABYTE4_OFFSET                       0
#define CAN2_TXMDH0_DATABYTE4_MASK                         0xff

#define CAN2_TXMDH0_DATABYTE5_OFFSET                       8
#define CAN2_TXMDH0_DATABYTE5_MASK                         0xff00

#define CAN2_TXMDH0_DATABYTE6_OFFSET                       16
#define CAN2_TXMDH0_DATABYTE6_MASK                         0xff0000

#define CAN2_TXMDH0_DATABYTE7_OFFSET                       24
#define CAN2_TXMDH0_DATABYTE7_MASK                         0xff000000

#define CAN2_TXMID1_TXMREQ_OFFSET                          0
#define CAN2_TXMID1_TXMREQ_MASK                            1

#define CAN2_TXMID1_TXRFREQ_OFFSET                         1
#define CAN2_TXMID1_TXRFREQ_MASK                           2

#define CAN2_TXMID1_IDTYPESEL_OFFSET                       2
#define CAN2_TXMID1_IDTYPESEL_MASK                         4

#define CAN2_TXMID1_EXTID_OFFSET                           3
#define CAN2_TXMID1_EXTID_MASK                             0x1ffff8

#define CAN2_TXMID1_STDID_OFFSET                           21
#define CAN2_TXMID1_STDID_MASK                             0xffe00000

#define CAN2_TXDLEN1_DLCODE_OFFSET                         0
#define CAN2_TXDLEN1_DLCODE_MASK                           0xf

#define CAN2_TXMDL1_DATABYTE0_OFFSET                       0
#define CAN2_TXMDL1_DATABYTE0_MASK                         0xff

#define CAN2_TXMDL1_DATABYTE1_OFFSET                       8
#define CAN2_TXMDL1_DATABYTE1_MASK                         0xff00

#define CAN2_TXMDL1_DATABYTE2_OFFSET                       16
#define CAN2_TXMDL1_DATABYTE2_MASK                         0xff0000

#define CAN2_TXMDL1_DATABYTE3_OFFSET                       24
#define CAN2_TXMDL1_DATABYTE3_MASK                         0xff000000

#define CAN2_TXMDH1_DATABYTE4_OFFSET                       0
#define CAN2_TXMDH1_DATABYTE4_MASK                         0xff

#define CAN2_TXMDH1_DATABYTE5_OFFSET                       8
#define CAN2_TXMDH1_DATABYTE5_MASK                         0xff00

#define CAN2_TXMDH1_DATABYTE6_OFFSET                       16
#define CAN2_TXMDH1_DATABYTE6_MASK                         0xff0000

#define CAN2_TXMDH1_DATABYTE7_OFFSET                       24
#define CAN2_TXMDH1_DATABYTE7_MASK                         0xff000000

#define CAN2_TXMID2_TXMREQ_OFFSET                          0
#define CAN2_TXMID2_TXMREQ_MASK                            1

#define CAN2_TXMID2_TXRFREQ_OFFSET                         1
#define CAN2_TXMID2_TXRFREQ_MASK                           2

#define CAN2_TXMID2_IDTYPESEL_OFFSET                       2
#define CAN2_TXMID2_IDTYPESEL_MASK                         4

#define CAN2_TXMID2_EXTID_OFFSET                           3
#define CAN2_TXMID2_EXTID_MASK                             0x1ffff8

#define CAN2_TXMID2_STDID_OFFSET                           21
#define CAN2_TXMID2_STDID_MASK                             0xffe00000

#define CAN2_TXDLEN2_DLCODE_OFFSET                         0
#define CAN2_TXDLEN2_DLCODE_MASK                           0xf

#define CAN2_TXMDL2_DATABYTE0_OFFSET                       0
#define CAN2_TXMDL2_DATABYTE0_MASK                         0xff

#define CAN2_TXMDL2_DATABYTE1_OFFSET                       8
#define CAN2_TXMDL2_DATABYTE1_MASK                         0xff00

#define CAN2_TXMDL2_DATABYTE2_OFFSET                       16
#define CAN2_TXMDL2_DATABYTE2_MASK                         0xff0000

#define CAN2_TXMDL2_DATABYTE3_OFFSET                       24
#define CAN2_TXMDL2_DATABYTE3_MASK                         0xff000000

#define CAN2_TXMDH2_DATABYTE4_OFFSET                       0
#define CAN2_TXMDH2_DATABYTE4_MASK                         0xff

#define CAN2_TXMDH2_DATABYTE5_OFFSET                       8
#define CAN2_TXMDH2_DATABYTE5_MASK                         0xff00

#define CAN2_TXMDH2_DATABYTE6_OFFSET                       16
#define CAN2_TXMDH2_DATABYTE6_MASK                         0xff0000

#define CAN2_TXMDH2_DATABYTE7_OFFSET                       24
#define CAN2_TXMDH2_DATABYTE7_MASK                         0xff000000

#define CAN2_RXMID0_RFTXREQ_OFFSET                         1
#define CAN2_RXMID0_RFTXREQ_MASK                           2

#define CAN2_RXMID0_IDTYPESEL_OFFSET                       2
#define CAN2_RXMID0_IDTYPESEL_MASK                         4

#define CAN2_RXMID0_EXTID_OFFSET                           3
#define CAN2_RXMID0_EXTID_MASK                             0x1ffff8

#define CAN2_RXMID0_STDID_OFFSET                           21
#define CAN2_RXMID0_STDID_MASK                             0xffe00000

#define CAN2_RXDLEN0_DLCODE_OFFSET                         0
#define CAN2_RXDLEN0_DLCODE_MASK                           0xf

#define CAN2_RXDLEN0_FMIDX_OFFSET                          8
#define CAN2_RXDLEN0_FMIDX_MASK                            0xff00

#define CAN2_RXMDL0_DATABYTE0_OFFSET                       0
#define CAN2_RXMDL0_DATABYTE0_MASK                         0xff

#define CAN2_RXMDL0_DATABYTE1_OFFSET                       8
#define CAN2_RXMDL0_DATABYTE1_MASK                         0xff00

#define CAN2_RXMDL0_DATABYTE2_OFFSET                       16
#define CAN2_RXMDL0_DATABYTE2_MASK                         0xff0000

#define CAN2_RXMDL0_DATABYTE3_OFFSET                       24
#define CAN2_RXMDL0_DATABYTE3_MASK                         0xff000000

#define CAN2_RXMDH0_DATABYTE4_OFFSET                       0
#define CAN2_RXMDH0_DATABYTE4_MASK                         0xff

#define CAN2_RXMDH0_DATABYTE5_OFFSET                       8
#define CAN2_RXMDH0_DATABYTE5_MASK                         0xff00

#define CAN2_RXMDH0_DATABYTE6_OFFSET                       16
#define CAN2_RXMDH0_DATABYTE6_MASK                         0xff0000

#define CAN2_RXMDH0_DATABYTE7_OFFSET                       24
#define CAN2_RXMDH0_DATABYTE7_MASK                         0xff000000

#define CAN2_RXMID1_RFTXREQ_OFFSET                         1
#define CAN2_RXMID1_RFTXREQ_MASK                           2

#define CAN2_RXMID1_IDTYPESEL_OFFSET                       2
#define CAN2_RXMID1_IDTYPESEL_MASK                         4

#define CAN2_RXMID1_EXTID_OFFSET                           3
#define CAN2_RXMID1_EXTID_MASK                             0x1ffff8

#define CAN2_RXMID1_STDID_OFFSET                           21
#define CAN2_RXMID1_STDID_MASK                             0xffe00000

#define CAN2_RXDLEN1_DLCODE_OFFSET                         0
#define CAN2_RXDLEN1_DLCODE_MASK                           0xf

#define CAN2_RXDLEN1_FMIDX_OFFSET                          8
#define CAN2_RXDLEN1_FMIDX_MASK                            0xff00

#define CAN2_RXMDL1_DATABYTE0_OFFSET                       0
#define CAN2_RXMDL1_DATABYTE0_MASK                         0xff

#define CAN2_RXMDL1_DATABYTE1_OFFSET                       8
#define CAN2_RXMDL1_DATABYTE1_MASK                         0xff00

#define CAN2_RXMDL1_DATABYTE2_OFFSET                       16
#define CAN2_RXMDL1_DATABYTE2_MASK                         0xff0000

#define CAN2_RXMDL1_DATABYTE3_OFFSET                       24
#define CAN2_RXMDL1_DATABYTE3_MASK                         0xff000000

#define CAN2_RXMDH1_DATABYTE4_OFFSET                       0
#define CAN2_RXMDH1_DATABYTE4_MASK                         0xff

#define CAN2_RXMDH1_DATABYTE5_OFFSET                       8
#define CAN2_RXMDH1_DATABYTE5_MASK                         0xff00

#define CAN2_RXMDH1_DATABYTE6_OFFSET                       16
#define CAN2_RXMDH1_DATABYTE6_MASK                         0xff0000

#define CAN2_RXMDH1_DATABYTE7_OFFSET                       24
#define CAN2_RXMDH1_DATABYTE7_MASK                         0xff000000

#define CAN2_FCTRL_FINITEN_OFFSET                          0
#define CAN2_FCTRL_FINITEN_MASK                            1

#define CAN2_FCTRL_CAN2SB_OFFSET                           8
#define CAN2_FCTRL_CAN2SB_MASK                             0x3f00

#define CAN2_FMCFG_FMCFG0_OFFSET                           0
#define CAN2_FMCFG_FMCFG0_MASK                             1

#define CAN2_FMCFG_FMCFG1_OFFSET                           1
#define CAN2_FMCFG_FMCFG1_MASK                             2

#define CAN2_FMCFG_FMCFG2_OFFSET                           2
#define CAN2_FMCFG_FMCFG2_MASK                             4

#define CAN2_FMCFG_FMCFG3_OFFSET                           3
#define CAN2_FMCFG_FMCFG3_MASK                             8

#define CAN2_FMCFG_FMCFG4_OFFSET                           4
#define CAN2_FMCFG_FMCFG4_MASK                             0x10

#define CAN2_FMCFG_FMCFG5_OFFSET                           5
#define CAN2_FMCFG_FMCFG5_MASK                             0x20

#define CAN2_FMCFG_FMCFG6_OFFSET                           6
#define CAN2_FMCFG_FMCFG6_MASK                             0x40

#define CAN2_FMCFG_FMCFG7_OFFSET                           7
#define CAN2_FMCFG_FMCFG7_MASK                             0x80

#define CAN2_FMCFG_FMCFG8_OFFSET                           8
#define CAN2_FMCFG_FMCFG8_MASK                             0x100

#define CAN2_FMCFG_FMCFG9_OFFSET                           9
#define CAN2_FMCFG_FMCFG9_MASK                             0x200

#define CAN2_FMCFG_FMCFG10_OFFSET                          10
#define CAN2_FMCFG_FMCFG10_MASK                            0x400

#define CAN2_FMCFG_FMCFG11_OFFSET                          11
#define CAN2_FMCFG_FMCFG11_MASK                            0x800

#define CAN2_FMCFG_FMCFG12_OFFSET                          12
#define CAN2_FMCFG_FMCFG12_MASK                            0x1000

#define CAN2_FMCFG_FMCFG13_OFFSET                          13
#define CAN2_FMCFG_FMCFG13_MASK                            0x2000

#define CAN2_FMCFG_FMCFG14_OFFSET                          14
#define CAN2_FMCFG_FMCFG14_MASK                            0x4000

#define CAN2_FMCFG_FMCFG15_OFFSET                          15
#define CAN2_FMCFG_FMCFG15_MASK                            0x8000

#define CAN2_FMCFG_FMCFG16_OFFSET                          16
#define CAN2_FMCFG_FMCFG16_MASK                            0x10000

#define CAN2_FMCFG_FMCFG17_OFFSET                          17
#define CAN2_FMCFG_FMCFG17_MASK                            0x20000

#define CAN2_FMCFG_FMCFG18_OFFSET                          18
#define CAN2_FMCFG_FMCFG18_MASK                            0x40000

#define CAN2_FMCFG_FMCFG19_OFFSET                          19
#define CAN2_FMCFG_FMCFG19_MASK                            0x80000

#define CAN2_FMCFG_FMCFG20_OFFSET                          20
#define CAN2_FMCFG_FMCFG20_MASK                            0x100000

#define CAN2_FMCFG_FMCFG21_OFFSET                          21
#define CAN2_FMCFG_FMCFG21_MASK                            0x200000

#define CAN2_FMCFG_FMCFG22_OFFSET                          22
#define CAN2_FMCFG_FMCFG22_MASK                            0x400000

#define CAN2_FMCFG_FMCFG23_OFFSET                          23
#define CAN2_FMCFG_FMCFG23_MASK                            0x800000

#define CAN2_FMCFG_FMCFG24_OFFSET                          24
#define CAN2_FMCFG_FMCFG24_MASK                            0x1000000

#define CAN2_FMCFG_FMCFG25_OFFSET                          25
#define CAN2_FMCFG_FMCFG25_MASK                            0x2000000

#define CAN2_FMCFG_FMCFG26_OFFSET                          26
#define CAN2_FMCFG_FMCFG26_MASK                            0x4000000

#define CAN2_FMCFG_FMCFG27_OFFSET                          27
#define CAN2_FMCFG_FMCFG27_MASK                            0x8000000

#define CAN2_FSCFG_FSCFG0_OFFSET                           0
#define CAN2_FSCFG_FSCFG0_MASK                             1

#define CAN2_FSCFG_FSCFG1_OFFSET                           1
#define CAN2_FSCFG_FSCFG1_MASK                             2

#define CAN2_FSCFG_FSCFG2_OFFSET                           2
#define CAN2_FSCFG_FSCFG2_MASK                             4

#define CAN2_FSCFG_FSCFG3_OFFSET                           3
#define CAN2_FSCFG_FSCFG3_MASK                             8

#define CAN2_FSCFG_FSCFG4_OFFSET                           4
#define CAN2_FSCFG_FSCFG4_MASK                             0x10

#define CAN2_FSCFG_FSCFG5_OFFSET                           5
#define CAN2_FSCFG_FSCFG5_MASK                             0x20

#define CAN2_FSCFG_FSCFG6_OFFSET                           6
#define CAN2_FSCFG_FSCFG6_MASK                             0x40

#define CAN2_FSCFG_FSCFG7_OFFSET                           7
#define CAN2_FSCFG_FSCFG7_MASK                             0x80

#define CAN2_FSCFG_FSCFG8_OFFSET                           8
#define CAN2_FSCFG_FSCFG8_MASK                             0x100

#define CAN2_FSCFG_FSCFG9_OFFSET                           9
#define CAN2_FSCFG_FSCFG9_MASK                             0x200

#define CAN2_FSCFG_FSCFG10_OFFSET                          10
#define CAN2_FSCFG_FSCFG10_MASK                            0x400

#define CAN2_FSCFG_FSCFG11_OFFSET                          11
#define CAN2_FSCFG_FSCFG11_MASK                            0x800

#define CAN2_FSCFG_FSCFG12_OFFSET                          12
#define CAN2_FSCFG_FSCFG12_MASK                            0x1000

#define CAN2_FSCFG_FSCFG13_OFFSET                          13
#define CAN2_FSCFG_FSCFG13_MASK                            0x2000

#define CAN2_FSCFG_FSCFG14_OFFSET                          14
#define CAN2_FSCFG_FSCFG14_MASK                            0x4000

#define CAN2_FSCFG_FSCFG15_OFFSET                          15
#define CAN2_FSCFG_FSCFG15_MASK                            0x8000

#define CAN2_FSCFG_FSCFG16_OFFSET                          16
#define CAN2_FSCFG_FSCFG16_MASK                            0x10000

#define CAN2_FSCFG_FSCFG17_OFFSET                          17
#define CAN2_FSCFG_FSCFG17_MASK                            0x20000

#define CAN2_FSCFG_FSCFG18_OFFSET                          18
#define CAN2_FSCFG_FSCFG18_MASK                            0x40000

#define CAN2_FSCFG_FSCFG19_OFFSET                          19
#define CAN2_FSCFG_FSCFG19_MASK                            0x80000

#define CAN2_FSCFG_FSCFG20_OFFSET                          20
#define CAN2_FSCFG_FSCFG20_MASK                            0x100000

#define CAN2_FSCFG_FSCFG21_OFFSET                          21
#define CAN2_FSCFG_FSCFG21_MASK                            0x200000

#define CAN2_FSCFG_FSCFG22_OFFSET                          22
#define CAN2_FSCFG_FSCFG22_MASK                            0x400000

#define CAN2_FSCFG_FSCFG23_OFFSET                          23
#define CAN2_FSCFG_FSCFG23_MASK                            0x800000

#define CAN2_FSCFG_FSCFG24_OFFSET                          24
#define CAN2_FSCFG_FSCFG24_MASK                            0x1000000

#define CAN2_FSCFG_FSCFG25_OFFSET                          25
#define CAN2_FSCFG_FSCFG25_MASK                            0x2000000

#define CAN2_FSCFG_FSCFG26_OFFSET                          26
#define CAN2_FSCFG_FSCFG26_MASK                            0x4000000

#define CAN2_FSCFG_FSCFG27_OFFSET                          27
#define CAN2_FSCFG_FSCFG27_MASK                            0x8000000

#define CAN2_FFASS_FFASS0_OFFSET                           0
#define CAN2_FFASS_FFASS0_MASK                             1

#define CAN2_FFASS_FFASS1_OFFSET                           1
#define CAN2_FFASS_FFASS1_MASK                             2

#define CAN2_FFASS_FFASS2_OFFSET                           2
#define CAN2_FFASS_FFASS2_MASK                             4

#define CAN2_FFASS_FFASS3_OFFSET                           3
#define CAN2_FFASS_FFASS3_MASK                             8

#define CAN2_FFASS_FFASS4_OFFSET                           4
#define CAN2_FFASS_FFASS4_MASK                             0x10

#define CAN2_FFASS_FFASS5_OFFSET                           5
#define CAN2_FFASS_FFASS5_MASK                             0x20

#define CAN2_FFASS_FFASS6_OFFSET                           6
#define CAN2_FFASS_FFASS6_MASK                             0x40

#define CAN2_FFASS_FFASS7_OFFSET                           7
#define CAN2_FFASS_FFASS7_MASK                             0x80

#define CAN2_FFASS_FFASS8_OFFSET                           8
#define CAN2_FFASS_FFASS8_MASK                             0x100

#define CAN2_FFASS_FFASS9_OFFSET                           9
#define CAN2_FFASS_FFASS9_MASK                             0x200

#define CAN2_FFASS_FFASS10_OFFSET                          10
#define CAN2_FFASS_FFASS10_MASK                            0x400

#define CAN2_FFASS_FFASS11_OFFSET                          11
#define CAN2_FFASS_FFASS11_MASK                            0x800

#define CAN2_FFASS_FFASS12_OFFSET                          12
#define CAN2_FFASS_FFASS12_MASK                            0x1000

#define CAN2_FFASS_FFASS13_OFFSET                          13
#define CAN2_FFASS_FFASS13_MASK                            0x2000

#define CAN2_FFASS_FFASS14_OFFSET                          14
#define CAN2_FFASS_FFASS14_MASK                            0x4000

#define CAN2_FFASS_FFASS15_OFFSET                          15
#define CAN2_FFASS_FFASS15_MASK                            0x8000

#define CAN2_FFASS_FFASS16_OFFSET                          16
#define CAN2_FFASS_FFASS16_MASK                            0x10000

#define CAN2_FFASS_FFASS17_OFFSET                          17
#define CAN2_FFASS_FFASS17_MASK                            0x20000

#define CAN2_FFASS_FFASS18_OFFSET                          18
#define CAN2_FFASS_FFASS18_MASK                            0x40000

#define CAN2_FFASS_FFASS19_OFFSET                          19
#define CAN2_FFASS_FFASS19_MASK                            0x80000

#define CAN2_FFASS_FFASS20_OFFSET                          20
#define CAN2_FFASS_FFASS20_MASK                            0x100000

#define CAN2_FFASS_FFASS21_OFFSET                          21
#define CAN2_FFASS_FFASS21_MASK                            0x200000

#define CAN2_FFASS_FFASS22_OFFSET                          22
#define CAN2_FFASS_FFASS22_MASK                            0x400000

#define CAN2_FFASS_FFASS23_OFFSET                          23
#define CAN2_FFASS_FFASS23_MASK                            0x800000

#define CAN2_FFASS_FFASS24_OFFSET                          24
#define CAN2_FFASS_FFASS24_MASK                            0x1000000

#define CAN2_FFASS_FFASS25_OFFSET                          25
#define CAN2_FFASS_FFASS25_MASK                            0x2000000

#define CAN2_FFASS_FFASS26_OFFSET                          26
#define CAN2_FFASS_FFASS26_MASK                            0x4000000

#define CAN2_FFASS_FFASS27_OFFSET                          27
#define CAN2_FFASS_FFASS27_MASK                            0x8000000

#define CAN2_FACT_FACT0_OFFSET                             0
#define CAN2_FACT_FACT0_MASK                               1

#define CAN2_FACT_FACT1_OFFSET                             1
#define CAN2_FACT_FACT1_MASK                               2

#define CAN2_FACT_FACT2_OFFSET                             2
#define CAN2_FACT_FACT2_MASK                               4

#define CAN2_FACT_FACT3_OFFSET                             3
#define CAN2_FACT_FACT3_MASK                               8

#define CAN2_FACT_FACT4_OFFSET                             4
#define CAN2_FACT_FACT4_MASK                               0x10

#define CAN2_FACT_FACT5_OFFSET                             5
#define CAN2_FACT_FACT5_MASK                               0x20

#define CAN2_FACT_FACT6_OFFSET                             6
#define CAN2_FACT_FACT6_MASK                               0x40

#define CAN2_FACT_FACT7_OFFSET                             7
#define CAN2_FACT_FACT7_MASK                               0x80

#define CAN2_FACT_FACT8_OFFSET                             8
#define CAN2_FACT_FACT8_MASK                               0x100

#define CAN2_FACT_FACT9_OFFSET                             9
#define CAN2_FACT_FACT9_MASK                               0x200

#define CAN2_FACT_FACT10_OFFSET                            10
#define CAN2_FACT_FACT10_MASK                              0x400

#define CAN2_FACT_FACT11_OFFSET                            11
#define CAN2_FACT_FACT11_MASK                              0x800

#define CAN2_FACT_FACT12_OFFSET                            12
#define CAN2_FACT_FACT12_MASK                              0x1000

#define CAN2_FACT_FACT13_OFFSET                            13
#define CAN2_FACT_FACT13_MASK                              0x2000

#define CAN2_FACT_FACT14_OFFSET                            14
#define CAN2_FACT_FACT14_MASK                              0x4000

#define CAN2_FACT_FACT15_OFFSET                            15
#define CAN2_FACT_FACT15_MASK                              0x8000

#define CAN2_FACT_FACT16_OFFSET                            16
#define CAN2_FACT_FACT16_MASK                              0x10000

#define CAN2_FACT_FACT17_OFFSET                            17
#define CAN2_FACT_FACT17_MASK                              0x20000

#define CAN2_FACT_FACT18_OFFSET                            18
#define CAN2_FACT_FACT18_MASK                              0x40000

#define CAN2_FACT_FACT19_OFFSET                            19
#define CAN2_FACT_FACT19_MASK                              0x80000

#define CAN2_FACT_FACT20_OFFSET                            20
#define CAN2_FACT_FACT20_MASK                              0x100000

#define CAN2_FACT_FACT21_OFFSET                            21
#define CAN2_FACT_FACT21_MASK                              0x200000

#define CAN2_FACT_FACT22_OFFSET                            22
#define CAN2_FACT_FACT22_MASK                              0x400000

#define CAN2_FACT_FACT23_OFFSET                            23
#define CAN2_FACT_FACT23_MASK                              0x800000

#define CAN2_FACT_FACT24_OFFSET                            24
#define CAN2_FACT_FACT24_MASK                              0x1000000

#define CAN2_FACT_FACT25_OFFSET                            25
#define CAN2_FACT_FACT25_MASK                              0x2000000

#define CAN2_FACT_FACT26_OFFSET                            26
#define CAN2_FACT_FACT26_MASK                              0x4000000

#define CAN2_FACT_FACT27_OFFSET                            27
#define CAN2_FACT_FACT27_MASK                              0x8000000

#define CAN2_F0BANK1_FBIT0_OFFSET                          0
#define CAN2_F0BANK1_FBIT0_MASK                            1

#define CAN2_F0BANK1_FBIT1_OFFSET                          1
#define CAN2_F0BANK1_FBIT1_MASK                            2

#define CAN2_F0BANK1_FBIT2_OFFSET                          2
#define CAN2_F0BANK1_FBIT2_MASK                            4

#define CAN2_F0BANK1_FBIT3_OFFSET                          3
#define CAN2_F0BANK1_FBIT3_MASK                            8

#define CAN2_F0BANK1_FBIT4_OFFSET                          4
#define CAN2_F0BANK1_FBIT4_MASK                            0x10

#define CAN2_F0BANK1_FBIT5_OFFSET                          5
#define CAN2_F0BANK1_FBIT5_MASK                            0x20

#define CAN2_F0BANK1_FBIT6_OFFSET                          6
#define CAN2_F0BANK1_FBIT6_MASK                            0x40

#define CAN2_F0BANK1_FBIT7_OFFSET                          7
#define CAN2_F0BANK1_FBIT7_MASK                            0x80

#define CAN2_F0BANK1_FBIT8_OFFSET                          8
#define CAN2_F0BANK1_FBIT8_MASK                            0x100

#define CAN2_F0BANK1_FBIT9_OFFSET                          9
#define CAN2_F0BANK1_FBIT9_MASK                            0x200

#define CAN2_F0BANK1_FBIT10_OFFSET                         10
#define CAN2_F0BANK1_FBIT10_MASK                           0x400

#define CAN2_F0BANK1_FBIT11_OFFSET                         11
#define CAN2_F0BANK1_FBIT11_MASK                           0x800

#define CAN2_F0BANK1_FBIT12_OFFSET                         12
#define CAN2_F0BANK1_FBIT12_MASK                           0x1000

#define CAN2_F0BANK1_FBIT13_OFFSET                         13
#define CAN2_F0BANK1_FBIT13_MASK                           0x2000

#define CAN2_F0BANK1_FBIT14_OFFSET                         14
#define CAN2_F0BANK1_FBIT14_MASK                           0x4000

#define CAN2_F0BANK1_FBIT15_OFFSET                         15
#define CAN2_F0BANK1_FBIT15_MASK                           0x8000

#define CAN2_F0BANK1_FBIT16_OFFSET                         16
#define CAN2_F0BANK1_FBIT16_MASK                           0x10000

#define CAN2_F0BANK1_FBIT17_OFFSET                         17
#define CAN2_F0BANK1_FBIT17_MASK                           0x20000

#define CAN2_F0BANK1_FBIT18_OFFSET                         18
#define CAN2_F0BANK1_FBIT18_MASK                           0x40000

#define CAN2_F0BANK1_FBIT19_OFFSET                         19
#define CAN2_F0BANK1_FBIT19_MASK                           0x80000

#define CAN2_F0BANK1_FBIT20_OFFSET                         20
#define CAN2_F0BANK1_FBIT20_MASK                           0x100000

#define CAN2_F0BANK1_FBIT21_OFFSET                         21
#define CAN2_F0BANK1_FBIT21_MASK                           0x200000

#define CAN2_F0BANK1_FBIT22_OFFSET                         22
#define CAN2_F0BANK1_FBIT22_MASK                           0x400000

#define CAN2_F0BANK1_FBIT23_OFFSET                         23
#define CAN2_F0BANK1_FBIT23_MASK                           0x800000

#define CAN2_F0BANK1_FBIT24_OFFSET                         24
#define CAN2_F0BANK1_FBIT24_MASK                           0x1000000

#define CAN2_F0BANK1_FBIT25_OFFSET                         25
#define CAN2_F0BANK1_FBIT25_MASK                           0x2000000

#define CAN2_F0BANK1_FBIT26_OFFSET                         26
#define CAN2_F0BANK1_FBIT26_MASK                           0x4000000

#define CAN2_F0BANK1_FBIT27_OFFSET                         27
#define CAN2_F0BANK1_FBIT27_MASK                           0x8000000

#define CAN2_F0BANK1_FBIT28_OFFSET                         28
#define CAN2_F0BANK1_FBIT28_MASK                           0x10000000

#define CAN2_F0BANK1_FBIT29_OFFSET                         29
#define CAN2_F0BANK1_FBIT29_MASK                           0x20000000

#define CAN2_F0BANK1_FBIT30_OFFSET                         30
#define CAN2_F0BANK1_FBIT30_MASK                           0x40000000

#define CAN2_F0BANK1_FBIT31_OFFSET                         31
#define CAN2_F0BANK1_FBIT31_MASK                           0x80000000

#define CAN2_F0BANK2_FBIT0_OFFSET                          0
#define CAN2_F0BANK2_FBIT0_MASK                            1

#define CAN2_F0BANK2_FBIT1_OFFSET                          1
#define CAN2_F0BANK2_FBIT1_MASK                            2

#define CAN2_F0BANK2_FBIT2_OFFSET                          2
#define CAN2_F0BANK2_FBIT2_MASK                            4

#define CAN2_F0BANK2_FBIT3_OFFSET                          3
#define CAN2_F0BANK2_FBIT3_MASK                            8

#define CAN2_F0BANK2_FBIT4_OFFSET                          4
#define CAN2_F0BANK2_FBIT4_MASK                            0x10

#define CAN2_F0BANK2_FBIT5_OFFSET                          5
#define CAN2_F0BANK2_FBIT5_MASK                            0x20

#define CAN2_F0BANK2_FBIT6_OFFSET                          6
#define CAN2_F0BANK2_FBIT6_MASK                            0x40

#define CAN2_F0BANK2_FBIT7_OFFSET                          7
#define CAN2_F0BANK2_FBIT7_MASK                            0x80

#define CAN2_F0BANK2_FBIT8_OFFSET                          8
#define CAN2_F0BANK2_FBIT8_MASK                            0x100

#define CAN2_F0BANK2_FBIT9_OFFSET                          9
#define CAN2_F0BANK2_FBIT9_MASK                            0x200

#define CAN2_F0BANK2_FBIT10_OFFSET                         10
#define CAN2_F0BANK2_FBIT10_MASK                           0x400

#define CAN2_F0BANK2_FBIT11_OFFSET                         11
#define CAN2_F0BANK2_FBIT11_MASK                           0x800

#define CAN2_F0BANK2_FBIT12_OFFSET                         12
#define CAN2_F0BANK2_FBIT12_MASK                           0x1000

#define CAN2_F0BANK2_FBIT13_OFFSET                         13
#define CAN2_F0BANK2_FBIT13_MASK                           0x2000

#define CAN2_F0BANK2_FBIT14_OFFSET                         14
#define CAN2_F0BANK2_FBIT14_MASK                           0x4000

#define CAN2_F0BANK2_FBIT15_OFFSET                         15
#define CAN2_F0BANK2_FBIT15_MASK                           0x8000

#define CAN2_F0BANK2_FBIT16_OFFSET                         16
#define CAN2_F0BANK2_FBIT16_MASK                           0x10000

#define CAN2_F0BANK2_FBIT17_OFFSET                         17
#define CAN2_F0BANK2_FBIT17_MASK                           0x20000

#define CAN2_F0BANK2_FBIT18_OFFSET                         18
#define CAN2_F0BANK2_FBIT18_MASK                           0x40000

#define CAN2_F0BANK2_FBIT19_OFFSET                         19
#define CAN2_F0BANK2_FBIT19_MASK                           0x80000

#define CAN2_F0BANK2_FBIT20_OFFSET                         20
#define CAN2_F0BANK2_FBIT20_MASK                           0x100000

#define CAN2_F0BANK2_FBIT21_OFFSET                         21
#define CAN2_F0BANK2_FBIT21_MASK                           0x200000

#define CAN2_F0BANK2_FBIT22_OFFSET                         22
#define CAN2_F0BANK2_FBIT22_MASK                           0x400000

#define CAN2_F0BANK2_FBIT23_OFFSET                         23
#define CAN2_F0BANK2_FBIT23_MASK                           0x800000

#define CAN2_F0BANK2_FBIT24_OFFSET                         24
#define CAN2_F0BANK2_FBIT24_MASK                           0x1000000

#define CAN2_F0BANK2_FBIT25_OFFSET                         25
#define CAN2_F0BANK2_FBIT25_MASK                           0x2000000

#define CAN2_F0BANK2_FBIT26_OFFSET                         26
#define CAN2_F0BANK2_FBIT26_MASK                           0x4000000

#define CAN2_F0BANK2_FBIT27_OFFSET                         27
#define CAN2_F0BANK2_FBIT27_MASK                           0x8000000

#define CAN2_F0BANK2_FBIT28_OFFSET                         28
#define CAN2_F0BANK2_FBIT28_MASK                           0x10000000

#define CAN2_F0BANK2_FBIT29_OFFSET                         29
#define CAN2_F0BANK2_FBIT29_MASK                           0x20000000

#define CAN2_F0BANK2_FBIT30_OFFSET                         30
#define CAN2_F0BANK2_FBIT30_MASK                           0x40000000

#define CAN2_F0BANK2_FBIT31_OFFSET                         31
#define CAN2_F0BANK2_FBIT31_MASK                           0x80000000

#define CAN2_F1BANK1_FBIT0_OFFSET                          0
#define CAN2_F1BANK1_FBIT0_MASK                            1

#define CAN2_F1BANK1_FBIT1_OFFSET                          1
#define CAN2_F1BANK1_FBIT1_MASK                            2

#define CAN2_F1BANK1_FBIT2_OFFSET                          2
#define CAN2_F1BANK1_FBIT2_MASK                            4

#define CAN2_F1BANK1_FBIT3_OFFSET                          3
#define CAN2_F1BANK1_FBIT3_MASK                            8

#define CAN2_F1BANK1_FBIT4_OFFSET                          4
#define CAN2_F1BANK1_FBIT4_MASK                            0x10

#define CAN2_F1BANK1_FBIT5_OFFSET                          5
#define CAN2_F1BANK1_FBIT5_MASK                            0x20

#define CAN2_F1BANK1_FBIT6_OFFSET                          6
#define CAN2_F1BANK1_FBIT6_MASK                            0x40

#define CAN2_F1BANK1_FBIT7_OFFSET                          7
#define CAN2_F1BANK1_FBIT7_MASK                            0x80

#define CAN2_F1BANK1_FBIT8_OFFSET                          8
#define CAN2_F1BANK1_FBIT8_MASK                            0x100

#define CAN2_F1BANK1_FBIT9_OFFSET                          9
#define CAN2_F1BANK1_FBIT9_MASK                            0x200

#define CAN2_F1BANK1_FBIT10_OFFSET                         10
#define CAN2_F1BANK1_FBIT10_MASK                           0x400

#define CAN2_F1BANK1_FBIT11_OFFSET                         11
#define CAN2_F1BANK1_FBIT11_MASK                           0x800

#define CAN2_F1BANK1_FBIT12_OFFSET                         12
#define CAN2_F1BANK1_FBIT12_MASK                           0x1000

#define CAN2_F1BANK1_FBIT13_OFFSET                         13
#define CAN2_F1BANK1_FBIT13_MASK                           0x2000

#define CAN2_F1BANK1_FBIT14_OFFSET                         14
#define CAN2_F1BANK1_FBIT14_MASK                           0x4000

#define CAN2_F1BANK1_FBIT15_OFFSET                         15
#define CAN2_F1BANK1_FBIT15_MASK                           0x8000

#define CAN2_F1BANK1_FBIT16_OFFSET                         16
#define CAN2_F1BANK1_FBIT16_MASK                           0x10000

#define CAN2_F1BANK1_FBIT17_OFFSET                         17
#define CAN2_F1BANK1_FBIT17_MASK                           0x20000

#define CAN2_F1BANK1_FBIT18_OFFSET                         18
#define CAN2_F1BANK1_FBIT18_MASK                           0x40000

#define CAN2_F1BANK1_FBIT19_OFFSET                         19
#define CAN2_F1BANK1_FBIT19_MASK                           0x80000

#define CAN2_F1BANK1_FBIT20_OFFSET                         20
#define CAN2_F1BANK1_FBIT20_MASK                           0x100000

#define CAN2_F1BANK1_FBIT21_OFFSET                         21
#define CAN2_F1BANK1_FBIT21_MASK                           0x200000

#define CAN2_F1BANK1_FBIT22_OFFSET                         22
#define CAN2_F1BANK1_FBIT22_MASK                           0x400000

#define CAN2_F1BANK1_FBIT23_OFFSET                         23
#define CAN2_F1BANK1_FBIT23_MASK                           0x800000

#define CAN2_F1BANK1_FBIT24_OFFSET                         24
#define CAN2_F1BANK1_FBIT24_MASK                           0x1000000

#define CAN2_F1BANK1_FBIT25_OFFSET                         25
#define CAN2_F1BANK1_FBIT25_MASK                           0x2000000

#define CAN2_F1BANK1_FBIT26_OFFSET                         26
#define CAN2_F1BANK1_FBIT26_MASK                           0x4000000

#define CAN2_F1BANK1_FBIT27_OFFSET                         27
#define CAN2_F1BANK1_FBIT27_MASK                           0x8000000

#define CAN2_F1BANK1_FBIT28_OFFSET                         28
#define CAN2_F1BANK1_FBIT28_MASK                           0x10000000

#define CAN2_F1BANK1_FBIT29_OFFSET                         29
#define CAN2_F1BANK1_FBIT29_MASK                           0x20000000

#define CAN2_F1BANK1_FBIT30_OFFSET                         30
#define CAN2_F1BANK1_FBIT30_MASK                           0x40000000

#define CAN2_F1BANK1_FBIT31_OFFSET                         31
#define CAN2_F1BANK1_FBIT31_MASK                           0x80000000

#define CAN2_F1BANK2_FBIT0_OFFSET                          0
#define CAN2_F1BANK2_FBIT0_MASK                            1

#define CAN2_F1BANK2_FBIT1_OFFSET                          1
#define CAN2_F1BANK2_FBIT1_MASK                            2

#define CAN2_F1BANK2_FBIT2_OFFSET                          2
#define CAN2_F1BANK2_FBIT2_MASK                            4

#define CAN2_F1BANK2_FBIT3_OFFSET                          3
#define CAN2_F1BANK2_FBIT3_MASK                            8

#define CAN2_F1BANK2_FBIT4_OFFSET                          4
#define CAN2_F1BANK2_FBIT4_MASK                            0x10

#define CAN2_F1BANK2_FBIT5_OFFSET                          5
#define CAN2_F1BANK2_FBIT5_MASK                            0x20

#define CAN2_F1BANK2_FBIT6_OFFSET                          6
#define CAN2_F1BANK2_FBIT6_MASK                            0x40

#define CAN2_F1BANK2_FBIT7_OFFSET                          7
#define CAN2_F1BANK2_FBIT7_MASK                            0x80

#define CAN2_F1BANK2_FBIT8_OFFSET                          8
#define CAN2_F1BANK2_FBIT8_MASK                            0x100

#define CAN2_F1BANK2_FBIT9_OFFSET                          9
#define CAN2_F1BANK2_FBIT9_MASK                            0x200

#define CAN2_F1BANK2_FBIT10_OFFSET                         10
#define CAN2_F1BANK2_FBIT10_MASK                           0x400

#define CAN2_F1BANK2_FBIT11_OFFSET                         11
#define CAN2_F1BANK2_FBIT11_MASK                           0x800

#define CAN2_F1BANK2_FBIT12_OFFSET                         12
#define CAN2_F1BANK2_FBIT12_MASK                           0x1000

#define CAN2_F1BANK2_FBIT13_OFFSET                         13
#define CAN2_F1BANK2_FBIT13_MASK                           0x2000

#define CAN2_F1BANK2_FBIT14_OFFSET                         14
#define CAN2_F1BANK2_FBIT14_MASK                           0x4000

#define CAN2_F1BANK2_FBIT15_OFFSET                         15
#define CAN2_F1BANK2_FBIT15_MASK                           0x8000

#define CAN2_F1BANK2_FBIT16_OFFSET                         16
#define CAN2_F1BANK2_FBIT16_MASK                           0x10000

#define CAN2_F1BANK2_FBIT17_OFFSET                         17
#define CAN2_F1BANK2_FBIT17_MASK                           0x20000

#define CAN2_F1BANK2_FBIT18_OFFSET                         18
#define CAN2_F1BANK2_FBIT18_MASK                           0x40000

#define CAN2_F1BANK2_FBIT19_OFFSET                         19
#define CAN2_F1BANK2_FBIT19_MASK                           0x80000

#define CAN2_F1BANK2_FBIT20_OFFSET                         20
#define CAN2_F1BANK2_FBIT20_MASK                           0x100000

#define CAN2_F1BANK2_FBIT21_OFFSET                         21
#define CAN2_F1BANK2_FBIT21_MASK                           0x200000

#define CAN2_F1BANK2_FBIT22_OFFSET                         22
#define CAN2_F1BANK2_FBIT22_MASK                           0x400000

#define CAN2_F1BANK2_FBIT23_OFFSET                         23
#define CAN2_F1BANK2_FBIT23_MASK                           0x800000

#define CAN2_F1BANK2_FBIT24_OFFSET                         24
#define CAN2_F1BANK2_FBIT24_MASK                           0x1000000

#define CAN2_F1BANK2_FBIT25_OFFSET                         25
#define CAN2_F1BANK2_FBIT25_MASK                           0x2000000

#define CAN2_F1BANK2_FBIT26_OFFSET                         26
#define CAN2_F1BANK2_FBIT26_MASK                           0x4000000

#define CAN2_F1BANK2_FBIT27_OFFSET                         27
#define CAN2_F1BANK2_FBIT27_MASK                           0x8000000

#define CAN2_F1BANK2_FBIT28_OFFSET                         28
#define CAN2_F1BANK2_FBIT28_MASK                           0x10000000

#define CAN2_F1BANK2_FBIT29_OFFSET                         29
#define CAN2_F1BANK2_FBIT29_MASK                           0x20000000

#define CAN2_F1BANK2_FBIT30_OFFSET                         30
#define CAN2_F1BANK2_FBIT30_MASK                           0x40000000

#define CAN2_F1BANK2_FBIT31_OFFSET                         31
#define CAN2_F1BANK2_FBIT31_MASK                           0x80000000

#define CAN2_F2BANK1_FBIT0_OFFSET                          0
#define CAN2_F2BANK1_FBIT0_MASK                            1

#define CAN2_F2BANK1_FBIT1_OFFSET                          1
#define CAN2_F2BANK1_FBIT1_MASK                            2

#define CAN2_F2BANK1_FBIT2_OFFSET                          2
#define CAN2_F2BANK1_FBIT2_MASK                            4

#define CAN2_F2BANK1_FBIT3_OFFSET                          3
#define CAN2_F2BANK1_FBIT3_MASK                            8

#define CAN2_F2BANK1_FBIT4_OFFSET                          4
#define CAN2_F2BANK1_FBIT4_MASK                            0x10

#define CAN2_F2BANK1_FBIT5_OFFSET                          5
#define CAN2_F2BANK1_FBIT5_MASK                            0x20

#define CAN2_F2BANK1_FBIT6_OFFSET                          6
#define CAN2_F2BANK1_FBIT6_MASK                            0x40

#define CAN2_F2BANK1_FBIT7_OFFSET                          7
#define CAN2_F2BANK1_FBIT7_MASK                            0x80

#define CAN2_F2BANK1_FBIT8_OFFSET                          8
#define CAN2_F2BANK1_FBIT8_MASK                            0x100

#define CAN2_F2BANK1_FBIT9_OFFSET                          9
#define CAN2_F2BANK1_FBIT9_MASK                            0x200

#define CAN2_F2BANK1_FBIT10_OFFSET                         10
#define CAN2_F2BANK1_FBIT10_MASK                           0x400

#define CAN2_F2BANK1_FBIT11_OFFSET                         11
#define CAN2_F2BANK1_FBIT11_MASK                           0x800

#define CAN2_F2BANK1_FBIT12_OFFSET                         12
#define CAN2_F2BANK1_FBIT12_MASK                           0x1000

#define CAN2_F2BANK1_FBIT13_OFFSET                         13
#define CAN2_F2BANK1_FBIT13_MASK                           0x2000

#define CAN2_F2BANK1_FBIT14_OFFSET                         14
#define CAN2_F2BANK1_FBIT14_MASK                           0x4000

#define CAN2_F2BANK1_FBIT15_OFFSET                         15
#define CAN2_F2BANK1_FBIT15_MASK                           0x8000

#define CAN2_F2BANK1_FBIT16_OFFSET                         16
#define CAN2_F2BANK1_FBIT16_MASK                           0x10000

#define CAN2_F2BANK1_FBIT17_OFFSET                         17
#define CAN2_F2BANK1_FBIT17_MASK                           0x20000

#define CAN2_F2BANK1_FBIT18_OFFSET                         18
#define CAN2_F2BANK1_FBIT18_MASK                           0x40000

#define CAN2_F2BANK1_FBIT19_OFFSET                         19
#define CAN2_F2BANK1_FBIT19_MASK                           0x80000

#define CAN2_F2BANK1_FBIT20_OFFSET                         20
#define CAN2_F2BANK1_FBIT20_MASK                           0x100000

#define CAN2_F2BANK1_FBIT21_OFFSET                         21
#define CAN2_F2BANK1_FBIT21_MASK                           0x200000

#define CAN2_F2BANK1_FBIT22_OFFSET                         22
#define CAN2_F2BANK1_FBIT22_MASK                           0x400000

#define CAN2_F2BANK1_FBIT23_OFFSET                         23
#define CAN2_F2BANK1_FBIT23_MASK                           0x800000

#define CAN2_F2BANK1_FBIT24_OFFSET                         24
#define CAN2_F2BANK1_FBIT24_MASK                           0x1000000

#define CAN2_F2BANK1_FBIT25_OFFSET                         25
#define CAN2_F2BANK1_FBIT25_MASK                           0x2000000

#define CAN2_F2BANK1_FBIT26_OFFSET                         26
#define CAN2_F2BANK1_FBIT26_MASK                           0x4000000

#define CAN2_F2BANK1_FBIT27_OFFSET                         27
#define CAN2_F2BANK1_FBIT27_MASK                           0x8000000

#define CAN2_F2BANK1_FBIT28_OFFSET                         28
#define CAN2_F2BANK1_FBIT28_MASK                           0x10000000

#define CAN2_F2BANK1_FBIT29_OFFSET                         29
#define CAN2_F2BANK1_FBIT29_MASK                           0x20000000

#define CAN2_F2BANK1_FBIT30_OFFSET                         30
#define CAN2_F2BANK1_FBIT30_MASK                           0x40000000

#define CAN2_F2BANK1_FBIT31_OFFSET                         31
#define CAN2_F2BANK1_FBIT31_MASK                           0x80000000

#define CAN2_F2BANK2_FBIT0_OFFSET                          0
#define CAN2_F2BANK2_FBIT0_MASK                            1

#define CAN2_F2BANK2_FBIT1_OFFSET                          1
#define CAN2_F2BANK2_FBIT1_MASK                            2

#define CAN2_F2BANK2_FBIT2_OFFSET                          2
#define CAN2_F2BANK2_FBIT2_MASK                            4

#define CAN2_F2BANK2_FBIT3_OFFSET                          3
#define CAN2_F2BANK2_FBIT3_MASK                            8

#define CAN2_F2BANK2_FBIT4_OFFSET                          4
#define CAN2_F2BANK2_FBIT4_MASK                            0x10

#define CAN2_F2BANK2_FBIT5_OFFSET                          5
#define CAN2_F2BANK2_FBIT5_MASK                            0x20

#define CAN2_F2BANK2_FBIT6_OFFSET                          6
#define CAN2_F2BANK2_FBIT6_MASK                            0x40

#define CAN2_F2BANK2_FBIT7_OFFSET                          7
#define CAN2_F2BANK2_FBIT7_MASK                            0x80

#define CAN2_F2BANK2_FBIT8_OFFSET                          8
#define CAN2_F2BANK2_FBIT8_MASK                            0x100

#define CAN2_F2BANK2_FBIT9_OFFSET                          9
#define CAN2_F2BANK2_FBIT9_MASK                            0x200

#define CAN2_F2BANK2_FBIT10_OFFSET                         10
#define CAN2_F2BANK2_FBIT10_MASK                           0x400

#define CAN2_F2BANK2_FBIT11_OFFSET                         11
#define CAN2_F2BANK2_FBIT11_MASK                           0x800

#define CAN2_F2BANK2_FBIT12_OFFSET                         12
#define CAN2_F2BANK2_FBIT12_MASK                           0x1000

#define CAN2_F2BANK2_FBIT13_OFFSET                         13
#define CAN2_F2BANK2_FBIT13_MASK                           0x2000

#define CAN2_F2BANK2_FBIT14_OFFSET                         14
#define CAN2_F2BANK2_FBIT14_MASK                           0x4000

#define CAN2_F2BANK2_FBIT15_OFFSET                         15
#define CAN2_F2BANK2_FBIT15_MASK                           0x8000

#define CAN2_F2BANK2_FBIT16_OFFSET                         16
#define CAN2_F2BANK2_FBIT16_MASK                           0x10000

#define CAN2_F2BANK2_FBIT17_OFFSET                         17
#define CAN2_F2BANK2_FBIT17_MASK                           0x20000

#define CAN2_F2BANK2_FBIT18_OFFSET                         18
#define CAN2_F2BANK2_FBIT18_MASK                           0x40000

#define CAN2_F2BANK2_FBIT19_OFFSET                         19
#define CAN2_F2BANK2_FBIT19_MASK                           0x80000

#define CAN2_F2BANK2_FBIT20_OFFSET                         20
#define CAN2_F2BANK2_FBIT20_MASK                           0x100000

#define CAN2_F2BANK2_FBIT21_OFFSET                         21
#define CAN2_F2BANK2_FBIT21_MASK                           0x200000

#define CAN2_F2BANK2_FBIT22_OFFSET                         22
#define CAN2_F2BANK2_FBIT22_MASK                           0x400000

#define CAN2_F2BANK2_FBIT23_OFFSET                         23
#define CAN2_F2BANK2_FBIT23_MASK                           0x800000

#define CAN2_F2BANK2_FBIT24_OFFSET                         24
#define CAN2_F2BANK2_FBIT24_MASK                           0x1000000

#define CAN2_F2BANK2_FBIT25_OFFSET                         25
#define CAN2_F2BANK2_FBIT25_MASK                           0x2000000

#define CAN2_F2BANK2_FBIT26_OFFSET                         26
#define CAN2_F2BANK2_FBIT26_MASK                           0x4000000

#define CAN2_F2BANK2_FBIT27_OFFSET                         27
#define CAN2_F2BANK2_FBIT27_MASK                           0x8000000

#define CAN2_F2BANK2_FBIT28_OFFSET                         28
#define CAN2_F2BANK2_FBIT28_MASK                           0x10000000

#define CAN2_F2BANK2_FBIT29_OFFSET                         29
#define CAN2_F2BANK2_FBIT29_MASK                           0x20000000

#define CAN2_F2BANK2_FBIT30_OFFSET                         30
#define CAN2_F2BANK2_FBIT30_MASK                           0x40000000

#define CAN2_F2BANK2_FBIT31_OFFSET                         31
#define CAN2_F2BANK2_FBIT31_MASK                           0x80000000

#define CAN2_F3BANK1_FBIT0_OFFSET                          0
#define CAN2_F3BANK1_FBIT0_MASK                            1

#define CAN2_F3BANK1_FBIT1_OFFSET                          1
#define CAN2_F3BANK1_FBIT1_MASK                            2

#define CAN2_F3BANK1_FBIT2_OFFSET                          2
#define CAN2_F3BANK1_FBIT2_MASK                            4

#define CAN2_F3BANK1_FBIT3_OFFSET                          3
#define CAN2_F3BANK1_FBIT3_MASK                            8

#define CAN2_F3BANK1_FBIT4_OFFSET                          4
#define CAN2_F3BANK1_FBIT4_MASK                            0x10

#define CAN2_F3BANK1_FBIT5_OFFSET                          5
#define CAN2_F3BANK1_FBIT5_MASK                            0x20

#define CAN2_F3BANK1_FBIT6_OFFSET                          6
#define CAN2_F3BANK1_FBIT6_MASK                            0x40

#define CAN2_F3BANK1_FBIT7_OFFSET                          7
#define CAN2_F3BANK1_FBIT7_MASK                            0x80

#define CAN2_F3BANK1_FBIT8_OFFSET                          8
#define CAN2_F3BANK1_FBIT8_MASK                            0x100

#define CAN2_F3BANK1_FBIT9_OFFSET                          9
#define CAN2_F3BANK1_FBIT9_MASK                            0x200

#define CAN2_F3BANK1_FBIT10_OFFSET                         10
#define CAN2_F3BANK1_FBIT10_MASK                           0x400

#define CAN2_F3BANK1_FBIT11_OFFSET                         11
#define CAN2_F3BANK1_FBIT11_MASK                           0x800

#define CAN2_F3BANK1_FBIT12_OFFSET                         12
#define CAN2_F3BANK1_FBIT12_MASK                           0x1000

#define CAN2_F3BANK1_FBIT13_OFFSET                         13
#define CAN2_F3BANK1_FBIT13_MASK                           0x2000

#define CAN2_F3BANK1_FBIT14_OFFSET                         14
#define CAN2_F3BANK1_FBIT14_MASK                           0x4000

#define CAN2_F3BANK1_FBIT15_OFFSET                         15
#define CAN2_F3BANK1_FBIT15_MASK                           0x8000

#define CAN2_F3BANK1_FBIT16_OFFSET                         16
#define CAN2_F3BANK1_FBIT16_MASK                           0x10000

#define CAN2_F3BANK1_FBIT17_OFFSET                         17
#define CAN2_F3BANK1_FBIT17_MASK                           0x20000

#define CAN2_F3BANK1_FBIT18_OFFSET                         18
#define CAN2_F3BANK1_FBIT18_MASK                           0x40000

#define CAN2_F3BANK1_FBIT19_OFFSET                         19
#define CAN2_F3BANK1_FBIT19_MASK                           0x80000

#define CAN2_F3BANK1_FBIT20_OFFSET                         20
#define CAN2_F3BANK1_FBIT20_MASK                           0x100000

#define CAN2_F3BANK1_FBIT21_OFFSET                         21
#define CAN2_F3BANK1_FBIT21_MASK                           0x200000

#define CAN2_F3BANK1_FBIT22_OFFSET                         22
#define CAN2_F3BANK1_FBIT22_MASK                           0x400000

#define CAN2_F3BANK1_FBIT23_OFFSET                         23
#define CAN2_F3BANK1_FBIT23_MASK                           0x800000

#define CAN2_F3BANK1_FBIT24_OFFSET                         24
#define CAN2_F3BANK1_FBIT24_MASK                           0x1000000

#define CAN2_F3BANK1_FBIT25_OFFSET                         25
#define CAN2_F3BANK1_FBIT25_MASK                           0x2000000

#define CAN2_F3BANK1_FBIT26_OFFSET                         26
#define CAN2_F3BANK1_FBIT26_MASK                           0x4000000

#define CAN2_F3BANK1_FBIT27_OFFSET                         27
#define CAN2_F3BANK1_FBIT27_MASK                           0x8000000

#define CAN2_F3BANK1_FBIT28_OFFSET                         28
#define CAN2_F3BANK1_FBIT28_MASK                           0x10000000

#define CAN2_F3BANK1_FBIT29_OFFSET                         29
#define CAN2_F3BANK1_FBIT29_MASK                           0x20000000

#define CAN2_F3BANK1_FBIT30_OFFSET                         30
#define CAN2_F3BANK1_FBIT30_MASK                           0x40000000

#define CAN2_F3BANK1_FBIT31_OFFSET                         31
#define CAN2_F3BANK1_FBIT31_MASK                           0x80000000

#define CAN2_F3BANK2_FBIT0_OFFSET                          0
#define CAN2_F3BANK2_FBIT0_MASK                            1

#define CAN2_F3BANK2_FBIT1_OFFSET                          1
#define CAN2_F3BANK2_FBIT1_MASK                            2

#define CAN2_F3BANK2_FBIT2_OFFSET                          2
#define CAN2_F3BANK2_FBIT2_MASK                            4

#define CAN2_F3BANK2_FBIT3_OFFSET                          3
#define CAN2_F3BANK2_FBIT3_MASK                            8

#define CAN2_F3BANK2_FBIT4_OFFSET                          4
#define CAN2_F3BANK2_FBIT4_MASK                            0x10

#define CAN2_F3BANK2_FBIT5_OFFSET                          5
#define CAN2_F3BANK2_FBIT5_MASK                            0x20

#define CAN2_F3BANK2_FBIT6_OFFSET                          6
#define CAN2_F3BANK2_FBIT6_MASK                            0x40

#define CAN2_F3BANK2_FBIT7_OFFSET                          7
#define CAN2_F3BANK2_FBIT7_MASK                            0x80

#define CAN2_F3BANK2_FBIT8_OFFSET                          8
#define CAN2_F3BANK2_FBIT8_MASK                            0x100

#define CAN2_F3BANK2_FBIT9_OFFSET                          9
#define CAN2_F3BANK2_FBIT9_MASK                            0x200

#define CAN2_F3BANK2_FBIT10_OFFSET                         10
#define CAN2_F3BANK2_FBIT10_MASK                           0x400

#define CAN2_F3BANK2_FBIT11_OFFSET                         11
#define CAN2_F3BANK2_FBIT11_MASK                           0x800

#define CAN2_F3BANK2_FBIT12_OFFSET                         12
#define CAN2_F3BANK2_FBIT12_MASK                           0x1000

#define CAN2_F3BANK2_FBIT13_OFFSET                         13
#define CAN2_F3BANK2_FBIT13_MASK                           0x2000

#define CAN2_F3BANK2_FBIT14_OFFSET                         14
#define CAN2_F3BANK2_FBIT14_MASK                           0x4000

#define CAN2_F3BANK2_FBIT15_OFFSET                         15
#define CAN2_F3BANK2_FBIT15_MASK                           0x8000

#define CAN2_F3BANK2_FBIT16_OFFSET                         16
#define CAN2_F3BANK2_FBIT16_MASK                           0x10000

#define CAN2_F3BANK2_FBIT17_OFFSET                         17
#define CAN2_F3BANK2_FBIT17_MASK                           0x20000

#define CAN2_F3BANK2_FBIT18_OFFSET                         18
#define CAN2_F3BANK2_FBIT18_MASK                           0x40000

#define CAN2_F3BANK2_FBIT19_OFFSET                         19
#define CAN2_F3BANK2_FBIT19_MASK                           0x80000

#define CAN2_F3BANK2_FBIT20_OFFSET                         20
#define CAN2_F3BANK2_FBIT20_MASK                           0x100000

#define CAN2_F3BANK2_FBIT21_OFFSET                         21
#define CAN2_F3BANK2_FBIT21_MASK                           0x200000

#define CAN2_F3BANK2_FBIT22_OFFSET                         22
#define CAN2_F3BANK2_FBIT22_MASK                           0x400000

#define CAN2_F3BANK2_FBIT23_OFFSET                         23
#define CAN2_F3BANK2_FBIT23_MASK                           0x800000

#define CAN2_F3BANK2_FBIT24_OFFSET                         24
#define CAN2_F3BANK2_FBIT24_MASK                           0x1000000

#define CAN2_F3BANK2_FBIT25_OFFSET                         25
#define CAN2_F3BANK2_FBIT25_MASK                           0x2000000

#define CAN2_F3BANK2_FBIT26_OFFSET                         26
#define CAN2_F3BANK2_FBIT26_MASK                           0x4000000

#define CAN2_F3BANK2_FBIT27_OFFSET                         27
#define CAN2_F3BANK2_FBIT27_MASK                           0x8000000

#define CAN2_F3BANK2_FBIT28_OFFSET                         28
#define CAN2_F3BANK2_FBIT28_MASK                           0x10000000

#define CAN2_F3BANK2_FBIT29_OFFSET                         29
#define CAN2_F3BANK2_FBIT29_MASK                           0x20000000

#define CAN2_F3BANK2_FBIT30_OFFSET                         30
#define CAN2_F3BANK2_FBIT30_MASK                           0x40000000

#define CAN2_F3BANK2_FBIT31_OFFSET                         31
#define CAN2_F3BANK2_FBIT31_MASK                           0x80000000

#define CAN2_F4BANK1_FBIT0_OFFSET                          0
#define CAN2_F4BANK1_FBIT0_MASK                            1

#define CAN2_F4BANK1_FBIT1_OFFSET                          1
#define CAN2_F4BANK1_FBIT1_MASK                            2

#define CAN2_F4BANK1_FBIT2_OFFSET                          2
#define CAN2_F4BANK1_FBIT2_MASK                            4

#define CAN2_F4BANK1_FBIT3_OFFSET                          3
#define CAN2_F4BANK1_FBIT3_MASK                            8

#define CAN2_F4BANK1_FBIT4_OFFSET                          4
#define CAN2_F4BANK1_FBIT4_MASK                            0x10

#define CAN2_F4BANK1_FBIT5_OFFSET                          5
#define CAN2_F4BANK1_FBIT5_MASK                            0x20

#define CAN2_F4BANK1_FBIT6_OFFSET                          6
#define CAN2_F4BANK1_FBIT6_MASK                            0x40

#define CAN2_F4BANK1_FBIT7_OFFSET                          7
#define CAN2_F4BANK1_FBIT7_MASK                            0x80

#define CAN2_F4BANK1_FBIT8_OFFSET                          8
#define CAN2_F4BANK1_FBIT8_MASK                            0x100

#define CAN2_F4BANK1_FBIT9_OFFSET                          9
#define CAN2_F4BANK1_FBIT9_MASK                            0x200

#define CAN2_F4BANK1_FBIT10_OFFSET                         10
#define CAN2_F4BANK1_FBIT10_MASK                           0x400

#define CAN2_F4BANK1_FBIT11_OFFSET                         11
#define CAN2_F4BANK1_FBIT11_MASK                           0x800

#define CAN2_F4BANK1_FBIT12_OFFSET                         12
#define CAN2_F4BANK1_FBIT12_MASK                           0x1000

#define CAN2_F4BANK1_FBIT13_OFFSET                         13
#define CAN2_F4BANK1_FBIT13_MASK                           0x2000

#define CAN2_F4BANK1_FBIT14_OFFSET                         14
#define CAN2_F4BANK1_FBIT14_MASK                           0x4000

#define CAN2_F4BANK1_FBIT15_OFFSET                         15
#define CAN2_F4BANK1_FBIT15_MASK                           0x8000

#define CAN2_F4BANK1_FBIT16_OFFSET                         16
#define CAN2_F4BANK1_FBIT16_MASK                           0x10000

#define CAN2_F4BANK1_FBIT17_OFFSET                         17
#define CAN2_F4BANK1_FBIT17_MASK                           0x20000

#define CAN2_F4BANK1_FBIT18_OFFSET                         18
#define CAN2_F4BANK1_FBIT18_MASK                           0x40000

#define CAN2_F4BANK1_FBIT19_OFFSET                         19
#define CAN2_F4BANK1_FBIT19_MASK                           0x80000

#define CAN2_F4BANK1_FBIT20_OFFSET                         20
#define CAN2_F4BANK1_FBIT20_MASK                           0x100000

#define CAN2_F4BANK1_FBIT21_OFFSET                         21
#define CAN2_F4BANK1_FBIT21_MASK                           0x200000

#define CAN2_F4BANK1_FBIT22_OFFSET                         22
#define CAN2_F4BANK1_FBIT22_MASK                           0x400000

#define CAN2_F4BANK1_FBIT23_OFFSET                         23
#define CAN2_F4BANK1_FBIT23_MASK                           0x800000

#define CAN2_F4BANK1_FBIT24_OFFSET                         24
#define CAN2_F4BANK1_FBIT24_MASK                           0x1000000

#define CAN2_F4BANK1_FBIT25_OFFSET                         25
#define CAN2_F4BANK1_FBIT25_MASK                           0x2000000

#define CAN2_F4BANK1_FBIT26_OFFSET                         26
#define CAN2_F4BANK1_FBIT26_MASK                           0x4000000

#define CAN2_F4BANK1_FBIT27_OFFSET                         27
#define CAN2_F4BANK1_FBIT27_MASK                           0x8000000

#define CAN2_F4BANK1_FBIT28_OFFSET                         28
#define CAN2_F4BANK1_FBIT28_MASK                           0x10000000

#define CAN2_F4BANK1_FBIT29_OFFSET                         29
#define CAN2_F4BANK1_FBIT29_MASK                           0x20000000

#define CAN2_F4BANK1_FBIT30_OFFSET                         30
#define CAN2_F4BANK1_FBIT30_MASK                           0x40000000

#define CAN2_F4BANK1_FBIT31_OFFSET                         31
#define CAN2_F4BANK1_FBIT31_MASK                           0x80000000

#define CAN2_F4BANK2_FBIT0_OFFSET                          0
#define CAN2_F4BANK2_FBIT0_MASK                            1

#define CAN2_F4BANK2_FBIT1_OFFSET                          1
#define CAN2_F4BANK2_FBIT1_MASK                            2

#define CAN2_F4BANK2_FBIT2_OFFSET                          2
#define CAN2_F4BANK2_FBIT2_MASK                            4

#define CAN2_F4BANK2_FBIT3_OFFSET                          3
#define CAN2_F4BANK2_FBIT3_MASK                            8

#define CAN2_F4BANK2_FBIT4_OFFSET                          4
#define CAN2_F4BANK2_FBIT4_MASK                            0x10

#define CAN2_F4BANK2_FBIT5_OFFSET                          5
#define CAN2_F4BANK2_FBIT5_MASK                            0x20

#define CAN2_F4BANK2_FBIT6_OFFSET                          6
#define CAN2_F4BANK2_FBIT6_MASK                            0x40

#define CAN2_F4BANK2_FBIT7_OFFSET                          7
#define CAN2_F4BANK2_FBIT7_MASK                            0x80

#define CAN2_F4BANK2_FBIT8_OFFSET                          8
#define CAN2_F4BANK2_FBIT8_MASK                            0x100

#define CAN2_F4BANK2_FBIT9_OFFSET                          9
#define CAN2_F4BANK2_FBIT9_MASK                            0x200

#define CAN2_F4BANK2_FBIT10_OFFSET                         10
#define CAN2_F4BANK2_FBIT10_MASK                           0x400

#define CAN2_F4BANK2_FBIT11_OFFSET                         11
#define CAN2_F4BANK2_FBIT11_MASK                           0x800

#define CAN2_F4BANK2_FBIT12_OFFSET                         12
#define CAN2_F4BANK2_FBIT12_MASK                           0x1000

#define CAN2_F4BANK2_FBIT13_OFFSET                         13
#define CAN2_F4BANK2_FBIT13_MASK                           0x2000

#define CAN2_F4BANK2_FBIT14_OFFSET                         14
#define CAN2_F4BANK2_FBIT14_MASK                           0x4000

#define CAN2_F4BANK2_FBIT15_OFFSET                         15
#define CAN2_F4BANK2_FBIT15_MASK                           0x8000

#define CAN2_F4BANK2_FBIT16_OFFSET                         16
#define CAN2_F4BANK2_FBIT16_MASK                           0x10000

#define CAN2_F4BANK2_FBIT17_OFFSET                         17
#define CAN2_F4BANK2_FBIT17_MASK                           0x20000

#define CAN2_F4BANK2_FBIT18_OFFSET                         18
#define CAN2_F4BANK2_FBIT18_MASK                           0x40000

#define CAN2_F4BANK2_FBIT19_OFFSET                         19
#define CAN2_F4BANK2_FBIT19_MASK                           0x80000

#define CAN2_F4BANK2_FBIT20_OFFSET                         20
#define CAN2_F4BANK2_FBIT20_MASK                           0x100000

#define CAN2_F4BANK2_FBIT21_OFFSET                         21
#define CAN2_F4BANK2_FBIT21_MASK                           0x200000

#define CAN2_F4BANK2_FBIT22_OFFSET                         22
#define CAN2_F4BANK2_FBIT22_MASK                           0x400000

#define CAN2_F4BANK2_FBIT23_OFFSET                         23
#define CAN2_F4BANK2_FBIT23_MASK                           0x800000

#define CAN2_F4BANK2_FBIT24_OFFSET                         24
#define CAN2_F4BANK2_FBIT24_MASK                           0x1000000

#define CAN2_F4BANK2_FBIT25_OFFSET                         25
#define CAN2_F4BANK2_FBIT25_MASK                           0x2000000

#define CAN2_F4BANK2_FBIT26_OFFSET                         26
#define CAN2_F4BANK2_FBIT26_MASK                           0x4000000

#define CAN2_F4BANK2_FBIT27_OFFSET                         27
#define CAN2_F4BANK2_FBIT27_MASK                           0x8000000

#define CAN2_F4BANK2_FBIT28_OFFSET                         28
#define CAN2_F4BANK2_FBIT28_MASK                           0x10000000

#define CAN2_F4BANK2_FBIT29_OFFSET                         29
#define CAN2_F4BANK2_FBIT29_MASK                           0x20000000

#define CAN2_F4BANK2_FBIT30_OFFSET                         30
#define CAN2_F4BANK2_FBIT30_MASK                           0x40000000

#define CAN2_F4BANK2_FBIT31_OFFSET                         31
#define CAN2_F4BANK2_FBIT31_MASK                           0x80000000

#define CAN2_F5BANK1_FBIT0_OFFSET                          0
#define CAN2_F5BANK1_FBIT0_MASK                            1

#define CAN2_F5BANK1_FBIT1_OFFSET                          1
#define CAN2_F5BANK1_FBIT1_MASK                            2

#define CAN2_F5BANK1_FBIT2_OFFSET                          2
#define CAN2_F5BANK1_FBIT2_MASK                            4

#define CAN2_F5BANK1_FBIT3_OFFSET                          3
#define CAN2_F5BANK1_FBIT3_MASK                            8

#define CAN2_F5BANK1_FBIT4_OFFSET                          4
#define CAN2_F5BANK1_FBIT4_MASK                            0x10

#define CAN2_F5BANK1_FBIT5_OFFSET                          5
#define CAN2_F5BANK1_FBIT5_MASK                            0x20

#define CAN2_F5BANK1_FBIT6_OFFSET                          6
#define CAN2_F5BANK1_FBIT6_MASK                            0x40

#define CAN2_F5BANK1_FBIT7_OFFSET                          7
#define CAN2_F5BANK1_FBIT7_MASK                            0x80

#define CAN2_F5BANK1_FBIT8_OFFSET                          8
#define CAN2_F5BANK1_FBIT8_MASK                            0x100

#define CAN2_F5BANK1_FBIT9_OFFSET                          9
#define CAN2_F5BANK1_FBIT9_MASK                            0x200

#define CAN2_F5BANK1_FBIT10_OFFSET                         10
#define CAN2_F5BANK1_FBIT10_MASK                           0x400

#define CAN2_F5BANK1_FBIT11_OFFSET                         11
#define CAN2_F5BANK1_FBIT11_MASK                           0x800

#define CAN2_F5BANK1_FBIT12_OFFSET                         12
#define CAN2_F5BANK1_FBIT12_MASK                           0x1000

#define CAN2_F5BANK1_FBIT13_OFFSET                         13
#define CAN2_F5BANK1_FBIT13_MASK                           0x2000

#define CAN2_F5BANK1_FBIT14_OFFSET                         14
#define CAN2_F5BANK1_FBIT14_MASK                           0x4000

#define CAN2_F5BANK1_FBIT15_OFFSET                         15
#define CAN2_F5BANK1_FBIT15_MASK                           0x8000

#define CAN2_F5BANK1_FBIT16_OFFSET                         16
#define CAN2_F5BANK1_FBIT16_MASK                           0x10000

#define CAN2_F5BANK1_FBIT17_OFFSET                         17
#define CAN2_F5BANK1_FBIT17_MASK                           0x20000

#define CAN2_F5BANK1_FBIT18_OFFSET                         18
#define CAN2_F5BANK1_FBIT18_MASK                           0x40000

#define CAN2_F5BANK1_FBIT19_OFFSET                         19
#define CAN2_F5BANK1_FBIT19_MASK                           0x80000

#define CAN2_F5BANK1_FBIT20_OFFSET                         20
#define CAN2_F5BANK1_FBIT20_MASK                           0x100000

#define CAN2_F5BANK1_FBIT21_OFFSET                         21
#define CAN2_F5BANK1_FBIT21_MASK                           0x200000

#define CAN2_F5BANK1_FBIT22_OFFSET                         22
#define CAN2_F5BANK1_FBIT22_MASK                           0x400000

#define CAN2_F5BANK1_FBIT23_OFFSET                         23
#define CAN2_F5BANK1_FBIT23_MASK                           0x800000

#define CAN2_F5BANK1_FBIT24_OFFSET                         24
#define CAN2_F5BANK1_FBIT24_MASK                           0x1000000

#define CAN2_F5BANK1_FBIT25_OFFSET                         25
#define CAN2_F5BANK1_FBIT25_MASK                           0x2000000

#define CAN2_F5BANK1_FBIT26_OFFSET                         26
#define CAN2_F5BANK1_FBIT26_MASK                           0x4000000

#define CAN2_F5BANK1_FBIT27_OFFSET                         27
#define CAN2_F5BANK1_FBIT27_MASK                           0x8000000

#define CAN2_F5BANK1_FBIT28_OFFSET                         28
#define CAN2_F5BANK1_FBIT28_MASK                           0x10000000

#define CAN2_F5BANK1_FBIT29_OFFSET                         29
#define CAN2_F5BANK1_FBIT29_MASK                           0x20000000

#define CAN2_F5BANK1_FBIT30_OFFSET                         30
#define CAN2_F5BANK1_FBIT30_MASK                           0x40000000

#define CAN2_F5BANK1_FBIT31_OFFSET                         31
#define CAN2_F5BANK1_FBIT31_MASK                           0x80000000

#define CAN2_F5BANK2_FBIT0_OFFSET                          0
#define CAN2_F5BANK2_FBIT0_MASK                            1

#define CAN2_F5BANK2_FBIT1_OFFSET                          1
#define CAN2_F5BANK2_FBIT1_MASK                            2

#define CAN2_F5BANK2_FBIT2_OFFSET                          2
#define CAN2_F5BANK2_FBIT2_MASK                            4

#define CAN2_F5BANK2_FBIT3_OFFSET                          3
#define CAN2_F5BANK2_FBIT3_MASK                            8

#define CAN2_F5BANK2_FBIT4_OFFSET                          4
#define CAN2_F5BANK2_FBIT4_MASK                            0x10

#define CAN2_F5BANK2_FBIT5_OFFSET                          5
#define CAN2_F5BANK2_FBIT5_MASK                            0x20

#define CAN2_F5BANK2_FBIT6_OFFSET                          6
#define CAN2_F5BANK2_FBIT6_MASK                            0x40

#define CAN2_F5BANK2_FBIT7_OFFSET                          7
#define CAN2_F5BANK2_FBIT7_MASK                            0x80

#define CAN2_F5BANK2_FBIT8_OFFSET                          8
#define CAN2_F5BANK2_FBIT8_MASK                            0x100

#define CAN2_F5BANK2_FBIT9_OFFSET                          9
#define CAN2_F5BANK2_FBIT9_MASK                            0x200

#define CAN2_F5BANK2_FBIT10_OFFSET                         10
#define CAN2_F5BANK2_FBIT10_MASK                           0x400

#define CAN2_F5BANK2_FBIT11_OFFSET                         11
#define CAN2_F5BANK2_FBIT11_MASK                           0x800

#define CAN2_F5BANK2_FBIT12_OFFSET                         12
#define CAN2_F5BANK2_FBIT12_MASK                           0x1000

#define CAN2_F5BANK2_FBIT13_OFFSET                         13
#define CAN2_F5BANK2_FBIT13_MASK                           0x2000

#define CAN2_F5BANK2_FBIT14_OFFSET                         14
#define CAN2_F5BANK2_FBIT14_MASK                           0x4000

#define CAN2_F5BANK2_FBIT15_OFFSET                         15
#define CAN2_F5BANK2_FBIT15_MASK                           0x8000

#define CAN2_F5BANK2_FBIT16_OFFSET                         16
#define CAN2_F5BANK2_FBIT16_MASK                           0x10000

#define CAN2_F5BANK2_FBIT17_OFFSET                         17
#define CAN2_F5BANK2_FBIT17_MASK                           0x20000

#define CAN2_F5BANK2_FBIT18_OFFSET                         18
#define CAN2_F5BANK2_FBIT18_MASK                           0x40000

#define CAN2_F5BANK2_FBIT19_OFFSET                         19
#define CAN2_F5BANK2_FBIT19_MASK                           0x80000

#define CAN2_F5BANK2_FBIT20_OFFSET                         20
#define CAN2_F5BANK2_FBIT20_MASK                           0x100000

#define CAN2_F5BANK2_FBIT21_OFFSET                         21
#define CAN2_F5BANK2_FBIT21_MASK                           0x200000

#define CAN2_F5BANK2_FBIT22_OFFSET                         22
#define CAN2_F5BANK2_FBIT22_MASK                           0x400000

#define CAN2_F5BANK2_FBIT23_OFFSET                         23
#define CAN2_F5BANK2_FBIT23_MASK                           0x800000

#define CAN2_F5BANK2_FBIT24_OFFSET                         24
#define CAN2_F5BANK2_FBIT24_MASK                           0x1000000

#define CAN2_F5BANK2_FBIT25_OFFSET                         25
#define CAN2_F5BANK2_FBIT25_MASK                           0x2000000

#define CAN2_F5BANK2_FBIT26_OFFSET                         26
#define CAN2_F5BANK2_FBIT26_MASK                           0x4000000

#define CAN2_F5BANK2_FBIT27_OFFSET                         27
#define CAN2_F5BANK2_FBIT27_MASK                           0x8000000

#define CAN2_F5BANK2_FBIT28_OFFSET                         28
#define CAN2_F5BANK2_FBIT28_MASK                           0x10000000

#define CAN2_F5BANK2_FBIT29_OFFSET                         29
#define CAN2_F5BANK2_FBIT29_MASK                           0x20000000

#define CAN2_F5BANK2_FBIT30_OFFSET                         30
#define CAN2_F5BANK2_FBIT30_MASK                           0x40000000

#define CAN2_F5BANK2_FBIT31_OFFSET                         31
#define CAN2_F5BANK2_FBIT31_MASK                           0x80000000

#define CAN2_F6BANK1_FBIT0_OFFSET                          0
#define CAN2_F6BANK1_FBIT0_MASK                            1

#define CAN2_F6BANK1_FBIT1_OFFSET                          1
#define CAN2_F6BANK1_FBIT1_MASK                            2

#define CAN2_F6BANK1_FBIT2_OFFSET                          2
#define CAN2_F6BANK1_FBIT2_MASK                            4

#define CAN2_F6BANK1_FBIT3_OFFSET                          3
#define CAN2_F6BANK1_FBIT3_MASK                            8

#define CAN2_F6BANK1_FBIT4_OFFSET                          4
#define CAN2_F6BANK1_FBIT4_MASK                            0x10

#define CAN2_F6BANK1_FBIT5_OFFSET                          5
#define CAN2_F6BANK1_FBIT5_MASK                            0x20

#define CAN2_F6BANK1_FBIT6_OFFSET                          6
#define CAN2_F6BANK1_FBIT6_MASK                            0x40

#define CAN2_F6BANK1_FBIT7_OFFSET                          7
#define CAN2_F6BANK1_FBIT7_MASK                            0x80

#define CAN2_F6BANK1_FBIT8_OFFSET                          8
#define CAN2_F6BANK1_FBIT8_MASK                            0x100

#define CAN2_F6BANK1_FBIT9_OFFSET                          9
#define CAN2_F6BANK1_FBIT9_MASK                            0x200

#define CAN2_F6BANK1_FBIT10_OFFSET                         10
#define CAN2_F6BANK1_FBIT10_MASK                           0x400

#define CAN2_F6BANK1_FBIT11_OFFSET                         11
#define CAN2_F6BANK1_FBIT11_MASK                           0x800

#define CAN2_F6BANK1_FBIT12_OFFSET                         12
#define CAN2_F6BANK1_FBIT12_MASK                           0x1000

#define CAN2_F6BANK1_FBIT13_OFFSET                         13
#define CAN2_F6BANK1_FBIT13_MASK                           0x2000

#define CAN2_F6BANK1_FBIT14_OFFSET                         14
#define CAN2_F6BANK1_FBIT14_MASK                           0x4000

#define CAN2_F6BANK1_FBIT15_OFFSET                         15
#define CAN2_F6BANK1_FBIT15_MASK                           0x8000

#define CAN2_F6BANK1_FBIT16_OFFSET                         16
#define CAN2_F6BANK1_FBIT16_MASK                           0x10000

#define CAN2_F6BANK1_FBIT17_OFFSET                         17
#define CAN2_F6BANK1_FBIT17_MASK                           0x20000

#define CAN2_F6BANK1_FBIT18_OFFSET                         18
#define CAN2_F6BANK1_FBIT18_MASK                           0x40000

#define CAN2_F6BANK1_FBIT19_OFFSET                         19
#define CAN2_F6BANK1_FBIT19_MASK                           0x80000

#define CAN2_F6BANK1_FBIT20_OFFSET                         20
#define CAN2_F6BANK1_FBIT20_MASK                           0x100000

#define CAN2_F6BANK1_FBIT21_OFFSET                         21
#define CAN2_F6BANK1_FBIT21_MASK                           0x200000

#define CAN2_F6BANK1_FBIT22_OFFSET                         22
#define CAN2_F6BANK1_FBIT22_MASK                           0x400000

#define CAN2_F6BANK1_FBIT23_OFFSET                         23
#define CAN2_F6BANK1_FBIT23_MASK                           0x800000

#define CAN2_F6BANK1_FBIT24_OFFSET                         24
#define CAN2_F6BANK1_FBIT24_MASK                           0x1000000

#define CAN2_F6BANK1_FBIT25_OFFSET                         25
#define CAN2_F6BANK1_FBIT25_MASK                           0x2000000

#define CAN2_F6BANK1_FBIT26_OFFSET                         26
#define CAN2_F6BANK1_FBIT26_MASK                           0x4000000

#define CAN2_F6BANK1_FBIT27_OFFSET                         27
#define CAN2_F6BANK1_FBIT27_MASK                           0x8000000

#define CAN2_F6BANK1_FBIT28_OFFSET                         28
#define CAN2_F6BANK1_FBIT28_MASK                           0x10000000

#define CAN2_F6BANK1_FBIT29_OFFSET                         29
#define CAN2_F6BANK1_FBIT29_MASK                           0x20000000

#define CAN2_F6BANK1_FBIT30_OFFSET                         30
#define CAN2_F6BANK1_FBIT30_MASK                           0x40000000

#define CAN2_F6BANK1_FBIT31_OFFSET                         31
#define CAN2_F6BANK1_FBIT31_MASK                           0x80000000

#define CAN2_F6BANK2_FBIT0_OFFSET                          0
#define CAN2_F6BANK2_FBIT0_MASK                            1

#define CAN2_F6BANK2_FBIT1_OFFSET                          1
#define CAN2_F6BANK2_FBIT1_MASK                            2

#define CAN2_F6BANK2_FBIT2_OFFSET                          2
#define CAN2_F6BANK2_FBIT2_MASK                            4

#define CAN2_F6BANK2_FBIT3_OFFSET                          3
#define CAN2_F6BANK2_FBIT3_MASK                            8

#define CAN2_F6BANK2_FBIT4_OFFSET                          4
#define CAN2_F6BANK2_FBIT4_MASK                            0x10

#define CAN2_F6BANK2_FBIT5_OFFSET                          5
#define CAN2_F6BANK2_FBIT5_MASK                            0x20

#define CAN2_F6BANK2_FBIT6_OFFSET                          6
#define CAN2_F6BANK2_FBIT6_MASK                            0x40

#define CAN2_F6BANK2_FBIT7_OFFSET                          7
#define CAN2_F6BANK2_FBIT7_MASK                            0x80

#define CAN2_F6BANK2_FBIT8_OFFSET                          8
#define CAN2_F6BANK2_FBIT8_MASK                            0x100

#define CAN2_F6BANK2_FBIT9_OFFSET                          9
#define CAN2_F6BANK2_FBIT9_MASK                            0x200

#define CAN2_F6BANK2_FBIT10_OFFSET                         10
#define CAN2_F6BANK2_FBIT10_MASK                           0x400

#define CAN2_F6BANK2_FBIT11_OFFSET                         11
#define CAN2_F6BANK2_FBIT11_MASK                           0x800

#define CAN2_F6BANK2_FBIT12_OFFSET                         12
#define CAN2_F6BANK2_FBIT12_MASK                           0x1000

#define CAN2_F6BANK2_FBIT13_OFFSET                         13
#define CAN2_F6BANK2_FBIT13_MASK                           0x2000

#define CAN2_F6BANK2_FBIT14_OFFSET                         14
#define CAN2_F6BANK2_FBIT14_MASK                           0x4000

#define CAN2_F6BANK2_FBIT15_OFFSET                         15
#define CAN2_F6BANK2_FBIT15_MASK                           0x8000

#define CAN2_F6BANK2_FBIT16_OFFSET                         16
#define CAN2_F6BANK2_FBIT16_MASK                           0x10000

#define CAN2_F6BANK2_FBIT17_OFFSET                         17
#define CAN2_F6BANK2_FBIT17_MASK                           0x20000

#define CAN2_F6BANK2_FBIT18_OFFSET                         18
#define CAN2_F6BANK2_FBIT18_MASK                           0x40000

#define CAN2_F6BANK2_FBIT19_OFFSET                         19
#define CAN2_F6BANK2_FBIT19_MASK                           0x80000

#define CAN2_F6BANK2_FBIT20_OFFSET                         20
#define CAN2_F6BANK2_FBIT20_MASK                           0x100000

#define CAN2_F6BANK2_FBIT21_OFFSET                         21
#define CAN2_F6BANK2_FBIT21_MASK                           0x200000

#define CAN2_F6BANK2_FBIT22_OFFSET                         22
#define CAN2_F6BANK2_FBIT22_MASK                           0x400000

#define CAN2_F6BANK2_FBIT23_OFFSET                         23
#define CAN2_F6BANK2_FBIT23_MASK                           0x800000

#define CAN2_F6BANK2_FBIT24_OFFSET                         24
#define CAN2_F6BANK2_FBIT24_MASK                           0x1000000

#define CAN2_F6BANK2_FBIT25_OFFSET                         25
#define CAN2_F6BANK2_FBIT25_MASK                           0x2000000

#define CAN2_F6BANK2_FBIT26_OFFSET                         26
#define CAN2_F6BANK2_FBIT26_MASK                           0x4000000

#define CAN2_F6BANK2_FBIT27_OFFSET                         27
#define CAN2_F6BANK2_FBIT27_MASK                           0x8000000

#define CAN2_F6BANK2_FBIT28_OFFSET                         28
#define CAN2_F6BANK2_FBIT28_MASK                           0x10000000

#define CAN2_F6BANK2_FBIT29_OFFSET                         29
#define CAN2_F6BANK2_FBIT29_MASK                           0x20000000

#define CAN2_F6BANK2_FBIT30_OFFSET                         30
#define CAN2_F6BANK2_FBIT30_MASK                           0x40000000

#define CAN2_F6BANK2_FBIT31_OFFSET                         31
#define CAN2_F6BANK2_FBIT31_MASK                           0x80000000

#define CAN2_F7BANK1_FBIT0_OFFSET                          0
#define CAN2_F7BANK1_FBIT0_MASK                            1

#define CAN2_F7BANK1_FBIT1_OFFSET                          1
#define CAN2_F7BANK1_FBIT1_MASK                            2

#define CAN2_F7BANK1_FBIT2_OFFSET                          2
#define CAN2_F7BANK1_FBIT2_MASK                            4

#define CAN2_F7BANK1_FBIT3_OFFSET                          3
#define CAN2_F7BANK1_FBIT3_MASK                            8

#define CAN2_F7BANK1_FBIT4_OFFSET                          4
#define CAN2_F7BANK1_FBIT4_MASK                            0x10

#define CAN2_F7BANK1_FBIT5_OFFSET                          5
#define CAN2_F7BANK1_FBIT5_MASK                            0x20

#define CAN2_F7BANK1_FBIT6_OFFSET                          6
#define CAN2_F7BANK1_FBIT6_MASK                            0x40

#define CAN2_F7BANK1_FBIT7_OFFSET                          7
#define CAN2_F7BANK1_FBIT7_MASK                            0x80

#define CAN2_F7BANK1_FBIT8_OFFSET                          8
#define CAN2_F7BANK1_FBIT8_MASK                            0x100

#define CAN2_F7BANK1_FBIT9_OFFSET                          9
#define CAN2_F7BANK1_FBIT9_MASK                            0x200

#define CAN2_F7BANK1_FBIT10_OFFSET                         10
#define CAN2_F7BANK1_FBIT10_MASK                           0x400

#define CAN2_F7BANK1_FBIT11_OFFSET                         11
#define CAN2_F7BANK1_FBIT11_MASK                           0x800

#define CAN2_F7BANK1_FBIT12_OFFSET                         12
#define CAN2_F7BANK1_FBIT12_MASK                           0x1000

#define CAN2_F7BANK1_FBIT13_OFFSET                         13
#define CAN2_F7BANK1_FBIT13_MASK                           0x2000

#define CAN2_F7BANK1_FBIT14_OFFSET                         14
#define CAN2_F7BANK1_FBIT14_MASK                           0x4000

#define CAN2_F7BANK1_FBIT15_OFFSET                         15
#define CAN2_F7BANK1_FBIT15_MASK                           0x8000

#define CAN2_F7BANK1_FBIT16_OFFSET                         16
#define CAN2_F7BANK1_FBIT16_MASK                           0x10000

#define CAN2_F7BANK1_FBIT17_OFFSET                         17
#define CAN2_F7BANK1_FBIT17_MASK                           0x20000

#define CAN2_F7BANK1_FBIT18_OFFSET                         18
#define CAN2_F7BANK1_FBIT18_MASK                           0x40000

#define CAN2_F7BANK1_FBIT19_OFFSET                         19
#define CAN2_F7BANK1_FBIT19_MASK                           0x80000

#define CAN2_F7BANK1_FBIT20_OFFSET                         20
#define CAN2_F7BANK1_FBIT20_MASK                           0x100000

#define CAN2_F7BANK1_FBIT21_OFFSET                         21
#define CAN2_F7BANK1_FBIT21_MASK                           0x200000

#define CAN2_F7BANK1_FBIT22_OFFSET                         22
#define CAN2_F7BANK1_FBIT22_MASK                           0x400000

#define CAN2_F7BANK1_FBIT23_OFFSET                         23
#define CAN2_F7BANK1_FBIT23_MASK                           0x800000

#define CAN2_F7BANK1_FBIT24_OFFSET                         24
#define CAN2_F7BANK1_FBIT24_MASK                           0x1000000

#define CAN2_F7BANK1_FBIT25_OFFSET                         25
#define CAN2_F7BANK1_FBIT25_MASK                           0x2000000

#define CAN2_F7BANK1_FBIT26_OFFSET                         26
#define CAN2_F7BANK1_FBIT26_MASK                           0x4000000

#define CAN2_F7BANK1_FBIT27_OFFSET                         27
#define CAN2_F7BANK1_FBIT27_MASK                           0x8000000

#define CAN2_F7BANK1_FBIT28_OFFSET                         28
#define CAN2_F7BANK1_FBIT28_MASK                           0x10000000

#define CAN2_F7BANK1_FBIT29_OFFSET                         29
#define CAN2_F7BANK1_FBIT29_MASK                           0x20000000

#define CAN2_F7BANK1_FBIT30_OFFSET                         30
#define CAN2_F7BANK1_FBIT30_MASK                           0x40000000

#define CAN2_F7BANK1_FBIT31_OFFSET                         31
#define CAN2_F7BANK1_FBIT31_MASK                           0x80000000

#define CAN2_F7BANK2_FBIT0_OFFSET                          0
#define CAN2_F7BANK2_FBIT0_MASK                            1

#define CAN2_F7BANK2_FBIT1_OFFSET                          1
#define CAN2_F7BANK2_FBIT1_MASK                            2

#define CAN2_F7BANK2_FBIT2_OFFSET                          2
#define CAN2_F7BANK2_FBIT2_MASK                            4

#define CAN2_F7BANK2_FBIT3_OFFSET                          3
#define CAN2_F7BANK2_FBIT3_MASK                            8

#define CAN2_F7BANK2_FBIT4_OFFSET                          4
#define CAN2_F7BANK2_FBIT4_MASK                            0x10

#define CAN2_F7BANK2_FBIT5_OFFSET                          5
#define CAN2_F7BANK2_FBIT5_MASK                            0x20

#define CAN2_F7BANK2_FBIT6_OFFSET                          6
#define CAN2_F7BANK2_FBIT6_MASK                            0x40

#define CAN2_F7BANK2_FBIT7_OFFSET                          7
#define CAN2_F7BANK2_FBIT7_MASK                            0x80

#define CAN2_F7BANK2_FBIT8_OFFSET                          8
#define CAN2_F7BANK2_FBIT8_MASK                            0x100

#define CAN2_F7BANK2_FBIT9_OFFSET                          9
#define CAN2_F7BANK2_FBIT9_MASK                            0x200

#define CAN2_F7BANK2_FBIT10_OFFSET                         10
#define CAN2_F7BANK2_FBIT10_MASK                           0x400

#define CAN2_F7BANK2_FBIT11_OFFSET                         11
#define CAN2_F7BANK2_FBIT11_MASK                           0x800

#define CAN2_F7BANK2_FBIT12_OFFSET                         12
#define CAN2_F7BANK2_FBIT12_MASK                           0x1000

#define CAN2_F7BANK2_FBIT13_OFFSET                         13
#define CAN2_F7BANK2_FBIT13_MASK                           0x2000

#define CAN2_F7BANK2_FBIT14_OFFSET                         14
#define CAN2_F7BANK2_FBIT14_MASK                           0x4000

#define CAN2_F7BANK2_FBIT15_OFFSET                         15
#define CAN2_F7BANK2_FBIT15_MASK                           0x8000

#define CAN2_F7BANK2_FBIT16_OFFSET                         16
#define CAN2_F7BANK2_FBIT16_MASK                           0x10000

#define CAN2_F7BANK2_FBIT17_OFFSET                         17
#define CAN2_F7BANK2_FBIT17_MASK                           0x20000

#define CAN2_F7BANK2_FBIT18_OFFSET                         18
#define CAN2_F7BANK2_FBIT18_MASK                           0x40000

#define CAN2_F7BANK2_FBIT19_OFFSET                         19
#define CAN2_F7BANK2_FBIT19_MASK                           0x80000

#define CAN2_F7BANK2_FBIT20_OFFSET                         20
#define CAN2_F7BANK2_FBIT20_MASK                           0x100000

#define CAN2_F7BANK2_FBIT21_OFFSET                         21
#define CAN2_F7BANK2_FBIT21_MASK                           0x200000

#define CAN2_F7BANK2_FBIT22_OFFSET                         22
#define CAN2_F7BANK2_FBIT22_MASK                           0x400000

#define CAN2_F7BANK2_FBIT23_OFFSET                         23
#define CAN2_F7BANK2_FBIT23_MASK                           0x800000

#define CAN2_F7BANK2_FBIT24_OFFSET                         24
#define CAN2_F7BANK2_FBIT24_MASK                           0x1000000

#define CAN2_F7BANK2_FBIT25_OFFSET                         25
#define CAN2_F7BANK2_FBIT25_MASK                           0x2000000

#define CAN2_F7BANK2_FBIT26_OFFSET                         26
#define CAN2_F7BANK2_FBIT26_MASK                           0x4000000

#define CAN2_F7BANK2_FBIT27_OFFSET                         27
#define CAN2_F7BANK2_FBIT27_MASK                           0x8000000

#define CAN2_F7BANK2_FBIT28_OFFSET                         28
#define CAN2_F7BANK2_FBIT28_MASK                           0x10000000

#define CAN2_F7BANK2_FBIT29_OFFSET                         29
#define CAN2_F7BANK2_FBIT29_MASK                           0x20000000

#define CAN2_F7BANK2_FBIT30_OFFSET                         30
#define CAN2_F7BANK2_FBIT30_MASK                           0x40000000

#define CAN2_F7BANK2_FBIT31_OFFSET                         31
#define CAN2_F7BANK2_FBIT31_MASK                           0x80000000

#define CAN2_F8BANK1_FBIT0_OFFSET                          0
#define CAN2_F8BANK1_FBIT0_MASK                            1

#define CAN2_F8BANK1_FBIT1_OFFSET                          1
#define CAN2_F8BANK1_FBIT1_MASK                            2

#define CAN2_F8BANK1_FBIT2_OFFSET                          2
#define CAN2_F8BANK1_FBIT2_MASK                            4

#define CAN2_F8BANK1_FBIT3_OFFSET                          3
#define CAN2_F8BANK1_FBIT3_MASK                            8

#define CAN2_F8BANK1_FBIT4_OFFSET                          4
#define CAN2_F8BANK1_FBIT4_MASK                            0x10

#define CAN2_F8BANK1_FBIT5_OFFSET                          5
#define CAN2_F8BANK1_FBIT5_MASK                            0x20

#define CAN2_F8BANK1_FBIT6_OFFSET                          6
#define CAN2_F8BANK1_FBIT6_MASK                            0x40

#define CAN2_F8BANK1_FBIT7_OFFSET                          7
#define CAN2_F8BANK1_FBIT7_MASK                            0x80

#define CAN2_F8BANK1_FBIT8_OFFSET                          8
#define CAN2_F8BANK1_FBIT8_MASK                            0x100

#define CAN2_F8BANK1_FBIT9_OFFSET                          9
#define CAN2_F8BANK1_FBIT9_MASK                            0x200

#define CAN2_F8BANK1_FBIT10_OFFSET                         10
#define CAN2_F8BANK1_FBIT10_MASK                           0x400

#define CAN2_F8BANK1_FBIT11_OFFSET                         11
#define CAN2_F8BANK1_FBIT11_MASK                           0x800

#define CAN2_F8BANK1_FBIT12_OFFSET                         12
#define CAN2_F8BANK1_FBIT12_MASK                           0x1000

#define CAN2_F8BANK1_FBIT13_OFFSET                         13
#define CAN2_F8BANK1_FBIT13_MASK                           0x2000

#define CAN2_F8BANK1_FBIT14_OFFSET                         14
#define CAN2_F8BANK1_FBIT14_MASK                           0x4000

#define CAN2_F8BANK1_FBIT15_OFFSET                         15
#define CAN2_F8BANK1_FBIT15_MASK                           0x8000

#define CAN2_F8BANK1_FBIT16_OFFSET                         16
#define CAN2_F8BANK1_FBIT16_MASK                           0x10000

#define CAN2_F8BANK1_FBIT17_OFFSET                         17
#define CAN2_F8BANK1_FBIT17_MASK                           0x20000

#define CAN2_F8BANK1_FBIT18_OFFSET                         18
#define CAN2_F8BANK1_FBIT18_MASK                           0x40000

#define CAN2_F8BANK1_FBIT19_OFFSET                         19
#define CAN2_F8BANK1_FBIT19_MASK                           0x80000

#define CAN2_F8BANK1_FBIT20_OFFSET                         20
#define CAN2_F8BANK1_FBIT20_MASK                           0x100000

#define CAN2_F8BANK1_FBIT21_OFFSET                         21
#define CAN2_F8BANK1_FBIT21_MASK                           0x200000

#define CAN2_F8BANK1_FBIT22_OFFSET                         22
#define CAN2_F8BANK1_FBIT22_MASK                           0x400000

#define CAN2_F8BANK1_FBIT23_OFFSET                         23
#define CAN2_F8BANK1_FBIT23_MASK                           0x800000

#define CAN2_F8BANK1_FBIT24_OFFSET                         24
#define CAN2_F8BANK1_FBIT24_MASK                           0x1000000

#define CAN2_F8BANK1_FBIT25_OFFSET                         25
#define CAN2_F8BANK1_FBIT25_MASK                           0x2000000

#define CAN2_F8BANK1_FBIT26_OFFSET                         26
#define CAN2_F8BANK1_FBIT26_MASK                           0x4000000

#define CAN2_F8BANK1_FBIT27_OFFSET                         27
#define CAN2_F8BANK1_FBIT27_MASK                           0x8000000

#define CAN2_F8BANK1_FBIT28_OFFSET                         28
#define CAN2_F8BANK1_FBIT28_MASK                           0x10000000

#define CAN2_F8BANK1_FBIT29_OFFSET                         29
#define CAN2_F8BANK1_FBIT29_MASK                           0x20000000

#define CAN2_F8BANK1_FBIT30_OFFSET                         30
#define CAN2_F8BANK1_FBIT30_MASK                           0x40000000

#define CAN2_F8BANK1_FBIT31_OFFSET                         31
#define CAN2_F8BANK1_FBIT31_MASK                           0x80000000

#define CAN2_F8BANK2_FBIT0_OFFSET                          0
#define CAN2_F8BANK2_FBIT0_MASK                            1

#define CAN2_F8BANK2_FBIT1_OFFSET                          1
#define CAN2_F8BANK2_FBIT1_MASK                            2

#define CAN2_F8BANK2_FBIT2_OFFSET                          2
#define CAN2_F8BANK2_FBIT2_MASK                            4

#define CAN2_F8BANK2_FBIT3_OFFSET                          3
#define CAN2_F8BANK2_FBIT3_MASK                            8

#define CAN2_F8BANK2_FBIT4_OFFSET                          4
#define CAN2_F8BANK2_FBIT4_MASK                            0x10

#define CAN2_F8BANK2_FBIT5_OFFSET                          5
#define CAN2_F8BANK2_FBIT5_MASK                            0x20

#define CAN2_F8BANK2_FBIT6_OFFSET                          6
#define CAN2_F8BANK2_FBIT6_MASK                            0x40

#define CAN2_F8BANK2_FBIT7_OFFSET                          7
#define CAN2_F8BANK2_FBIT7_MASK                            0x80

#define CAN2_F8BANK2_FBIT8_OFFSET                          8
#define CAN2_F8BANK2_FBIT8_MASK                            0x100

#define CAN2_F8BANK2_FBIT9_OFFSET                          9
#define CAN2_F8BANK2_FBIT9_MASK                            0x200

#define CAN2_F8BANK2_FBIT10_OFFSET                         10
#define CAN2_F8BANK2_FBIT10_MASK                           0x400

#define CAN2_F8BANK2_FBIT11_OFFSET                         11
#define CAN2_F8BANK2_FBIT11_MASK                           0x800

#define CAN2_F8BANK2_FBIT12_OFFSET                         12
#define CAN2_F8BANK2_FBIT12_MASK                           0x1000

#define CAN2_F8BANK2_FBIT13_OFFSET                         13
#define CAN2_F8BANK2_FBIT13_MASK                           0x2000

#define CAN2_F8BANK2_FBIT14_OFFSET                         14
#define CAN2_F8BANK2_FBIT14_MASK                           0x4000

#define CAN2_F8BANK2_FBIT15_OFFSET                         15
#define CAN2_F8BANK2_FBIT15_MASK                           0x8000

#define CAN2_F8BANK2_FBIT16_OFFSET                         16
#define CAN2_F8BANK2_FBIT16_MASK                           0x10000

#define CAN2_F8BANK2_FBIT17_OFFSET                         17
#define CAN2_F8BANK2_FBIT17_MASK                           0x20000

#define CAN2_F8BANK2_FBIT18_OFFSET                         18
#define CAN2_F8BANK2_FBIT18_MASK                           0x40000

#define CAN2_F8BANK2_FBIT19_OFFSET                         19
#define CAN2_F8BANK2_FBIT19_MASK                           0x80000

#define CAN2_F8BANK2_FBIT20_OFFSET                         20
#define CAN2_F8BANK2_FBIT20_MASK                           0x100000

#define CAN2_F8BANK2_FBIT21_OFFSET                         21
#define CAN2_F8BANK2_FBIT21_MASK                           0x200000

#define CAN2_F8BANK2_FBIT22_OFFSET                         22
#define CAN2_F8BANK2_FBIT22_MASK                           0x400000

#define CAN2_F8BANK2_FBIT23_OFFSET                         23
#define CAN2_F8BANK2_FBIT23_MASK                           0x800000

#define CAN2_F8BANK2_FBIT24_OFFSET                         24
#define CAN2_F8BANK2_FBIT24_MASK                           0x1000000

#define CAN2_F8BANK2_FBIT25_OFFSET                         25
#define CAN2_F8BANK2_FBIT25_MASK                           0x2000000

#define CAN2_F8BANK2_FBIT26_OFFSET                         26
#define CAN2_F8BANK2_FBIT26_MASK                           0x4000000

#define CAN2_F8BANK2_FBIT27_OFFSET                         27
#define CAN2_F8BANK2_FBIT27_MASK                           0x8000000

#define CAN2_F8BANK2_FBIT28_OFFSET                         28
#define CAN2_F8BANK2_FBIT28_MASK                           0x10000000

#define CAN2_F8BANK2_FBIT29_OFFSET                         29
#define CAN2_F8BANK2_FBIT29_MASK                           0x20000000

#define CAN2_F8BANK2_FBIT30_OFFSET                         30
#define CAN2_F8BANK2_FBIT30_MASK                           0x40000000

#define CAN2_F8BANK2_FBIT31_OFFSET                         31
#define CAN2_F8BANK2_FBIT31_MASK                           0x80000000

#define CAN2_F9BANK1_FBIT0_OFFSET                          0
#define CAN2_F9BANK1_FBIT0_MASK                            1

#define CAN2_F9BANK1_FBIT1_OFFSET                          1
#define CAN2_F9BANK1_FBIT1_MASK                            2

#define CAN2_F9BANK1_FBIT2_OFFSET                          2
#define CAN2_F9BANK1_FBIT2_MASK                            4

#define CAN2_F9BANK1_FBIT3_OFFSET                          3
#define CAN2_F9BANK1_FBIT3_MASK                            8

#define CAN2_F9BANK1_FBIT4_OFFSET                          4
#define CAN2_F9BANK1_FBIT4_MASK                            0x10

#define CAN2_F9BANK1_FBIT5_OFFSET                          5
#define CAN2_F9BANK1_FBIT5_MASK                            0x20

#define CAN2_F9BANK1_FBIT6_OFFSET                          6
#define CAN2_F9BANK1_FBIT6_MASK                            0x40

#define CAN2_F9BANK1_FBIT7_OFFSET                          7
#define CAN2_F9BANK1_FBIT7_MASK                            0x80

#define CAN2_F9BANK1_FBIT8_OFFSET                          8
#define CAN2_F9BANK1_FBIT8_MASK                            0x100

#define CAN2_F9BANK1_FBIT9_OFFSET                          9
#define CAN2_F9BANK1_FBIT9_MASK                            0x200

#define CAN2_F9BANK1_FBIT10_OFFSET                         10
#define CAN2_F9BANK1_FBIT10_MASK                           0x400

#define CAN2_F9BANK1_FBIT11_OFFSET                         11
#define CAN2_F9BANK1_FBIT11_MASK                           0x800

#define CAN2_F9BANK1_FBIT12_OFFSET                         12
#define CAN2_F9BANK1_FBIT12_MASK                           0x1000

#define CAN2_F9BANK1_FBIT13_OFFSET                         13
#define CAN2_F9BANK1_FBIT13_MASK                           0x2000

#define CAN2_F9BANK1_FBIT14_OFFSET                         14
#define CAN2_F9BANK1_FBIT14_MASK                           0x4000

#define CAN2_F9BANK1_FBIT15_OFFSET                         15
#define CAN2_F9BANK1_FBIT15_MASK                           0x8000

#define CAN2_F9BANK1_FBIT16_OFFSET                         16
#define CAN2_F9BANK1_FBIT16_MASK                           0x10000

#define CAN2_F9BANK1_FBIT17_OFFSET                         17
#define CAN2_F9BANK1_FBIT17_MASK                           0x20000

#define CAN2_F9BANK1_FBIT18_OFFSET                         18
#define CAN2_F9BANK1_FBIT18_MASK                           0x40000

#define CAN2_F9BANK1_FBIT19_OFFSET                         19
#define CAN2_F9BANK1_FBIT19_MASK                           0x80000

#define CAN2_F9BANK1_FBIT20_OFFSET                         20
#define CAN2_F9BANK1_FBIT20_MASK                           0x100000

#define CAN2_F9BANK1_FBIT21_OFFSET                         21
#define CAN2_F9BANK1_FBIT21_MASK                           0x200000

#define CAN2_F9BANK1_FBIT22_OFFSET                         22
#define CAN2_F9BANK1_FBIT22_MASK                           0x400000

#define CAN2_F9BANK1_FBIT23_OFFSET                         23
#define CAN2_F9BANK1_FBIT23_MASK                           0x800000

#define CAN2_F9BANK1_FBIT24_OFFSET                         24
#define CAN2_F9BANK1_FBIT24_MASK                           0x1000000

#define CAN2_F9BANK1_FBIT25_OFFSET                         25
#define CAN2_F9BANK1_FBIT25_MASK                           0x2000000

#define CAN2_F9BANK1_FBIT26_OFFSET                         26
#define CAN2_F9BANK1_FBIT26_MASK                           0x4000000

#define CAN2_F9BANK1_FBIT27_OFFSET                         27
#define CAN2_F9BANK1_FBIT27_MASK                           0x8000000

#define CAN2_F9BANK1_FBIT28_OFFSET                         28
#define CAN2_F9BANK1_FBIT28_MASK                           0x10000000

#define CAN2_F9BANK1_FBIT29_OFFSET                         29
#define CAN2_F9BANK1_FBIT29_MASK                           0x20000000

#define CAN2_F9BANK1_FBIT30_OFFSET                         30
#define CAN2_F9BANK1_FBIT30_MASK                           0x40000000

#define CAN2_F9BANK1_FBIT31_OFFSET                         31
#define CAN2_F9BANK1_FBIT31_MASK                           0x80000000

#define CAN2_F9BANK2_FBIT0_OFFSET                          0
#define CAN2_F9BANK2_FBIT0_MASK                            1

#define CAN2_F9BANK2_FBIT1_OFFSET                          1
#define CAN2_F9BANK2_FBIT1_MASK                            2

#define CAN2_F9BANK2_FBIT2_OFFSET                          2
#define CAN2_F9BANK2_FBIT2_MASK                            4

#define CAN2_F9BANK2_FBIT3_OFFSET                          3
#define CAN2_F9BANK2_FBIT3_MASK                            8

#define CAN2_F9BANK2_FBIT4_OFFSET                          4
#define CAN2_F9BANK2_FBIT4_MASK                            0x10

#define CAN2_F9BANK2_FBIT5_OFFSET                          5
#define CAN2_F9BANK2_FBIT5_MASK                            0x20

#define CAN2_F9BANK2_FBIT6_OFFSET                          6
#define CAN2_F9BANK2_FBIT6_MASK                            0x40

#define CAN2_F9BANK2_FBIT7_OFFSET                          7
#define CAN2_F9BANK2_FBIT7_MASK                            0x80

#define CAN2_F9BANK2_FBIT8_OFFSET                          8
#define CAN2_F9BANK2_FBIT8_MASK                            0x100

#define CAN2_F9BANK2_FBIT9_OFFSET                          9
#define CAN2_F9BANK2_FBIT9_MASK                            0x200

#define CAN2_F9BANK2_FBIT10_OFFSET                         10
#define CAN2_F9BANK2_FBIT10_MASK                           0x400

#define CAN2_F9BANK2_FBIT11_OFFSET                         11
#define CAN2_F9BANK2_FBIT11_MASK                           0x800

#define CAN2_F9BANK2_FBIT12_OFFSET                         12
#define CAN2_F9BANK2_FBIT12_MASK                           0x1000

#define CAN2_F9BANK2_FBIT13_OFFSET                         13
#define CAN2_F9BANK2_FBIT13_MASK                           0x2000

#define CAN2_F9BANK2_FBIT14_OFFSET                         14
#define CAN2_F9BANK2_FBIT14_MASK                           0x4000

#define CAN2_F9BANK2_FBIT15_OFFSET                         15
#define CAN2_F9BANK2_FBIT15_MASK                           0x8000

#define CAN2_F9BANK2_FBIT16_OFFSET                         16
#define CAN2_F9BANK2_FBIT16_MASK                           0x10000

#define CAN2_F9BANK2_FBIT17_OFFSET                         17
#define CAN2_F9BANK2_FBIT17_MASK                           0x20000

#define CAN2_F9BANK2_FBIT18_OFFSET                         18
#define CAN2_F9BANK2_FBIT18_MASK                           0x40000

#define CAN2_F9BANK2_FBIT19_OFFSET                         19
#define CAN2_F9BANK2_FBIT19_MASK                           0x80000

#define CAN2_F9BANK2_FBIT20_OFFSET                         20
#define CAN2_F9BANK2_FBIT20_MASK                           0x100000

#define CAN2_F9BANK2_FBIT21_OFFSET                         21
#define CAN2_F9BANK2_FBIT21_MASK                           0x200000

#define CAN2_F9BANK2_FBIT22_OFFSET                         22
#define CAN2_F9BANK2_FBIT22_MASK                           0x400000

#define CAN2_F9BANK2_FBIT23_OFFSET                         23
#define CAN2_F9BANK2_FBIT23_MASK                           0x800000

#define CAN2_F9BANK2_FBIT24_OFFSET                         24
#define CAN2_F9BANK2_FBIT24_MASK                           0x1000000

#define CAN2_F9BANK2_FBIT25_OFFSET                         25
#define CAN2_F9BANK2_FBIT25_MASK                           0x2000000

#define CAN2_F9BANK2_FBIT26_OFFSET                         26
#define CAN2_F9BANK2_FBIT26_MASK                           0x4000000

#define CAN2_F9BANK2_FBIT27_OFFSET                         27
#define CAN2_F9BANK2_FBIT27_MASK                           0x8000000

#define CAN2_F9BANK2_FBIT28_OFFSET                         28
#define CAN2_F9BANK2_FBIT28_MASK                           0x10000000

#define CAN2_F9BANK2_FBIT29_OFFSET                         29
#define CAN2_F9BANK2_FBIT29_MASK                           0x20000000

#define CAN2_F9BANK2_FBIT30_OFFSET                         30
#define CAN2_F9BANK2_FBIT30_MASK                           0x40000000

#define CAN2_F9BANK2_FBIT31_OFFSET                         31
#define CAN2_F9BANK2_FBIT31_MASK                           0x80000000

#define CAN2_F10BANK1_FBIT0_OFFSET                         0
#define CAN2_F10BANK1_FBIT0_MASK                           1

#define CAN2_F10BANK1_FBIT1_OFFSET                         1
#define CAN2_F10BANK1_FBIT1_MASK                           2

#define CAN2_F10BANK1_FBIT2_OFFSET                         2
#define CAN2_F10BANK1_FBIT2_MASK                           4

#define CAN2_F10BANK1_FBIT3_OFFSET                         3
#define CAN2_F10BANK1_FBIT3_MASK                           8

#define CAN2_F10BANK1_FBIT4_OFFSET                         4
#define CAN2_F10BANK1_FBIT4_MASK                           0x10

#define CAN2_F10BANK1_FBIT5_OFFSET                         5
#define CAN2_F10BANK1_FBIT5_MASK                           0x20

#define CAN2_F10BANK1_FBIT6_OFFSET                         6
#define CAN2_F10BANK1_FBIT6_MASK                           0x40

#define CAN2_F10BANK1_FBIT7_OFFSET                         7
#define CAN2_F10BANK1_FBIT7_MASK                           0x80

#define CAN2_F10BANK1_FBIT8_OFFSET                         8
#define CAN2_F10BANK1_FBIT8_MASK                           0x100

#define CAN2_F10BANK1_FBIT9_OFFSET                         9
#define CAN2_F10BANK1_FBIT9_MASK                           0x200

#define CAN2_F10BANK1_FBIT10_OFFSET                        10
#define CAN2_F10BANK1_FBIT10_MASK                          0x400

#define CAN2_F10BANK1_FBIT11_OFFSET                        11
#define CAN2_F10BANK1_FBIT11_MASK                          0x800

#define CAN2_F10BANK1_FBIT12_OFFSET                        12
#define CAN2_F10BANK1_FBIT12_MASK                          0x1000

#define CAN2_F10BANK1_FBIT13_OFFSET                        13
#define CAN2_F10BANK1_FBIT13_MASK                          0x2000

#define CAN2_F10BANK1_FBIT14_OFFSET                        14
#define CAN2_F10BANK1_FBIT14_MASK                          0x4000

#define CAN2_F10BANK1_FBIT15_OFFSET                        15
#define CAN2_F10BANK1_FBIT15_MASK                          0x8000

#define CAN2_F10BANK1_FBIT16_OFFSET                        16
#define CAN2_F10BANK1_FBIT16_MASK                          0x10000

#define CAN2_F10BANK1_FBIT17_OFFSET                        17
#define CAN2_F10BANK1_FBIT17_MASK                          0x20000

#define CAN2_F10BANK1_FBIT18_OFFSET                        18
#define CAN2_F10BANK1_FBIT18_MASK                          0x40000

#define CAN2_F10BANK1_FBIT19_OFFSET                        19
#define CAN2_F10BANK1_FBIT19_MASK                          0x80000

#define CAN2_F10BANK1_FBIT20_OFFSET                        20
#define CAN2_F10BANK1_FBIT20_MASK                          0x100000

#define CAN2_F10BANK1_FBIT21_OFFSET                        21
#define CAN2_F10BANK1_FBIT21_MASK                          0x200000

#define CAN2_F10BANK1_FBIT22_OFFSET                        22
#define CAN2_F10BANK1_FBIT22_MASK                          0x400000

#define CAN2_F10BANK1_FBIT23_OFFSET                        23
#define CAN2_F10BANK1_FBIT23_MASK                          0x800000

#define CAN2_F10BANK1_FBIT24_OFFSET                        24
#define CAN2_F10BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F10BANK1_FBIT25_OFFSET                        25
#define CAN2_F10BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F10BANK1_FBIT26_OFFSET                        26
#define CAN2_F10BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F10BANK1_FBIT27_OFFSET                        27
#define CAN2_F10BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F10BANK1_FBIT28_OFFSET                        28
#define CAN2_F10BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F10BANK1_FBIT29_OFFSET                        29
#define CAN2_F10BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F10BANK1_FBIT30_OFFSET                        30
#define CAN2_F10BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F10BANK1_FBIT31_OFFSET                        31
#define CAN2_F10BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F10BANK2_FBIT0_OFFSET                         0
#define CAN2_F10BANK2_FBIT0_MASK                           1

#define CAN2_F10BANK2_FBIT1_OFFSET                         1
#define CAN2_F10BANK2_FBIT1_MASK                           2

#define CAN2_F10BANK2_FBIT2_OFFSET                         2
#define CAN2_F10BANK2_FBIT2_MASK                           4

#define CAN2_F10BANK2_FBIT3_OFFSET                         3
#define CAN2_F10BANK2_FBIT3_MASK                           8

#define CAN2_F10BANK2_FBIT4_OFFSET                         4
#define CAN2_F10BANK2_FBIT4_MASK                           0x10

#define CAN2_F10BANK2_FBIT5_OFFSET                         5
#define CAN2_F10BANK2_FBIT5_MASK                           0x20

#define CAN2_F10BANK2_FBIT6_OFFSET                         6
#define CAN2_F10BANK2_FBIT6_MASK                           0x40

#define CAN2_F10BANK2_FBIT7_OFFSET                         7
#define CAN2_F10BANK2_FBIT7_MASK                           0x80

#define CAN2_F10BANK2_FBIT8_OFFSET                         8
#define CAN2_F10BANK2_FBIT8_MASK                           0x100

#define CAN2_F10BANK2_FBIT9_OFFSET                         9
#define CAN2_F10BANK2_FBIT9_MASK                           0x200

#define CAN2_F10BANK2_FBIT10_OFFSET                        10
#define CAN2_F10BANK2_FBIT10_MASK                          0x400

#define CAN2_F10BANK2_FBIT11_OFFSET                        11
#define CAN2_F10BANK2_FBIT11_MASK                          0x800

#define CAN2_F10BANK2_FBIT12_OFFSET                        12
#define CAN2_F10BANK2_FBIT12_MASK                          0x1000

#define CAN2_F10BANK2_FBIT13_OFFSET                        13
#define CAN2_F10BANK2_FBIT13_MASK                          0x2000

#define CAN2_F10BANK2_FBIT14_OFFSET                        14
#define CAN2_F10BANK2_FBIT14_MASK                          0x4000

#define CAN2_F10BANK2_FBIT15_OFFSET                        15
#define CAN2_F10BANK2_FBIT15_MASK                          0x8000

#define CAN2_F10BANK2_FBIT16_OFFSET                        16
#define CAN2_F10BANK2_FBIT16_MASK                          0x10000

#define CAN2_F10BANK2_FBIT17_OFFSET                        17
#define CAN2_F10BANK2_FBIT17_MASK                          0x20000

#define CAN2_F10BANK2_FBIT18_OFFSET                        18
#define CAN2_F10BANK2_FBIT18_MASK                          0x40000

#define CAN2_F10BANK2_FBIT19_OFFSET                        19
#define CAN2_F10BANK2_FBIT19_MASK                          0x80000

#define CAN2_F10BANK2_FBIT20_OFFSET                        20
#define CAN2_F10BANK2_FBIT20_MASK                          0x100000

#define CAN2_F10BANK2_FBIT21_OFFSET                        21
#define CAN2_F10BANK2_FBIT21_MASK                          0x200000

#define CAN2_F10BANK2_FBIT22_OFFSET                        22
#define CAN2_F10BANK2_FBIT22_MASK                          0x400000

#define CAN2_F10BANK2_FBIT23_OFFSET                        23
#define CAN2_F10BANK2_FBIT23_MASK                          0x800000

#define CAN2_F10BANK2_FBIT24_OFFSET                        24
#define CAN2_F10BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F10BANK2_FBIT25_OFFSET                        25
#define CAN2_F10BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F10BANK2_FBIT26_OFFSET                        26
#define CAN2_F10BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F10BANK2_FBIT27_OFFSET                        27
#define CAN2_F10BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F10BANK2_FBIT28_OFFSET                        28
#define CAN2_F10BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F10BANK2_FBIT29_OFFSET                        29
#define CAN2_F10BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F10BANK2_FBIT30_OFFSET                        30
#define CAN2_F10BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F10BANK2_FBIT31_OFFSET                        31
#define CAN2_F10BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F11BANK1_FBIT0_OFFSET                         0
#define CAN2_F11BANK1_FBIT0_MASK                           1

#define CAN2_F11BANK1_FBIT1_OFFSET                         1
#define CAN2_F11BANK1_FBIT1_MASK                           2

#define CAN2_F11BANK1_FBIT2_OFFSET                         2
#define CAN2_F11BANK1_FBIT2_MASK                           4

#define CAN2_F11BANK1_FBIT3_OFFSET                         3
#define CAN2_F11BANK1_FBIT3_MASK                           8

#define CAN2_F11BANK1_FBIT4_OFFSET                         4
#define CAN2_F11BANK1_FBIT4_MASK                           0x10

#define CAN2_F11BANK1_FBIT5_OFFSET                         5
#define CAN2_F11BANK1_FBIT5_MASK                           0x20

#define CAN2_F11BANK1_FBIT6_OFFSET                         6
#define CAN2_F11BANK1_FBIT6_MASK                           0x40

#define CAN2_F11BANK1_FBIT7_OFFSET                         7
#define CAN2_F11BANK1_FBIT7_MASK                           0x80

#define CAN2_F11BANK1_FBIT8_OFFSET                         8
#define CAN2_F11BANK1_FBIT8_MASK                           0x100

#define CAN2_F11BANK1_FBIT9_OFFSET                         9
#define CAN2_F11BANK1_FBIT9_MASK                           0x200

#define CAN2_F11BANK1_FBIT10_OFFSET                        10
#define CAN2_F11BANK1_FBIT10_MASK                          0x400

#define CAN2_F11BANK1_FBIT11_OFFSET                        11
#define CAN2_F11BANK1_FBIT11_MASK                          0x800

#define CAN2_F11BANK1_FBIT12_OFFSET                        12
#define CAN2_F11BANK1_FBIT12_MASK                          0x1000

#define CAN2_F11BANK1_FBIT13_OFFSET                        13
#define CAN2_F11BANK1_FBIT13_MASK                          0x2000

#define CAN2_F11BANK1_FBIT14_OFFSET                        14
#define CAN2_F11BANK1_FBIT14_MASK                          0x4000

#define CAN2_F11BANK1_FBIT15_OFFSET                        15
#define CAN2_F11BANK1_FBIT15_MASK                          0x8000

#define CAN2_F11BANK1_FBIT16_OFFSET                        16
#define CAN2_F11BANK1_FBIT16_MASK                          0x10000

#define CAN2_F11BANK1_FBIT17_OFFSET                        17
#define CAN2_F11BANK1_FBIT17_MASK                          0x20000

#define CAN2_F11BANK1_FBIT18_OFFSET                        18
#define CAN2_F11BANK1_FBIT18_MASK                          0x40000

#define CAN2_F11BANK1_FBIT19_OFFSET                        19
#define CAN2_F11BANK1_FBIT19_MASK                          0x80000

#define CAN2_F11BANK1_FBIT20_OFFSET                        20
#define CAN2_F11BANK1_FBIT20_MASK                          0x100000

#define CAN2_F11BANK1_FBIT21_OFFSET                        21
#define CAN2_F11BANK1_FBIT21_MASK                          0x200000

#define CAN2_F11BANK1_FBIT22_OFFSET                        22
#define CAN2_F11BANK1_FBIT22_MASK                          0x400000

#define CAN2_F11BANK1_FBIT23_OFFSET                        23
#define CAN2_F11BANK1_FBIT23_MASK                          0x800000

#define CAN2_F11BANK1_FBIT24_OFFSET                        24
#define CAN2_F11BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F11BANK1_FBIT25_OFFSET                        25
#define CAN2_F11BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F11BANK1_FBIT26_OFFSET                        26
#define CAN2_F11BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F11BANK1_FBIT27_OFFSET                        27
#define CAN2_F11BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F11BANK1_FBIT28_OFFSET                        28
#define CAN2_F11BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F11BANK1_FBIT29_OFFSET                        29
#define CAN2_F11BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F11BANK1_FBIT30_OFFSET                        30
#define CAN2_F11BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F11BANK1_FBIT31_OFFSET                        31
#define CAN2_F11BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F11BANK2_FBIT0_OFFSET                         0
#define CAN2_F11BANK2_FBIT0_MASK                           1

#define CAN2_F11BANK2_FBIT1_OFFSET                         1
#define CAN2_F11BANK2_FBIT1_MASK                           2

#define CAN2_F11BANK2_FBIT2_OFFSET                         2
#define CAN2_F11BANK2_FBIT2_MASK                           4

#define CAN2_F11BANK2_FBIT3_OFFSET                         3
#define CAN2_F11BANK2_FBIT3_MASK                           8

#define CAN2_F11BANK2_FBIT4_OFFSET                         4
#define CAN2_F11BANK2_FBIT4_MASK                           0x10

#define CAN2_F11BANK2_FBIT5_OFFSET                         5
#define CAN2_F11BANK2_FBIT5_MASK                           0x20

#define CAN2_F11BANK2_FBIT6_OFFSET                         6
#define CAN2_F11BANK2_FBIT6_MASK                           0x40

#define CAN2_F11BANK2_FBIT7_OFFSET                         7
#define CAN2_F11BANK2_FBIT7_MASK                           0x80

#define CAN2_F11BANK2_FBIT8_OFFSET                         8
#define CAN2_F11BANK2_FBIT8_MASK                           0x100

#define CAN2_F11BANK2_FBIT9_OFFSET                         9
#define CAN2_F11BANK2_FBIT9_MASK                           0x200

#define CAN2_F11BANK2_FBIT10_OFFSET                        10
#define CAN2_F11BANK2_FBIT10_MASK                          0x400

#define CAN2_F11BANK2_FBIT11_OFFSET                        11
#define CAN2_F11BANK2_FBIT11_MASK                          0x800

#define CAN2_F11BANK2_FBIT12_OFFSET                        12
#define CAN2_F11BANK2_FBIT12_MASK                          0x1000

#define CAN2_F11BANK2_FBIT13_OFFSET                        13
#define CAN2_F11BANK2_FBIT13_MASK                          0x2000

#define CAN2_F11BANK2_FBIT14_OFFSET                        14
#define CAN2_F11BANK2_FBIT14_MASK                          0x4000

#define CAN2_F11BANK2_FBIT15_OFFSET                        15
#define CAN2_F11BANK2_FBIT15_MASK                          0x8000

#define CAN2_F11BANK2_FBIT16_OFFSET                        16
#define CAN2_F11BANK2_FBIT16_MASK                          0x10000

#define CAN2_F11BANK2_FBIT17_OFFSET                        17
#define CAN2_F11BANK2_FBIT17_MASK                          0x20000

#define CAN2_F11BANK2_FBIT18_OFFSET                        18
#define CAN2_F11BANK2_FBIT18_MASK                          0x40000

#define CAN2_F11BANK2_FBIT19_OFFSET                        19
#define CAN2_F11BANK2_FBIT19_MASK                          0x80000

#define CAN2_F11BANK2_FBIT20_OFFSET                        20
#define CAN2_F11BANK2_FBIT20_MASK                          0x100000

#define CAN2_F11BANK2_FBIT21_OFFSET                        21
#define CAN2_F11BANK2_FBIT21_MASK                          0x200000

#define CAN2_F11BANK2_FBIT22_OFFSET                        22
#define CAN2_F11BANK2_FBIT22_MASK                          0x400000

#define CAN2_F11BANK2_FBIT23_OFFSET                        23
#define CAN2_F11BANK2_FBIT23_MASK                          0x800000

#define CAN2_F11BANK2_FBIT24_OFFSET                        24
#define CAN2_F11BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F11BANK2_FBIT25_OFFSET                        25
#define CAN2_F11BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F11BANK2_FBIT26_OFFSET                        26
#define CAN2_F11BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F11BANK2_FBIT27_OFFSET                        27
#define CAN2_F11BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F11BANK2_FBIT28_OFFSET                        28
#define CAN2_F11BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F11BANK2_FBIT29_OFFSET                        29
#define CAN2_F11BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F11BANK2_FBIT30_OFFSET                        30
#define CAN2_F11BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F11BANK2_FBIT31_OFFSET                        31
#define CAN2_F11BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F12BANK1_FBIT0_OFFSET                         0
#define CAN2_F12BANK1_FBIT0_MASK                           1

#define CAN2_F12BANK1_FBIT1_OFFSET                         1
#define CAN2_F12BANK1_FBIT1_MASK                           2

#define CAN2_F12BANK1_FBIT2_OFFSET                         2
#define CAN2_F12BANK1_FBIT2_MASK                           4

#define CAN2_F12BANK1_FBIT3_OFFSET                         3
#define CAN2_F12BANK1_FBIT3_MASK                           8

#define CAN2_F12BANK1_FBIT4_OFFSET                         4
#define CAN2_F12BANK1_FBIT4_MASK                           0x10

#define CAN2_F12BANK1_FBIT5_OFFSET                         5
#define CAN2_F12BANK1_FBIT5_MASK                           0x20

#define CAN2_F12BANK1_FBIT6_OFFSET                         6
#define CAN2_F12BANK1_FBIT6_MASK                           0x40

#define CAN2_F12BANK1_FBIT7_OFFSET                         7
#define CAN2_F12BANK1_FBIT7_MASK                           0x80

#define CAN2_F12BANK1_FBIT8_OFFSET                         8
#define CAN2_F12BANK1_FBIT8_MASK                           0x100

#define CAN2_F12BANK1_FBIT9_OFFSET                         9
#define CAN2_F12BANK1_FBIT9_MASK                           0x200

#define CAN2_F12BANK1_FBIT10_OFFSET                        10
#define CAN2_F12BANK1_FBIT10_MASK                          0x400

#define CAN2_F12BANK1_FBIT11_OFFSET                        11
#define CAN2_F12BANK1_FBIT11_MASK                          0x800

#define CAN2_F12BANK1_FBIT12_OFFSET                        12
#define CAN2_F12BANK1_FBIT12_MASK                          0x1000

#define CAN2_F12BANK1_FBIT13_OFFSET                        13
#define CAN2_F12BANK1_FBIT13_MASK                          0x2000

#define CAN2_F12BANK1_FBIT14_OFFSET                        14
#define CAN2_F12BANK1_FBIT14_MASK                          0x4000

#define CAN2_F12BANK1_FBIT15_OFFSET                        15
#define CAN2_F12BANK1_FBIT15_MASK                          0x8000

#define CAN2_F12BANK1_FBIT16_OFFSET                        16
#define CAN2_F12BANK1_FBIT16_MASK                          0x10000

#define CAN2_F12BANK1_FBIT17_OFFSET                        17
#define CAN2_F12BANK1_FBIT17_MASK                          0x20000

#define CAN2_F12BANK1_FBIT18_OFFSET                        18
#define CAN2_F12BANK1_FBIT18_MASK                          0x40000

#define CAN2_F12BANK1_FBIT19_OFFSET                        19
#define CAN2_F12BANK1_FBIT19_MASK                          0x80000

#define CAN2_F12BANK1_FBIT20_OFFSET                        20
#define CAN2_F12BANK1_FBIT20_MASK                          0x100000

#define CAN2_F12BANK1_FBIT21_OFFSET                        21
#define CAN2_F12BANK1_FBIT21_MASK                          0x200000

#define CAN2_F12BANK1_FBIT22_OFFSET                        22
#define CAN2_F12BANK1_FBIT22_MASK                          0x400000

#define CAN2_F12BANK1_FBIT23_OFFSET                        23
#define CAN2_F12BANK1_FBIT23_MASK                          0x800000

#define CAN2_F12BANK1_FBIT24_OFFSET                        24
#define CAN2_F12BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F12BANK1_FBIT25_OFFSET                        25
#define CAN2_F12BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F12BANK1_FBIT26_OFFSET                        26
#define CAN2_F12BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F12BANK1_FBIT27_OFFSET                        27
#define CAN2_F12BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F12BANK1_FBIT28_OFFSET                        28
#define CAN2_F12BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F12BANK1_FBIT29_OFFSET                        29
#define CAN2_F12BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F12BANK1_FBIT30_OFFSET                        30
#define CAN2_F12BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F12BANK1_FBIT31_OFFSET                        31
#define CAN2_F12BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F12BANK2_FBIT0_OFFSET                         0
#define CAN2_F12BANK2_FBIT0_MASK                           1

#define CAN2_F12BANK2_FBIT1_OFFSET                         1
#define CAN2_F12BANK2_FBIT1_MASK                           2

#define CAN2_F12BANK2_FBIT2_OFFSET                         2
#define CAN2_F12BANK2_FBIT2_MASK                           4

#define CAN2_F12BANK2_FBIT3_OFFSET                         3
#define CAN2_F12BANK2_FBIT3_MASK                           8

#define CAN2_F12BANK2_FBIT4_OFFSET                         4
#define CAN2_F12BANK2_FBIT4_MASK                           0x10

#define CAN2_F12BANK2_FBIT5_OFFSET                         5
#define CAN2_F12BANK2_FBIT5_MASK                           0x20

#define CAN2_F12BANK2_FBIT6_OFFSET                         6
#define CAN2_F12BANK2_FBIT6_MASK                           0x40

#define CAN2_F12BANK2_FBIT7_OFFSET                         7
#define CAN2_F12BANK2_FBIT7_MASK                           0x80

#define CAN2_F12BANK2_FBIT8_OFFSET                         8
#define CAN2_F12BANK2_FBIT8_MASK                           0x100

#define CAN2_F12BANK2_FBIT9_OFFSET                         9
#define CAN2_F12BANK2_FBIT9_MASK                           0x200

#define CAN2_F12BANK2_FBIT10_OFFSET                        10
#define CAN2_F12BANK2_FBIT10_MASK                          0x400

#define CAN2_F12BANK2_FBIT11_OFFSET                        11
#define CAN2_F12BANK2_FBIT11_MASK                          0x800

#define CAN2_F12BANK2_FBIT12_OFFSET                        12
#define CAN2_F12BANK2_FBIT12_MASK                          0x1000

#define CAN2_F12BANK2_FBIT13_OFFSET                        13
#define CAN2_F12BANK2_FBIT13_MASK                          0x2000

#define CAN2_F12BANK2_FBIT14_OFFSET                        14
#define CAN2_F12BANK2_FBIT14_MASK                          0x4000

#define CAN2_F12BANK2_FBIT15_OFFSET                        15
#define CAN2_F12BANK2_FBIT15_MASK                          0x8000

#define CAN2_F12BANK2_FBIT16_OFFSET                        16
#define CAN2_F12BANK2_FBIT16_MASK                          0x10000

#define CAN2_F12BANK2_FBIT17_OFFSET                        17
#define CAN2_F12BANK2_FBIT17_MASK                          0x20000

#define CAN2_F12BANK2_FBIT18_OFFSET                        18
#define CAN2_F12BANK2_FBIT18_MASK                          0x40000

#define CAN2_F12BANK2_FBIT19_OFFSET                        19
#define CAN2_F12BANK2_FBIT19_MASK                          0x80000

#define CAN2_F12BANK2_FBIT20_OFFSET                        20
#define CAN2_F12BANK2_FBIT20_MASK                          0x100000

#define CAN2_F12BANK2_FBIT21_OFFSET                        21
#define CAN2_F12BANK2_FBIT21_MASK                          0x200000

#define CAN2_F12BANK2_FBIT22_OFFSET                        22
#define CAN2_F12BANK2_FBIT22_MASK                          0x400000

#define CAN2_F12BANK2_FBIT23_OFFSET                        23
#define CAN2_F12BANK2_FBIT23_MASK                          0x800000

#define CAN2_F12BANK2_FBIT24_OFFSET                        24
#define CAN2_F12BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F12BANK2_FBIT25_OFFSET                        25
#define CAN2_F12BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F12BANK2_FBIT26_OFFSET                        26
#define CAN2_F12BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F12BANK2_FBIT27_OFFSET                        27
#define CAN2_F12BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F12BANK2_FBIT28_OFFSET                        28
#define CAN2_F12BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F12BANK2_FBIT29_OFFSET                        29
#define CAN2_F12BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F12BANK2_FBIT30_OFFSET                        30
#define CAN2_F12BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F12BANK2_FBIT31_OFFSET                        31
#define CAN2_F12BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F13BANK1_FBIT0_OFFSET                         0
#define CAN2_F13BANK1_FBIT0_MASK                           1

#define CAN2_F13BANK1_FBIT1_OFFSET                         1
#define CAN2_F13BANK1_FBIT1_MASK                           2

#define CAN2_F13BANK1_FBIT2_OFFSET                         2
#define CAN2_F13BANK1_FBIT2_MASK                           4

#define CAN2_F13BANK1_FBIT3_OFFSET                         3
#define CAN2_F13BANK1_FBIT3_MASK                           8

#define CAN2_F13BANK1_FBIT4_OFFSET                         4
#define CAN2_F13BANK1_FBIT4_MASK                           0x10

#define CAN2_F13BANK1_FBIT5_OFFSET                         5
#define CAN2_F13BANK1_FBIT5_MASK                           0x20

#define CAN2_F13BANK1_FBIT6_OFFSET                         6
#define CAN2_F13BANK1_FBIT6_MASK                           0x40

#define CAN2_F13BANK1_FBIT7_OFFSET                         7
#define CAN2_F13BANK1_FBIT7_MASK                           0x80

#define CAN2_F13BANK1_FBIT8_OFFSET                         8
#define CAN2_F13BANK1_FBIT8_MASK                           0x100

#define CAN2_F13BANK1_FBIT9_OFFSET                         9
#define CAN2_F13BANK1_FBIT9_MASK                           0x200

#define CAN2_F13BANK1_FBIT10_OFFSET                        10
#define CAN2_F13BANK1_FBIT10_MASK                          0x400

#define CAN2_F13BANK1_FBIT11_OFFSET                        11
#define CAN2_F13BANK1_FBIT11_MASK                          0x800

#define CAN2_F13BANK1_FBIT12_OFFSET                        12
#define CAN2_F13BANK1_FBIT12_MASK                          0x1000

#define CAN2_F13BANK1_FBIT13_OFFSET                        13
#define CAN2_F13BANK1_FBIT13_MASK                          0x2000

#define CAN2_F13BANK1_FBIT14_OFFSET                        14
#define CAN2_F13BANK1_FBIT14_MASK                          0x4000

#define CAN2_F13BANK1_FBIT15_OFFSET                        15
#define CAN2_F13BANK1_FBIT15_MASK                          0x8000

#define CAN2_F13BANK1_FBIT16_OFFSET                        16
#define CAN2_F13BANK1_FBIT16_MASK                          0x10000

#define CAN2_F13BANK1_FBIT17_OFFSET                        17
#define CAN2_F13BANK1_FBIT17_MASK                          0x20000

#define CAN2_F13BANK1_FBIT18_OFFSET                        18
#define CAN2_F13BANK1_FBIT18_MASK                          0x40000

#define CAN2_F13BANK1_FBIT19_OFFSET                        19
#define CAN2_F13BANK1_FBIT19_MASK                          0x80000

#define CAN2_F13BANK1_FBIT20_OFFSET                        20
#define CAN2_F13BANK1_FBIT20_MASK                          0x100000

#define CAN2_F13BANK1_FBIT21_OFFSET                        21
#define CAN2_F13BANK1_FBIT21_MASK                          0x200000

#define CAN2_F13BANK1_FBIT22_OFFSET                        22
#define CAN2_F13BANK1_FBIT22_MASK                          0x400000

#define CAN2_F13BANK1_FBIT23_OFFSET                        23
#define CAN2_F13BANK1_FBIT23_MASK                          0x800000

#define CAN2_F13BANK1_FBIT24_OFFSET                        24
#define CAN2_F13BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F13BANK1_FBIT25_OFFSET                        25
#define CAN2_F13BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F13BANK1_FBIT26_OFFSET                        26
#define CAN2_F13BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F13BANK1_FBIT27_OFFSET                        27
#define CAN2_F13BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F13BANK1_FBIT28_OFFSET                        28
#define CAN2_F13BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F13BANK1_FBIT29_OFFSET                        29
#define CAN2_F13BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F13BANK1_FBIT30_OFFSET                        30
#define CAN2_F13BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F13BANK1_FBIT31_OFFSET                        31
#define CAN2_F13BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F13BANK2_FBIT0_OFFSET                         0
#define CAN2_F13BANK2_FBIT0_MASK                           1

#define CAN2_F13BANK2_FBIT1_OFFSET                         1
#define CAN2_F13BANK2_FBIT1_MASK                           2

#define CAN2_F13BANK2_FBIT2_OFFSET                         2
#define CAN2_F13BANK2_FBIT2_MASK                           4

#define CAN2_F13BANK2_FBIT3_OFFSET                         3
#define CAN2_F13BANK2_FBIT3_MASK                           8

#define CAN2_F13BANK2_FBIT4_OFFSET                         4
#define CAN2_F13BANK2_FBIT4_MASK                           0x10

#define CAN2_F13BANK2_FBIT5_OFFSET                         5
#define CAN2_F13BANK2_FBIT5_MASK                           0x20

#define CAN2_F13BANK2_FBIT6_OFFSET                         6
#define CAN2_F13BANK2_FBIT6_MASK                           0x40

#define CAN2_F13BANK2_FBIT7_OFFSET                         7
#define CAN2_F13BANK2_FBIT7_MASK                           0x80

#define CAN2_F13BANK2_FBIT8_OFFSET                         8
#define CAN2_F13BANK2_FBIT8_MASK                           0x100

#define CAN2_F13BANK2_FBIT9_OFFSET                         9
#define CAN2_F13BANK2_FBIT9_MASK                           0x200

#define CAN2_F13BANK2_FBIT10_OFFSET                        10
#define CAN2_F13BANK2_FBIT10_MASK                          0x400

#define CAN2_F13BANK2_FBIT11_OFFSET                        11
#define CAN2_F13BANK2_FBIT11_MASK                          0x800

#define CAN2_F13BANK2_FBIT12_OFFSET                        12
#define CAN2_F13BANK2_FBIT12_MASK                          0x1000

#define CAN2_F13BANK2_FBIT13_OFFSET                        13
#define CAN2_F13BANK2_FBIT13_MASK                          0x2000

#define CAN2_F13BANK2_FBIT14_OFFSET                        14
#define CAN2_F13BANK2_FBIT14_MASK                          0x4000

#define CAN2_F13BANK2_FBIT15_OFFSET                        15
#define CAN2_F13BANK2_FBIT15_MASK                          0x8000

#define CAN2_F13BANK2_FBIT16_OFFSET                        16
#define CAN2_F13BANK2_FBIT16_MASK                          0x10000

#define CAN2_F13BANK2_FBIT17_OFFSET                        17
#define CAN2_F13BANK2_FBIT17_MASK                          0x20000

#define CAN2_F13BANK2_FBIT18_OFFSET                        18
#define CAN2_F13BANK2_FBIT18_MASK                          0x40000

#define CAN2_F13BANK2_FBIT19_OFFSET                        19
#define CAN2_F13BANK2_FBIT19_MASK                          0x80000

#define CAN2_F13BANK2_FBIT20_OFFSET                        20
#define CAN2_F13BANK2_FBIT20_MASK                          0x100000

#define CAN2_F13BANK2_FBIT21_OFFSET                        21
#define CAN2_F13BANK2_FBIT21_MASK                          0x200000

#define CAN2_F13BANK2_FBIT22_OFFSET                        22
#define CAN2_F13BANK2_FBIT22_MASK                          0x400000

#define CAN2_F13BANK2_FBIT23_OFFSET                        23
#define CAN2_F13BANK2_FBIT23_MASK                          0x800000

#define CAN2_F13BANK2_FBIT24_OFFSET                        24
#define CAN2_F13BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F13BANK2_FBIT25_OFFSET                        25
#define CAN2_F13BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F13BANK2_FBIT26_OFFSET                        26
#define CAN2_F13BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F13BANK2_FBIT27_OFFSET                        27
#define CAN2_F13BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F13BANK2_FBIT28_OFFSET                        28
#define CAN2_F13BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F13BANK2_FBIT29_OFFSET                        29
#define CAN2_F13BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F13BANK2_FBIT30_OFFSET                        30
#define CAN2_F13BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F13BANK2_FBIT31_OFFSET                        31
#define CAN2_F13BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F14BANK1_FBIT0_OFFSET                         0
#define CAN2_F14BANK1_FBIT0_MASK                           1

#define CAN2_F14BANK1_FBIT1_OFFSET                         1
#define CAN2_F14BANK1_FBIT1_MASK                           2

#define CAN2_F14BANK1_FBIT2_OFFSET                         2
#define CAN2_F14BANK1_FBIT2_MASK                           4

#define CAN2_F14BANK1_FBIT3_OFFSET                         3
#define CAN2_F14BANK1_FBIT3_MASK                           8

#define CAN2_F14BANK1_FBIT4_OFFSET                         4
#define CAN2_F14BANK1_FBIT4_MASK                           0x10

#define CAN2_F14BANK1_FBIT5_OFFSET                         5
#define CAN2_F14BANK1_FBIT5_MASK                           0x20

#define CAN2_F14BANK1_FBIT6_OFFSET                         6
#define CAN2_F14BANK1_FBIT6_MASK                           0x40

#define CAN2_F14BANK1_FBIT7_OFFSET                         7
#define CAN2_F14BANK1_FBIT7_MASK                           0x80

#define CAN2_F14BANK1_FBIT8_OFFSET                         8
#define CAN2_F14BANK1_FBIT8_MASK                           0x100

#define CAN2_F14BANK1_FBIT9_OFFSET                         9
#define CAN2_F14BANK1_FBIT9_MASK                           0x200

#define CAN2_F14BANK1_FBIT10_OFFSET                        10
#define CAN2_F14BANK1_FBIT10_MASK                          0x400

#define CAN2_F14BANK1_FBIT11_OFFSET                        11
#define CAN2_F14BANK1_FBIT11_MASK                          0x800

#define CAN2_F14BANK1_FBIT12_OFFSET                        12
#define CAN2_F14BANK1_FBIT12_MASK                          0x1000

#define CAN2_F14BANK1_FBIT13_OFFSET                        13
#define CAN2_F14BANK1_FBIT13_MASK                          0x2000

#define CAN2_F14BANK1_FBIT14_OFFSET                        14
#define CAN2_F14BANK1_FBIT14_MASK                          0x4000

#define CAN2_F14BANK1_FBIT15_OFFSET                        15
#define CAN2_F14BANK1_FBIT15_MASK                          0x8000

#define CAN2_F14BANK1_FBIT16_OFFSET                        16
#define CAN2_F14BANK1_FBIT16_MASK                          0x10000

#define CAN2_F14BANK1_FBIT17_OFFSET                        17
#define CAN2_F14BANK1_FBIT17_MASK                          0x20000

#define CAN2_F14BANK1_FBIT18_OFFSET                        18
#define CAN2_F14BANK1_FBIT18_MASK                          0x40000

#define CAN2_F14BANK1_FBIT19_OFFSET                        19
#define CAN2_F14BANK1_FBIT19_MASK                          0x80000

#define CAN2_F14BANK1_FBIT20_OFFSET                        20
#define CAN2_F14BANK1_FBIT20_MASK                          0x100000

#define CAN2_F14BANK1_FBIT21_OFFSET                        21
#define CAN2_F14BANK1_FBIT21_MASK                          0x200000

#define CAN2_F14BANK1_FBIT22_OFFSET                        22
#define CAN2_F14BANK1_FBIT22_MASK                          0x400000

#define CAN2_F14BANK1_FBIT23_OFFSET                        23
#define CAN2_F14BANK1_FBIT23_MASK                          0x800000

#define CAN2_F14BANK1_FBIT24_OFFSET                        24
#define CAN2_F14BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F14BANK1_FBIT25_OFFSET                        25
#define CAN2_F14BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F14BANK1_FBIT26_OFFSET                        26
#define CAN2_F14BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F14BANK1_FBIT27_OFFSET                        27
#define CAN2_F14BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F14BANK1_FBIT28_OFFSET                        28
#define CAN2_F14BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F14BANK1_FBIT29_OFFSET                        29
#define CAN2_F14BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F14BANK1_FBIT30_OFFSET                        30
#define CAN2_F14BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F14BANK1_FBIT31_OFFSET                        31
#define CAN2_F14BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F14BANK2_FBIT0_OFFSET                         0
#define CAN2_F14BANK2_FBIT0_MASK                           1

#define CAN2_F14BANK2_FBIT1_OFFSET                         1
#define CAN2_F14BANK2_FBIT1_MASK                           2

#define CAN2_F14BANK2_FBIT2_OFFSET                         2
#define CAN2_F14BANK2_FBIT2_MASK                           4

#define CAN2_F14BANK2_FBIT3_OFFSET                         3
#define CAN2_F14BANK2_FBIT3_MASK                           8

#define CAN2_F14BANK2_FBIT4_OFFSET                         4
#define CAN2_F14BANK2_FBIT4_MASK                           0x10

#define CAN2_F14BANK2_FBIT5_OFFSET                         5
#define CAN2_F14BANK2_FBIT5_MASK                           0x20

#define CAN2_F14BANK2_FBIT6_OFFSET                         6
#define CAN2_F14BANK2_FBIT6_MASK                           0x40

#define CAN2_F14BANK2_FBIT7_OFFSET                         7
#define CAN2_F14BANK2_FBIT7_MASK                           0x80

#define CAN2_F14BANK2_FBIT8_OFFSET                         8
#define CAN2_F14BANK2_FBIT8_MASK                           0x100

#define CAN2_F14BANK2_FBIT9_OFFSET                         9
#define CAN2_F14BANK2_FBIT9_MASK                           0x200

#define CAN2_F14BANK2_FBIT10_OFFSET                        10
#define CAN2_F14BANK2_FBIT10_MASK                          0x400

#define CAN2_F14BANK2_FBIT11_OFFSET                        11
#define CAN2_F14BANK2_FBIT11_MASK                          0x800

#define CAN2_F14BANK2_FBIT12_OFFSET                        12
#define CAN2_F14BANK2_FBIT12_MASK                          0x1000

#define CAN2_F14BANK2_FBIT13_OFFSET                        13
#define CAN2_F14BANK2_FBIT13_MASK                          0x2000

#define CAN2_F14BANK2_FBIT14_OFFSET                        14
#define CAN2_F14BANK2_FBIT14_MASK                          0x4000

#define CAN2_F14BANK2_FBIT15_OFFSET                        15
#define CAN2_F14BANK2_FBIT15_MASK                          0x8000

#define CAN2_F14BANK2_FBIT16_OFFSET                        16
#define CAN2_F14BANK2_FBIT16_MASK                          0x10000

#define CAN2_F14BANK2_FBIT17_OFFSET                        17
#define CAN2_F14BANK2_FBIT17_MASK                          0x20000

#define CAN2_F14BANK2_FBIT18_OFFSET                        18
#define CAN2_F14BANK2_FBIT18_MASK                          0x40000

#define CAN2_F14BANK2_FBIT19_OFFSET                        19
#define CAN2_F14BANK2_FBIT19_MASK                          0x80000

#define CAN2_F14BANK2_FBIT20_OFFSET                        20
#define CAN2_F14BANK2_FBIT20_MASK                          0x100000

#define CAN2_F14BANK2_FBIT21_OFFSET                        21
#define CAN2_F14BANK2_FBIT21_MASK                          0x200000

#define CAN2_F14BANK2_FBIT22_OFFSET                        22
#define CAN2_F14BANK2_FBIT22_MASK                          0x400000

#define CAN2_F14BANK2_FBIT23_OFFSET                        23
#define CAN2_F14BANK2_FBIT23_MASK                          0x800000

#define CAN2_F14BANK2_FBIT24_OFFSET                        24
#define CAN2_F14BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F14BANK2_FBIT25_OFFSET                        25
#define CAN2_F14BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F14BANK2_FBIT26_OFFSET                        26
#define CAN2_F14BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F14BANK2_FBIT27_OFFSET                        27
#define CAN2_F14BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F14BANK2_FBIT28_OFFSET                        28
#define CAN2_F14BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F14BANK2_FBIT29_OFFSET                        29
#define CAN2_F14BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F14BANK2_FBIT30_OFFSET                        30
#define CAN2_F14BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F14BANK2_FBIT31_OFFSET                        31
#define CAN2_F14BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F15BANK1_FBIT0_OFFSET                         0
#define CAN2_F15BANK1_FBIT0_MASK                           1

#define CAN2_F15BANK1_FBIT1_OFFSET                         1
#define CAN2_F15BANK1_FBIT1_MASK                           2

#define CAN2_F15BANK1_FBIT2_OFFSET                         2
#define CAN2_F15BANK1_FBIT2_MASK                           4

#define CAN2_F15BANK1_FBIT3_OFFSET                         3
#define CAN2_F15BANK1_FBIT3_MASK                           8

#define CAN2_F15BANK1_FBIT4_OFFSET                         4
#define CAN2_F15BANK1_FBIT4_MASK                           0x10

#define CAN2_F15BANK1_FBIT5_OFFSET                         5
#define CAN2_F15BANK1_FBIT5_MASK                           0x20

#define CAN2_F15BANK1_FBIT6_OFFSET                         6
#define CAN2_F15BANK1_FBIT6_MASK                           0x40

#define CAN2_F15BANK1_FBIT7_OFFSET                         7
#define CAN2_F15BANK1_FBIT7_MASK                           0x80

#define CAN2_F15BANK1_FBIT8_OFFSET                         8
#define CAN2_F15BANK1_FBIT8_MASK                           0x100

#define CAN2_F15BANK1_FBIT9_OFFSET                         9
#define CAN2_F15BANK1_FBIT9_MASK                           0x200

#define CAN2_F15BANK1_FBIT10_OFFSET                        10
#define CAN2_F15BANK1_FBIT10_MASK                          0x400

#define CAN2_F15BANK1_FBIT11_OFFSET                        11
#define CAN2_F15BANK1_FBIT11_MASK                          0x800

#define CAN2_F15BANK1_FBIT12_OFFSET                        12
#define CAN2_F15BANK1_FBIT12_MASK                          0x1000

#define CAN2_F15BANK1_FBIT13_OFFSET                        13
#define CAN2_F15BANK1_FBIT13_MASK                          0x2000

#define CAN2_F15BANK1_FBIT14_OFFSET                        14
#define CAN2_F15BANK1_FBIT14_MASK                          0x4000

#define CAN2_F15BANK1_FBIT15_OFFSET                        15
#define CAN2_F15BANK1_FBIT15_MASK                          0x8000

#define CAN2_F15BANK1_FBIT16_OFFSET                        16
#define CAN2_F15BANK1_FBIT16_MASK                          0x10000

#define CAN2_F15BANK1_FBIT17_OFFSET                        17
#define CAN2_F15BANK1_FBIT17_MASK                          0x20000

#define CAN2_F15BANK1_FBIT18_OFFSET                        18
#define CAN2_F15BANK1_FBIT18_MASK                          0x40000

#define CAN2_F15BANK1_FBIT19_OFFSET                        19
#define CAN2_F15BANK1_FBIT19_MASK                          0x80000

#define CAN2_F15BANK1_FBIT20_OFFSET                        20
#define CAN2_F15BANK1_FBIT20_MASK                          0x100000

#define CAN2_F15BANK1_FBIT21_OFFSET                        21
#define CAN2_F15BANK1_FBIT21_MASK                          0x200000

#define CAN2_F15BANK1_FBIT22_OFFSET                        22
#define CAN2_F15BANK1_FBIT22_MASK                          0x400000

#define CAN2_F15BANK1_FBIT23_OFFSET                        23
#define CAN2_F15BANK1_FBIT23_MASK                          0x800000

#define CAN2_F15BANK1_FBIT24_OFFSET                        24
#define CAN2_F15BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F15BANK1_FBIT25_OFFSET                        25
#define CAN2_F15BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F15BANK1_FBIT26_OFFSET                        26
#define CAN2_F15BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F15BANK1_FBIT27_OFFSET                        27
#define CAN2_F15BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F15BANK1_FBIT28_OFFSET                        28
#define CAN2_F15BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F15BANK1_FBIT29_OFFSET                        29
#define CAN2_F15BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F15BANK1_FBIT30_OFFSET                        30
#define CAN2_F15BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F15BANK1_FBIT31_OFFSET                        31
#define CAN2_F15BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F15BANK2_FBIT0_OFFSET                         0
#define CAN2_F15BANK2_FBIT0_MASK                           1

#define CAN2_F15BANK2_FBIT1_OFFSET                         1
#define CAN2_F15BANK2_FBIT1_MASK                           2

#define CAN2_F15BANK2_FBIT2_OFFSET                         2
#define CAN2_F15BANK2_FBIT2_MASK                           4

#define CAN2_F15BANK2_FBIT3_OFFSET                         3
#define CAN2_F15BANK2_FBIT3_MASK                           8

#define CAN2_F15BANK2_FBIT4_OFFSET                         4
#define CAN2_F15BANK2_FBIT4_MASK                           0x10

#define CAN2_F15BANK2_FBIT5_OFFSET                         5
#define CAN2_F15BANK2_FBIT5_MASK                           0x20

#define CAN2_F15BANK2_FBIT6_OFFSET                         6
#define CAN2_F15BANK2_FBIT6_MASK                           0x40

#define CAN2_F15BANK2_FBIT7_OFFSET                         7
#define CAN2_F15BANK2_FBIT7_MASK                           0x80

#define CAN2_F15BANK2_FBIT8_OFFSET                         8
#define CAN2_F15BANK2_FBIT8_MASK                           0x100

#define CAN2_F15BANK2_FBIT9_OFFSET                         9
#define CAN2_F15BANK2_FBIT9_MASK                           0x200

#define CAN2_F15BANK2_FBIT10_OFFSET                        10
#define CAN2_F15BANK2_FBIT10_MASK                          0x400

#define CAN2_F15BANK2_FBIT11_OFFSET                        11
#define CAN2_F15BANK2_FBIT11_MASK                          0x800

#define CAN2_F15BANK2_FBIT12_OFFSET                        12
#define CAN2_F15BANK2_FBIT12_MASK                          0x1000

#define CAN2_F15BANK2_FBIT13_OFFSET                        13
#define CAN2_F15BANK2_FBIT13_MASK                          0x2000

#define CAN2_F15BANK2_FBIT14_OFFSET                        14
#define CAN2_F15BANK2_FBIT14_MASK                          0x4000

#define CAN2_F15BANK2_FBIT15_OFFSET                        15
#define CAN2_F15BANK2_FBIT15_MASK                          0x8000

#define CAN2_F15BANK2_FBIT16_OFFSET                        16
#define CAN2_F15BANK2_FBIT16_MASK                          0x10000

#define CAN2_F15BANK2_FBIT17_OFFSET                        17
#define CAN2_F15BANK2_FBIT17_MASK                          0x20000

#define CAN2_F15BANK2_FBIT18_OFFSET                        18
#define CAN2_F15BANK2_FBIT18_MASK                          0x40000

#define CAN2_F15BANK2_FBIT19_OFFSET                        19
#define CAN2_F15BANK2_FBIT19_MASK                          0x80000

#define CAN2_F15BANK2_FBIT20_OFFSET                        20
#define CAN2_F15BANK2_FBIT20_MASK                          0x100000

#define CAN2_F15BANK2_FBIT21_OFFSET                        21
#define CAN2_F15BANK2_FBIT21_MASK                          0x200000

#define CAN2_F15BANK2_FBIT22_OFFSET                        22
#define CAN2_F15BANK2_FBIT22_MASK                          0x400000

#define CAN2_F15BANK2_FBIT23_OFFSET                        23
#define CAN2_F15BANK2_FBIT23_MASK                          0x800000

#define CAN2_F15BANK2_FBIT24_OFFSET                        24
#define CAN2_F15BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F15BANK2_FBIT25_OFFSET                        25
#define CAN2_F15BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F15BANK2_FBIT26_OFFSET                        26
#define CAN2_F15BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F15BANK2_FBIT27_OFFSET                        27
#define CAN2_F15BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F15BANK2_FBIT28_OFFSET                        28
#define CAN2_F15BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F15BANK2_FBIT29_OFFSET                        29
#define CAN2_F15BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F15BANK2_FBIT30_OFFSET                        30
#define CAN2_F15BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F15BANK2_FBIT31_OFFSET                        31
#define CAN2_F15BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F16BANK1_FBIT0_OFFSET                         0
#define CAN2_F16BANK1_FBIT0_MASK                           1

#define CAN2_F16BANK1_FBIT1_OFFSET                         1
#define CAN2_F16BANK1_FBIT1_MASK                           2

#define CAN2_F16BANK1_FBIT2_OFFSET                         2
#define CAN2_F16BANK1_FBIT2_MASK                           4

#define CAN2_F16BANK1_FBIT3_OFFSET                         3
#define CAN2_F16BANK1_FBIT3_MASK                           8

#define CAN2_F16BANK1_FBIT4_OFFSET                         4
#define CAN2_F16BANK1_FBIT4_MASK                           0x10

#define CAN2_F16BANK1_FBIT5_OFFSET                         5
#define CAN2_F16BANK1_FBIT5_MASK                           0x20

#define CAN2_F16BANK1_FBIT6_OFFSET                         6
#define CAN2_F16BANK1_FBIT6_MASK                           0x40

#define CAN2_F16BANK1_FBIT7_OFFSET                         7
#define CAN2_F16BANK1_FBIT7_MASK                           0x80

#define CAN2_F16BANK1_FBIT8_OFFSET                         8
#define CAN2_F16BANK1_FBIT8_MASK                           0x100

#define CAN2_F16BANK1_FBIT9_OFFSET                         9
#define CAN2_F16BANK1_FBIT9_MASK                           0x200

#define CAN2_F16BANK1_FBIT10_OFFSET                        10
#define CAN2_F16BANK1_FBIT10_MASK                          0x400

#define CAN2_F16BANK1_FBIT11_OFFSET                        11
#define CAN2_F16BANK1_FBIT11_MASK                          0x800

#define CAN2_F16BANK1_FBIT12_OFFSET                        12
#define CAN2_F16BANK1_FBIT12_MASK                          0x1000

#define CAN2_F16BANK1_FBIT13_OFFSET                        13
#define CAN2_F16BANK1_FBIT13_MASK                          0x2000

#define CAN2_F16BANK1_FBIT14_OFFSET                        14
#define CAN2_F16BANK1_FBIT14_MASK                          0x4000

#define CAN2_F16BANK1_FBIT15_OFFSET                        15
#define CAN2_F16BANK1_FBIT15_MASK                          0x8000

#define CAN2_F16BANK1_FBIT16_OFFSET                        16
#define CAN2_F16BANK1_FBIT16_MASK                          0x10000

#define CAN2_F16BANK1_FBIT17_OFFSET                        17
#define CAN2_F16BANK1_FBIT17_MASK                          0x20000

#define CAN2_F16BANK1_FBIT18_OFFSET                        18
#define CAN2_F16BANK1_FBIT18_MASK                          0x40000

#define CAN2_F16BANK1_FBIT19_OFFSET                        19
#define CAN2_F16BANK1_FBIT19_MASK                          0x80000

#define CAN2_F16BANK1_FBIT20_OFFSET                        20
#define CAN2_F16BANK1_FBIT20_MASK                          0x100000

#define CAN2_F16BANK1_FBIT21_OFFSET                        21
#define CAN2_F16BANK1_FBIT21_MASK                          0x200000

#define CAN2_F16BANK1_FBIT22_OFFSET                        22
#define CAN2_F16BANK1_FBIT22_MASK                          0x400000

#define CAN2_F16BANK1_FBIT23_OFFSET                        23
#define CAN2_F16BANK1_FBIT23_MASK                          0x800000

#define CAN2_F16BANK1_FBIT24_OFFSET                        24
#define CAN2_F16BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F16BANK1_FBIT25_OFFSET                        25
#define CAN2_F16BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F16BANK1_FBIT26_OFFSET                        26
#define CAN2_F16BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F16BANK1_FBIT27_OFFSET                        27
#define CAN2_F16BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F16BANK1_FBIT28_OFFSET                        28
#define CAN2_F16BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F16BANK1_FBIT29_OFFSET                        29
#define CAN2_F16BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F16BANK1_FBIT30_OFFSET                        30
#define CAN2_F16BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F16BANK1_FBIT31_OFFSET                        31
#define CAN2_F16BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F16BANK2_FBIT0_OFFSET                         0
#define CAN2_F16BANK2_FBIT0_MASK                           1

#define CAN2_F16BANK2_FBIT1_OFFSET                         1
#define CAN2_F16BANK2_FBIT1_MASK                           2

#define CAN2_F16BANK2_FBIT2_OFFSET                         2
#define CAN2_F16BANK2_FBIT2_MASK                           4

#define CAN2_F16BANK2_FBIT3_OFFSET                         3
#define CAN2_F16BANK2_FBIT3_MASK                           8

#define CAN2_F16BANK2_FBIT4_OFFSET                         4
#define CAN2_F16BANK2_FBIT4_MASK                           0x10

#define CAN2_F16BANK2_FBIT5_OFFSET                         5
#define CAN2_F16BANK2_FBIT5_MASK                           0x20

#define CAN2_F16BANK2_FBIT6_OFFSET                         6
#define CAN2_F16BANK2_FBIT6_MASK                           0x40

#define CAN2_F16BANK2_FBIT7_OFFSET                         7
#define CAN2_F16BANK2_FBIT7_MASK                           0x80

#define CAN2_F16BANK2_FBIT8_OFFSET                         8
#define CAN2_F16BANK2_FBIT8_MASK                           0x100

#define CAN2_F16BANK2_FBIT9_OFFSET                         9
#define CAN2_F16BANK2_FBIT9_MASK                           0x200

#define CAN2_F16BANK2_FBIT10_OFFSET                        10
#define CAN2_F16BANK2_FBIT10_MASK                          0x400

#define CAN2_F16BANK2_FBIT11_OFFSET                        11
#define CAN2_F16BANK2_FBIT11_MASK                          0x800

#define CAN2_F16BANK2_FBIT12_OFFSET                        12
#define CAN2_F16BANK2_FBIT12_MASK                          0x1000

#define CAN2_F16BANK2_FBIT13_OFFSET                        13
#define CAN2_F16BANK2_FBIT13_MASK                          0x2000

#define CAN2_F16BANK2_FBIT14_OFFSET                        14
#define CAN2_F16BANK2_FBIT14_MASK                          0x4000

#define CAN2_F16BANK2_FBIT15_OFFSET                        15
#define CAN2_F16BANK2_FBIT15_MASK                          0x8000

#define CAN2_F16BANK2_FBIT16_OFFSET                        16
#define CAN2_F16BANK2_FBIT16_MASK                          0x10000

#define CAN2_F16BANK2_FBIT17_OFFSET                        17
#define CAN2_F16BANK2_FBIT17_MASK                          0x20000

#define CAN2_F16BANK2_FBIT18_OFFSET                        18
#define CAN2_F16BANK2_FBIT18_MASK                          0x40000

#define CAN2_F16BANK2_FBIT19_OFFSET                        19
#define CAN2_F16BANK2_FBIT19_MASK                          0x80000

#define CAN2_F16BANK2_FBIT20_OFFSET                        20
#define CAN2_F16BANK2_FBIT20_MASK                          0x100000

#define CAN2_F16BANK2_FBIT21_OFFSET                        21
#define CAN2_F16BANK2_FBIT21_MASK                          0x200000

#define CAN2_F16BANK2_FBIT22_OFFSET                        22
#define CAN2_F16BANK2_FBIT22_MASK                          0x400000

#define CAN2_F16BANK2_FBIT23_OFFSET                        23
#define CAN2_F16BANK2_FBIT23_MASK                          0x800000

#define CAN2_F16BANK2_FBIT24_OFFSET                        24
#define CAN2_F16BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F16BANK2_FBIT25_OFFSET                        25
#define CAN2_F16BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F16BANK2_FBIT26_OFFSET                        26
#define CAN2_F16BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F16BANK2_FBIT27_OFFSET                        27
#define CAN2_F16BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F16BANK2_FBIT28_OFFSET                        28
#define CAN2_F16BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F16BANK2_FBIT29_OFFSET                        29
#define CAN2_F16BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F16BANK2_FBIT30_OFFSET                        30
#define CAN2_F16BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F16BANK2_FBIT31_OFFSET                        31
#define CAN2_F16BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F17BANK1_FBIT0_OFFSET                         0
#define CAN2_F17BANK1_FBIT0_MASK                           1

#define CAN2_F17BANK1_FBIT1_OFFSET                         1
#define CAN2_F17BANK1_FBIT1_MASK                           2

#define CAN2_F17BANK1_FBIT2_OFFSET                         2
#define CAN2_F17BANK1_FBIT2_MASK                           4

#define CAN2_F17BANK1_FBIT3_OFFSET                         3
#define CAN2_F17BANK1_FBIT3_MASK                           8

#define CAN2_F17BANK1_FBIT4_OFFSET                         4
#define CAN2_F17BANK1_FBIT4_MASK                           0x10

#define CAN2_F17BANK1_FBIT5_OFFSET                         5
#define CAN2_F17BANK1_FBIT5_MASK                           0x20

#define CAN2_F17BANK1_FBIT6_OFFSET                         6
#define CAN2_F17BANK1_FBIT6_MASK                           0x40

#define CAN2_F17BANK1_FBIT7_OFFSET                         7
#define CAN2_F17BANK1_FBIT7_MASK                           0x80

#define CAN2_F17BANK1_FBIT8_OFFSET                         8
#define CAN2_F17BANK1_FBIT8_MASK                           0x100

#define CAN2_F17BANK1_FBIT9_OFFSET                         9
#define CAN2_F17BANK1_FBIT9_MASK                           0x200

#define CAN2_F17BANK1_FBIT10_OFFSET                        10
#define CAN2_F17BANK1_FBIT10_MASK                          0x400

#define CAN2_F17BANK1_FBIT11_OFFSET                        11
#define CAN2_F17BANK1_FBIT11_MASK                          0x800

#define CAN2_F17BANK1_FBIT12_OFFSET                        12
#define CAN2_F17BANK1_FBIT12_MASK                          0x1000

#define CAN2_F17BANK1_FBIT13_OFFSET                        13
#define CAN2_F17BANK1_FBIT13_MASK                          0x2000

#define CAN2_F17BANK1_FBIT14_OFFSET                        14
#define CAN2_F17BANK1_FBIT14_MASK                          0x4000

#define CAN2_F17BANK1_FBIT15_OFFSET                        15
#define CAN2_F17BANK1_FBIT15_MASK                          0x8000

#define CAN2_F17BANK1_FBIT16_OFFSET                        16
#define CAN2_F17BANK1_FBIT16_MASK                          0x10000

#define CAN2_F17BANK1_FBIT17_OFFSET                        17
#define CAN2_F17BANK1_FBIT17_MASK                          0x20000

#define CAN2_F17BANK1_FBIT18_OFFSET                        18
#define CAN2_F17BANK1_FBIT18_MASK                          0x40000

#define CAN2_F17BANK1_FBIT19_OFFSET                        19
#define CAN2_F17BANK1_FBIT19_MASK                          0x80000

#define CAN2_F17BANK1_FBIT20_OFFSET                        20
#define CAN2_F17BANK1_FBIT20_MASK                          0x100000

#define CAN2_F17BANK1_FBIT21_OFFSET                        21
#define CAN2_F17BANK1_FBIT21_MASK                          0x200000

#define CAN2_F17BANK1_FBIT22_OFFSET                        22
#define CAN2_F17BANK1_FBIT22_MASK                          0x400000

#define CAN2_F17BANK1_FBIT23_OFFSET                        23
#define CAN2_F17BANK1_FBIT23_MASK                          0x800000

#define CAN2_F17BANK1_FBIT24_OFFSET                        24
#define CAN2_F17BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F17BANK1_FBIT25_OFFSET                        25
#define CAN2_F17BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F17BANK1_FBIT26_OFFSET                        26
#define CAN2_F17BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F17BANK1_FBIT27_OFFSET                        27
#define CAN2_F17BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F17BANK1_FBIT28_OFFSET                        28
#define CAN2_F17BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F17BANK1_FBIT29_OFFSET                        29
#define CAN2_F17BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F17BANK1_FBIT30_OFFSET                        30
#define CAN2_F17BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F17BANK1_FBIT31_OFFSET                        31
#define CAN2_F17BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F17BANK2_FBIT0_OFFSET                         0
#define CAN2_F17BANK2_FBIT0_MASK                           1

#define CAN2_F17BANK2_FBIT1_OFFSET                         1
#define CAN2_F17BANK2_FBIT1_MASK                           2

#define CAN2_F17BANK2_FBIT2_OFFSET                         2
#define CAN2_F17BANK2_FBIT2_MASK                           4

#define CAN2_F17BANK2_FBIT3_OFFSET                         3
#define CAN2_F17BANK2_FBIT3_MASK                           8

#define CAN2_F17BANK2_FBIT4_OFFSET                         4
#define CAN2_F17BANK2_FBIT4_MASK                           0x10

#define CAN2_F17BANK2_FBIT5_OFFSET                         5
#define CAN2_F17BANK2_FBIT5_MASK                           0x20

#define CAN2_F17BANK2_FBIT6_OFFSET                         6
#define CAN2_F17BANK2_FBIT6_MASK                           0x40

#define CAN2_F17BANK2_FBIT7_OFFSET                         7
#define CAN2_F17BANK2_FBIT7_MASK                           0x80

#define CAN2_F17BANK2_FBIT8_OFFSET                         8
#define CAN2_F17BANK2_FBIT8_MASK                           0x100

#define CAN2_F17BANK2_FBIT9_OFFSET                         9
#define CAN2_F17BANK2_FBIT9_MASK                           0x200

#define CAN2_F17BANK2_FBIT10_OFFSET                        10
#define CAN2_F17BANK2_FBIT10_MASK                          0x400

#define CAN2_F17BANK2_FBIT11_OFFSET                        11
#define CAN2_F17BANK2_FBIT11_MASK                          0x800

#define CAN2_F17BANK2_FBIT12_OFFSET                        12
#define CAN2_F17BANK2_FBIT12_MASK                          0x1000

#define CAN2_F17BANK2_FBIT13_OFFSET                        13
#define CAN2_F17BANK2_FBIT13_MASK                          0x2000

#define CAN2_F17BANK2_FBIT14_OFFSET                        14
#define CAN2_F17BANK2_FBIT14_MASK                          0x4000

#define CAN2_F17BANK2_FBIT15_OFFSET                        15
#define CAN2_F17BANK2_FBIT15_MASK                          0x8000

#define CAN2_F17BANK2_FBIT16_OFFSET                        16
#define CAN2_F17BANK2_FBIT16_MASK                          0x10000

#define CAN2_F17BANK2_FBIT17_OFFSET                        17
#define CAN2_F17BANK2_FBIT17_MASK                          0x20000

#define CAN2_F17BANK2_FBIT18_OFFSET                        18
#define CAN2_F17BANK2_FBIT18_MASK                          0x40000

#define CAN2_F17BANK2_FBIT19_OFFSET                        19
#define CAN2_F17BANK2_FBIT19_MASK                          0x80000

#define CAN2_F17BANK2_FBIT20_OFFSET                        20
#define CAN2_F17BANK2_FBIT20_MASK                          0x100000

#define CAN2_F17BANK2_FBIT21_OFFSET                        21
#define CAN2_F17BANK2_FBIT21_MASK                          0x200000

#define CAN2_F17BANK2_FBIT22_OFFSET                        22
#define CAN2_F17BANK2_FBIT22_MASK                          0x400000

#define CAN2_F17BANK2_FBIT23_OFFSET                        23
#define CAN2_F17BANK2_FBIT23_MASK                          0x800000

#define CAN2_F17BANK2_FBIT24_OFFSET                        24
#define CAN2_F17BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F17BANK2_FBIT25_OFFSET                        25
#define CAN2_F17BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F17BANK2_FBIT26_OFFSET                        26
#define CAN2_F17BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F17BANK2_FBIT27_OFFSET                        27
#define CAN2_F17BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F17BANK2_FBIT28_OFFSET                        28
#define CAN2_F17BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F17BANK2_FBIT29_OFFSET                        29
#define CAN2_F17BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F17BANK2_FBIT30_OFFSET                        30
#define CAN2_F17BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F17BANK2_FBIT31_OFFSET                        31
#define CAN2_F17BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F18BANK1_FBIT0_OFFSET                         0
#define CAN2_F18BANK1_FBIT0_MASK                           1

#define CAN2_F18BANK1_FBIT1_OFFSET                         1
#define CAN2_F18BANK1_FBIT1_MASK                           2

#define CAN2_F18BANK1_FBIT2_OFFSET                         2
#define CAN2_F18BANK1_FBIT2_MASK                           4

#define CAN2_F18BANK1_FBIT3_OFFSET                         3
#define CAN2_F18BANK1_FBIT3_MASK                           8

#define CAN2_F18BANK1_FBIT4_OFFSET                         4
#define CAN2_F18BANK1_FBIT4_MASK                           0x10

#define CAN2_F18BANK1_FBIT5_OFFSET                         5
#define CAN2_F18BANK1_FBIT5_MASK                           0x20

#define CAN2_F18BANK1_FBIT6_OFFSET                         6
#define CAN2_F18BANK1_FBIT6_MASK                           0x40

#define CAN2_F18BANK1_FBIT7_OFFSET                         7
#define CAN2_F18BANK1_FBIT7_MASK                           0x80

#define CAN2_F18BANK1_FBIT8_OFFSET                         8
#define CAN2_F18BANK1_FBIT8_MASK                           0x100

#define CAN2_F18BANK1_FBIT9_OFFSET                         9
#define CAN2_F18BANK1_FBIT9_MASK                           0x200

#define CAN2_F18BANK1_FBIT10_OFFSET                        10
#define CAN2_F18BANK1_FBIT10_MASK                          0x400

#define CAN2_F18BANK1_FBIT11_OFFSET                        11
#define CAN2_F18BANK1_FBIT11_MASK                          0x800

#define CAN2_F18BANK1_FBIT12_OFFSET                        12
#define CAN2_F18BANK1_FBIT12_MASK                          0x1000

#define CAN2_F18BANK1_FBIT13_OFFSET                        13
#define CAN2_F18BANK1_FBIT13_MASK                          0x2000

#define CAN2_F18BANK1_FBIT14_OFFSET                        14
#define CAN2_F18BANK1_FBIT14_MASK                          0x4000

#define CAN2_F18BANK1_FBIT15_OFFSET                        15
#define CAN2_F18BANK1_FBIT15_MASK                          0x8000

#define CAN2_F18BANK1_FBIT16_OFFSET                        16
#define CAN2_F18BANK1_FBIT16_MASK                          0x10000

#define CAN2_F18BANK1_FBIT17_OFFSET                        17
#define CAN2_F18BANK1_FBIT17_MASK                          0x20000

#define CAN2_F18BANK1_FBIT18_OFFSET                        18
#define CAN2_F18BANK1_FBIT18_MASK                          0x40000

#define CAN2_F18BANK1_FBIT19_OFFSET                        19
#define CAN2_F18BANK1_FBIT19_MASK                          0x80000

#define CAN2_F18BANK1_FBIT20_OFFSET                        20
#define CAN2_F18BANK1_FBIT20_MASK                          0x100000

#define CAN2_F18BANK1_FBIT21_OFFSET                        21
#define CAN2_F18BANK1_FBIT21_MASK                          0x200000

#define CAN2_F18BANK1_FBIT22_OFFSET                        22
#define CAN2_F18BANK1_FBIT22_MASK                          0x400000

#define CAN2_F18BANK1_FBIT23_OFFSET                        23
#define CAN2_F18BANK1_FBIT23_MASK                          0x800000

#define CAN2_F18BANK1_FBIT24_OFFSET                        24
#define CAN2_F18BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F18BANK1_FBIT25_OFFSET                        25
#define CAN2_F18BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F18BANK1_FBIT26_OFFSET                        26
#define CAN2_F18BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F18BANK1_FBIT27_OFFSET                        27
#define CAN2_F18BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F18BANK1_FBIT28_OFFSET                        28
#define CAN2_F18BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F18BANK1_FBIT29_OFFSET                        29
#define CAN2_F18BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F18BANK1_FBIT30_OFFSET                        30
#define CAN2_F18BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F18BANK1_FBIT31_OFFSET                        31
#define CAN2_F18BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F18BANK2_FBIT0_OFFSET                         0
#define CAN2_F18BANK2_FBIT0_MASK                           1

#define CAN2_F18BANK2_FBIT1_OFFSET                         1
#define CAN2_F18BANK2_FBIT1_MASK                           2

#define CAN2_F18BANK2_FBIT2_OFFSET                         2
#define CAN2_F18BANK2_FBIT2_MASK                           4

#define CAN2_F18BANK2_FBIT3_OFFSET                         3
#define CAN2_F18BANK2_FBIT3_MASK                           8

#define CAN2_F18BANK2_FBIT4_OFFSET                         4
#define CAN2_F18BANK2_FBIT4_MASK                           0x10

#define CAN2_F18BANK2_FBIT5_OFFSET                         5
#define CAN2_F18BANK2_FBIT5_MASK                           0x20

#define CAN2_F18BANK2_FBIT6_OFFSET                         6
#define CAN2_F18BANK2_FBIT6_MASK                           0x40

#define CAN2_F18BANK2_FBIT7_OFFSET                         7
#define CAN2_F18BANK2_FBIT7_MASK                           0x80

#define CAN2_F18BANK2_FBIT8_OFFSET                         8
#define CAN2_F18BANK2_FBIT8_MASK                           0x100

#define CAN2_F18BANK2_FBIT9_OFFSET                         9
#define CAN2_F18BANK2_FBIT9_MASK                           0x200

#define CAN2_F18BANK2_FBIT10_OFFSET                        10
#define CAN2_F18BANK2_FBIT10_MASK                          0x400

#define CAN2_F18BANK2_FBIT11_OFFSET                        11
#define CAN2_F18BANK2_FBIT11_MASK                          0x800

#define CAN2_F18BANK2_FBIT12_OFFSET                        12
#define CAN2_F18BANK2_FBIT12_MASK                          0x1000

#define CAN2_F18BANK2_FBIT13_OFFSET                        13
#define CAN2_F18BANK2_FBIT13_MASK                          0x2000

#define CAN2_F18BANK2_FBIT14_OFFSET                        14
#define CAN2_F18BANK2_FBIT14_MASK                          0x4000

#define CAN2_F18BANK2_FBIT15_OFFSET                        15
#define CAN2_F18BANK2_FBIT15_MASK                          0x8000

#define CAN2_F18BANK2_FBIT16_OFFSET                        16
#define CAN2_F18BANK2_FBIT16_MASK                          0x10000

#define CAN2_F18BANK2_FBIT17_OFFSET                        17
#define CAN2_F18BANK2_FBIT17_MASK                          0x20000

#define CAN2_F18BANK2_FBIT18_OFFSET                        18
#define CAN2_F18BANK2_FBIT18_MASK                          0x40000

#define CAN2_F18BANK2_FBIT19_OFFSET                        19
#define CAN2_F18BANK2_FBIT19_MASK                          0x80000

#define CAN2_F18BANK2_FBIT20_OFFSET                        20
#define CAN2_F18BANK2_FBIT20_MASK                          0x100000

#define CAN2_F18BANK2_FBIT21_OFFSET                        21
#define CAN2_F18BANK2_FBIT21_MASK                          0x200000

#define CAN2_F18BANK2_FBIT22_OFFSET                        22
#define CAN2_F18BANK2_FBIT22_MASK                          0x400000

#define CAN2_F18BANK2_FBIT23_OFFSET                        23
#define CAN2_F18BANK2_FBIT23_MASK                          0x800000

#define CAN2_F18BANK2_FBIT24_OFFSET                        24
#define CAN2_F18BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F18BANK2_FBIT25_OFFSET                        25
#define CAN2_F18BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F18BANK2_FBIT26_OFFSET                        26
#define CAN2_F18BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F18BANK2_FBIT27_OFFSET                        27
#define CAN2_F18BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F18BANK2_FBIT28_OFFSET                        28
#define CAN2_F18BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F18BANK2_FBIT29_OFFSET                        29
#define CAN2_F18BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F18BANK2_FBIT30_OFFSET                        30
#define CAN2_F18BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F18BANK2_FBIT31_OFFSET                        31
#define CAN2_F18BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F19BANK1_FBIT0_OFFSET                         0
#define CAN2_F19BANK1_FBIT0_MASK                           1

#define CAN2_F19BANK1_FBIT1_OFFSET                         1
#define CAN2_F19BANK1_FBIT1_MASK                           2

#define CAN2_F19BANK1_FBIT2_OFFSET                         2
#define CAN2_F19BANK1_FBIT2_MASK                           4

#define CAN2_F19BANK1_FBIT3_OFFSET                         3
#define CAN2_F19BANK1_FBIT3_MASK                           8

#define CAN2_F19BANK1_FBIT4_OFFSET                         4
#define CAN2_F19BANK1_FBIT4_MASK                           0x10

#define CAN2_F19BANK1_FBIT5_OFFSET                         5
#define CAN2_F19BANK1_FBIT5_MASK                           0x20

#define CAN2_F19BANK1_FBIT6_OFFSET                         6
#define CAN2_F19BANK1_FBIT6_MASK                           0x40

#define CAN2_F19BANK1_FBIT7_OFFSET                         7
#define CAN2_F19BANK1_FBIT7_MASK                           0x80

#define CAN2_F19BANK1_FBIT8_OFFSET                         8
#define CAN2_F19BANK1_FBIT8_MASK                           0x100

#define CAN2_F19BANK1_FBIT9_OFFSET                         9
#define CAN2_F19BANK1_FBIT9_MASK                           0x200

#define CAN2_F19BANK1_FBIT10_OFFSET                        10
#define CAN2_F19BANK1_FBIT10_MASK                          0x400

#define CAN2_F19BANK1_FBIT11_OFFSET                        11
#define CAN2_F19BANK1_FBIT11_MASK                          0x800

#define CAN2_F19BANK1_FBIT12_OFFSET                        12
#define CAN2_F19BANK1_FBIT12_MASK                          0x1000

#define CAN2_F19BANK1_FBIT13_OFFSET                        13
#define CAN2_F19BANK1_FBIT13_MASK                          0x2000

#define CAN2_F19BANK1_FBIT14_OFFSET                        14
#define CAN2_F19BANK1_FBIT14_MASK                          0x4000

#define CAN2_F19BANK1_FBIT15_OFFSET                        15
#define CAN2_F19BANK1_FBIT15_MASK                          0x8000

#define CAN2_F19BANK1_FBIT16_OFFSET                        16
#define CAN2_F19BANK1_FBIT16_MASK                          0x10000

#define CAN2_F19BANK1_FBIT17_OFFSET                        17
#define CAN2_F19BANK1_FBIT17_MASK                          0x20000

#define CAN2_F19BANK1_FBIT18_OFFSET                        18
#define CAN2_F19BANK1_FBIT18_MASK                          0x40000

#define CAN2_F19BANK1_FBIT19_OFFSET                        19
#define CAN2_F19BANK1_FBIT19_MASK                          0x80000

#define CAN2_F19BANK1_FBIT20_OFFSET                        20
#define CAN2_F19BANK1_FBIT20_MASK                          0x100000

#define CAN2_F19BANK1_FBIT21_OFFSET                        21
#define CAN2_F19BANK1_FBIT21_MASK                          0x200000

#define CAN2_F19BANK1_FBIT22_OFFSET                        22
#define CAN2_F19BANK1_FBIT22_MASK                          0x400000

#define CAN2_F19BANK1_FBIT23_OFFSET                        23
#define CAN2_F19BANK1_FBIT23_MASK                          0x800000

#define CAN2_F19BANK1_FBIT24_OFFSET                        24
#define CAN2_F19BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F19BANK1_FBIT25_OFFSET                        25
#define CAN2_F19BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F19BANK1_FBIT26_OFFSET                        26
#define CAN2_F19BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F19BANK1_FBIT27_OFFSET                        27
#define CAN2_F19BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F19BANK1_FBIT28_OFFSET                        28
#define CAN2_F19BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F19BANK1_FBIT29_OFFSET                        29
#define CAN2_F19BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F19BANK1_FBIT30_OFFSET                        30
#define CAN2_F19BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F19BANK1_FBIT31_OFFSET                        31
#define CAN2_F19BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F19BANK2_FBIT0_OFFSET                         0
#define CAN2_F19BANK2_FBIT0_MASK                           1

#define CAN2_F19BANK2_FBIT1_OFFSET                         1
#define CAN2_F19BANK2_FBIT1_MASK                           2

#define CAN2_F19BANK2_FBIT2_OFFSET                         2
#define CAN2_F19BANK2_FBIT2_MASK                           4

#define CAN2_F19BANK2_FBIT3_OFFSET                         3
#define CAN2_F19BANK2_FBIT3_MASK                           8

#define CAN2_F19BANK2_FBIT4_OFFSET                         4
#define CAN2_F19BANK2_FBIT4_MASK                           0x10

#define CAN2_F19BANK2_FBIT5_OFFSET                         5
#define CAN2_F19BANK2_FBIT5_MASK                           0x20

#define CAN2_F19BANK2_FBIT6_OFFSET                         6
#define CAN2_F19BANK2_FBIT6_MASK                           0x40

#define CAN2_F19BANK2_FBIT7_OFFSET                         7
#define CAN2_F19BANK2_FBIT7_MASK                           0x80

#define CAN2_F19BANK2_FBIT8_OFFSET                         8
#define CAN2_F19BANK2_FBIT8_MASK                           0x100

#define CAN2_F19BANK2_FBIT9_OFFSET                         9
#define CAN2_F19BANK2_FBIT9_MASK                           0x200

#define CAN2_F19BANK2_FBIT10_OFFSET                        10
#define CAN2_F19BANK2_FBIT10_MASK                          0x400

#define CAN2_F19BANK2_FBIT11_OFFSET                        11
#define CAN2_F19BANK2_FBIT11_MASK                          0x800

#define CAN2_F19BANK2_FBIT12_OFFSET                        12
#define CAN2_F19BANK2_FBIT12_MASK                          0x1000

#define CAN2_F19BANK2_FBIT13_OFFSET                        13
#define CAN2_F19BANK2_FBIT13_MASK                          0x2000

#define CAN2_F19BANK2_FBIT14_OFFSET                        14
#define CAN2_F19BANK2_FBIT14_MASK                          0x4000

#define CAN2_F19BANK2_FBIT15_OFFSET                        15
#define CAN2_F19BANK2_FBIT15_MASK                          0x8000

#define CAN2_F19BANK2_FBIT16_OFFSET                        16
#define CAN2_F19BANK2_FBIT16_MASK                          0x10000

#define CAN2_F19BANK2_FBIT17_OFFSET                        17
#define CAN2_F19BANK2_FBIT17_MASK                          0x20000

#define CAN2_F19BANK2_FBIT18_OFFSET                        18
#define CAN2_F19BANK2_FBIT18_MASK                          0x40000

#define CAN2_F19BANK2_FBIT19_OFFSET                        19
#define CAN2_F19BANK2_FBIT19_MASK                          0x80000

#define CAN2_F19BANK2_FBIT20_OFFSET                        20
#define CAN2_F19BANK2_FBIT20_MASK                          0x100000

#define CAN2_F19BANK2_FBIT21_OFFSET                        21
#define CAN2_F19BANK2_FBIT21_MASK                          0x200000

#define CAN2_F19BANK2_FBIT22_OFFSET                        22
#define CAN2_F19BANK2_FBIT22_MASK                          0x400000

#define CAN2_F19BANK2_FBIT23_OFFSET                        23
#define CAN2_F19BANK2_FBIT23_MASK                          0x800000

#define CAN2_F19BANK2_FBIT24_OFFSET                        24
#define CAN2_F19BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F19BANK2_FBIT25_OFFSET                        25
#define CAN2_F19BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F19BANK2_FBIT26_OFFSET                        26
#define CAN2_F19BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F19BANK2_FBIT27_OFFSET                        27
#define CAN2_F19BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F19BANK2_FBIT28_OFFSET                        28
#define CAN2_F19BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F19BANK2_FBIT29_OFFSET                        29
#define CAN2_F19BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F19BANK2_FBIT30_OFFSET                        30
#define CAN2_F19BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F19BANK2_FBIT31_OFFSET                        31
#define CAN2_F19BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F20BANK1_FBIT0_OFFSET                         0
#define CAN2_F20BANK1_FBIT0_MASK                           1

#define CAN2_F20BANK1_FBIT1_OFFSET                         1
#define CAN2_F20BANK1_FBIT1_MASK                           2

#define CAN2_F20BANK1_FBIT2_OFFSET                         2
#define CAN2_F20BANK1_FBIT2_MASK                           4

#define CAN2_F20BANK1_FBIT3_OFFSET                         3
#define CAN2_F20BANK1_FBIT3_MASK                           8

#define CAN2_F20BANK1_FBIT4_OFFSET                         4
#define CAN2_F20BANK1_FBIT4_MASK                           0x10

#define CAN2_F20BANK1_FBIT5_OFFSET                         5
#define CAN2_F20BANK1_FBIT5_MASK                           0x20

#define CAN2_F20BANK1_FBIT6_OFFSET                         6
#define CAN2_F20BANK1_FBIT6_MASK                           0x40

#define CAN2_F20BANK1_FBIT7_OFFSET                         7
#define CAN2_F20BANK1_FBIT7_MASK                           0x80

#define CAN2_F20BANK1_FBIT8_OFFSET                         8
#define CAN2_F20BANK1_FBIT8_MASK                           0x100

#define CAN2_F20BANK1_FBIT9_OFFSET                         9
#define CAN2_F20BANK1_FBIT9_MASK                           0x200

#define CAN2_F20BANK1_FBIT10_OFFSET                        10
#define CAN2_F20BANK1_FBIT10_MASK                          0x400

#define CAN2_F20BANK1_FBIT11_OFFSET                        11
#define CAN2_F20BANK1_FBIT11_MASK                          0x800

#define CAN2_F20BANK1_FBIT12_OFFSET                        12
#define CAN2_F20BANK1_FBIT12_MASK                          0x1000

#define CAN2_F20BANK1_FBIT13_OFFSET                        13
#define CAN2_F20BANK1_FBIT13_MASK                          0x2000

#define CAN2_F20BANK1_FBIT14_OFFSET                        14
#define CAN2_F20BANK1_FBIT14_MASK                          0x4000

#define CAN2_F20BANK1_FBIT15_OFFSET                        15
#define CAN2_F20BANK1_FBIT15_MASK                          0x8000

#define CAN2_F20BANK1_FBIT16_OFFSET                        16
#define CAN2_F20BANK1_FBIT16_MASK                          0x10000

#define CAN2_F20BANK1_FBIT17_OFFSET                        17
#define CAN2_F20BANK1_FBIT17_MASK                          0x20000

#define CAN2_F20BANK1_FBIT18_OFFSET                        18
#define CAN2_F20BANK1_FBIT18_MASK                          0x40000

#define CAN2_F20BANK1_FBIT19_OFFSET                        19
#define CAN2_F20BANK1_FBIT19_MASK                          0x80000

#define CAN2_F20BANK1_FBIT20_OFFSET                        20
#define CAN2_F20BANK1_FBIT20_MASK                          0x100000

#define CAN2_F20BANK1_FBIT21_OFFSET                        21
#define CAN2_F20BANK1_FBIT21_MASK                          0x200000

#define CAN2_F20BANK1_FBIT22_OFFSET                        22
#define CAN2_F20BANK1_FBIT22_MASK                          0x400000

#define CAN2_F20BANK1_FBIT23_OFFSET                        23
#define CAN2_F20BANK1_FBIT23_MASK                          0x800000

#define CAN2_F20BANK1_FBIT24_OFFSET                        24
#define CAN2_F20BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F20BANK1_FBIT25_OFFSET                        25
#define CAN2_F20BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F20BANK1_FBIT26_OFFSET                        26
#define CAN2_F20BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F20BANK1_FBIT27_OFFSET                        27
#define CAN2_F20BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F20BANK1_FBIT28_OFFSET                        28
#define CAN2_F20BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F20BANK1_FBIT29_OFFSET                        29
#define CAN2_F20BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F20BANK1_FBIT30_OFFSET                        30
#define CAN2_F20BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F20BANK1_FBIT31_OFFSET                        31
#define CAN2_F20BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F20BANK2_FBIT0_OFFSET                         0
#define CAN2_F20BANK2_FBIT0_MASK                           1

#define CAN2_F20BANK2_FBIT1_OFFSET                         1
#define CAN2_F20BANK2_FBIT1_MASK                           2

#define CAN2_F20BANK2_FBIT2_OFFSET                         2
#define CAN2_F20BANK2_FBIT2_MASK                           4

#define CAN2_F20BANK2_FBIT3_OFFSET                         3
#define CAN2_F20BANK2_FBIT3_MASK                           8

#define CAN2_F20BANK2_FBIT4_OFFSET                         4
#define CAN2_F20BANK2_FBIT4_MASK                           0x10

#define CAN2_F20BANK2_FBIT5_OFFSET                         5
#define CAN2_F20BANK2_FBIT5_MASK                           0x20

#define CAN2_F20BANK2_FBIT6_OFFSET                         6
#define CAN2_F20BANK2_FBIT6_MASK                           0x40

#define CAN2_F20BANK2_FBIT7_OFFSET                         7
#define CAN2_F20BANK2_FBIT7_MASK                           0x80

#define CAN2_F20BANK2_FBIT8_OFFSET                         8
#define CAN2_F20BANK2_FBIT8_MASK                           0x100

#define CAN2_F20BANK2_FBIT9_OFFSET                         9
#define CAN2_F20BANK2_FBIT9_MASK                           0x200

#define CAN2_F20BANK2_FBIT10_OFFSET                        10
#define CAN2_F20BANK2_FBIT10_MASK                          0x400

#define CAN2_F20BANK2_FBIT11_OFFSET                        11
#define CAN2_F20BANK2_FBIT11_MASK                          0x800

#define CAN2_F20BANK2_FBIT12_OFFSET                        12
#define CAN2_F20BANK2_FBIT12_MASK                          0x1000

#define CAN2_F20BANK2_FBIT13_OFFSET                        13
#define CAN2_F20BANK2_FBIT13_MASK                          0x2000

#define CAN2_F20BANK2_FBIT14_OFFSET                        14
#define CAN2_F20BANK2_FBIT14_MASK                          0x4000

#define CAN2_F20BANK2_FBIT15_OFFSET                        15
#define CAN2_F20BANK2_FBIT15_MASK                          0x8000

#define CAN2_F20BANK2_FBIT16_OFFSET                        16
#define CAN2_F20BANK2_FBIT16_MASK                          0x10000

#define CAN2_F20BANK2_FBIT17_OFFSET                        17
#define CAN2_F20BANK2_FBIT17_MASK                          0x20000

#define CAN2_F20BANK2_FBIT18_OFFSET                        18
#define CAN2_F20BANK2_FBIT18_MASK                          0x40000

#define CAN2_F20BANK2_FBIT19_OFFSET                        19
#define CAN2_F20BANK2_FBIT19_MASK                          0x80000

#define CAN2_F20BANK2_FBIT20_OFFSET                        20
#define CAN2_F20BANK2_FBIT20_MASK                          0x100000

#define CAN2_F20BANK2_FBIT21_OFFSET                        21
#define CAN2_F20BANK2_FBIT21_MASK                          0x200000

#define CAN2_F20BANK2_FBIT22_OFFSET                        22
#define CAN2_F20BANK2_FBIT22_MASK                          0x400000

#define CAN2_F20BANK2_FBIT23_OFFSET                        23
#define CAN2_F20BANK2_FBIT23_MASK                          0x800000

#define CAN2_F20BANK2_FBIT24_OFFSET                        24
#define CAN2_F20BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F20BANK2_FBIT25_OFFSET                        25
#define CAN2_F20BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F20BANK2_FBIT26_OFFSET                        26
#define CAN2_F20BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F20BANK2_FBIT27_OFFSET                        27
#define CAN2_F20BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F20BANK2_FBIT28_OFFSET                        28
#define CAN2_F20BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F20BANK2_FBIT29_OFFSET                        29
#define CAN2_F20BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F20BANK2_FBIT30_OFFSET                        30
#define CAN2_F20BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F20BANK2_FBIT31_OFFSET                        31
#define CAN2_F20BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F21BANK1_FBIT0_OFFSET                         0
#define CAN2_F21BANK1_FBIT0_MASK                           1

#define CAN2_F21BANK1_FBIT1_OFFSET                         1
#define CAN2_F21BANK1_FBIT1_MASK                           2

#define CAN2_F21BANK1_FBIT2_OFFSET                         2
#define CAN2_F21BANK1_FBIT2_MASK                           4

#define CAN2_F21BANK1_FBIT3_OFFSET                         3
#define CAN2_F21BANK1_FBIT3_MASK                           8

#define CAN2_F21BANK1_FBIT4_OFFSET                         4
#define CAN2_F21BANK1_FBIT4_MASK                           0x10

#define CAN2_F21BANK1_FBIT5_OFFSET                         5
#define CAN2_F21BANK1_FBIT5_MASK                           0x20

#define CAN2_F21BANK1_FBIT6_OFFSET                         6
#define CAN2_F21BANK1_FBIT6_MASK                           0x40

#define CAN2_F21BANK1_FBIT7_OFFSET                         7
#define CAN2_F21BANK1_FBIT7_MASK                           0x80

#define CAN2_F21BANK1_FBIT8_OFFSET                         8
#define CAN2_F21BANK1_FBIT8_MASK                           0x100

#define CAN2_F21BANK1_FBIT9_OFFSET                         9
#define CAN2_F21BANK1_FBIT9_MASK                           0x200

#define CAN2_F21BANK1_FBIT10_OFFSET                        10
#define CAN2_F21BANK1_FBIT10_MASK                          0x400

#define CAN2_F21BANK1_FBIT11_OFFSET                        11
#define CAN2_F21BANK1_FBIT11_MASK                          0x800

#define CAN2_F21BANK1_FBIT12_OFFSET                        12
#define CAN2_F21BANK1_FBIT12_MASK                          0x1000

#define CAN2_F21BANK1_FBIT13_OFFSET                        13
#define CAN2_F21BANK1_FBIT13_MASK                          0x2000

#define CAN2_F21BANK1_FBIT14_OFFSET                        14
#define CAN2_F21BANK1_FBIT14_MASK                          0x4000

#define CAN2_F21BANK1_FBIT15_OFFSET                        15
#define CAN2_F21BANK1_FBIT15_MASK                          0x8000

#define CAN2_F21BANK1_FBIT16_OFFSET                        16
#define CAN2_F21BANK1_FBIT16_MASK                          0x10000

#define CAN2_F21BANK1_FBIT17_OFFSET                        17
#define CAN2_F21BANK1_FBIT17_MASK                          0x20000

#define CAN2_F21BANK1_FBIT18_OFFSET                        18
#define CAN2_F21BANK1_FBIT18_MASK                          0x40000

#define CAN2_F21BANK1_FBIT19_OFFSET                        19
#define CAN2_F21BANK1_FBIT19_MASK                          0x80000

#define CAN2_F21BANK1_FBIT20_OFFSET                        20
#define CAN2_F21BANK1_FBIT20_MASK                          0x100000

#define CAN2_F21BANK1_FBIT21_OFFSET                        21
#define CAN2_F21BANK1_FBIT21_MASK                          0x200000

#define CAN2_F21BANK1_FBIT22_OFFSET                        22
#define CAN2_F21BANK1_FBIT22_MASK                          0x400000

#define CAN2_F21BANK1_FBIT23_OFFSET                        23
#define CAN2_F21BANK1_FBIT23_MASK                          0x800000

#define CAN2_F21BANK1_FBIT24_OFFSET                        24
#define CAN2_F21BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F21BANK1_FBIT25_OFFSET                        25
#define CAN2_F21BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F21BANK1_FBIT26_OFFSET                        26
#define CAN2_F21BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F21BANK1_FBIT27_OFFSET                        27
#define CAN2_F21BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F21BANK1_FBIT28_OFFSET                        28
#define CAN2_F21BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F21BANK1_FBIT29_OFFSET                        29
#define CAN2_F21BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F21BANK1_FBIT30_OFFSET                        30
#define CAN2_F21BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F21BANK1_FBIT31_OFFSET                        31
#define CAN2_F21BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F21BANK2_FBIT0_OFFSET                         0
#define CAN2_F21BANK2_FBIT0_MASK                           1

#define CAN2_F21BANK2_FBIT1_OFFSET                         1
#define CAN2_F21BANK2_FBIT1_MASK                           2

#define CAN2_F21BANK2_FBIT2_OFFSET                         2
#define CAN2_F21BANK2_FBIT2_MASK                           4

#define CAN2_F21BANK2_FBIT3_OFFSET                         3
#define CAN2_F21BANK2_FBIT3_MASK                           8

#define CAN2_F21BANK2_FBIT4_OFFSET                         4
#define CAN2_F21BANK2_FBIT4_MASK                           0x10

#define CAN2_F21BANK2_FBIT5_OFFSET                         5
#define CAN2_F21BANK2_FBIT5_MASK                           0x20

#define CAN2_F21BANK2_FBIT6_OFFSET                         6
#define CAN2_F21BANK2_FBIT6_MASK                           0x40

#define CAN2_F21BANK2_FBIT7_OFFSET                         7
#define CAN2_F21BANK2_FBIT7_MASK                           0x80

#define CAN2_F21BANK2_FBIT8_OFFSET                         8
#define CAN2_F21BANK2_FBIT8_MASK                           0x100

#define CAN2_F21BANK2_FBIT9_OFFSET                         9
#define CAN2_F21BANK2_FBIT9_MASK                           0x200

#define CAN2_F21BANK2_FBIT10_OFFSET                        10
#define CAN2_F21BANK2_FBIT10_MASK                          0x400

#define CAN2_F21BANK2_FBIT11_OFFSET                        11
#define CAN2_F21BANK2_FBIT11_MASK                          0x800

#define CAN2_F21BANK2_FBIT12_OFFSET                        12
#define CAN2_F21BANK2_FBIT12_MASK                          0x1000

#define CAN2_F21BANK2_FBIT13_OFFSET                        13
#define CAN2_F21BANK2_FBIT13_MASK                          0x2000

#define CAN2_F21BANK2_FBIT14_OFFSET                        14
#define CAN2_F21BANK2_FBIT14_MASK                          0x4000

#define CAN2_F21BANK2_FBIT15_OFFSET                        15
#define CAN2_F21BANK2_FBIT15_MASK                          0x8000

#define CAN2_F21BANK2_FBIT16_OFFSET                        16
#define CAN2_F21BANK2_FBIT16_MASK                          0x10000

#define CAN2_F21BANK2_FBIT17_OFFSET                        17
#define CAN2_F21BANK2_FBIT17_MASK                          0x20000

#define CAN2_F21BANK2_FBIT18_OFFSET                        18
#define CAN2_F21BANK2_FBIT18_MASK                          0x40000

#define CAN2_F21BANK2_FBIT19_OFFSET                        19
#define CAN2_F21BANK2_FBIT19_MASK                          0x80000

#define CAN2_F21BANK2_FBIT20_OFFSET                        20
#define CAN2_F21BANK2_FBIT20_MASK                          0x100000

#define CAN2_F21BANK2_FBIT21_OFFSET                        21
#define CAN2_F21BANK2_FBIT21_MASK                          0x200000

#define CAN2_F21BANK2_FBIT22_OFFSET                        22
#define CAN2_F21BANK2_FBIT22_MASK                          0x400000

#define CAN2_F21BANK2_FBIT23_OFFSET                        23
#define CAN2_F21BANK2_FBIT23_MASK                          0x800000

#define CAN2_F21BANK2_FBIT24_OFFSET                        24
#define CAN2_F21BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F21BANK2_FBIT25_OFFSET                        25
#define CAN2_F21BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F21BANK2_FBIT26_OFFSET                        26
#define CAN2_F21BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F21BANK2_FBIT27_OFFSET                        27
#define CAN2_F21BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F21BANK2_FBIT28_OFFSET                        28
#define CAN2_F21BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F21BANK2_FBIT29_OFFSET                        29
#define CAN2_F21BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F21BANK2_FBIT30_OFFSET                        30
#define CAN2_F21BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F21BANK2_FBIT31_OFFSET                        31
#define CAN2_F21BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F22BANK1_FBIT0_OFFSET                         0
#define CAN2_F22BANK1_FBIT0_MASK                           1

#define CAN2_F22BANK1_FBIT1_OFFSET                         1
#define CAN2_F22BANK1_FBIT1_MASK                           2

#define CAN2_F22BANK1_FBIT2_OFFSET                         2
#define CAN2_F22BANK1_FBIT2_MASK                           4

#define CAN2_F22BANK1_FBIT3_OFFSET                         3
#define CAN2_F22BANK1_FBIT3_MASK                           8

#define CAN2_F22BANK1_FBIT4_OFFSET                         4
#define CAN2_F22BANK1_FBIT4_MASK                           0x10

#define CAN2_F22BANK1_FBIT5_OFFSET                         5
#define CAN2_F22BANK1_FBIT5_MASK                           0x20

#define CAN2_F22BANK1_FBIT6_OFFSET                         6
#define CAN2_F22BANK1_FBIT6_MASK                           0x40

#define CAN2_F22BANK1_FBIT7_OFFSET                         7
#define CAN2_F22BANK1_FBIT7_MASK                           0x80

#define CAN2_F22BANK1_FBIT8_OFFSET                         8
#define CAN2_F22BANK1_FBIT8_MASK                           0x100

#define CAN2_F22BANK1_FBIT9_OFFSET                         9
#define CAN2_F22BANK1_FBIT9_MASK                           0x200

#define CAN2_F22BANK1_FBIT10_OFFSET                        10
#define CAN2_F22BANK1_FBIT10_MASK                          0x400

#define CAN2_F22BANK1_FBIT11_OFFSET                        11
#define CAN2_F22BANK1_FBIT11_MASK                          0x800

#define CAN2_F22BANK1_FBIT12_OFFSET                        12
#define CAN2_F22BANK1_FBIT12_MASK                          0x1000

#define CAN2_F22BANK1_FBIT13_OFFSET                        13
#define CAN2_F22BANK1_FBIT13_MASK                          0x2000

#define CAN2_F22BANK1_FBIT14_OFFSET                        14
#define CAN2_F22BANK1_FBIT14_MASK                          0x4000

#define CAN2_F22BANK1_FBIT15_OFFSET                        15
#define CAN2_F22BANK1_FBIT15_MASK                          0x8000

#define CAN2_F22BANK1_FBIT16_OFFSET                        16
#define CAN2_F22BANK1_FBIT16_MASK                          0x10000

#define CAN2_F22BANK1_FBIT17_OFFSET                        17
#define CAN2_F22BANK1_FBIT17_MASK                          0x20000

#define CAN2_F22BANK1_FBIT18_OFFSET                        18
#define CAN2_F22BANK1_FBIT18_MASK                          0x40000

#define CAN2_F22BANK1_FBIT19_OFFSET                        19
#define CAN2_F22BANK1_FBIT19_MASK                          0x80000

#define CAN2_F22BANK1_FBIT20_OFFSET                        20
#define CAN2_F22BANK1_FBIT20_MASK                          0x100000

#define CAN2_F22BANK1_FBIT21_OFFSET                        21
#define CAN2_F22BANK1_FBIT21_MASK                          0x200000

#define CAN2_F22BANK1_FBIT22_OFFSET                        22
#define CAN2_F22BANK1_FBIT22_MASK                          0x400000

#define CAN2_F22BANK1_FBIT23_OFFSET                        23
#define CAN2_F22BANK1_FBIT23_MASK                          0x800000

#define CAN2_F22BANK1_FBIT24_OFFSET                        24
#define CAN2_F22BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F22BANK1_FBIT25_OFFSET                        25
#define CAN2_F22BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F22BANK1_FBIT26_OFFSET                        26
#define CAN2_F22BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F22BANK1_FBIT27_OFFSET                        27
#define CAN2_F22BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F22BANK1_FBIT28_OFFSET                        28
#define CAN2_F22BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F22BANK1_FBIT29_OFFSET                        29
#define CAN2_F22BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F22BANK1_FBIT30_OFFSET                        30
#define CAN2_F22BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F22BANK1_FBIT31_OFFSET                        31
#define CAN2_F22BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F22BANK2_FBIT0_OFFSET                         0
#define CAN2_F22BANK2_FBIT0_MASK                           1

#define CAN2_F22BANK2_FBIT1_OFFSET                         1
#define CAN2_F22BANK2_FBIT1_MASK                           2

#define CAN2_F22BANK2_FBIT2_OFFSET                         2
#define CAN2_F22BANK2_FBIT2_MASK                           4

#define CAN2_F22BANK2_FBIT3_OFFSET                         3
#define CAN2_F22BANK2_FBIT3_MASK                           8

#define CAN2_F22BANK2_FBIT4_OFFSET                         4
#define CAN2_F22BANK2_FBIT4_MASK                           0x10

#define CAN2_F22BANK2_FBIT5_OFFSET                         5
#define CAN2_F22BANK2_FBIT5_MASK                           0x20

#define CAN2_F22BANK2_FBIT6_OFFSET                         6
#define CAN2_F22BANK2_FBIT6_MASK                           0x40

#define CAN2_F22BANK2_FBIT7_OFFSET                         7
#define CAN2_F22BANK2_FBIT7_MASK                           0x80

#define CAN2_F22BANK2_FBIT8_OFFSET                         8
#define CAN2_F22BANK2_FBIT8_MASK                           0x100

#define CAN2_F22BANK2_FBIT9_OFFSET                         9
#define CAN2_F22BANK2_FBIT9_MASK                           0x200

#define CAN2_F22BANK2_FBIT10_OFFSET                        10
#define CAN2_F22BANK2_FBIT10_MASK                          0x400

#define CAN2_F22BANK2_FBIT11_OFFSET                        11
#define CAN2_F22BANK2_FBIT11_MASK                          0x800

#define CAN2_F22BANK2_FBIT12_OFFSET                        12
#define CAN2_F22BANK2_FBIT12_MASK                          0x1000

#define CAN2_F22BANK2_FBIT13_OFFSET                        13
#define CAN2_F22BANK2_FBIT13_MASK                          0x2000

#define CAN2_F22BANK2_FBIT14_OFFSET                        14
#define CAN2_F22BANK2_FBIT14_MASK                          0x4000

#define CAN2_F22BANK2_FBIT15_OFFSET                        15
#define CAN2_F22BANK2_FBIT15_MASK                          0x8000

#define CAN2_F22BANK2_FBIT16_OFFSET                        16
#define CAN2_F22BANK2_FBIT16_MASK                          0x10000

#define CAN2_F22BANK2_FBIT17_OFFSET                        17
#define CAN2_F22BANK2_FBIT17_MASK                          0x20000

#define CAN2_F22BANK2_FBIT18_OFFSET                        18
#define CAN2_F22BANK2_FBIT18_MASK                          0x40000

#define CAN2_F22BANK2_FBIT19_OFFSET                        19
#define CAN2_F22BANK2_FBIT19_MASK                          0x80000

#define CAN2_F22BANK2_FBIT20_OFFSET                        20
#define CAN2_F22BANK2_FBIT20_MASK                          0x100000

#define CAN2_F22BANK2_FBIT21_OFFSET                        21
#define CAN2_F22BANK2_FBIT21_MASK                          0x200000

#define CAN2_F22BANK2_FBIT22_OFFSET                        22
#define CAN2_F22BANK2_FBIT22_MASK                          0x400000

#define CAN2_F22BANK2_FBIT23_OFFSET                        23
#define CAN2_F22BANK2_FBIT23_MASK                          0x800000

#define CAN2_F22BANK2_FBIT24_OFFSET                        24
#define CAN2_F22BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F22BANK2_FBIT25_OFFSET                        25
#define CAN2_F22BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F22BANK2_FBIT26_OFFSET                        26
#define CAN2_F22BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F22BANK2_FBIT27_OFFSET                        27
#define CAN2_F22BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F22BANK2_FBIT28_OFFSET                        28
#define CAN2_F22BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F22BANK2_FBIT29_OFFSET                        29
#define CAN2_F22BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F22BANK2_FBIT30_OFFSET                        30
#define CAN2_F22BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F22BANK2_FBIT31_OFFSET                        31
#define CAN2_F22BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F23BANK1_FBIT0_OFFSET                         0
#define CAN2_F23BANK1_FBIT0_MASK                           1

#define CAN2_F23BANK1_FBIT1_OFFSET                         1
#define CAN2_F23BANK1_FBIT1_MASK                           2

#define CAN2_F23BANK1_FBIT2_OFFSET                         2
#define CAN2_F23BANK1_FBIT2_MASK                           4

#define CAN2_F23BANK1_FBIT3_OFFSET                         3
#define CAN2_F23BANK1_FBIT3_MASK                           8

#define CAN2_F23BANK1_FBIT4_OFFSET                         4
#define CAN2_F23BANK1_FBIT4_MASK                           0x10

#define CAN2_F23BANK1_FBIT5_OFFSET                         5
#define CAN2_F23BANK1_FBIT5_MASK                           0x20

#define CAN2_F23BANK1_FBIT6_OFFSET                         6
#define CAN2_F23BANK1_FBIT6_MASK                           0x40

#define CAN2_F23BANK1_FBIT7_OFFSET                         7
#define CAN2_F23BANK1_FBIT7_MASK                           0x80

#define CAN2_F23BANK1_FBIT8_OFFSET                         8
#define CAN2_F23BANK1_FBIT8_MASK                           0x100

#define CAN2_F23BANK1_FBIT9_OFFSET                         9
#define CAN2_F23BANK1_FBIT9_MASK                           0x200

#define CAN2_F23BANK1_FBIT10_OFFSET                        10
#define CAN2_F23BANK1_FBIT10_MASK                          0x400

#define CAN2_F23BANK1_FBIT11_OFFSET                        11
#define CAN2_F23BANK1_FBIT11_MASK                          0x800

#define CAN2_F23BANK1_FBIT12_OFFSET                        12
#define CAN2_F23BANK1_FBIT12_MASK                          0x1000

#define CAN2_F23BANK1_FBIT13_OFFSET                        13
#define CAN2_F23BANK1_FBIT13_MASK                          0x2000

#define CAN2_F23BANK1_FBIT14_OFFSET                        14
#define CAN2_F23BANK1_FBIT14_MASK                          0x4000

#define CAN2_F23BANK1_FBIT15_OFFSET                        15
#define CAN2_F23BANK1_FBIT15_MASK                          0x8000

#define CAN2_F23BANK1_FBIT16_OFFSET                        16
#define CAN2_F23BANK1_FBIT16_MASK                          0x10000

#define CAN2_F23BANK1_FBIT17_OFFSET                        17
#define CAN2_F23BANK1_FBIT17_MASK                          0x20000

#define CAN2_F23BANK1_FBIT18_OFFSET                        18
#define CAN2_F23BANK1_FBIT18_MASK                          0x40000

#define CAN2_F23BANK1_FBIT19_OFFSET                        19
#define CAN2_F23BANK1_FBIT19_MASK                          0x80000

#define CAN2_F23BANK1_FBIT20_OFFSET                        20
#define CAN2_F23BANK1_FBIT20_MASK                          0x100000

#define CAN2_F23BANK1_FBIT21_OFFSET                        21
#define CAN2_F23BANK1_FBIT21_MASK                          0x200000

#define CAN2_F23BANK1_FBIT22_OFFSET                        22
#define CAN2_F23BANK1_FBIT22_MASK                          0x400000

#define CAN2_F23BANK1_FBIT23_OFFSET                        23
#define CAN2_F23BANK1_FBIT23_MASK                          0x800000

#define CAN2_F23BANK1_FBIT24_OFFSET                        24
#define CAN2_F23BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F23BANK1_FBIT25_OFFSET                        25
#define CAN2_F23BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F23BANK1_FBIT26_OFFSET                        26
#define CAN2_F23BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F23BANK1_FBIT27_OFFSET                        27
#define CAN2_F23BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F23BANK1_FBIT28_OFFSET                        28
#define CAN2_F23BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F23BANK1_FBIT29_OFFSET                        29
#define CAN2_F23BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F23BANK1_FBIT30_OFFSET                        30
#define CAN2_F23BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F23BANK1_FBIT31_OFFSET                        31
#define CAN2_F23BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F23BANK2_FBIT0_OFFSET                         0
#define CAN2_F23BANK2_FBIT0_MASK                           1

#define CAN2_F23BANK2_FBIT1_OFFSET                         1
#define CAN2_F23BANK2_FBIT1_MASK                           2

#define CAN2_F23BANK2_FBIT2_OFFSET                         2
#define CAN2_F23BANK2_FBIT2_MASK                           4

#define CAN2_F23BANK2_FBIT3_OFFSET                         3
#define CAN2_F23BANK2_FBIT3_MASK                           8

#define CAN2_F23BANK2_FBIT4_OFFSET                         4
#define CAN2_F23BANK2_FBIT4_MASK                           0x10

#define CAN2_F23BANK2_FBIT5_OFFSET                         5
#define CAN2_F23BANK2_FBIT5_MASK                           0x20

#define CAN2_F23BANK2_FBIT6_OFFSET                         6
#define CAN2_F23BANK2_FBIT6_MASK                           0x40

#define CAN2_F23BANK2_FBIT7_OFFSET                         7
#define CAN2_F23BANK2_FBIT7_MASK                           0x80

#define CAN2_F23BANK2_FBIT8_OFFSET                         8
#define CAN2_F23BANK2_FBIT8_MASK                           0x100

#define CAN2_F23BANK2_FBIT9_OFFSET                         9
#define CAN2_F23BANK2_FBIT9_MASK                           0x200

#define CAN2_F23BANK2_FBIT10_OFFSET                        10
#define CAN2_F23BANK2_FBIT10_MASK                          0x400

#define CAN2_F23BANK2_FBIT11_OFFSET                        11
#define CAN2_F23BANK2_FBIT11_MASK                          0x800

#define CAN2_F23BANK2_FBIT12_OFFSET                        12
#define CAN2_F23BANK2_FBIT12_MASK                          0x1000

#define CAN2_F23BANK2_FBIT13_OFFSET                        13
#define CAN2_F23BANK2_FBIT13_MASK                          0x2000

#define CAN2_F23BANK2_FBIT14_OFFSET                        14
#define CAN2_F23BANK2_FBIT14_MASK                          0x4000

#define CAN2_F23BANK2_FBIT15_OFFSET                        15
#define CAN2_F23BANK2_FBIT15_MASK                          0x8000

#define CAN2_F23BANK2_FBIT16_OFFSET                        16
#define CAN2_F23BANK2_FBIT16_MASK                          0x10000

#define CAN2_F23BANK2_FBIT17_OFFSET                        17
#define CAN2_F23BANK2_FBIT17_MASK                          0x20000

#define CAN2_F23BANK2_FBIT18_OFFSET                        18
#define CAN2_F23BANK2_FBIT18_MASK                          0x40000

#define CAN2_F23BANK2_FBIT19_OFFSET                        19
#define CAN2_F23BANK2_FBIT19_MASK                          0x80000

#define CAN2_F23BANK2_FBIT20_OFFSET                        20
#define CAN2_F23BANK2_FBIT20_MASK                          0x100000

#define CAN2_F23BANK2_FBIT21_OFFSET                        21
#define CAN2_F23BANK2_FBIT21_MASK                          0x200000

#define CAN2_F23BANK2_FBIT22_OFFSET                        22
#define CAN2_F23BANK2_FBIT22_MASK                          0x400000

#define CAN2_F23BANK2_FBIT23_OFFSET                        23
#define CAN2_F23BANK2_FBIT23_MASK                          0x800000

#define CAN2_F23BANK2_FBIT24_OFFSET                        24
#define CAN2_F23BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F23BANK2_FBIT25_OFFSET                        25
#define CAN2_F23BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F23BANK2_FBIT26_OFFSET                        26
#define CAN2_F23BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F23BANK2_FBIT27_OFFSET                        27
#define CAN2_F23BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F23BANK2_FBIT28_OFFSET                        28
#define CAN2_F23BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F23BANK2_FBIT29_OFFSET                        29
#define CAN2_F23BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F23BANK2_FBIT30_OFFSET                        30
#define CAN2_F23BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F23BANK2_FBIT31_OFFSET                        31
#define CAN2_F23BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F24BANK1_FBIT0_OFFSET                         0
#define CAN2_F24BANK1_FBIT0_MASK                           1

#define CAN2_F24BANK1_FBIT1_OFFSET                         1
#define CAN2_F24BANK1_FBIT1_MASK                           2

#define CAN2_F24BANK1_FBIT2_OFFSET                         2
#define CAN2_F24BANK1_FBIT2_MASK                           4

#define CAN2_F24BANK1_FBIT3_OFFSET                         3
#define CAN2_F24BANK1_FBIT3_MASK                           8

#define CAN2_F24BANK1_FBIT4_OFFSET                         4
#define CAN2_F24BANK1_FBIT4_MASK                           0x10

#define CAN2_F24BANK1_FBIT5_OFFSET                         5
#define CAN2_F24BANK1_FBIT5_MASK                           0x20

#define CAN2_F24BANK1_FBIT6_OFFSET                         6
#define CAN2_F24BANK1_FBIT6_MASK                           0x40

#define CAN2_F24BANK1_FBIT7_OFFSET                         7
#define CAN2_F24BANK1_FBIT7_MASK                           0x80

#define CAN2_F24BANK1_FBIT8_OFFSET                         8
#define CAN2_F24BANK1_FBIT8_MASK                           0x100

#define CAN2_F24BANK1_FBIT9_OFFSET                         9
#define CAN2_F24BANK1_FBIT9_MASK                           0x200

#define CAN2_F24BANK1_FBIT10_OFFSET                        10
#define CAN2_F24BANK1_FBIT10_MASK                          0x400

#define CAN2_F24BANK1_FBIT11_OFFSET                        11
#define CAN2_F24BANK1_FBIT11_MASK                          0x800

#define CAN2_F24BANK1_FBIT12_OFFSET                        12
#define CAN2_F24BANK1_FBIT12_MASK                          0x1000

#define CAN2_F24BANK1_FBIT13_OFFSET                        13
#define CAN2_F24BANK1_FBIT13_MASK                          0x2000

#define CAN2_F24BANK1_FBIT14_OFFSET                        14
#define CAN2_F24BANK1_FBIT14_MASK                          0x4000

#define CAN2_F24BANK1_FBIT15_OFFSET                        15
#define CAN2_F24BANK1_FBIT15_MASK                          0x8000

#define CAN2_F24BANK1_FBIT16_OFFSET                        16
#define CAN2_F24BANK1_FBIT16_MASK                          0x10000

#define CAN2_F24BANK1_FBIT17_OFFSET                        17
#define CAN2_F24BANK1_FBIT17_MASK                          0x20000

#define CAN2_F24BANK1_FBIT18_OFFSET                        18
#define CAN2_F24BANK1_FBIT18_MASK                          0x40000

#define CAN2_F24BANK1_FBIT19_OFFSET                        19
#define CAN2_F24BANK1_FBIT19_MASK                          0x80000

#define CAN2_F24BANK1_FBIT20_OFFSET                        20
#define CAN2_F24BANK1_FBIT20_MASK                          0x100000

#define CAN2_F24BANK1_FBIT21_OFFSET                        21
#define CAN2_F24BANK1_FBIT21_MASK                          0x200000

#define CAN2_F24BANK1_FBIT22_OFFSET                        22
#define CAN2_F24BANK1_FBIT22_MASK                          0x400000

#define CAN2_F24BANK1_FBIT23_OFFSET                        23
#define CAN2_F24BANK1_FBIT23_MASK                          0x800000

#define CAN2_F24BANK1_FBIT24_OFFSET                        24
#define CAN2_F24BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F24BANK1_FBIT25_OFFSET                        25
#define CAN2_F24BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F24BANK1_FBIT26_OFFSET                        26
#define CAN2_F24BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F24BANK1_FBIT27_OFFSET                        27
#define CAN2_F24BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F24BANK1_FBIT28_OFFSET                        28
#define CAN2_F24BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F24BANK1_FBIT29_OFFSET                        29
#define CAN2_F24BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F24BANK1_FBIT30_OFFSET                        30
#define CAN2_F24BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F24BANK1_FBIT31_OFFSET                        31
#define CAN2_F24BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F24BANK2_FBIT0_OFFSET                         0
#define CAN2_F24BANK2_FBIT0_MASK                           1

#define CAN2_F24BANK2_FBIT1_OFFSET                         1
#define CAN2_F24BANK2_FBIT1_MASK                           2

#define CAN2_F24BANK2_FBIT2_OFFSET                         2
#define CAN2_F24BANK2_FBIT2_MASK                           4

#define CAN2_F24BANK2_FBIT3_OFFSET                         3
#define CAN2_F24BANK2_FBIT3_MASK                           8

#define CAN2_F24BANK2_FBIT4_OFFSET                         4
#define CAN2_F24BANK2_FBIT4_MASK                           0x10

#define CAN2_F24BANK2_FBIT5_OFFSET                         5
#define CAN2_F24BANK2_FBIT5_MASK                           0x20

#define CAN2_F24BANK2_FBIT6_OFFSET                         6
#define CAN2_F24BANK2_FBIT6_MASK                           0x40

#define CAN2_F24BANK2_FBIT7_OFFSET                         7
#define CAN2_F24BANK2_FBIT7_MASK                           0x80

#define CAN2_F24BANK2_FBIT8_OFFSET                         8
#define CAN2_F24BANK2_FBIT8_MASK                           0x100

#define CAN2_F24BANK2_FBIT9_OFFSET                         9
#define CAN2_F24BANK2_FBIT9_MASK                           0x200

#define CAN2_F24BANK2_FBIT10_OFFSET                        10
#define CAN2_F24BANK2_FBIT10_MASK                          0x400

#define CAN2_F24BANK2_FBIT11_OFFSET                        11
#define CAN2_F24BANK2_FBIT11_MASK                          0x800

#define CAN2_F24BANK2_FBIT12_OFFSET                        12
#define CAN2_F24BANK2_FBIT12_MASK                          0x1000

#define CAN2_F24BANK2_FBIT13_OFFSET                        13
#define CAN2_F24BANK2_FBIT13_MASK                          0x2000

#define CAN2_F24BANK2_FBIT14_OFFSET                        14
#define CAN2_F24BANK2_FBIT14_MASK                          0x4000

#define CAN2_F24BANK2_FBIT15_OFFSET                        15
#define CAN2_F24BANK2_FBIT15_MASK                          0x8000

#define CAN2_F24BANK2_FBIT16_OFFSET                        16
#define CAN2_F24BANK2_FBIT16_MASK                          0x10000

#define CAN2_F24BANK2_FBIT17_OFFSET                        17
#define CAN2_F24BANK2_FBIT17_MASK                          0x20000

#define CAN2_F24BANK2_FBIT18_OFFSET                        18
#define CAN2_F24BANK2_FBIT18_MASK                          0x40000

#define CAN2_F24BANK2_FBIT19_OFFSET                        19
#define CAN2_F24BANK2_FBIT19_MASK                          0x80000

#define CAN2_F24BANK2_FBIT20_OFFSET                        20
#define CAN2_F24BANK2_FBIT20_MASK                          0x100000

#define CAN2_F24BANK2_FBIT21_OFFSET                        21
#define CAN2_F24BANK2_FBIT21_MASK                          0x200000

#define CAN2_F24BANK2_FBIT22_OFFSET                        22
#define CAN2_F24BANK2_FBIT22_MASK                          0x400000

#define CAN2_F24BANK2_FBIT23_OFFSET                        23
#define CAN2_F24BANK2_FBIT23_MASK                          0x800000

#define CAN2_F24BANK2_FBIT24_OFFSET                        24
#define CAN2_F24BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F24BANK2_FBIT25_OFFSET                        25
#define CAN2_F24BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F24BANK2_FBIT26_OFFSET                        26
#define CAN2_F24BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F24BANK2_FBIT27_OFFSET                        27
#define CAN2_F24BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F24BANK2_FBIT28_OFFSET                        28
#define CAN2_F24BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F24BANK2_FBIT29_OFFSET                        29
#define CAN2_F24BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F24BANK2_FBIT30_OFFSET                        30
#define CAN2_F24BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F24BANK2_FBIT31_OFFSET                        31
#define CAN2_F24BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F25BANK1_FBIT0_OFFSET                         0
#define CAN2_F25BANK1_FBIT0_MASK                           1

#define CAN2_F25BANK1_FBIT1_OFFSET                         1
#define CAN2_F25BANK1_FBIT1_MASK                           2

#define CAN2_F25BANK1_FBIT2_OFFSET                         2
#define CAN2_F25BANK1_FBIT2_MASK                           4

#define CAN2_F25BANK1_FBIT3_OFFSET                         3
#define CAN2_F25BANK1_FBIT3_MASK                           8

#define CAN2_F25BANK1_FBIT4_OFFSET                         4
#define CAN2_F25BANK1_FBIT4_MASK                           0x10

#define CAN2_F25BANK1_FBIT5_OFFSET                         5
#define CAN2_F25BANK1_FBIT5_MASK                           0x20

#define CAN2_F25BANK1_FBIT6_OFFSET                         6
#define CAN2_F25BANK1_FBIT6_MASK                           0x40

#define CAN2_F25BANK1_FBIT7_OFFSET                         7
#define CAN2_F25BANK1_FBIT7_MASK                           0x80

#define CAN2_F25BANK1_FBIT8_OFFSET                         8
#define CAN2_F25BANK1_FBIT8_MASK                           0x100

#define CAN2_F25BANK1_FBIT9_OFFSET                         9
#define CAN2_F25BANK1_FBIT9_MASK                           0x200

#define CAN2_F25BANK1_FBIT10_OFFSET                        10
#define CAN2_F25BANK1_FBIT10_MASK                          0x400

#define CAN2_F25BANK1_FBIT11_OFFSET                        11
#define CAN2_F25BANK1_FBIT11_MASK                          0x800

#define CAN2_F25BANK1_FBIT12_OFFSET                        12
#define CAN2_F25BANK1_FBIT12_MASK                          0x1000

#define CAN2_F25BANK1_FBIT13_OFFSET                        13
#define CAN2_F25BANK1_FBIT13_MASK                          0x2000

#define CAN2_F25BANK1_FBIT14_OFFSET                        14
#define CAN2_F25BANK1_FBIT14_MASK                          0x4000

#define CAN2_F25BANK1_FBIT15_OFFSET                        15
#define CAN2_F25BANK1_FBIT15_MASK                          0x8000

#define CAN2_F25BANK1_FBIT16_OFFSET                        16
#define CAN2_F25BANK1_FBIT16_MASK                          0x10000

#define CAN2_F25BANK1_FBIT17_OFFSET                        17
#define CAN2_F25BANK1_FBIT17_MASK                          0x20000

#define CAN2_F25BANK1_FBIT18_OFFSET                        18
#define CAN2_F25BANK1_FBIT18_MASK                          0x40000

#define CAN2_F25BANK1_FBIT19_OFFSET                        19
#define CAN2_F25BANK1_FBIT19_MASK                          0x80000

#define CAN2_F25BANK1_FBIT20_OFFSET                        20
#define CAN2_F25BANK1_FBIT20_MASK                          0x100000

#define CAN2_F25BANK1_FBIT21_OFFSET                        21
#define CAN2_F25BANK1_FBIT21_MASK                          0x200000

#define CAN2_F25BANK1_FBIT22_OFFSET                        22
#define CAN2_F25BANK1_FBIT22_MASK                          0x400000

#define CAN2_F25BANK1_FBIT23_OFFSET                        23
#define CAN2_F25BANK1_FBIT23_MASK                          0x800000

#define CAN2_F25BANK1_FBIT24_OFFSET                        24
#define CAN2_F25BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F25BANK1_FBIT25_OFFSET                        25
#define CAN2_F25BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F25BANK1_FBIT26_OFFSET                        26
#define CAN2_F25BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F25BANK1_FBIT27_OFFSET                        27
#define CAN2_F25BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F25BANK1_FBIT28_OFFSET                        28
#define CAN2_F25BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F25BANK1_FBIT29_OFFSET                        29
#define CAN2_F25BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F25BANK1_FBIT30_OFFSET                        30
#define CAN2_F25BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F25BANK1_FBIT31_OFFSET                        31
#define CAN2_F25BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F25BANK2_FBIT0_OFFSET                         0
#define CAN2_F25BANK2_FBIT0_MASK                           1

#define CAN2_F25BANK2_FBIT1_OFFSET                         1
#define CAN2_F25BANK2_FBIT1_MASK                           2

#define CAN2_F25BANK2_FBIT2_OFFSET                         2
#define CAN2_F25BANK2_FBIT2_MASK                           4

#define CAN2_F25BANK2_FBIT3_OFFSET                         3
#define CAN2_F25BANK2_FBIT3_MASK                           8

#define CAN2_F25BANK2_FBIT4_OFFSET                         4
#define CAN2_F25BANK2_FBIT4_MASK                           0x10

#define CAN2_F25BANK2_FBIT5_OFFSET                         5
#define CAN2_F25BANK2_FBIT5_MASK                           0x20

#define CAN2_F25BANK2_FBIT6_OFFSET                         6
#define CAN2_F25BANK2_FBIT6_MASK                           0x40

#define CAN2_F25BANK2_FBIT7_OFFSET                         7
#define CAN2_F25BANK2_FBIT7_MASK                           0x80

#define CAN2_F25BANK2_FBIT8_OFFSET                         8
#define CAN2_F25BANK2_FBIT8_MASK                           0x100

#define CAN2_F25BANK2_FBIT9_OFFSET                         9
#define CAN2_F25BANK2_FBIT9_MASK                           0x200

#define CAN2_F25BANK2_FBIT10_OFFSET                        10
#define CAN2_F25BANK2_FBIT10_MASK                          0x400

#define CAN2_F25BANK2_FBIT11_OFFSET                        11
#define CAN2_F25BANK2_FBIT11_MASK                          0x800

#define CAN2_F25BANK2_FBIT12_OFFSET                        12
#define CAN2_F25BANK2_FBIT12_MASK                          0x1000

#define CAN2_F25BANK2_FBIT13_OFFSET                        13
#define CAN2_F25BANK2_FBIT13_MASK                          0x2000

#define CAN2_F25BANK2_FBIT14_OFFSET                        14
#define CAN2_F25BANK2_FBIT14_MASK                          0x4000

#define CAN2_F25BANK2_FBIT15_OFFSET                        15
#define CAN2_F25BANK2_FBIT15_MASK                          0x8000

#define CAN2_F25BANK2_FBIT16_OFFSET                        16
#define CAN2_F25BANK2_FBIT16_MASK                          0x10000

#define CAN2_F25BANK2_FBIT17_OFFSET                        17
#define CAN2_F25BANK2_FBIT17_MASK                          0x20000

#define CAN2_F25BANK2_FBIT18_OFFSET                        18
#define CAN2_F25BANK2_FBIT18_MASK                          0x40000

#define CAN2_F25BANK2_FBIT19_OFFSET                        19
#define CAN2_F25BANK2_FBIT19_MASK                          0x80000

#define CAN2_F25BANK2_FBIT20_OFFSET                        20
#define CAN2_F25BANK2_FBIT20_MASK                          0x100000

#define CAN2_F25BANK2_FBIT21_OFFSET                        21
#define CAN2_F25BANK2_FBIT21_MASK                          0x200000

#define CAN2_F25BANK2_FBIT22_OFFSET                        22
#define CAN2_F25BANK2_FBIT22_MASK                          0x400000

#define CAN2_F25BANK2_FBIT23_OFFSET                        23
#define CAN2_F25BANK2_FBIT23_MASK                          0x800000

#define CAN2_F25BANK2_FBIT24_OFFSET                        24
#define CAN2_F25BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F25BANK2_FBIT25_OFFSET                        25
#define CAN2_F25BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F25BANK2_FBIT26_OFFSET                        26
#define CAN2_F25BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F25BANK2_FBIT27_OFFSET                        27
#define CAN2_F25BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F25BANK2_FBIT28_OFFSET                        28
#define CAN2_F25BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F25BANK2_FBIT29_OFFSET                        29
#define CAN2_F25BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F25BANK2_FBIT30_OFFSET                        30
#define CAN2_F25BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F25BANK2_FBIT31_OFFSET                        31
#define CAN2_F25BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F26BANK1_FBIT0_OFFSET                         0
#define CAN2_F26BANK1_FBIT0_MASK                           1

#define CAN2_F26BANK1_FBIT1_OFFSET                         1
#define CAN2_F26BANK1_FBIT1_MASK                           2

#define CAN2_F26BANK1_FBIT2_OFFSET                         2
#define CAN2_F26BANK1_FBIT2_MASK                           4

#define CAN2_F26BANK1_FBIT3_OFFSET                         3
#define CAN2_F26BANK1_FBIT3_MASK                           8

#define CAN2_F26BANK1_FBIT4_OFFSET                         4
#define CAN2_F26BANK1_FBIT4_MASK                           0x10

#define CAN2_F26BANK1_FBIT5_OFFSET                         5
#define CAN2_F26BANK1_FBIT5_MASK                           0x20

#define CAN2_F26BANK1_FBIT6_OFFSET                         6
#define CAN2_F26BANK1_FBIT6_MASK                           0x40

#define CAN2_F26BANK1_FBIT7_OFFSET                         7
#define CAN2_F26BANK1_FBIT7_MASK                           0x80

#define CAN2_F26BANK1_FBIT8_OFFSET                         8
#define CAN2_F26BANK1_FBIT8_MASK                           0x100

#define CAN2_F26BANK1_FBIT9_OFFSET                         9
#define CAN2_F26BANK1_FBIT9_MASK                           0x200

#define CAN2_F26BANK1_FBIT10_OFFSET                        10
#define CAN2_F26BANK1_FBIT10_MASK                          0x400

#define CAN2_F26BANK1_FBIT11_OFFSET                        11
#define CAN2_F26BANK1_FBIT11_MASK                          0x800

#define CAN2_F26BANK1_FBIT12_OFFSET                        12
#define CAN2_F26BANK1_FBIT12_MASK                          0x1000

#define CAN2_F26BANK1_FBIT13_OFFSET                        13
#define CAN2_F26BANK1_FBIT13_MASK                          0x2000

#define CAN2_F26BANK1_FBIT14_OFFSET                        14
#define CAN2_F26BANK1_FBIT14_MASK                          0x4000

#define CAN2_F26BANK1_FBIT15_OFFSET                        15
#define CAN2_F26BANK1_FBIT15_MASK                          0x8000

#define CAN2_F26BANK1_FBIT16_OFFSET                        16
#define CAN2_F26BANK1_FBIT16_MASK                          0x10000

#define CAN2_F26BANK1_FBIT17_OFFSET                        17
#define CAN2_F26BANK1_FBIT17_MASK                          0x20000

#define CAN2_F26BANK1_FBIT18_OFFSET                        18
#define CAN2_F26BANK1_FBIT18_MASK                          0x40000

#define CAN2_F26BANK1_FBIT19_OFFSET                        19
#define CAN2_F26BANK1_FBIT19_MASK                          0x80000

#define CAN2_F26BANK1_FBIT20_OFFSET                        20
#define CAN2_F26BANK1_FBIT20_MASK                          0x100000

#define CAN2_F26BANK1_FBIT21_OFFSET                        21
#define CAN2_F26BANK1_FBIT21_MASK                          0x200000

#define CAN2_F26BANK1_FBIT22_OFFSET                        22
#define CAN2_F26BANK1_FBIT22_MASK                          0x400000

#define CAN2_F26BANK1_FBIT23_OFFSET                        23
#define CAN2_F26BANK1_FBIT23_MASK                          0x800000

#define CAN2_F26BANK1_FBIT24_OFFSET                        24
#define CAN2_F26BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F26BANK1_FBIT25_OFFSET                        25
#define CAN2_F26BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F26BANK1_FBIT26_OFFSET                        26
#define CAN2_F26BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F26BANK1_FBIT27_OFFSET                        27
#define CAN2_F26BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F26BANK1_FBIT28_OFFSET                        28
#define CAN2_F26BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F26BANK1_FBIT29_OFFSET                        29
#define CAN2_F26BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F26BANK1_FBIT30_OFFSET                        30
#define CAN2_F26BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F26BANK1_FBIT31_OFFSET                        31
#define CAN2_F26BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F26BANK2_FBIT0_OFFSET                         0
#define CAN2_F26BANK2_FBIT0_MASK                           1

#define CAN2_F26BANK2_FBIT1_OFFSET                         1
#define CAN2_F26BANK2_FBIT1_MASK                           2

#define CAN2_F26BANK2_FBIT2_OFFSET                         2
#define CAN2_F26BANK2_FBIT2_MASK                           4

#define CAN2_F26BANK2_FBIT3_OFFSET                         3
#define CAN2_F26BANK2_FBIT3_MASK                           8

#define CAN2_F26BANK2_FBIT4_OFFSET                         4
#define CAN2_F26BANK2_FBIT4_MASK                           0x10

#define CAN2_F26BANK2_FBIT5_OFFSET                         5
#define CAN2_F26BANK2_FBIT5_MASK                           0x20

#define CAN2_F26BANK2_FBIT6_OFFSET                         6
#define CAN2_F26BANK2_FBIT6_MASK                           0x40

#define CAN2_F26BANK2_FBIT7_OFFSET                         7
#define CAN2_F26BANK2_FBIT7_MASK                           0x80

#define CAN2_F26BANK2_FBIT8_OFFSET                         8
#define CAN2_F26BANK2_FBIT8_MASK                           0x100

#define CAN2_F26BANK2_FBIT9_OFFSET                         9
#define CAN2_F26BANK2_FBIT9_MASK                           0x200

#define CAN2_F26BANK2_FBIT10_OFFSET                        10
#define CAN2_F26BANK2_FBIT10_MASK                          0x400

#define CAN2_F26BANK2_FBIT11_OFFSET                        11
#define CAN2_F26BANK2_FBIT11_MASK                          0x800

#define CAN2_F26BANK2_FBIT12_OFFSET                        12
#define CAN2_F26BANK2_FBIT12_MASK                          0x1000

#define CAN2_F26BANK2_FBIT13_OFFSET                        13
#define CAN2_F26BANK2_FBIT13_MASK                          0x2000

#define CAN2_F26BANK2_FBIT14_OFFSET                        14
#define CAN2_F26BANK2_FBIT14_MASK                          0x4000

#define CAN2_F26BANK2_FBIT15_OFFSET                        15
#define CAN2_F26BANK2_FBIT15_MASK                          0x8000

#define CAN2_F26BANK2_FBIT16_OFFSET                        16
#define CAN2_F26BANK2_FBIT16_MASK                          0x10000

#define CAN2_F26BANK2_FBIT17_OFFSET                        17
#define CAN2_F26BANK2_FBIT17_MASK                          0x20000

#define CAN2_F26BANK2_FBIT18_OFFSET                        18
#define CAN2_F26BANK2_FBIT18_MASK                          0x40000

#define CAN2_F26BANK2_FBIT19_OFFSET                        19
#define CAN2_F26BANK2_FBIT19_MASK                          0x80000

#define CAN2_F26BANK2_FBIT20_OFFSET                        20
#define CAN2_F26BANK2_FBIT20_MASK                          0x100000

#define CAN2_F26BANK2_FBIT21_OFFSET                        21
#define CAN2_F26BANK2_FBIT21_MASK                          0x200000

#define CAN2_F26BANK2_FBIT22_OFFSET                        22
#define CAN2_F26BANK2_FBIT22_MASK                          0x400000

#define CAN2_F26BANK2_FBIT23_OFFSET                        23
#define CAN2_F26BANK2_FBIT23_MASK                          0x800000

#define CAN2_F26BANK2_FBIT24_OFFSET                        24
#define CAN2_F26BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F26BANK2_FBIT25_OFFSET                        25
#define CAN2_F26BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F26BANK2_FBIT26_OFFSET                        26
#define CAN2_F26BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F26BANK2_FBIT27_OFFSET                        27
#define CAN2_F26BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F26BANK2_FBIT28_OFFSET                        28
#define CAN2_F26BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F26BANK2_FBIT29_OFFSET                        29
#define CAN2_F26BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F26BANK2_FBIT30_OFFSET                        30
#define CAN2_F26BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F26BANK2_FBIT31_OFFSET                        31
#define CAN2_F26BANK2_FBIT31_MASK                          0x80000000

#define CAN2_F27BANK1_FBIT0_OFFSET                         0
#define CAN2_F27BANK1_FBIT0_MASK                           1

#define CAN2_F27BANK1_FBIT1_OFFSET                         1
#define CAN2_F27BANK1_FBIT1_MASK                           2

#define CAN2_F27BANK1_FBIT2_OFFSET                         2
#define CAN2_F27BANK1_FBIT2_MASK                           4

#define CAN2_F27BANK1_FBIT3_OFFSET                         3
#define CAN2_F27BANK1_FBIT3_MASK                           8

#define CAN2_F27BANK1_FBIT4_OFFSET                         4
#define CAN2_F27BANK1_FBIT4_MASK                           0x10

#define CAN2_F27BANK1_FBIT5_OFFSET                         5
#define CAN2_F27BANK1_FBIT5_MASK                           0x20

#define CAN2_F27BANK1_FBIT6_OFFSET                         6
#define CAN2_F27BANK1_FBIT6_MASK                           0x40

#define CAN2_F27BANK1_FBIT7_OFFSET                         7
#define CAN2_F27BANK1_FBIT7_MASK                           0x80

#define CAN2_F27BANK1_FBIT8_OFFSET                         8
#define CAN2_F27BANK1_FBIT8_MASK                           0x100

#define CAN2_F27BANK1_FBIT9_OFFSET                         9
#define CAN2_F27BANK1_FBIT9_MASK                           0x200

#define CAN2_F27BANK1_FBIT10_OFFSET                        10
#define CAN2_F27BANK1_FBIT10_MASK                          0x400

#define CAN2_F27BANK1_FBIT11_OFFSET                        11
#define CAN2_F27BANK1_FBIT11_MASK                          0x800

#define CAN2_F27BANK1_FBIT12_OFFSET                        12
#define CAN2_F27BANK1_FBIT12_MASK                          0x1000

#define CAN2_F27BANK1_FBIT13_OFFSET                        13
#define CAN2_F27BANK1_FBIT13_MASK                          0x2000

#define CAN2_F27BANK1_FBIT14_OFFSET                        14
#define CAN2_F27BANK1_FBIT14_MASK                          0x4000

#define CAN2_F27BANK1_FBIT15_OFFSET                        15
#define CAN2_F27BANK1_FBIT15_MASK                          0x8000

#define CAN2_F27BANK1_FBIT16_OFFSET                        16
#define CAN2_F27BANK1_FBIT16_MASK                          0x10000

#define CAN2_F27BANK1_FBIT17_OFFSET                        17
#define CAN2_F27BANK1_FBIT17_MASK                          0x20000

#define CAN2_F27BANK1_FBIT18_OFFSET                        18
#define CAN2_F27BANK1_FBIT18_MASK                          0x40000

#define CAN2_F27BANK1_FBIT19_OFFSET                        19
#define CAN2_F27BANK1_FBIT19_MASK                          0x80000

#define CAN2_F27BANK1_FBIT20_OFFSET                        20
#define CAN2_F27BANK1_FBIT20_MASK                          0x100000

#define CAN2_F27BANK1_FBIT21_OFFSET                        21
#define CAN2_F27BANK1_FBIT21_MASK                          0x200000

#define CAN2_F27BANK1_FBIT22_OFFSET                        22
#define CAN2_F27BANK1_FBIT22_MASK                          0x400000

#define CAN2_F27BANK1_FBIT23_OFFSET                        23
#define CAN2_F27BANK1_FBIT23_MASK                          0x800000

#define CAN2_F27BANK1_FBIT24_OFFSET                        24
#define CAN2_F27BANK1_FBIT24_MASK                          0x1000000

#define CAN2_F27BANK1_FBIT25_OFFSET                        25
#define CAN2_F27BANK1_FBIT25_MASK                          0x2000000

#define CAN2_F27BANK1_FBIT26_OFFSET                        26
#define CAN2_F27BANK1_FBIT26_MASK                          0x4000000

#define CAN2_F27BANK1_FBIT27_OFFSET                        27
#define CAN2_F27BANK1_FBIT27_MASK                          0x8000000

#define CAN2_F27BANK1_FBIT28_OFFSET                        28
#define CAN2_F27BANK1_FBIT28_MASK                          0x10000000

#define CAN2_F27BANK1_FBIT29_OFFSET                        29
#define CAN2_F27BANK1_FBIT29_MASK                          0x20000000

#define CAN2_F27BANK1_FBIT30_OFFSET                        30
#define CAN2_F27BANK1_FBIT30_MASK                          0x40000000

#define CAN2_F27BANK1_FBIT31_OFFSET                        31
#define CAN2_F27BANK1_FBIT31_MASK                          0x80000000

#define CAN2_F27BANK2_FBIT0_OFFSET                         0
#define CAN2_F27BANK2_FBIT0_MASK                           1

#define CAN2_F27BANK2_FBIT1_OFFSET                         1
#define CAN2_F27BANK2_FBIT1_MASK                           2

#define CAN2_F27BANK2_FBIT2_OFFSET                         2
#define CAN2_F27BANK2_FBIT2_MASK                           4

#define CAN2_F27BANK2_FBIT3_OFFSET                         3
#define CAN2_F27BANK2_FBIT3_MASK                           8

#define CAN2_F27BANK2_FBIT4_OFFSET                         4
#define CAN2_F27BANK2_FBIT4_MASK                           0x10

#define CAN2_F27BANK2_FBIT5_OFFSET                         5
#define CAN2_F27BANK2_FBIT5_MASK                           0x20

#define CAN2_F27BANK2_FBIT6_OFFSET                         6
#define CAN2_F27BANK2_FBIT6_MASK                           0x40

#define CAN2_F27BANK2_FBIT7_OFFSET                         7
#define CAN2_F27BANK2_FBIT7_MASK                           0x80

#define CAN2_F27BANK2_FBIT8_OFFSET                         8
#define CAN2_F27BANK2_FBIT8_MASK                           0x100

#define CAN2_F27BANK2_FBIT9_OFFSET                         9
#define CAN2_F27BANK2_FBIT9_MASK                           0x200

#define CAN2_F27BANK2_FBIT10_OFFSET                        10
#define CAN2_F27BANK2_FBIT10_MASK                          0x400

#define CAN2_F27BANK2_FBIT11_OFFSET                        11
#define CAN2_F27BANK2_FBIT11_MASK                          0x800

#define CAN2_F27BANK2_FBIT12_OFFSET                        12
#define CAN2_F27BANK2_FBIT12_MASK                          0x1000

#define CAN2_F27BANK2_FBIT13_OFFSET                        13
#define CAN2_F27BANK2_FBIT13_MASK                          0x2000

#define CAN2_F27BANK2_FBIT14_OFFSET                        14
#define CAN2_F27BANK2_FBIT14_MASK                          0x4000

#define CAN2_F27BANK2_FBIT15_OFFSET                        15
#define CAN2_F27BANK2_FBIT15_MASK                          0x8000

#define CAN2_F27BANK2_FBIT16_OFFSET                        16
#define CAN2_F27BANK2_FBIT16_MASK                          0x10000

#define CAN2_F27BANK2_FBIT17_OFFSET                        17
#define CAN2_F27BANK2_FBIT17_MASK                          0x20000

#define CAN2_F27BANK2_FBIT18_OFFSET                        18
#define CAN2_F27BANK2_FBIT18_MASK                          0x40000

#define CAN2_F27BANK2_FBIT19_OFFSET                        19
#define CAN2_F27BANK2_FBIT19_MASK                          0x80000

#define CAN2_F27BANK2_FBIT20_OFFSET                        20
#define CAN2_F27BANK2_FBIT20_MASK                          0x100000

#define CAN2_F27BANK2_FBIT21_OFFSET                        21
#define CAN2_F27BANK2_FBIT21_MASK                          0x200000

#define CAN2_F27BANK2_FBIT22_OFFSET                        22
#define CAN2_F27BANK2_FBIT22_MASK                          0x400000

#define CAN2_F27BANK2_FBIT23_OFFSET                        23
#define CAN2_F27BANK2_FBIT23_MASK                          0x800000

#define CAN2_F27BANK2_FBIT24_OFFSET                        24
#define CAN2_F27BANK2_FBIT24_MASK                          0x1000000

#define CAN2_F27BANK2_FBIT25_OFFSET                        25
#define CAN2_F27BANK2_FBIT25_MASK                          0x2000000

#define CAN2_F27BANK2_FBIT26_OFFSET                        26
#define CAN2_F27BANK2_FBIT26_MASK                          0x4000000

#define CAN2_F27BANK2_FBIT27_OFFSET                        27
#define CAN2_F27BANK2_FBIT27_MASK                          0x8000000

#define CAN2_F27BANK2_FBIT28_OFFSET                        28
#define CAN2_F27BANK2_FBIT28_MASK                          0x10000000

#define CAN2_F27BANK2_FBIT29_OFFSET                        29
#define CAN2_F27BANK2_FBIT29_MASK                          0x20000000

#define CAN2_F27BANK2_FBIT30_OFFSET                        30
#define CAN2_F27BANK2_FBIT30_MASK                          0x40000000

#define CAN2_F27BANK2_FBIT31_OFFSET                        31
#define CAN2_F27BANK2_FBIT31_MASK                          0x80000000


typedef struct
{

/** MCTRL MCTRL (offset: 0x0)
  CAN Master control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INITREQ
  offset: 0, size: 1, access: 
  INITREQ
  Field: SLEEPREQ
  offset: 1, size: 1, access: 
  SLEEPREQ
  Field: TXFPCFG
  offset: 2, size: 1, access: 
  TXFPCFG
  Field: RXFLOCK
  offset: 3, size: 1, access: 
  RXFLOCK
  Field: ARTXMD
  offset: 4, size: 1, access: 
  ARTXMD
  Field: AWUPCFG
  offset: 5, size: 1, access: 
  AWUPCFG
  Field: ALBOFFM
  offset: 6, size: 1, access: 
  ALBOFFM
  Field: SWRST
  offset: 15, size: 1, access: 
  SWRST
  Field: DBGFRZE
  offset: 16, size: 1, access: 
  DBGFRZE
*/
volatile uint32_t MCTRL;

/** MSTS MSTS (offset: 0x4)
  CAN Master States register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INITFLG
  offset: 0, size: 1, access: read-only
  INITFLG
  Field: SLEEPFLG
  offset: 1, size: 1, access: read-only
  SLEEPFLG
  Field: ERRIFLG
  offset: 2, size: 1, access: read-write
  ERRIFLG
  Field: WUPIFLG
  offset: 3, size: 1, access: read-write
  WUPIFLG
  Field: SLEEPIFLG
  offset: 4, size: 1, access: read-write
  SLEEPIFLG
  Field: TXMFLG
  offset: 8, size: 1, access: read-only
  TXMFLG
  Field: RXMFLG
  offset: 9, size: 1, access: read-only
  RXMFLG
  Field: LSAMVALUE
  offset: 10, size: 1, access: read-only
  LSAMVALUE
  Field: RXSIGL
  offset: 11, size: 1, access: read-only
  RXSIGL
*/
volatile uint32_t MSTS;

/** TXSTS TXSTS (offset: 0x8)
  CAN Send States register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: REQCFLG0
  offset: 0, size: 1, access: read-write
  REQCFLG0
  Field: TXSUSFLG0
  offset: 1, size: 1, access: read-write
  TXSUSFLG0
  Field: ARBLSTFLG0
  offset: 2, size: 1, access: read-write
  ARBLSTFLG0
  Field: TXERRFLG0
  offset: 3, size: 1, access: read-write
  TXERRFLG0
  Field: ABREQFLG0
  offset: 7, size: 1, access: read-write
  ABREQFLG0
  Field: REQCFLG1
  offset: 8, size: 1, access: read-write
  REQCFLG1
  Field: TXSUSFLG1
  offset: 9, size: 1, access: read-write
  TXSUSFLG1
  Field: ARBLSTFLG1
  offset: 10, size: 1, access: read-write
  ARBLSTFLG1
  Field: TXERRFLG1
  offset: 11, size: 1, access: read-write
  TXERRFLG1
  Field: ABREQFLG1
  offset: 15, size: 1, access: read-write
  ABREQFLG1
  Field: REQCFLG2
  offset: 16, size: 1, access: read-write
  REQCFLG2
  Field: TXSUSFLG2
  offset: 17, size: 1, access: read-write
  TXSUSFLG2
  Field: ARBLSTFLG2
  offset: 18, size: 1, access: read-write
  ARBLSTFLG2
  Field: TXERRFLG2
  offset: 19, size: 1, access: read-write
  TXERRFLG2
  Field: ABREQFLG2
  offset: 23, size: 1, access: read-write
  ABREQFLG2
  Field: EMNUM
  offset: 24, size: 2, access: read-only
  EMNUM
  Field: TXMEFLG0
  offset: 26, size: 1, access: read-only
  TXMEFLG0
  Field: TXMEFLG1
  offset: 27, size: 1, access: read-only
  TXMEFLG1
  Field: TXMEFLG2
  offset: 28, size: 1, access: read-only
  TXMEFLG2
  Field: LOWESTP0
  offset: 29, size: 1, access: read-only
  LOWESTP0
  Field: LOWESTP1
  offset: 30, size: 1, access: read-only
  LOWESTP1
  Field: LOWESTP2
  offset: 31, size: 1, access: read-only
  LOWESTP2
*/
volatile uint32_t TXSTS;

/** RXF0 RXF0 (offset: 0xc)
  CAN Receive FIFO 0 register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FMNUM0
  offset: 0, size: 2, access: read-only
  FMNUM0
  Field: FFULLFLG0
  offset: 3, size: 1, access: read-write
  FFULLFLG0
  Field: FOVRFLG0
  offset: 4, size: 1, access: read-write
  FOVRFLG0
  Field: RFOM0
  offset: 5, size: 1, access: read-write
  RFOM0
*/
volatile uint32_t RXF0;

/** RXF1 RXF1 (offset: 0x10)
  CAN Receive FIFO 1 register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FMNUM1
  offset: 0, size: 2, access: read-only
  FMNUM1
  Field: FFULLFLG1
  offset: 3, size: 1, access: read-write
  FFULLFLG1
  Field: FOVRFLG1
  offset: 4, size: 1, access: read-write
  FOVRFLG1
  Field: RFOM1
  offset: 5, size: 1, access: read-write
  RFOM1
*/
volatile uint32_t RXF1;

/** INTEN INTEN (offset: 0x14)
  CAN Interrupts register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TXMEIEN
  offset: 0, size: 1, access: 
  TXMEIEN
  Field: FMIEN0
  offset: 1, size: 1, access: 
  FMIEN0
  Field: FFULLIEN0
  offset: 2, size: 1, access: 
  FFULLIEN0
  Field: FOVRIEN0
  offset: 3, size: 1, access: 
  FOVRIEN0
  Field: FMIEN1
  offset: 4, size: 1, access: 
  FMIEN1
  Field: FFULLIEN1
  offset: 5, size: 1, access: 
  FFULLIEN1
  Field: FOVRIEN1
  offset: 6, size: 1, access: 
  FOVRIEN1
  Field: ERRWIEN
  offset: 8, size: 1, access: 
  ERRWIEN
  Field: ERRPIEN
  offset: 9, size: 1, access: 
  ERRPIEN
  Field: BOFFIEN
  offset: 10, size: 1, access: 
  BOFFIEN
  Field: LECIEN
  offset: 11, size: 1, access: 
  LECIEN
  Field: ERRIEN
  offset: 15, size: 1, access: 
  ERRIEN
  Field: WUPIEN
  offset: 16, size: 1, access: 
  WUPIEN
  Field: SLEEPIEN
  offset: 17, size: 1, access: 
  SLEEPIEN
*/
volatile uint32_t INTEN;

/** ERRSTS ERRSTS (offset: 0x18)
  CAN Error States register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ERRWFLG
  offset: 0, size: 1, access: read-only
  ERRWFLG
  Field: ERRPFLG
  offset: 1, size: 1, access: read-only
  ERRPFLG
  Field: BOFLG
  offset: 2, size: 1, access: read-only
  BOFLG
  Field: LERRC
  offset: 4, size: 3, access: read-write
  LERRC
  Field: TXERRCNT
  offset: 16, size: 8, access: read-only
  TXERRCNT
  Field: RXERRCNT
  offset: 24, size: 8, access: read-only
  RXERRCNT
*/
volatile uint32_t ERRSTS;

/** BITTIM BITTIM (offset: 0x1c)
  CAN Bit Time register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BRPSC
  offset: 0, size: 10, access: 
  BRPSC
  Field: TIMSEG1
  offset: 16, size: 4, access: 
  TIMSEG1
  Field: TIMSEG2
  offset: 20, size: 3, access: 
  TIMSEG2
  Field: RSYNJW
  offset: 24, size: 2, access: 
  RSYNJW
  Field: LBKMEN
  offset: 30, size: 1, access: 
  LBKMEN
  Field: SILMEN
  offset: 31, size: 1, access: 
  SILMEN
*/
volatile uint32_t BITTIM;
volatile uint32_t reserved0[88];

/** TXMID0 TXMID0 (offset: 0x180)
  CAN Each mailbox contains the sending mailbox identifier register 0
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TXMREQ
  offset: 0, size: 1, access: 
  TXMREQ
  Field: TXRFREQ
  offset: 1, size: 1, access: 
  TXRFREQ
  Field: IDTYPESEL
  offset: 2, size: 1, access: 
  IDTYPESEL
  Field: EXTID
  offset: 3, size: 18, access: 
  EXTID
  Field: STDID
  offset: 21, size: 11, access: 
  STDID
*/
volatile uint32_t TXMID0;

/** TXDLEN0 TXDLEN0 (offset: 0x184)
  CAN Send the mailbox data length and timestamp register 0
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DLCODE
  offset: 0, size: 4, access: 
  DLCODE
*/
volatile uint32_t TXDLEN0;

/** TXMDL0 TXMDL0 (offset: 0x188)
  CAN Send mailbox low byte data register 0
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATABYTE0
  offset: 0, size: 8, access: 
  DATABYTE0
  Field: DATABYTE1
  offset: 8, size: 8, access: 
  DATABYTE1
  Field: DATABYTE2
  offset: 16, size: 8, access: 
  DATABYTE2
  Field: DATABYTE3
  offset: 24, size: 8, access: 
  DATABYTE3
*/
volatile uint32_t TXMDL0;

/** TXMDH0 TXMDH0 (offset: 0x18c)
  CAN Send mailbox High byte data register 0
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATABYTE4
  offset: 0, size: 8, access: 
  DATABYTE4
  Field: DATABYTE5
  offset: 8, size: 8, access: 
  DATABYTE5
  Field: DATABYTE6
  offset: 16, size: 8, access: 
  DATABYTE6
  Field: DATABYTE7
  offset: 24, size: 8, access: 
  DATABYTE7
*/
volatile uint32_t TXMDH0;

/** TXMID1 TXMID1 (offset: 0x190)
  CAN Each mailbox contains the sending mailbox identifier register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TXMREQ
  offset: 0, size: 1, access: 
  TXMREQ
  Field: TXRFREQ
  offset: 1, size: 1, access: 
  TXRFREQ
  Field: IDTYPESEL
  offset: 2, size: 1, access: 
  IDTYPESEL
  Field: EXTID
  offset: 3, size: 18, access: 
  EXTID
  Field: STDID
  offset: 21, size: 11, access: 
  STDID
*/
volatile uint32_t TXMID1;

/** TXDLEN1 TXDLEN1 (offset: 0x194)
  CAN Send the mailbox data length and timestamp register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DLCODE
  offset: 0, size: 4, access: 
  DLCODE
*/
volatile uint32_t TXDLEN1;

/** TXMDL1 TXMDL1 (offset: 0x198)
  CAN Send mailbox low byte data register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATABYTE0
  offset: 0, size: 8, access: 
  DATABYTE0
  Field: DATABYTE1
  offset: 8, size: 8, access: 
  DATABYTE1
  Field: DATABYTE2
  offset: 16, size: 8, access: 
  DATABYTE2
  Field: DATABYTE3
  offset: 24, size: 8, access: 
  DATABYTE3
*/
volatile uint32_t TXMDL1;

/** TXMDH1 TXMDH1 (offset: 0x19c)
  CAN Send mailbox High byte data register1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATABYTE4
  offset: 0, size: 8, access: 
  DATABYTE4
  Field: DATABYTE5
  offset: 8, size: 8, access: 
  DATABYTE5
  Field: DATABYTE6
  offset: 16, size: 8, access: 
  DATABYTE6
  Field: DATABYTE7
  offset: 24, size: 8, access: 
  DATABYTE7
*/
volatile uint32_t TXMDH1;

/** TXMID2 TXMID2 (offset: 0x1a0)
  CAN Each mailbox contains the sending mailbox identifier register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TXMREQ
  offset: 0, size: 1, access: 
  TXMREQ
  Field: TXRFREQ
  offset: 1, size: 1, access: 
  TXRFREQ
  Field: IDTYPESEL
  offset: 2, size: 1, access: 
  IDTYPESEL
  Field: EXTID
  offset: 3, size: 18, access: 
  EXTID
  Field: STDID
  offset: 21, size: 11, access: 
  STDID
*/
volatile uint32_t TXMID2;

/** TXDLEN2 TXDLEN2 (offset: 0x1a4)
  CAN Send the mailbox data length and timestamp register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DLCODE
  offset: 0, size: 4, access: 
  DLCODE
*/
volatile uint32_t TXDLEN2;

/** TXMDL2 TXMDL2 (offset: 0x1a8)
  CAN Send mailbox low byte data register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATABYTE0
  offset: 0, size: 8, access: 
  DATABYTE0
  Field: DATABYTE1
  offset: 8, size: 8, access: 
  DATABYTE1
  Field: DATABYTE2
  offset: 16, size: 8, access: 
  DATABYTE2
  Field: DATABYTE3
  offset: 24, size: 8, access: 
  DATABYTE3
*/
volatile uint32_t TXMDL2;

/** TXMDH2 TXMDH2 (offset: 0x1ac)
  CAN Send mailbox High byte data register2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATABYTE4
  offset: 0, size: 8, access: 
  DATABYTE4
  Field: DATABYTE5
  offset: 8, size: 8, access: 
  DATABYTE5
  Field: DATABYTE6
  offset: 16, size: 8, access: 
  DATABYTE6
  Field: DATABYTE7
  offset: 24, size: 8, access: 
  DATABYTE7
*/
volatile uint32_t TXMDH2;

/** RXMID0 RXMID0 (offset: 0x1b0)
  CAN Each mailbox contains the receive mailbox identifier register 0
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RFTXREQ
  offset: 1, size: 1, access: 
  RFTXREQ
  Field: IDTYPESEL
  offset: 2, size: 1, access: 
  IDTYPESEL
  Field: EXTID
  offset: 3, size: 18, access: 
  EXTID
  Field: STDID
  offset: 21, size: 11, access: 
  STDID
*/
volatile uint32_t RXMID0;

/** RXDLEN0 RXDLEN0 (offset: 0x1b4)
  CAN receive the mailbox data length and timestamp register 0
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DLCODE
  offset: 0, size: 4, access: 
  DLCODE
  Field: FMIDX
  offset: 8, size: 8, access: 
  FMIDX
*/
volatile uint32_t RXDLEN0;

/** RXMDL0 RXMDL0 (offset: 0x1b8)
  CAN receive mailbox low byte data register 0
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATABYTE0
  offset: 0, size: 8, access: 
  DATABYTE1
  Field: DATABYTE1
  offset: 8, size: 8, access: 
  DATABYTE2
  Field: DATABYTE2
  offset: 16, size: 8, access: 
  DATABYTE3
  Field: DATABYTE3
  offset: 24, size: 8, access: 
  DATABYTE4
*/
volatile uint32_t RXMDL0;

/** RXMDH0 RXMDH0 (offset: 0x1bc)
  CAN receive mailbox High byte data register 0
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATABYTE4
  offset: 0, size: 8, access: 
  DATABYTE5
  Field: DATABYTE5
  offset: 8, size: 8, access: 
  DATABYTE6
  Field: DATABYTE6
  offset: 16, size: 8, access: 
  DATABYTE7
  Field: DATABYTE7
  offset: 24, size: 8, access: 
  DATABYTE8
*/
volatile uint32_t RXMDH0;

/** RXMID1 RXMID1 (offset: 0x1c0)
  CAN Each mailbox contains the receive mailbox identifier register 1
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: RFTXREQ
  offset: 1, size: 1, access: 
  RFTXREQ
  Field: IDTYPESEL
  offset: 2, size: 1, access: 
  IDTYPESEL
  Field: EXTID
  offset: 3, size: 18, access: 
  EXTID
  Field: STDID
  offset: 21, size: 11, access: 
  STDID
*/
volatile uint32_t RXMID1;

/** RXDLEN1 RXDLEN1 (offset: 0x1c4)
  CAN receive the mailbox data length and timestamp register 1
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DLCODE
  offset: 0, size: 4, access: 
  DLCODE
  Field: FMIDX
  offset: 8, size: 8, access: 
  FMIDX
*/
volatile uint32_t RXDLEN1;

/** RXMDL1 RXMDL1 (offset: 0x1c8)
  CAN receive mailbox low byte data register 1
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATABYTE0
  offset: 0, size: 8, access: 
  DATABYTE1
  Field: DATABYTE1
  offset: 8, size: 8, access: 
  DATABYTE2
  Field: DATABYTE2
  offset: 16, size: 8, access: 
  DATABYTE3
  Field: DATABYTE3
  offset: 24, size: 8, access: 
  DATABYTE4
*/
volatile uint32_t RXMDL1;

/** RXMDH1 RXMDH1 (offset: 0x1cc)
  CAN receive mailbox High byte data register 1
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATABYTE4
  offset: 0, size: 8, access: 
  DATABYTE5
  Field: DATABYTE5
  offset: 8, size: 8, access: 
  DATABYTE6
  Field: DATABYTE6
  offset: 16, size: 8, access: 
  DATABYTE7
  Field: DATABYTE7
  offset: 24, size: 8, access: 
  DATABYTE8
*/
volatile uint32_t RXMDH1;
volatile uint32_t reserved1[12];

/** FCTRL FCTRL (offset: 0x200)
  CAN Filter the master control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FINITEN
  offset: 0, size: 1, access: 
  FINITEN
  Field: CAN2SB
  offset: 8, size: 6, access: 
  CAN2 Start Bank
*/
volatile uint32_t FCTRL;

/** FMCFG FMCFG (offset: 0x204)
  CAN Filter register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FMCFG0
  offset: 0, size: 1, access: 
  Filter mode
  Field: FMCFG1
  offset: 1, size: 1, access: 
  Filter mode
  Field: FMCFG2
  offset: 2, size: 1, access: 
  Filter mode
  Field: FMCFG3
  offset: 3, size: 1, access: 
  Filter mode
  Field: FMCFG4
  offset: 4, size: 1, access: 
  Filter mode
  Field: FMCFG5
  offset: 5, size: 1, access: 
  Filter mode
  Field: FMCFG6
  offset: 6, size: 1, access: 
  Filter mode
  Field: FMCFG7
  offset: 7, size: 1, access: 
  Filter mode
  Field: FMCFG8
  offset: 8, size: 1, access: 
  Filter mode
  Field: FMCFG9
  offset: 9, size: 1, access: 
  Filter mode
  Field: FMCFG10
  offset: 10, size: 1, access: 
  Filter mode
  Field: FMCFG11
  offset: 11, size: 1, access: 
  Filter mode
  Field: FMCFG12
  offset: 12, size: 1, access: 
  Filter mode
  Field: FMCFG13
  offset: 13, size: 1, access: 
  Filter mode
  Field: FMCFG14
  offset: 14, size: 1, access: 
  Filter mode
  Field: FMCFG15
  offset: 15, size: 1, access: 
  Filter mode
  Field: FMCFG16
  offset: 16, size: 1, access: 
  Filter mode
  Field: FMCFG17
  offset: 17, size: 1, access: 
  Filter mode
  Field: FMCFG18
  offset: 18, size: 1, access: 
  Filter mode
  Field: FMCFG19
  offset: 19, size: 1, access: 
  Filter mode
  Field: FMCFG20
  offset: 20, size: 1, access: 
  Filter mode
  Field: FMCFG21
  offset: 21, size: 1, access: 
  Filter mode
  Field: FMCFG22
  offset: 22, size: 1, access: 
  Filter mode
  Field: FMCFG23
  offset: 23, size: 1, access: 
  Filter mode
  Field: FMCFG24
  offset: 24, size: 1, access: 
  Filter mode
  Field: FMCFG25
  offset: 25, size: 1, access: 
  Filter mode
  Field: FMCFG26
  offset: 26, size: 1, access: 
  Filter mode
  Field: FMCFG27
  offset: 27, size: 1, access: 
  Filter mode
*/
volatile uint32_t FMCFG;
volatile uint32_t reserved2;

/** FSCFG FSCFG (offset: 0x20c)
  CAN Filter bit width register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FSCFG0
  offset: 0, size: 1, access: 
  Filter bit
  Field: FSCFG1
  offset: 1, size: 1, access: 
  Filter bit
  Field: FSCFG2
  offset: 2, size: 1, access: 
  Filter bit
  Field: FSCFG3
  offset: 3, size: 1, access: 
  Filter bit
  Field: FSCFG4
  offset: 4, size: 1, access: 
  Filter bit
  Field: FSCFG5
  offset: 5, size: 1, access: 
  Filter bit
  Field: FSCFG6
  offset: 6, size: 1, access: 
  Filter bit
  Field: FSCFG7
  offset: 7, size: 1, access: 
  Filter bit
  Field: FSCFG8
  offset: 8, size: 1, access: 
  Filter bit
  Field: FSCFG9
  offset: 9, size: 1, access: 
  Filter bit
  Field: FSCFG10
  offset: 10, size: 1, access: 
  Filter bit
  Field: FSCFG11
  offset: 11, size: 1, access: 
  Filter bit
  Field: FSCFG12
  offset: 12, size: 1, access: 
  Filter bit
  Field: FSCFG13
  offset: 13, size: 1, access: 
  Filter bit
  Field: FSCFG14
  offset: 14, size: 1, access: 
  Filter bit
  Field: FSCFG15
  offset: 15, size: 1, access: 
  Filter bit
  Field: FSCFG16
  offset: 16, size: 1, access: 
  Filter bit
  Field: FSCFG17
  offset: 17, size: 1, access: 
  Filter bit
  Field: FSCFG18
  offset: 18, size: 1, access: 
  Filter bit
  Field: FSCFG19
  offset: 19, size: 1, access: 
  Filter bit
  Field: FSCFG20
  offset: 20, size: 1, access: 
  Filter bit
  Field: FSCFG21
  offset: 21, size: 1, access: 
  Filter bit
  Field: FSCFG22
  offset: 22, size: 1, access: 
  Filter bit
  Field: FSCFG23
  offset: 23, size: 1, access: 
  Filter bit
  Field: FSCFG24
  offset: 24, size: 1, access: 
  Filter bit
  Field: FSCFG25
  offset: 25, size: 1, access: 
  Filter bit
  Field: FSCFG26
  offset: 26, size: 1, access: 
  Filter bit
  Field: FSCFG27
  offset: 27, size: 1, access: 
  Filter bit
*/
volatile uint32_t FSCFG;
volatile uint32_t reserved3;

/** FFASS FFASS (offset: 0x214)
  CAN Filter FIFO associated registers
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FFASS0
  offset: 0, size: 1, access: 
  Filter FIFO assignment for filter 0
  Field: FFASS1
  offset: 1, size: 1, access: 
  Filter FIFO assignment for filter 1
  Field: FFASS2
  offset: 2, size: 1, access: 
  Filter FIFO assignment for filter 2
  Field: FFASS3
  offset: 3, size: 1, access: 
  Filter FIFO assignment for filter 3
  Field: FFASS4
  offset: 4, size: 1, access: 
  Filter FIFO assignment for filter 4
  Field: FFASS5
  offset: 5, size: 1, access: 
  Filter FIFO assignment for filter 5
  Field: FFASS6
  offset: 6, size: 1, access: 
  Filter FIFO assignment for filter 6
  Field: FFASS7
  offset: 7, size: 1, access: 
  Filter FIFO assignment for filter 7
  Field: FFASS8
  offset: 8, size: 1, access: 
  Filter FIFO assignment for filter 8
  Field: FFASS9
  offset: 9, size: 1, access: 
  Filter FIFO assignment for filter 9
  Field: FFASS10
  offset: 10, size: 1, access: 
  Filter FIFO assignment for filter 10
  Field: FFASS11
  offset: 11, size: 1, access: 
  Filter FIFO assignment for filter 11
  Field: FFASS12
  offset: 12, size: 1, access: 
  Filter FIFO assignment for filter 12
  Field: FFASS13
  offset: 13, size: 1, access: 
  Filter FIFO assignment for filter 13
  Field: FFASS14
  offset: 14, size: 1, access: 
  Filter FIFO assignment for filter 14
  Field: FFASS15
  offset: 15, size: 1, access: 
  Filter FIFO assignment for filter 15
  Field: FFASS16
  offset: 16, size: 1, access: 
  Filter FIFO assignment for filter 16
  Field: FFASS17
  offset: 17, size: 1, access: 
  Filter FIFO assignment for filter 17
  Field: FFASS18
  offset: 18, size: 1, access: 
  Filter FIFO assignment for filter 18
  Field: FFASS19
  offset: 19, size: 1, access: 
  Filter FIFO assignment for filter 19
  Field: FFASS20
  offset: 20, size: 1, access: 
  Filter FIFO assignment for filter 20
  Field: FFASS21
  offset: 21, size: 1, access: 
  Filter FIFO assignment for filter 21
  Field: FFASS22
  offset: 22, size: 1, access: 
  Filter FIFO assignment for filter 22
  Field: FFASS23
  offset: 23, size: 1, access: 
  Filter FIFO assignment for filter 23
  Field: FFASS24
  offset: 24, size: 1, access: 
  Filter FIFO assignment for filter 24
  Field: FFASS25
  offset: 25, size: 1, access: 
  Filter FIFO assignment for filter 25
  Field: FFASS26
  offset: 26, size: 1, access: 
  Filter FIFO assignment for filter 26
  Field: FFASS27
  offset: 27, size: 1, access: 
  Filter FIFO assignment for filter 27
*/
volatile uint32_t FFASS;
volatile uint32_t reserved4;

/** FACT FACT (offset: 0x21c)
  CAN Filter activation register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FACT0
  offset: 0, size: 1, access: 
  Filter active
  Field: FACT1
  offset: 1, size: 1, access: 
  Filter active
  Field: FACT2
  offset: 2, size: 1, access: 
  Filter active
  Field: FACT3
  offset: 3, size: 1, access: 
  Filter active
  Field: FACT4
  offset: 4, size: 1, access: 
  Filter active
  Field: FACT5
  offset: 5, size: 1, access: 
  Filter active
  Field: FACT6
  offset: 6, size: 1, access: 
  Filter active
  Field: FACT7
  offset: 7, size: 1, access: 
  Filter active
  Field: FACT8
  offset: 8, size: 1, access: 
  Filter active
  Field: FACT9
  offset: 9, size: 1, access: 
  Filter active
  Field: FACT10
  offset: 10, size: 1, access: 
  Filter active
  Field: FACT11
  offset: 11, size: 1, access: 
  Filter active
  Field: FACT12
  offset: 12, size: 1, access: 
  Filter active
  Field: FACT13
  offset: 13, size: 1, access: 
  Filter active
  Field: FACT14
  offset: 14, size: 1, access: 
  Filter active
  Field: FACT15
  offset: 15, size: 1, access: 
  Filter active
  Field: FACT16
  offset: 16, size: 1, access: 
  Filter active
  Field: FACT17
  offset: 17, size: 1, access: 
  Filter active
  Field: FACT18
  offset: 18, size: 1, access: 
  Filter active
  Field: FACT19
  offset: 19, size: 1, access: 
  Filter active
  Field: FACT20
  offset: 20, size: 1, access: 
  Filter active
  Field: FACT21
  offset: 21, size: 1, access: 
  Filter active
  Field: FACT22
  offset: 22, size: 1, access: 
  Filter active
  Field: FACT23
  offset: 23, size: 1, access: 
  Filter active
  Field: FACT24
  offset: 24, size: 1, access: 
  Filter active
  Field: FACT25
  offset: 25, size: 1, access: 
  Filter active
  Field: FACT26
  offset: 26, size: 1, access: 
  Filter active
  Field: FACT27
  offset: 27, size: 1, access: 
  Filter active
*/
volatile uint32_t FACT;
volatile uint32_t reserved5[8];

/** F0BANK1 F0BANK1 (offset: 0x240)
  Filter bank 0 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F0BANK1;

/** F0BANK2 F0BANK2 (offset: 0x244)
  Filter bank 0 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F0BANK2;

/** F1BANK1 F1BANK1 (offset: 0x248)
  Filter bank 1 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F1BANK1;

/** F1BANK2 F1BANK2 (offset: 0x24c)
  Filter bank 1 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F1BANK2;

/** F2BANK1 F2BANK1 (offset: 0x250)
  Filter bank 2 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F2BANK1;

/** F2BANK2 F2BANK2 (offset: 0x254)
  Filter bank 2 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F2BANK2;

/** F3BANK1 F3BANK1 (offset: 0x258)
  Filter bank 3 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F3BANK1;

/** F3BANK2 F3BANK2 (offset: 0x25c)
  Filter bank 3 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F3BANK2;

/** F4BANK1 F4BANK1 (offset: 0x260)
  Filter bank 4 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F4BANK1;

/** F4BANK2 F4BANK2 (offset: 0x264)
  Filter bank 4 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F4BANK2;

/** F5BANK1 F5BANK1 (offset: 0x268)
  Filter bank 5 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F5BANK1;

/** F5BANK2 F5BANK2 (offset: 0x26c)
  Filter bank 5 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F5BANK2;

/** F6BANK1 F6BANK1 (offset: 0x270)
  Filter bank 6 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F6BANK1;

/** F6BANK2 F6BANK2 (offset: 0x274)
  Filter bank 6 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F6BANK2;

/** F7BANK1 F7BANK1 (offset: 0x278)
  Filter bank 7 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F7BANK1;

/** F7BANK2 F7BANK2 (offset: 0x27c)
  Filter bank 7 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F7BANK2;

/** F8BANK1 F8BANK1 (offset: 0x280)
  Filter bank 8 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F8BANK1;

/** F8BANK2 F8BANK2 (offset: 0x284)
  Filter bank 8 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F8BANK2;

/** F9BANK1 F9BANK1 (offset: 0x288)
  Filter bank 9 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F9BANK1;

/** F9BANK2 F9BANK2 (offset: 0x28c)
  Filter bank 9 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F9BANK2;

/** F10BANK1 F10BANK1 (offset: 0x290)
  Filter bank 10 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F10BANK1;

/** F10BANK2 F10BANK2 (offset: 0x294)
  Filter bank 10 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F10BANK2;

/** F11BANK1 F11BANK1 (offset: 0x298)
  Filter bank 11 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F11BANK1;

/** F11BANK2 F11BANK2 (offset: 0x29c)
  Filter bank 11 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F11BANK2;

/** F12BANK1 F12BANK1 (offset: 0x2a0)
  Filter bank 12 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F12BANK1;

/** F12BANK2 F12BANK2 (offset: 0x2a4)
  Filter bank 12 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F12BANK2;

/** F13BANK1 F13BANK1 (offset: 0x2a8)
  Filter bank 13 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F13BANK1;

/** F13BANK2 F13BANK2 (offset: 0x2ac)
  Filter bank 13 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F13BANK2;

/** F14BANK1 F14BANK1 (offset: 0x2b0)
  Filter bank 14 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F14BANK1;

/** F14BANK2 F14BANK2 (offset: 0x2b4)
  Filter bank 14 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F14BANK2;

/** F15BANK1 F15BANK1 (offset: 0x2b8)
  Filter bank 15 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F15BANK1;

/** F15BANK2 F15BANK2 (offset: 0x2bc)
  Filter bank 15 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F15BANK2;

/** F16BANK1 F16BANK1 (offset: 0x2c0)
  Filter bank 16 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F16BANK1;

/** F16BANK2 F16BANK2 (offset: 0x2c4)
  Filter bank 16 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F16BANK2;

/** F17BANK1 F17BANK1 (offset: 0x2c8)
  Filter bank 17 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F17BANK1;

/** F17BANK2 F17BANK2 (offset: 0x2cc)
  Filter bank 17 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F17BANK2;

/** F18BANK1 F18BANK1 (offset: 0x2d0)
  Filter bank 18 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F18BANK1;

/** F18BANK2 F18BANK2 (offset: 0x2d4)
  Filter bank 18 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F18BANK2;

/** F19BANK1 F19BANK1 (offset: 0x2d8)
  Filter bank 19 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F19BANK1;

/** F19BANK2 F19BANK2 (offset: 0x2dc)
  Filter bank 19 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F19BANK2;

/** F20BANK1 F20BANK1 (offset: 0x2e0)
  Filter bank 20 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F20BANK1;

/** F20BANK2 F20BANK2 (offset: 0x2e4)
  Filter bank 20 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F20BANK2;

/** F21BANK1 F21BANK1 (offset: 0x2e8)
  Filter bank 21 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F21BANK1;

/** F21BANK2 F21BANK2 (offset: 0x2ec)
  Filter bank 21 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F21BANK2;

/** F22BANK1 F22BANK1 (offset: 0x2f0)
  Filter bank 22 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F22BANK1;

/** F22BANK2 F22BANK2 (offset: 0x2f4)
  Filter bank 22 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F22BANK2;

/** F23BANK1 F23BANK1 (offset: 0x2f8)
  Filter bank 23 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F23BANK1;

/** F23BANK2 F23BANK2 (offset: 0x2fc)
  Filter bank 23 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F23BANK2;

/** F24BANK1 F24BANK1 (offset: 0x300)
  Filter bank 24 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F24BANK1;

/** F24BANK2 F24BANK2 (offset: 0x304)
  Filter bank 24 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F24BANK2;

/** F25BANK1 F25BANK1 (offset: 0x308)
  Filter bank 25 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F25BANK1;

/** F25BANK2 F25BANK2 (offset: 0x30c)
  Filter bank 25 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F25BANK2;

/** F26BANK1 F26BANK1 (offset: 0x310)
  Filter bank 26 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F26BANK1;

/** F26BANK2 F26BANK2 (offset: 0x314)
  Filter bank 26 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F26BANK2;

/** F27BANK1 F27BANK1 (offset: 0x318)
  Filter bank 27 register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F27BANK1;

/** F27BANK2 F27BANK2 (offset: 0x31c)
  Filter bank 27 register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FBIT0
  offset: 0, size: 1, access: 
  Filter bits
  Field: FBIT1
  offset: 1, size: 1, access: 
  Filter bits
  Field: FBIT2
  offset: 2, size: 1, access: 
  Filter bits
  Field: FBIT3
  offset: 3, size: 1, access: 
  Filter bits
  Field: FBIT4
  offset: 4, size: 1, access: 
  Filter bits
  Field: FBIT5
  offset: 5, size: 1, access: 
  Filter bits
  Field: FBIT6
  offset: 6, size: 1, access: 
  Filter bits
  Field: FBIT7
  offset: 7, size: 1, access: 
  Filter bits
  Field: FBIT8
  offset: 8, size: 1, access: 
  Filter bits
  Field: FBIT9
  offset: 9, size: 1, access: 
  Filter bits
  Field: FBIT10
  offset: 10, size: 1, access: 
  Filter bits
  Field: FBIT11
  offset: 11, size: 1, access: 
  Filter bits
  Field: FBIT12
  offset: 12, size: 1, access: 
  Filter bits
  Field: FBIT13
  offset: 13, size: 1, access: 
  Filter bits
  Field: FBIT14
  offset: 14, size: 1, access: 
  Filter bits
  Field: FBIT15
  offset: 15, size: 1, access: 
  Filter bits
  Field: FBIT16
  offset: 16, size: 1, access: 
  Filter bits
  Field: FBIT17
  offset: 17, size: 1, access: 
  Filter bits
  Field: FBIT18
  offset: 18, size: 1, access: 
  Filter bits
  Field: FBIT19
  offset: 19, size: 1, access: 
  Filter bits
  Field: FBIT20
  offset: 20, size: 1, access: 
  Filter bits
  Field: FBIT21
  offset: 21, size: 1, access: 
  Filter bits
  Field: FBIT22
  offset: 22, size: 1, access: 
  Filter bits
  Field: FBIT23
  offset: 23, size: 1, access: 
  Filter bits
  Field: FBIT24
  offset: 24, size: 1, access: 
  Filter bits
  Field: FBIT25
  offset: 25, size: 1, access: 
  Filter bits
  Field: FBIT26
  offset: 26, size: 1, access: 
  Filter bits
  Field: FBIT27
  offset: 27, size: 1, access: 
  Filter bits
  Field: FBIT28
  offset: 28, size: 1, access: 
  Filter bits
  Field: FBIT29
  offset: 29, size: 1, access: 
  Filter bits
  Field: FBIT30
  offset: 30, size: 1, access: 
  Filter bits
  Field: FBIT31
  offset: 31, size: 1, access: 
  Filter bits
*/
volatile uint32_t F27BANK2;
} CAN2_type;

#define CAN2 ((CAN2_type *) 0x40006800)

#endif // HW_CAN2_H
