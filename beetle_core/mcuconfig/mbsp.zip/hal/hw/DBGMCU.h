#ifndef HW_DBGMCU_H
#define HW_DBGMCU_H
/** Debug support */
/** Memory Block starting at 0xE0042000 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define DBGMCU_IDCODE_EQR_OFFSET                           0
#define DBGMCU_IDCODE_EQR_MASK                             0xfff

#define DBGMCU_IDCODE_WVR_OFFSET                           16
#define DBGMCU_IDCODE_WVR_MASK                             0xffff0000

#define DBGMCU_CFG_SLEEP_CLK_STS_OFFSET                    0
#define DBGMCU_CFG_SLEEP_CLK_STS_MASK                      1

#define DBGMCU_CFG_STOP_CLK_STS_OFFSET                     1
#define DBGMCU_CFG_STOP_CLK_STS_MASK                       2

#define DBGMCU_CFG_STANDBY_CLK_STS_OFFSET                  2
#define DBGMCU_CFG_STANDBY_CLK_STS_MASK                    4

#define DBGMCU_CFG_TRACE_IOEN_OFFSET                       5
#define DBGMCU_CFG_TRACE_IOEN_MASK                         0x20

#define DBGMCU_CFG_TRACE_MODE_OFFSET                       6
#define DBGMCU_CFG_TRACE_MODE_MASK                         0xc0

#define DBGMCU_APB1F_TMR2_STS_OFFSET                       0
#define DBGMCU_APB1F_TMR2_STS_MASK                         1

#define DBGMCU_APB1F_TMR3_STS_OFFSET                       1
#define DBGMCU_APB1F_TMR3_STS_MASK                         2

#define DBGMCU_APB1F_TMR4_STS_OFFSET                       2
#define DBGMCU_APB1F_TMR4_STS_MASK                         4

#define DBGMCU_APB1F_TMR5_STS_OFFSET                       3
#define DBGMCU_APB1F_TMR5_STS_MASK                         8

#define DBGMCU_APB1F_TMR12_STS_OFFSET                      6
#define DBGMCU_APB1F_TMR12_STS_MASK                        0x40

#define DBGMCU_APB1F_TMR13_STS_OFFSET                      7
#define DBGMCU_APB1F_TMR13_STS_MASK                        0x80

#define DBGMCU_APB1F_TMR14_STS_OFFSET                      8
#define DBGMCU_APB1F_TMR14_STS_MASK                        0x100

#define DBGMCU_APB1F_RTC_STS_OFFSET                        11
#define DBGMCU_APB1F_RTC_STS_MASK                          0x800

#define DBGMCU_APB1F_WWDT_STS_OFFSET                       12
#define DBGMCU_APB1F_WWDT_STS_MASK                         0x1000

#define DBGMCU_APB1F_IWDT_STS_OFFSET                       21
#define DBGMCU_APB1F_IWDT_STS_MASK                         0x200000

#define DBGMCU_APB1F_I2C1_SMBUS_TIMEOUT_STS_OFFSET         22
#define DBGMCU_APB1F_I2C1_SMBUS_TIMEOUT_STS_MASK           0x400000

#define DBGMCU_APB1F_I2C2_SMBUS_TIMEOUT_STS_OFFSET         23
#define DBGMCU_APB1F_I2C2_SMBUS_TIMEOUT_STS_MASK           0x800000

#define DBGMCU_APB1F_I2C3_SMBUS_TIMEOUT_STS_OFFSET         25
#define DBGMCU_APB1F_I2C3_SMBUS_TIMEOUT_STS_MASK           0x2000000

#define DBGMCU_APB1F_CAN1_STS_OFFSET                       26
#define DBGMCU_APB1F_CAN1_STS_MASK                         0x4000000

#define DBGMCU_APB1F_CAN2_STS_OFFSET                       27
#define DBGMCU_APB1F_CAN2_STS_MASK                         0x8000000

#define DBGMCU_APB2F_TMR1_STS_OFFSET                       0
#define DBGMCU_APB2F_TMR1_STS_MASK                         1

#define DBGMCU_APB2F_TMR8_STS_OFFSET                       1
#define DBGMCU_APB2F_TMR8_STS_MASK                         2

#define DBGMCU_APB2F_TMR9_STS_OFFSET                       16
#define DBGMCU_APB2F_TMR9_STS_MASK                         0x10000

#define DBGMCU_APB2F_TMR10_STS_OFFSET                      17
#define DBGMCU_APB2F_TMR10_STS_MASK                        0x20000

#define DBGMCU_APB2F_TMR11_STS_OFFSET                      18
#define DBGMCU_APB2F_TMR11_STS_MASK                        0x40000


typedef struct
{

/** IDCODE IDCODE (offset: 0x0)
  IDCODE
  access : read-only
  reset value : 0x10006411
  reset mask : 0xFFFFFFFF
  Field: EQR
  offset: 0, size: 12, access: 
  Equipment Recognition
  Field: WVR
  offset: 16, size: 16, access: 
  Wafer Version Recognition
*/
volatile uint32_t IDCODE;

/** CFG CFG (offset: 0x4)
  Control Register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SLEEP_CLK_STS
  offset: 0, size: 1, access: 
  Configure clock status when MCU is debugged in sleep mode
  Field: STOP_CLK_STS
  offset: 1, size: 1, access: 
  Configure clock status when MCU is debugged in stop mode
  Field: STANDBY_CLK_STS
  offset: 2, size: 1, access: 
  Configure clock status when MCU is debugged in standby mode
  Field: TRACE_IOEN
  offset: 5, size: 1, access: 
  Trace Debug Pin Enable
  Field: TRACE_MODE
  offset: 6, size: 2, access: 
  Trace Debug Pin Mode Configure
*/
volatile uint32_t CFG;

/** APB1F APB1F (offset: 0x8)
  Debug MCU APB1 Freeze registe
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TMR2_STS
  offset: 0, size: 1, access: 
  TMR2 counter stopped when core is halted
  Field: TMR3_STS
  offset: 1, size: 1, access: 
  TMR3 counter stopped when core is halted
  Field: TMR4_STS
  offset: 2, size: 1, access: 
  TMR4 counter stopped when core is halted
  Field: TMR5_STS
  offset: 3, size: 1, access: 
  TMR5 counter stopped when core is halted
  Field: TMR12_STS
  offset: 6, size: 1, access: 
  TMR12 counter stopped when core is halted
  Field: TMR13_STS
  offset: 7, size: 1, access: 
  TMR13 counter stopped when core is halted
  Field: TMR14_STS
  offset: 8, size: 1, access: 
  TMR14 counter stopped when core is halted
  Field: RTC_STS
  offset: 11, size: 1, access: 
  RTC counter stopped when core is halted
  Field: WWDT_STS
  offset: 12, size: 1, access: 
  WWDT counter stopped when core is halted
  Field: IWDT_STS
  offset: 21, size: 1, access: 
  IWDT counter stopped when core is halted
  Field: I2C1_SMBUS_TIMEOUT_STS
  offset: 22, size: 1, access: 
  I2C1_SMBUS_TIMEOUT_STS
  Field: I2C2_SMBUS_TIMEOUT_STS
  offset: 23, size: 1, access: 
  I2C2_SMBUS_TIMEOUT_STS
  Field: I2C3_SMBUS_TIMEOUT_STS
  offset: 25, size: 1, access: 
  I2C3_SMBUS_TIMEOUT_STS
  Field: CAN1_STS
  offset: 26, size: 1, access: 
  CAN1 counter stopped when core is halted
  Field: CAN2_STS
  offset: 27, size: 1, access: 
  CAN2 counter stopped when core is halted
*/
volatile uint32_t APB1F;

/** APB2F APB2F (offset: 0xc)
  Debug MCU APB2 Freeze registe
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TMR1_STS
  offset: 0, size: 1, access: 
  TMR1 counter stopped when core is halted
  Field: TMR8_STS
  offset: 1, size: 1, access: 
  TMR8 counter stopped when core is halted
  Field: TMR9_STS
  offset: 16, size: 1, access: 
  TMR9 counter stopped when core is halted
  Field: TMR10_STS
  offset: 17, size: 1, access: 
  TMR10 counter stopped when core is halted
  Field: TMR11_STS
  offset: 18, size: 1, access: 
  TMR11 counter stopped when core is halted
*/
volatile uint32_t APB2F;
} DBGMCU_type;

#define DBGMCU ((DBGMCU_type *) 0xE0042000)

#endif // HW_DBGMCU_H
