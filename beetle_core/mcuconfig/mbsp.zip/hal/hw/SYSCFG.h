#ifndef HW_SYSCFG_H
#define HW_SYSCFG_H
/** System configuration controller */
/** Memory Block starting at 0x40013800 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define SYSCFG_MMSEL_MMSEL_OFFSET                          0
#define SYSCFG_MMSEL_MMSEL_MASK                            3

#define SYSCFG_PMCFG_ADCX02EN_OFFSET                       16
#define SYSCFG_PMCFG_ADCX02EN_MASK                         0x10000

#define SYSCFG_EINTCFG1_EINT3_OFFSET                       12
#define SYSCFG_EINTCFG1_EINT3_MASK                         0xf000

#define SYSCFG_EINTCFG1_EINT2_OFFSET                       8
#define SYSCFG_EINTCFG1_EINT2_MASK                         0xf00

#define SYSCFG_EINTCFG1_EINT1_OFFSET                       4
#define SYSCFG_EINTCFG1_EINT1_MASK                         0xf0

#define SYSCFG_EINTCFG1_EINT0_OFFSET                       0
#define SYSCFG_EINTCFG1_EINT0_MASK                         0xf

#define SYSCFG_EINTCFG2_EINT7_OFFSET                       12
#define SYSCFG_EINTCFG2_EINT7_MASK                         0xf000

#define SYSCFG_EINTCFG2_EINT6_OFFSET                       8
#define SYSCFG_EINTCFG2_EINT6_MASK                         0xf00

#define SYSCFG_EINTCFG2_EINT5_OFFSET                       4
#define SYSCFG_EINTCFG2_EINT5_MASK                         0xf0

#define SYSCFG_EINTCFG2_EINT4_OFFSET                       0
#define SYSCFG_EINTCFG2_EINT4_MASK                         0xf

#define SYSCFG_EINTCFG3_EINT11_OFFSET                      12
#define SYSCFG_EINTCFG3_EINT11_MASK                        0xf000

#define SYSCFG_EINTCFG3_EINT10_OFFSET                      8
#define SYSCFG_EINTCFG3_EINT10_MASK                        0xf00

#define SYSCFG_EINTCFG3_EINT9_OFFSET                       4
#define SYSCFG_EINTCFG3_EINT9_MASK                         0xf0

#define SYSCFG_EINTCFG3_EINT8_OFFSET                       0
#define SYSCFG_EINTCFG3_EINT8_MASK                         0xf

#define SYSCFG_EINTCFG4_ENET15_OFFSET                      12
#define SYSCFG_EINTCFG4_ENET15_MASK                        0xf000

#define SYSCFG_EINTCFG4_ENET14_OFFSET                      8
#define SYSCFG_EINTCFG4_ENET14_MASK                        0xf00

#define SYSCFG_EINTCFG4_ENET13_OFFSET                      4
#define SYSCFG_EINTCFG4_ENET13_MASK                        0xf0

#define SYSCFG_EINTCFG4_ENET12_OFFSET                      0
#define SYSCFG_EINTCFG4_ENET12_MASK                        0xf

#define SYSCFG_CCCTRL_EDYFLG_OFFSET                        8
#define SYSCFG_CCCTRL_EDYFLG_MASK                          0x100

#define SYSCFG_CCCTRL_CCPD_OFFSET                          0
#define SYSCFG_CCCTRL_CCPD_MASK                            1


typedef struct
{

/** MMSEL MMSEL (offset: 0x0)
  memory remap register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MMSEL
  offset: 0, size: 2, access: 
  Memory Mapping Select
*/
volatile uint32_t MMSEL;

/** PMCFG PMCFG (offset: 0x4)
  peripheral mode configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ADCx02EN
  offset: 16, size: 1, access: 
  ADCx Option 2 Enable
*/
volatile uint32_t PMCFG;

/** EINTCFG1 EINTCFG1 (offset: 0x8)
  external interrupt configuration register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EINT3
  offset: 12, size: 4, access: 
  EINTx Configure
  Field: EINT2
  offset: 8, size: 4, access: 
  EINTx Configure
  Field: EINT1
  offset: 4, size: 4, access: 
  EINTx Configure
  Field: EINT0
  offset: 0, size: 4, access: 
  EINTx Configure
*/
volatile uint32_t EINTCFG1;

/** EINTCFG2 EINTCFG2 (offset: 0xc)
  external interrupt configuration register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EINT7
  offset: 12, size: 4, access: 
  EINTx Configure
  Field: EINT6
  offset: 8, size: 4, access: 
  EINTx Configure
  Field: EINT5
  offset: 4, size: 4, access: 
  EINTx Configure
  Field: EINT4
  offset: 0, size: 4, access: 
  EINTx Configure
*/
volatile uint32_t EINTCFG2;

/** EINTCFG3 EINTCFG3 (offset: 0x10)
  external interrupt configuration register 3
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EINT11
  offset: 12, size: 4, access: 
  EINTx Configure
  Field: EINT10
  offset: 8, size: 4, access: 
  EINTx Configure
  Field: EINT9
  offset: 4, size: 4, access: 
  EINTx Configure
  Field: EINT8
  offset: 0, size: 4, access: 
  EINTx Configure
*/
volatile uint32_t EINTCFG3;

/** EINTCFG4 EINTCFG4 (offset: 0x14)
  external interrupt configuration register 4
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ENET15
  offset: 12, size: 4, access: 
  EINTx Configure
  Field: ENET14
  offset: 8, size: 4, access: 
  EINTx Configure
  Field: ENET13
  offset: 4, size: 4, access: 
  EINTx Configure
  Field: ENET12
  offset: 0, size: 4, access: 
  EINTx Configure
*/
volatile uint32_t EINTCFG4;
volatile uint32_t reserved0[2];

/** CCCTRL CCCTRL (offset: 0x20)
  Compensation cell control register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: EDYFLG
  offset: 8, size: 1, access: read-only
  Compensation Cell Ready Flag
  Field: CCPD
  offset: 0, size: 1, access: read-write
  Compensation Cell Power-down
*/
volatile uint32_t CCCTRL;
} SYSCFG_type;

#define SYSCFG ((SYSCFG_type *) 0x40013800)

#endif // HW_SYSCFG_H
