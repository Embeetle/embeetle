#ifndef HW_RNG_H
#define HW_RNG_H
/** Random number generator */
/** Interrupt : HASH_RNG (Vector: 80) Rng global interrupt */
/** Interrupt : FPU (Vector: 81) FPU interrupt */
/** Memory Block starting at 0x50060800 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define RNG_CTRL_INTEN_OFFSET                              3
#define RNG_CTRL_INTEN_MASK                                8

#define RNG_CTRL_RNGEN_OFFSET                              2
#define RNG_CTRL_RNGEN_MASK                                4

#define RNG_STS_FSINT_OFFSET                               6
#define RNG_STS_FSINT_MASK                                 0x40

#define RNG_STS_CLKERINT_OFFSET                            5
#define RNG_STS_CLKERINT_MASK                              0x20

#define RNG_STS_FSCSTS_OFFSET                              2
#define RNG_STS_FSCSTS_MASK                                4

#define RNG_STS_CLKERCSTS_OFFSET                           1
#define RNG_STS_CLKERCSTS_MASK                             2

#define RNG_STS_DATARDY_OFFSET                             0
#define RNG_STS_DATARDY_MASK                               1

#define RNG_DATA_DATA_OFFSET                               0
#define RNG_DATA_DATA_MASK                                 0xffffffff


typedef struct
{

/** CTRL CTRL (offset: 0x0)
  control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: INTEN
  offset: 3, size: 1, access: 
  Interrupt enable
  Field: RNGEN
  offset: 2, size: 1, access: 
  Random number generator enable
*/
volatile uint32_t CTRL;

/** STS STS (offset: 0x4)
  status register
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: FSINT
  offset: 6, size: 1, access: read-write
  Seed error interrupt status
  Field: CLKERINT
  offset: 5, size: 1, access: read-write
  Clock error interrupt status
  Field: FSCSTS
  offset: 2, size: 1, access: read-only
  Seed error current status
  Field: CLKERCSTS
  offset: 1, size: 1, access: read-only
  Clock error current status
  Field: DATARDY
  offset: 0, size: 1, access: read-only
  Data ready
*/
volatile uint32_t STS;

/** DATA DATA (offset: 0x8)
  data register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATA
  offset: 0, size: 32, access: 
  Random data
*/
volatile uint32_t DATA;
} RNG_type;

#define RNG ((RNG_type *) 0x50060800)

#endif // HW_RNG_H
