#ifndef HW_TMR12_H
#define HW_TMR12_H
/** General purpose timers */
/** Interrupt : TMR8_BRK_TMR12 (Vector: 43) TMR8 Break interrupt and TMR12 global interrupt */
/** Memory Block starting at 0x40001800 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define TMR12_CTRL1_CLKDIV_OFFSET                          8
#define TMR12_CTRL1_CLKDIV_MASK                            0x300

#define TMR12_CTRL1_ARPEN_OFFSET                           7
#define TMR12_CTRL1_ARPEN_MASK                             0x80

#define TMR12_CTRL1_SPMEN_OFFSET                           3
#define TMR12_CTRL1_SPMEN_MASK                             8

#define TMR12_CTRL1_URSSEL_OFFSET                          2
#define TMR12_CTRL1_URSSEL_MASK                            4

#define TMR12_CTRL1_UD_OFFSET                              1
#define TMR12_CTRL1_UD_MASK                                2

#define TMR12_CTRL1_CNTEN_OFFSET                           0
#define TMR12_CTRL1_CNTEN_MASK                             1

#define TMR12_SMCTRL_MSMEN_OFFSET                          7
#define TMR12_SMCTRL_MSMEN_MASK                            0x80

#define TMR12_SMCTRL_TRGSEL_OFFSET                         4
#define TMR12_SMCTRL_TRGSEL_MASK                           0x70

#define TMR12_SMCTRL_SMFSEL_OFFSET                         0
#define TMR12_SMCTRL_SMFSEL_MASK                           7

#define TMR12_DIEN_TRGIEN_OFFSET                           6
#define TMR12_DIEN_TRGIEN_MASK                             0x40

#define TMR12_DIEN_CC2IEN_OFFSET                           2
#define TMR12_DIEN_CC2IEN_MASK                             4

#define TMR12_DIEN_CC1IEN_OFFSET                           1
#define TMR12_DIEN_CC1IEN_MASK                             2

#define TMR12_DIEN_UIEN_OFFSET                             0
#define TMR12_DIEN_UIEN_MASK                               1

#define TMR12_STS_CC2RCFLG_OFFSET                          10
#define TMR12_STS_CC2RCFLG_MASK                            0x400

#define TMR12_STS_CC1RCFLG_OFFSET                          9
#define TMR12_STS_CC1RCFLG_MASK                            0x200

#define TMR12_STS_TRGIFLG_OFFSET                           6
#define TMR12_STS_TRGIFLG_MASK                             0x40

#define TMR12_STS_CC2IFLG_OFFSET                           2
#define TMR12_STS_CC2IFLG_MASK                             4

#define TMR12_STS_CC1IFLG_OFFSET                           1
#define TMR12_STS_CC1IFLG_MASK                             2

#define TMR12_STS_UIFLG_OFFSET                             0
#define TMR12_STS_UIFLG_MASK                               1

#define TMR12_CEG_TEG_OFFSET                               6
#define TMR12_CEG_TEG_MASK                                 0x40

#define TMR12_CEG_CC2EG_OFFSET                             2
#define TMR12_CEG_CC2EG_MASK                               4

#define TMR12_CEG_CC1EG_OFFSET                             1
#define TMR12_CEG_CC1EG_MASK                               2

#define TMR12_CEG_UEG_OFFSET                               0
#define TMR12_CEG_UEG_MASK                                 1

#define TMR12_CCM1_COMPARE_OC2MOD_OFFSET                   12
#define TMR12_CCM1_COMPARE_OC2MOD_MASK                     0x7000

#define TMR12_CCM1_COMPARE_OC2PEN_OFFSET                   11
#define TMR12_CCM1_COMPARE_OC2PEN_MASK                     0x800

#define TMR12_CCM1_COMPARE_OC2FEN_OFFSET                   10
#define TMR12_CCM1_COMPARE_OC2FEN_MASK                     0x400

#define TMR12_CCM1_COMPARE_CC2SEL_OFFSET                   8
#define TMR12_CCM1_COMPARE_CC2SEL_MASK                     0x300

#define TMR12_CCM1_COMPARE_OC1MOD_OFFSET                   4
#define TMR12_CCM1_COMPARE_OC1MOD_MASK                     0x70

#define TMR12_CCM1_COMPARE_OC1PEN_OFFSET                   3
#define TMR12_CCM1_COMPARE_OC1PEN_MASK                     8

#define TMR12_CCM1_COMPARE_OC1FEN_OFFSET                   2
#define TMR12_CCM1_COMPARE_OC1FEN_MASK                     4

#define TMR12_CCM1_COMPARE_CC1SEL_OFFSET                   0
#define TMR12_CCM1_COMPARE_CC1SEL_MASK                     3

#define TMR12_CCEN_CC2NPOL_OFFSET                          7
#define TMR12_CCEN_CC2NPOL_MASK                            0x80

#define TMR12_CCEN_CC2POL_OFFSET                           5
#define TMR12_CCEN_CC2POL_MASK                             0x20

#define TMR12_CCEN_CC2EN_OFFSET                            4
#define TMR12_CCEN_CC2EN_MASK                              0x10

#define TMR12_CCEN_CC1NPOL_OFFSET                          3
#define TMR12_CCEN_CC1NPOL_MASK                            8

#define TMR12_CCEN_CC1POL_OFFSET                           1
#define TMR12_CCEN_CC1POL_MASK                             2

#define TMR12_CCEN_CC1EN_OFFSET                            0
#define TMR12_CCEN_CC1EN_MASK                              1

#define TMR12_CNT_CNT_OFFSET                               0
#define TMR12_CNT_CNT_MASK                                 0xffff

#define TMR12_PSC_PSC_OFFSET                               0
#define TMR12_PSC_PSC_MASK                                 0xffff

#define TMR12_AUTORLD_AUTORLD_OFFSET                       0
#define TMR12_AUTORLD_AUTORLD_MASK                         0xffff

#define TMR12_CC1_CC1_OFFSET                               0
#define TMR12_CC1_CC1_MASK                                 0xffff

#define TMR12_CC2_CC2_OFFSET                               0
#define TMR12_CC2_CC2_MASK                                 0xffff


typedef struct
{

/** CTRL1 CTRL1 (offset: 0x0)
  control register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CLKDIV
  offset: 8, size: 2, access: 
  Clock division
  Field: ARPEN
  offset: 7, size: 1, access: 
  Auto-reload preload enable
  Field: SPMEN
  offset: 3, size: 1, access: 
  One-pulse mode
  Field: URSSEL
  offset: 2, size: 1, access: 
  Update request source
  Field: UD
  offset: 1, size: 1, access: 
  Update disable
  Field: CNTEN
  offset: 0, size: 1, access: 
  Counter enable
*/
volatile uint32_t CTRL1;
volatile uint32_t reserved0;

/** SMCTRL SMCTRL (offset: 0x8)
  slave mode control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MSMEN
  offset: 7, size: 1, access: 
  Master/Slave mode
  Field: TRGSEL
  offset: 4, size: 3, access: 
  Trigger selection
  Field: SMFSEL
  offset: 0, size: 3, access: 
  Slave mode selection
*/
volatile uint32_t SMCTRL;

/** DIEN DIEN (offset: 0xc)
  DMA/Interrupt enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TRGIEN
  offset: 6, size: 1, access: 
  Trigger interrupt enable
  Field: CC2IEN
  offset: 2, size: 1, access: 
  Capture/Compare 2 interrupt enable
  Field: CC1IEN
  offset: 1, size: 1, access: 
  Capture/Compare 1 interrupt enable
  Field: UIEN
  offset: 0, size: 1, access: 
  Update interrupt enable
*/
volatile uint32_t DIEN;

/** STS STS (offset: 0x10)
  status register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC2RCFLG
  offset: 10, size: 1, access: 
  Capture/compare 2 overcapture flag
  Field: CC1RCFLG
  offset: 9, size: 1, access: 
  Capture/Compare 1 overcapture flag
  Field: TRGIFLG
  offset: 6, size: 1, access: 
  Trigger interrupt flag
  Field: CC2IFLG
  offset: 2, size: 1, access: 
  Capture/Compare 2 interrupt flag
  Field: CC1IFLG
  offset: 1, size: 1, access: 
  Capture/compare 1 interrupt flag
  Field: UIFLG
  offset: 0, size: 1, access: 
  Update interrupt flag
*/
volatile uint32_t STS;

/** CEG CEG (offset: 0x14)
  control event generation register
  access : write-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TEG
  offset: 6, size: 1, access: 
  Trigger generation
  Field: CC2EG
  offset: 2, size: 1, access: 
  Capture/compare 2 generation
  Field: CC1EG
  offset: 1, size: 1, access: 
  Capture/compare 1 generation
  Field: UEG
  offset: 0, size: 1, access: 
  Update generation
*/
volatile uint32_t CEG;

/** CCM1_COMPARE CCM1_COMPARE (offset: 0x18)
  capture/compare mode register 1 (output mode)
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OC2MOD
  offset: 12, size: 3, access: 
  Output Compare 2 mode
  Field: OC2PEN
  offset: 11, size: 1, access: 
  Output Compare 2 preload enable
  Field: OC2FEN
  offset: 10, size: 1, access: 
  Output Compare 2 fast enable
  Field: CC2SEL
  offset: 8, size: 2, access: 
  Capture/Compare 2 selection
  Field: OC1MOD
  offset: 4, size: 3, access: 
  Output Compare 1 mode
  Field: OC1PEN
  offset: 3, size: 1, access: 
  Output Compare 1 preload enable
  Field: OC1FEN
  offset: 2, size: 1, access: 
  Output Compare 1 fast enable
  Field: CC1SEL
  offset: 0, size: 2, access: 
  Capture/Compare 1 selection
*/
volatile uint32_t CCM1_COMPARE;
volatile uint32_t reserved1;

/** CCEN CCEN (offset: 0x20)
  capture/compare enable register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC2NPOL
  offset: 7, size: 1, access: 
  Capture/Compare 2 output Polarity
  Field: CC2POL
  offset: 5, size: 1, access: 
  Capture/Compare 2 output Polarity
  Field: CC2EN
  offset: 4, size: 1, access: 
  Capture/Compare 2 output enable
  Field: CC1NPOL
  offset: 3, size: 1, access: 
  Capture/Compare 1 output Polarity
  Field: CC1POL
  offset: 1, size: 1, access: 
  Capture/Compare 1 output Polarity
  Field: CC1EN
  offset: 0, size: 1, access: 
  Capture/Compare 1 output enable
*/
volatile uint32_t CCEN;

/** CNT CNT (offset: 0x24)
  counter
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CNT
  offset: 0, size: 16, access: 
  counter value
*/
volatile uint32_t CNT;

/** PSC PSC (offset: 0x28)
  prescaler
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PSC
  offset: 0, size: 16, access: 
  Prescaler value
*/
volatile uint32_t PSC;

/** AUTORLD AUTORLD (offset: 0x2c)
  auto-reload register
  access : read-write
  reset value : 0xFFFF
  reset mask : 0xFFFFFFFF
  Field: AUTORLD
  offset: 0, size: 16, access: 
  Auto-reload value
*/
volatile uint32_t AUTORLD;
volatile uint32_t reserved2;

/** CC1 CC1 (offset: 0x34)
  capture/compare register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC1
  offset: 0, size: 16, access: 
  Capture/Compare 1 value
*/
volatile uint32_t CC1;

/** CC2 CC2 (offset: 0x38)
  capture/compare register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CC2
  offset: 0, size: 16, access: 
  Capture/Compare 2 value
*/
volatile uint32_t CC2;
} TMR12_type;

#define TMR12 ((TMR12_type *) 0x40001800)

#endif // HW_TMR12_H
