#ifndef HW_RTC_H
#define HW_RTC_H
/** Real-time clock */
/** Interrupt : RTC_WKUP (Vector: 3) RTC Wakeup interrupt through the EINT line 22 */
/** Interrupt : RTC_Alarm (Vector: 41) RTC Alarms (A and B) through EINT line 17 interrupt */
/** Memory Block starting at 0x40002800 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define RTC_TIME_TIMEFCFG_OFFSET                           22
#define RTC_TIME_TIMEFCFG_MASK                             0x400000

#define RTC_TIME_HRT_OFFSET                                20
#define RTC_TIME_HRT_MASK                                  0x300000

#define RTC_TIME_HRU_OFFSET                                16
#define RTC_TIME_HRU_MASK                                  0xf0000

#define RTC_TIME_MINT_OFFSET                               12
#define RTC_TIME_MINT_MASK                                 0x7000

#define RTC_TIME_MINU_OFFSET                               8
#define RTC_TIME_MINU_MASK                                 0xf00

#define RTC_TIME_SECT_OFFSET                               4
#define RTC_TIME_SECT_MASK                                 0x70

#define RTC_TIME_SECU_OFFSET                               0
#define RTC_TIME_SECU_MASK                                 0xf

#define RTC_DATE_YRT_OFFSET                                20
#define RTC_DATE_YRT_MASK                                  0xf00000

#define RTC_DATE_YRU_OFFSET                                16
#define RTC_DATE_YRU_MASK                                  0xf0000

#define RTC_DATE_WEEKSEL_OFFSET                            13
#define RTC_DATE_WEEKSEL_MASK                              0xe000

#define RTC_DATE_MONT_OFFSET                               12
#define RTC_DATE_MONT_MASK                                 0x1000

#define RTC_DATE_MONU_OFFSET                               8
#define RTC_DATE_MONU_MASK                                 0xf00

#define RTC_DATE_DAYT_OFFSET                               4
#define RTC_DATE_DAYT_MASK                                 0x30

#define RTC_DATE_DAYU_OFFSET                               0
#define RTC_DATE_DAYU_MASK                                 0xf

#define RTC_CTRL_CALOEN_OFFSET                             23
#define RTC_CTRL_CALOEN_MASK                               0x800000

#define RTC_CTRL_OUTSEL_OFFSET                             21
#define RTC_CTRL_OUTSEL_MASK                               0x600000

#define RTC_CTRL_POLCFG_OFFSET                             20
#define RTC_CTRL_POLCFG_MASK                               0x100000

#define RTC_CTRL_CALOSEL_OFFSET                            19
#define RTC_CTRL_CALOSEL_MASK                              0x80000

#define RTC_CTRL_BAKP_OFFSET                               18
#define RTC_CTRL_BAKP_MASK                                 0x40000

#define RTC_CTRL_WTCCFG_OFFSET                             17
#define RTC_CTRL_WTCCFG_MASK                               0x20000

#define RTC_CTRL_STCCFG_OFFSET                             16
#define RTC_CTRL_STCCFG_MASK                               0x10000

#define RTC_CTRL_TSIEN_OFFSET                              15
#define RTC_CTRL_TSIEN_MASK                                0x8000

#define RTC_CTRL_WUTIEN_OFFSET                             14
#define RTC_CTRL_WUTIEN_MASK                               0x4000

#define RTC_CTRL_ALRBIEN_OFFSET                            13
#define RTC_CTRL_ALRBIEN_MASK                              0x2000

#define RTC_CTRL_ALRAIEN_OFFSET                            12
#define RTC_CTRL_ALRAIEN_MASK                              0x1000

#define RTC_CTRL_TSEN_OFFSET                               11
#define RTC_CTRL_TSEN_MASK                                 0x800

#define RTC_CTRL_WUTEN_OFFSET                              10
#define RTC_CTRL_WUTEN_MASK                                0x400

#define RTC_CTRL_ALRBEN_OFFSET                             9
#define RTC_CTRL_ALRBEN_MASK                               0x200

#define RTC_CTRL_ALRAEN_OFFSET                             8
#define RTC_CTRL_ALRAEN_MASK                               0x100

#define RTC_CTRL_DCALEN_OFFSET                             7
#define RTC_CTRL_DCALEN_MASK                               0x80

#define RTC_CTRL_TIMEFCFG_OFFSET                           6
#define RTC_CTRL_TIMEFCFG_MASK                             0x40

#define RTC_CTRL_RCMCFG_OFFSET                             5
#define RTC_CTRL_RCMCFG_MASK                               0x20

#define RTC_CTRL_RCLKDEN_OFFSET                            4
#define RTC_CTRL_RCLKDEN_MASK                              0x10

#define RTC_CTRL_TSETECFG_OFFSET                           3
#define RTC_CTRL_TSETECFG_MASK                             8

#define RTC_CTRL_WUCLKSEL_OFFSET                           0
#define RTC_CTRL_WUCLKSEL_MASK                             7

#define RTC_STS_ALRAWFLG_OFFSET                            0
#define RTC_STS_ALRAWFLG_MASK                              1

#define RTC_STS_ALRBWFLG_OFFSET                            1
#define RTC_STS_ALRBWFLG_MASK                              2

#define RTC_STS_WUTWFLG_OFFSET                             2
#define RTC_STS_WUTWFLG_MASK                               4

#define RTC_STS_SOPFLG_OFFSET                              3
#define RTC_STS_SOPFLG_MASK                                8

#define RTC_STS_INITSFLG_OFFSET                            4
#define RTC_STS_INITSFLG_MASK                              0x10

#define RTC_STS_RSFLG_OFFSET                               5
#define RTC_STS_RSFLG_MASK                                 0x20

#define RTC_STS_RINITFLG_OFFSET                            6
#define RTC_STS_RINITFLG_MASK                              0x40

#define RTC_STS_INITEN_OFFSET                              7
#define RTC_STS_INITEN_MASK                                0x80

#define RTC_STS_ALRAFLG_OFFSET                             8
#define RTC_STS_ALRAFLG_MASK                               0x100

#define RTC_STS_ALRBFLG_OFFSET                             9
#define RTC_STS_ALRBFLG_MASK                               0x200

#define RTC_STS_WUTFLG_OFFSET                              10
#define RTC_STS_WUTFLG_MASK                                0x400

#define RTC_STS_TSFLG_OFFSET                               11
#define RTC_STS_TSFLG_MASK                                 0x800

#define RTC_STS_TSOVRFLG_OFFSET                            12
#define RTC_STS_TSOVRFLG_MASK                              0x1000

#define RTC_STS_TP1FLG_OFFSET                              13
#define RTC_STS_TP1FLG_MASK                                0x2000

#define RTC_STS_RCALPFLG_OFFSET                            16
#define RTC_STS_RCALPFLG_MASK                              0x10000

#define RTC_PSC_APSC_OFFSET                                16
#define RTC_PSC_APSC_MASK                                  0x7f0000

#define RTC_PSC_SPSC_OFFSET                                0
#define RTC_PSC_SPSC_MASK                                  0x7fff

#define RTC_AUTORLD_WUAUTORE_OFFSET                        0
#define RTC_AUTORLD_WUAUTORE_MASK                          0xffff

#define RTC_DCAL_DCALCFG_OFFSET                            7
#define RTC_DCAL_DCALCFG_MASK                              0x80

#define RTC_DCAL_DCAL_OFFSET                               0
#define RTC_DCAL_DCAL_MASK                                 0x1f

#define RTC_ALRMA_DATEMEN_OFFSET                           31
#define RTC_ALRMA_DATEMEN_MASK                             0x80000000

#define RTC_ALRMA_WEEKSEL_OFFSET                           30
#define RTC_ALRMA_WEEKSEL_MASK                             0x40000000

#define RTC_ALRMA_DAYT_OFFSET                              28
#define RTC_ALRMA_DAYT_MASK                                0x30000000

#define RTC_ALRMA_DAYU_OFFSET                              24
#define RTC_ALRMA_DAYU_MASK                                0xf000000

#define RTC_ALRMA_HRMEN_OFFSET                             23
#define RTC_ALRMA_HRMEN_MASK                               0x800000

#define RTC_ALRMA_TIMEFCFG_OFFSET                          22
#define RTC_ALRMA_TIMEFCFG_MASK                            0x400000

#define RTC_ALRMA_HRT_OFFSET                               20
#define RTC_ALRMA_HRT_MASK                                 0x300000

#define RTC_ALRMA_HRU_OFFSET                               16
#define RTC_ALRMA_HRU_MASK                                 0xf0000

#define RTC_ALRMA_MINMEN_OFFSET                            15
#define RTC_ALRMA_MINMEN_MASK                              0x8000

#define RTC_ALRMA_MINT_OFFSET                              12
#define RTC_ALRMA_MINT_MASK                                0x7000

#define RTC_ALRMA_MINU_OFFSET                              8
#define RTC_ALRMA_MINU_MASK                                0xf00

#define RTC_ALRMA_SECMEN_OFFSET                            7
#define RTC_ALRMA_SECMEN_MASK                              0x80

#define RTC_ALRMA_SECT_OFFSET                              4
#define RTC_ALRMA_SECT_MASK                                0x70

#define RTC_ALRMA_SECU_OFFSET                              0
#define RTC_ALRMA_SECU_MASK                                0xf

#define RTC_ALRMB_DATEMEN_OFFSET                           31
#define RTC_ALRMB_DATEMEN_MASK                             0x80000000

#define RTC_ALRMB_WEEKSEL_OFFSET                           30
#define RTC_ALRMB_WEEKSEL_MASK                             0x40000000

#define RTC_ALRMB_DAYT_OFFSET                              28
#define RTC_ALRMB_DAYT_MASK                                0x30000000

#define RTC_ALRMB_DAYU_OFFSET                              24
#define RTC_ALRMB_DAYU_MASK                                0xf000000

#define RTC_ALRMB_HRMEN_OFFSET                             23
#define RTC_ALRMB_HRMEN_MASK                               0x800000

#define RTC_ALRMB_TIMEFCFG_OFFSET                          22
#define RTC_ALRMB_TIMEFCFG_MASK                            0x400000

#define RTC_ALRMB_HRT_OFFSET                               20
#define RTC_ALRMB_HRT_MASK                                 0x300000

#define RTC_ALRMB_HRU_OFFSET                               16
#define RTC_ALRMB_HRU_MASK                                 0xf0000

#define RTC_ALRMB_MINMEN_OFFSET                            15
#define RTC_ALRMB_MINMEN_MASK                              0x8000

#define RTC_ALRMB_MINT_OFFSET                              12
#define RTC_ALRMB_MINT_MASK                                0x7000

#define RTC_ALRMB_MINU_OFFSET                              8
#define RTC_ALRMB_MINU_MASK                                0xf00

#define RTC_ALRMB_SECMEN_OFFSET                            7
#define RTC_ALRMB_SECMEN_MASK                              0x80

#define RTC_ALRMB_SECT_OFFSET                              4
#define RTC_ALRMB_SECT_MASK                                0x70

#define RTC_ALRMB_SECU_OFFSET                              0
#define RTC_ALRMB_SECU_MASK                                0xf

#define RTC_WRPROT_KEY_OFFSET                              0
#define RTC_WRPROT_KEY_MASK                                0xff

#define RTC_SUBSEC_SUBSEC_OFFSET                           0
#define RTC_SUBSEC_SUBSEC_MASK                             0xffff

#define RTC_SHIFT_ADD1SECEN_OFFSET                         31
#define RTC_SHIFT_ADD1SECEN_MASK                           0x80000000

#define RTC_SHIFT_SFSEC_OFFSET                             0
#define RTC_SHIFT_SFSEC_MASK                               0x7fff

#define RTC_TSTIME_TIMEFCFG_OFFSET                         22
#define RTC_TSTIME_TIMEFCFG_MASK                           0x400000

#define RTC_TSTIME_HRT_OFFSET                              20
#define RTC_TSTIME_HRT_MASK                                0x300000

#define RTC_TSTIME_HRU_OFFSET                              16
#define RTC_TSTIME_HRU_MASK                                0xf0000

#define RTC_TSTIME_MINT_OFFSET                             12
#define RTC_TSTIME_MINT_MASK                               0x7000

#define RTC_TSTIME_MINU_OFFSET                             8
#define RTC_TSTIME_MINU_MASK                               0xf00

#define RTC_TSTIME_SECT_OFFSET                             4
#define RTC_TSTIME_SECT_MASK                               0x70

#define RTC_TSTIME_SECU_OFFSET                             0
#define RTC_TSTIME_SECU_MASK                               0xf

#define RTC_TSDATE_WEEKSEL_OFFSET                          13
#define RTC_TSDATE_WEEKSEL_MASK                            0xe000

#define RTC_TSDATE_MONT_OFFSET                             12
#define RTC_TSDATE_MONT_MASK                               0x1000

#define RTC_TSDATE_MONU_OFFSET                             8
#define RTC_TSDATE_MONU_MASK                               0xf00

#define RTC_TSDATE_DAYT_OFFSET                             4
#define RTC_TSDATE_DAYT_MASK                               0x30

#define RTC_TSDATE_DAYU_OFFSET                             0
#define RTC_TSDATE_DAYU_MASK                               0xf

#define RTC_TSSUBSEC_SUBSEC_OFFSET                         0
#define RTC_TSSUBSEC_SUBSEC_MASK                           0xffff

#define RTC_CAL_ICALFEN_OFFSET                             15
#define RTC_CAL_ICALFEN_MASK                               0x8000

#define RTC_CAL_CAL8CFG_OFFSET                             14
#define RTC_CAL_CAL8CFG_MASK                               0x4000

#define RTC_CAL_CAL16CFG_OFFSET                            13
#define RTC_CAL_CAL16CFG_MASK                              0x2000

#define RTC_CAL_RECALF_OFFSET                              0
#define RTC_CAL_RECALF_MASK                                0x1ff

#define RTC_TACFG_ALRMOT_OFFSET                            18
#define RTC_TACFG_ALRMOT_MASK                              0x40000

#define RTC_TACFG_TSMSEL_OFFSET                            17
#define RTC_TACFG_TSMSEL_MASK                              0x20000

#define RTC_TACFG_TP1MSEL_OFFSET                           16
#define RTC_TACFG_TP1MSEL_MASK                             0x10000

#define RTC_TACFG_TP1PUDIS_OFFSET                          15
#define RTC_TACFG_TP1PUDIS_MASK                            0x8000

#define RTC_TACFG_TPPRDUSEL_OFFSET                         13
#define RTC_TACFG_TPPRDUSEL_MASK                           0x6000

#define RTC_TACFG_TPFCSEL_OFFSET                           11
#define RTC_TACFG_TPFCSEL_MASK                             0x1800

#define RTC_TACFG_TPSFSEL_OFFSET                           8
#define RTC_TACFG_TPSFSEL_MASK                             0x700

#define RTC_TACFG_TPTSEN_OFFSET                            7
#define RTC_TACFG_TPTSEN_MASK                              0x80

#define RTC_TACFG_TPIEN_OFFSET                             2
#define RTC_TACFG_TPIEN_MASK                               4

#define RTC_TACFG_TP1ALCFG_OFFSET                          1
#define RTC_TACFG_TP1ALCFG_MASK                            2

#define RTC_TACFG_TP1EN_OFFSET                             0
#define RTC_TACFG_TP1EN_MASK                               1

#define RTC_ALRMASS_MASKSEL_OFFSET                         24
#define RTC_ALRMASS_MASKSEL_MASK                           0xf000000

#define RTC_ALRMASS_SUBSEC_OFFSET                          0
#define RTC_ALRMASS_SUBSEC_MASK                            0x7fff

#define RTC_ALRMBSS_MASKSEL_OFFSET                         24
#define RTC_ALRMBSS_MASKSEL_MASK                           0xf000000

#define RTC_ALRMBSS_SUBSEC_OFFSET                          0
#define RTC_ALRMBSS_SUBSEC_MASK                            0x7fff

#define RTC_BAKP0_BAKP_OFFSET                              0
#define RTC_BAKP0_BAKP_MASK                                0xffffffff

#define RTC_BAKP1_BAKP_OFFSET                              0
#define RTC_BAKP1_BAKP_MASK                                0xffffffff

#define RTC_BAKP2_BAKP_OFFSET                              0
#define RTC_BAKP2_BAKP_MASK                                0xffffffff

#define RTC_BAKP3_BAKP_OFFSET                              0
#define RTC_BAKP3_BAKP_MASK                                0xffffffff

#define RTC_BAKP4_BAKP_OFFSET                              0
#define RTC_BAKP4_BAKP_MASK                                0xffffffff

#define RTC_BAKP5_BAKP_OFFSET                              0
#define RTC_BAKP5_BAKP_MASK                                0xffffffff

#define RTC_BAKP6_BAKP_OFFSET                              0
#define RTC_BAKP6_BAKP_MASK                                0xffffffff

#define RTC_BAKP7_BAKP_OFFSET                              0
#define RTC_BAKP7_BAKP_MASK                                0xffffffff

#define RTC_BAKP8_BAKP_OFFSET                              0
#define RTC_BAKP8_BAKP_MASK                                0xffffffff

#define RTC_BAKP9_BAKP_OFFSET                              0
#define RTC_BAKP9_BAKP_MASK                                0xffffffff

#define RTC_BAKP10_BAKP_OFFSET                             0
#define RTC_BAKP10_BAKP_MASK                               0xffffffff

#define RTC_BAKP11_BAKP_OFFSET                             0
#define RTC_BAKP11_BAKP_MASK                               0xffffffff

#define RTC_BAKP12_BAKP_OFFSET                             0
#define RTC_BAKP12_BAKP_MASK                               0xffffffff

#define RTC_BAKP13_BAKP_OFFSET                             0
#define RTC_BAKP13_BAKP_MASK                               0xffffffff

#define RTC_BAKP14_BAKP_OFFSET                             0
#define RTC_BAKP14_BAKP_MASK                               0xffffffff

#define RTC_BAKP15_BAKP_OFFSET                             0
#define RTC_BAKP15_BAKP_MASK                               0xffffffff

#define RTC_BAKP16_BAKP_OFFSET                             0
#define RTC_BAKP16_BAKP_MASK                               0xffffffff

#define RTC_BAKP17_BAKP_OFFSET                             0
#define RTC_BAKP17_BAKP_MASK                               0xffffffff

#define RTC_BAKP18_BAKP_OFFSET                             0
#define RTC_BAKP18_BAKP_MASK                               0xffffffff

#define RTC_BAKP19_BAKP_OFFSET                             0
#define RTC_BAKP19_BAKP_MASK                               0xffffffff


typedef struct
{

/** TIME TIME (offset: 0x0)
  time register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TIMEFCFG
  offset: 22, size: 1, access: 
  AM/PM notation
  Field: HRT
  offset: 20, size: 2, access: 
  Hour tens in BCD format
  Field: HRU
  offset: 16, size: 4, access: 
  Hour units in BCD format
  Field: MINT
  offset: 12, size: 3, access: 
  Minute tens in BCD format
  Field: MINU
  offset: 8, size: 4, access: 
  Minute units in BCD format
  Field: SECT
  offset: 4, size: 3, access: 
  Second tens in BCD format
  Field: SECU
  offset: 0, size: 4, access: 
  Second units in BCD format
*/
volatile uint32_t TIME;

/** DATE DATE (offset: 0x4)
  date register
  access : read-write
  reset value : 0x2101
  reset mask : 0xFFFFFFFF
  Field: YRT
  offset: 20, size: 4, access: 
  Year tens in BCD format
  Field: YRU
  offset: 16, size: 4, access: 
  Year units in BCD format
  Field: WEEKSEL
  offset: 13, size: 3, access: 
  Week day units
  Field: MONT
  offset: 12, size: 1, access: 
  Month tens in BCD format
  Field: MONU
  offset: 8, size: 4, access: 
  Month units in BCD format
  Field: DAYT
  offset: 4, size: 2, access: 
  Date tens in BCD format
  Field: DAYU
  offset: 0, size: 4, access: 
  Date units in BCD format
*/
volatile uint32_t DATE;

/** CTRL CTRL (offset: 0x8)
  control register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CALOEN
  offset: 23, size: 1, access: 
  Calibration output enable
  Field: OUTSEL
  offset: 21, size: 2, access: 
  Output selection
  Field: POLCFG
  offset: 20, size: 1, access: 
  Output polarity
  Field: CALOSEL
  offset: 19, size: 1, access: 
  Calibration Output Value Select
  Field: BAKP
  offset: 18, size: 1, access: 
  Backup
  Field: WTCCFG
  offset: 17, size: 1, access: 
  Subtract 1 hour (winter time change)
  Field: STCCFG
  offset: 16, size: 1, access: 
  Add 1 hour (summer time change)
  Field: TSIEN
  offset: 15, size: 1, access: 
  Time-stamp interrupt enable
  Field: WUTIEN
  offset: 14, size: 1, access: 
  Wakeup timer interrupt enable
  Field: ALRBIEN
  offset: 13, size: 1, access: 
  Alarm B interrupt enable
  Field: ALRAIEN
  offset: 12, size: 1, access: 
  Alarm A interrupt enable
  Field: TSEN
  offset: 11, size: 1, access: 
  Time stamp enable
  Field: WUTEN
  offset: 10, size: 1, access: 
  Wakeup timer enable
  Field: ALRBEN
  offset: 9, size: 1, access: 
  Alarm B enable
  Field: ALRAEN
  offset: 8, size: 1, access: 
  Alarm A enable
  Field: DCALEN
  offset: 7, size: 1, access: 
  Coarse digital calibration enable
  Field: TIMEFCFG
  offset: 6, size: 1, access: 
  Hour format
  Field: RCMCFG
  offset: 5, size: 1, access: 
  Read Calendar Value Mode Configure
  Field: RCLKDEN
  offset: 4, size: 1, access: 
  Reference clock detection enable (50 or 60 Hz)
  Field: TSETECFG
  offset: 3, size: 1, access: 
  Time-stamp event active edge
  Field: WUCLKSEL
  offset: 0, size: 3, access: 
  Wakeup clock selection
*/
volatile uint32_t CTRL;

/** STS STS (offset: 0xc)
  initialization and status register
  reset value : 0x7
  reset mask : 0xFFFFFFFF
  Field: ALRAWFLG
  offset: 0, size: 1, access: read-only
  Alarm A write flag
  Field: ALRBWFLG
  offset: 1, size: 1, access: read-only
  Alarm B write flag
  Field: WUTWFLG
  offset: 2, size: 1, access: read-only
  Wakeup timer write flag
  Field: SOPFLG
  offset: 3, size: 1, access: read-write
  Shift operation pending
  Field: INITSFLG
  offset: 4, size: 1, access: read-only
  Initialization status flag
  Field: RSFLG
  offset: 5, size: 1, access: read-write
  Registers synchronization flag
  Field: RINITFLG
  offset: 6, size: 1, access: read-only
  Register Initialization Occur Flag
  Field: INITEN
  offset: 7, size: 1, access: read-write
  Initialization Mode Enable
  Field: ALRAFLG
  offset: 8, size: 1, access: read-write
  Alarm A flag
  Field: ALRBFLG
  offset: 9, size: 1, access: read-write
  Alarm B flag
  Field: WUTFLG
  offset: 10, size: 1, access: read-write
  Wakeup timer flag
  Field: TSFLG
  offset: 11, size: 1, access: read-write
  Time-stamp flag
  Field: TSOVRFLG
  offset: 12, size: 1, access: read-write
  Time-stamp overflow flag
  Field: TP1FLG
  offset: 13, size: 1, access: read-write
  Tamper detection flag
  Field: RCALPFLG
  offset: 16, size: 1, access: read-only
  Recalibration pending Flag
*/
volatile uint32_t STS;

/** PSC PSC (offset: 0x10)
  prescaler register
  access : read-write
  reset value : 0x7F00FF
  reset mask : 0xFFFFFFFF
  Field: APSC
  offset: 16, size: 7, access: 
  Asynchronous prescaler factor
  Field: SPSC
  offset: 0, size: 15, access: 
  Synchronous prescaler factor
*/
volatile uint32_t PSC;

/** AUTORLD AUTORLD (offset: 0x14)
  wakeup timer register
  access : read-write
  reset value : 0xFFFF
  reset mask : 0xFFFFFFFF
  Field: WUAUTORE
  offset: 0, size: 16, access: 
  Wakeup auto-reload value bits
*/
volatile uint32_t AUTORLD;

/** DCAL DCAL (offset: 0x18)
  calibration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DCALCFG
  offset: 7, size: 1, access: 
  Digital calibration sign
  Field: DCAL
  offset: 0, size: 5, access: 
  Digital calibration
*/
volatile uint32_t DCAL;

/** ALRMA ALRMA (offset: 0x1c)
  alarm A register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATEMEN
  offset: 31, size: 1, access: 
  Alarm A date mask
  Field: WEEKSEL
  offset: 30, size: 1, access: 
  Week day selection
  Field: DAYT
  offset: 28, size: 2, access: 
  Date tens in BCD format
  Field: DAYU
  offset: 24, size: 4, access: 
  Date units or day in BCD format
  Field: HRMEN
  offset: 23, size: 1, access: 
  Alarm A hours mask
  Field: TIMEFCFG
  offset: 22, size: 1, access: 
  AM/PM notation
  Field: HRT
  offset: 20, size: 2, access: 
  Hour tens in BCD format
  Field: HRU
  offset: 16, size: 4, access: 
  Hour units in BCD format
  Field: MINMEN
  offset: 15, size: 1, access: 
  Alarm A minutes mask
  Field: MINT
  offset: 12, size: 3, access: 
  Minute tens in BCD format
  Field: MINU
  offset: 8, size: 4, access: 
  Minute units in BCD format
  Field: SECMEN
  offset: 7, size: 1, access: 
  Alarm A seconds mask
  Field: SECT
  offset: 4, size: 3, access: 
  Second tens in BCD format
  Field: SECU
  offset: 0, size: 4, access: 
  Second units in BCD format
*/
volatile uint32_t ALRMA;

/** ALRMB ALRMB (offset: 0x20)
  alarm B register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATEMEN
  offset: 31, size: 1, access: 
  Alarm A date mask
  Field: WEEKSEL
  offset: 30, size: 1, access: 
  Week day selection
  Field: DAYT
  offset: 28, size: 2, access: 
  Date tens in BCD format
  Field: DAYU
  offset: 24, size: 4, access: 
  Date units or day in BCD format
  Field: HRMEN
  offset: 23, size: 1, access: 
  Alarm A hours mask
  Field: TIMEFCFG
  offset: 22, size: 1, access: 
  AM/PM notation
  Field: HRT
  offset: 20, size: 2, access: 
  Hour tens in BCD format
  Field: HRU
  offset: 16, size: 4, access: 
  Hour units in BCD format
  Field: MINMEN
  offset: 15, size: 1, access: 
  Alarm A minutes mask
  Field: MINT
  offset: 12, size: 3, access: 
  Minute tens in BCD format
  Field: MINU
  offset: 8, size: 4, access: 
  Minute units in BCD format
  Field: SECMEN
  offset: 7, size: 1, access: 
  Alarm A seconds mask
  Field: SECT
  offset: 4, size: 3, access: 
  Second tens in BCD format
  Field: SECU
  offset: 0, size: 4, access: 
  Second units in BCD format
*/
volatile uint32_t ALRMB;

/** WRPROT WRPROT (offset: 0x24)
  write protection register
  access : write-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: KEY
  offset: 0, size: 8, access: 
  Write protection key
*/
volatile uint32_t WRPROT;

/** SUBSEC SUBSEC (offset: 0x28)
  sub second register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SUBSEC
  offset: 0, size: 16, access: 
  Sub second value
*/
volatile uint32_t SUBSEC;

/** SHIFT SHIFT (offset: 0x2c)
  shift control register
  access : write-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ADD1SECEN
  offset: 31, size: 1, access: 
  Add one second
  Field: SFSEC
  offset: 0, size: 15, access: 
  Subtract a fraction of a second
*/
volatile uint32_t SHIFT;

/** TSTIME TSTIME (offset: 0x30)
  time stamp time register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TIMEFCFG
  offset: 22, size: 1, access: 
  Time Format Configure
  Field: HRT
  offset: 20, size: 2, access: 
  Hour Ten&apos;s Place in BCD Format Setup
  Field: HRU
  offset: 16, size: 4, access: 
  Hour Ones Unit in BCD Format Setup
  Field: MINT
  offset: 12, size: 3, access: 
  Minute Ten&apos;s Place in BCD Format Setup
  Field: MINU
  offset: 8, size: 4, access: 
  Minute Ones Unit in BCD Format Setup
  Field: SECT
  offset: 4, size: 3, access: 
  Second Ten&apos;s Place in BCD Format Setup
  Field: SECU
  offset: 0, size: 4, access: 
  Second Ones Unit in BCD Format Setup
*/
volatile uint32_t TSTIME;

/** TSDATE TSDATE (offset: 0x34)
  time stamp date register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: WEEKSEL
  offset: 13, size: 3, access: 
  Week day units
  Field: MONT
  offset: 12, size: 1, access: 
  Month tens in BCD format
  Field: MONU
  offset: 8, size: 4, access: 
  Month units in BCD format
  Field: DAYT
  offset: 4, size: 2, access: 
  Date tens in BCD format
  Field: DAYU
  offset: 0, size: 4, access: 
  Date units in BCD format
*/
volatile uint32_t TSDATE;

/** TSSUBSEC TSSUBSEC (offset: 0x38)
  timestamp sub second register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SUBSEC
  offset: 0, size: 16, access: 
  Sub Second Value Setup
*/
volatile uint32_t TSSUBSEC;

/** CAL CAL (offset: 0x3c)
  calibration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ICALFEN
  offset: 15, size: 1, access: 
  Increase frequency of RTC by 488.5 ppm
  Field: CAL8CFG
  offset: 14, size: 1, access: 
  Use an 8-second calibration cycle period
  Field: CAL16CFG
  offset: 13, size: 1, access: 
  Use a 16-second calibration cycle period
  Field: RECALF
  offset: 0, size: 9, access: 
  Calibration minus
*/
volatile uint32_t CAL;

/** TACFG TACFG (offset: 0x40)
  tamper and alternate function configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: ALRMOT
  offset: 18, size: 1, access: 
  AFO_ALARM output type
  Field: TSMSEL
  offset: 17, size: 1, access: 
  TIMESTAMP mapping
  Field: TP1MSEL
  offset: 16, size: 1, access: 
  TAMPER1 mapping
  Field: TP1PUDIS
  offset: 15, size: 1, access: 
  TAMPER pull-up disable
  Field: TPPRDUSEL
  offset: 13, size: 2, access: 
  Tamper precharge duration
  Field: TPFCSEL
  offset: 11, size: 2, access: 
  Tamper filter count
  Field: TPSFSEL
  offset: 8, size: 3, access: 
  Tamper sampling frequency
  Field: TPTSEN
  offset: 7, size: 1, access: 
  Activate timestamp on tamper detection event
  Field: TPIEN
  offset: 2, size: 1, access: 
  Tamper interrupt enable
  Field: TP1ALCFG
  offset: 1, size: 1, access: 
  Active level for tamper 1
  Field: TP1EN
  offset: 0, size: 1, access: 
  Tamper 1 detection enable
*/
volatile uint32_t TACFG;

/** ALRMASS ALRMASS (offset: 0x44)
  alarm A sub second register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MASKSEL
  offset: 24, size: 4, access: 
  Mask the most-significant bits starting at this bit
  Field: SUBSEC
  offset: 0, size: 15, access: 
  Sub seconds value
*/
volatile uint32_t ALRMASS;

/** ALRMBSS ALRMBSS (offset: 0x48)
  alarm B sub second register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: MASKSEL
  offset: 24, size: 4, access: 
  Mask the most-significant bits starting at this bit
  Field: SUBSEC
  offset: 0, size: 15, access: 
  Sub seconds value
*/
volatile uint32_t ALRMBSS;
volatile uint32_t reserved0;

/** BAKP0 BAKP0 (offset: 0x50)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP0;

/** BAKP1 BAKP1 (offset: 0x54)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP1;

/** BAKP2 BAKP2 (offset: 0x58)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP2;

/** BAKP3 BAKP3 (offset: 0x5c)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP3;

/** BAKP4 BAKP4 (offset: 0x60)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP4;

/** BAKP5 BAKP5 (offset: 0x64)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP5;

/** BAKP6 BAKP6 (offset: 0x68)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP6;

/** BAKP7 BAKP7 (offset: 0x6c)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP7;

/** BAKP8 BAKP8 (offset: 0x70)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP8;

/** BAKP9 BAKP9 (offset: 0x74)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP9;

/** BAKP10 BAKP10 (offset: 0x78)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP10;

/** BAKP11 BAKP11 (offset: 0x7c)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP11;

/** BAKP12 BAKP12 (offset: 0x80)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP12;

/** BAKP13 BAKP13 (offset: 0x84)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP13;

/** BAKP14 BAKP14 (offset: 0x88)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP14;

/** BAKP15 BAKP15 (offset: 0x8c)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP15;

/** BAKP16 BAKP16 (offset: 0x90)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP16;

/** BAKP17 BAKP17 (offset: 0x94)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP17;

/** BAKP18 BAKP18 (offset: 0x98)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP18;

/** BAKP19 BAKP19 (offset: 0x9c)
  backup register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: BAKP
  offset: 0, size: 32, access: 
  Backup Value Setup
*/
volatile uint32_t BAKP19;
} RTC_type;

#define RTC ((RTC_type *) 0x40002800)

#endif // HW_RTC_H
