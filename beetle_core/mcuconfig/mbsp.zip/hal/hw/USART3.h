#ifndef HW_USART3_H
#define HW_USART3_H
/** Universal synchronous asynchronous receiver transmitter */
/** Interrupt : USART3 (Vector: 39) USART3 global interrupt */
/** Memory Block starting at 0x40004800 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define USART3_STS_CTSFLG_OFFSET                           9
#define USART3_STS_CTSFLG_MASK                             0x200

#define USART3_STS_LBDFLG_OFFSET                           8
#define USART3_STS_LBDFLG_MASK                             0x100

#define USART3_STS_TXBEFLG_OFFSET                          7
#define USART3_STS_TXBEFLG_MASK                            0x80

#define USART3_STS_TXCFLG_OFFSET                           6
#define USART3_STS_TXCFLG_MASK                             0x40

#define USART3_STS_RXBNEFLG_OFFSET                         5
#define USART3_STS_RXBNEFLG_MASK                           0x20

#define USART3_STS_IDLEFLG_OFFSET                          4
#define USART3_STS_IDLEFLG_MASK                            0x10

#define USART3_STS_OVREFLG_OFFSET                          3
#define USART3_STS_OVREFLG_MASK                            8

#define USART3_STS_NEFLG_OFFSET                            2
#define USART3_STS_NEFLG_MASK                              4

#define USART3_STS_FEFLG_OFFSET                            1
#define USART3_STS_FEFLG_MASK                              2

#define USART3_STS_PEFLG_OFFSET                            0
#define USART3_STS_PEFLG_MASK                              1

#define USART3_DATA_DATA_OFFSET                            0
#define USART3_DATA_DATA_MASK                              0x1ff

#define USART3_BR_IBR_OFFSET                               4
#define USART3_BR_IBR_MASK                                 0xfff0

#define USART3_BR_FBR_OFFSET                               0
#define USART3_BR_FBR_MASK                                 0xf

#define USART3_CTRL1_OSMCFG_OFFSET                         15
#define USART3_CTRL1_OSMCFG_MASK                           0x8000

#define USART3_CTRL1_UEN_OFFSET                            13
#define USART3_CTRL1_UEN_MASK                              0x2000

#define USART3_CTRL1_DBLCFG_OFFSET                         12
#define USART3_CTRL1_DBLCFG_MASK                           0x1000

#define USART3_CTRL1_WUPMCFG_OFFSET                        11
#define USART3_CTRL1_WUPMCFG_MASK                          0x800

#define USART3_CTRL1_PCEN_OFFSET                           10
#define USART3_CTRL1_PCEN_MASK                             0x400

#define USART3_CTRL1_PCFG_OFFSET                           9
#define USART3_CTRL1_PCFG_MASK                             0x200

#define USART3_CTRL1_PEIEN_OFFSET                          8
#define USART3_CTRL1_PEIEN_MASK                            0x100

#define USART3_CTRL1_TXBEIEN_OFFSET                        7
#define USART3_CTRL1_TXBEIEN_MASK                          0x80

#define USART3_CTRL1_TXCIEN_OFFSET                         6
#define USART3_CTRL1_TXCIEN_MASK                           0x40

#define USART3_CTRL1_RXBNEIEN_OFFSET                       5
#define USART3_CTRL1_RXBNEIEN_MASK                         0x20

#define USART3_CTRL1_IDLEIEN_OFFSET                        4
#define USART3_CTRL1_IDLEIEN_MASK                          0x10

#define USART3_CTRL1_TXEN_OFFSET                           3
#define USART3_CTRL1_TXEN_MASK                             8

#define USART3_CTRL1_RXEN_OFFSET                           2
#define USART3_CTRL1_RXEN_MASK                             4

#define USART3_CTRL1_RXMUTEEN_OFFSET                       1
#define USART3_CTRL1_RXMUTEEN_MASK                         2

#define USART3_CTRL1_TXBF_OFFSET                           0
#define USART3_CTRL1_TXBF_MASK                             1

#define USART3_CTRL2_LINMEN_OFFSET                         14
#define USART3_CTRL2_LINMEN_MASK                           0x4000

#define USART3_CTRL2_STOPCFG_OFFSET                        12
#define USART3_CTRL2_STOPCFG_MASK                          0x3000

#define USART3_CTRL2_CLKEN_OFFSET                          11
#define USART3_CTRL2_CLKEN_MASK                            0x800

#define USART3_CTRL2_CPOL_OFFSET                           10
#define USART3_CTRL2_CPOL_MASK                             0x400

#define USART3_CTRL2_CPHA_OFFSET                           9
#define USART3_CTRL2_CPHA_MASK                             0x200

#define USART3_CTRL2_LBCPOEN_OFFSET                        8
#define USART3_CTRL2_LBCPOEN_MASK                          0x100

#define USART3_CTRL2_LBDIEN_OFFSET                         6
#define USART3_CTRL2_LBDIEN_MASK                           0x40

#define USART3_CTRL2_LBDLCFG_OFFSET                        5
#define USART3_CTRL2_LBDLCFG_MASK                          0x20

#define USART3_CTRL2_ADDR_OFFSET                           0
#define USART3_CTRL2_ADDR_MASK                             0xf

#define USART3_CTRL3_SAMCFG_OFFSET                         11
#define USART3_CTRL3_SAMCFG_MASK                           0x800

#define USART3_CTRL3_CTSIEN_OFFSET                         10
#define USART3_CTRL3_CTSIEN_MASK                           0x400

#define USART3_CTRL3_CTSEN_OFFSET                          9
#define USART3_CTRL3_CTSEN_MASK                            0x200

#define USART3_CTRL3_RTSEN_OFFSET                          8
#define USART3_CTRL3_RTSEN_MASK                            0x100

#define USART3_CTRL3_DMATXEN_OFFSET                        7
#define USART3_CTRL3_DMATXEN_MASK                          0x80

#define USART3_CTRL3_DMARXEN_OFFSET                        6
#define USART3_CTRL3_DMARXEN_MASK                          0x40

#define USART3_CTRL3_SCEN_OFFSET                           5
#define USART3_CTRL3_SCEN_MASK                             0x20

#define USART3_CTRL3_SCNACKEN_OFFSET                       4
#define USART3_CTRL3_SCNACKEN_MASK                         0x10

#define USART3_CTRL3_HDEN_OFFSET                           3
#define USART3_CTRL3_HDEN_MASK                             8

#define USART3_CTRL3_IRLPEN_OFFSET                         2
#define USART3_CTRL3_IRLPEN_MASK                           4

#define USART3_CTRL3_IREN_OFFSET                           1
#define USART3_CTRL3_IREN_MASK                             2

#define USART3_CTRL3_ERRIEN_OFFSET                         0
#define USART3_CTRL3_ERRIEN_MASK                           1

#define USART3_GTPSC_GRDT_OFFSET                           8
#define USART3_GTPSC_GRDT_MASK                             0xff00

#define USART3_GTPSC_PSC_OFFSET                            0
#define USART3_GTPSC_PSC_MASK                              0xff


typedef struct
{

/** STS STS (offset: 0x0)
  Status register
  reset value : 0xC0
  reset mask : 0xFFFFFFFF
  Field: CTSFLG
  offset: 9, size: 1, access: read-write
  CTS flag
  Field: LBDFLG
  offset: 8, size: 1, access: read-write
  LIN break detection flag
  Field: TXBEFLG
  offset: 7, size: 1, access: read-only
  Transmit data register empty
  Field: TXCFLG
  offset: 6, size: 1, access: read-write
  Transmission complete
  Field: RXBNEFLG
  offset: 5, size: 1, access: read-write
  Read data register not empty
  Field: IDLEFLG
  offset: 4, size: 1, access: read-only
  IDLE line detected
  Field: OVREFLG
  offset: 3, size: 1, access: read-only
  Overrun error
  Field: NEFLG
  offset: 2, size: 1, access: read-only
  Noise detected flag
  Field: FEFLG
  offset: 1, size: 1, access: read-only
  Framing error
  Field: PEFLG
  offset: 0, size: 1, access: read-only
  Parity error
*/
volatile uint32_t STS;

/** DATA DATA (offset: 0x4)
  Data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: DATA
  offset: 0, size: 9, access: 
  Data value
*/
volatile uint32_t DATA;

/** BR BR (offset: 0x8)
  Baud rate register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: IBR
  offset: 4, size: 12, access: 
  mantissa of USARTDIV
  Field: FBR
  offset: 0, size: 4, access: 
  fraction of USARTDIV
*/
volatile uint32_t BR;

/** CTRL1 CTRL1 (offset: 0xc)
  Control register 1
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: OSMCFG
  offset: 15, size: 1, access: 
  Oversampling mode
  Field: UEN
  offset: 13, size: 1, access: 
  USART enable
  Field: DBLCFG
  offset: 12, size: 1, access: 
  Word length
  Field: WUPMCFG
  offset: 11, size: 1, access: 
  Wakeup method
  Field: PCEN
  offset: 10, size: 1, access: 
  Parity control enable
  Field: PCFG
  offset: 9, size: 1, access: 
  Parity selection
  Field: PEIEN
  offset: 8, size: 1, access: 
  Parity Error Interrupt Enable
  Field: TXBEIEN
  offset: 7, size: 1, access: 
  Transmit Buffer Empty Interrupt Enable
  Field: TXCIEN
  offset: 6, size: 1, access: 
  Transmission complete interrupt enable
  Field: RXBNEIEN
  offset: 5, size: 1, access: 
  RXNE interrupt enable
  Field: IDLEIEN
  offset: 4, size: 1, access: 
  IDLE interrupt enable
  Field: TXEN
  offset: 3, size: 1, access: 
  Transmitter enable
  Field: RXEN
  offset: 2, size: 1, access: 
  Receiver enable
  Field: RXMUTEEN
  offset: 1, size: 1, access: 
  Receiver wakeup
  Field: TXBF
  offset: 0, size: 1, access: 
  Send break
*/
volatile uint32_t CTRL1;

/** CTRL2 CTRL2 (offset: 0x10)
  Control register 2
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: LINMEN
  offset: 14, size: 1, access: 
  LIN mode enable
  Field: STOPCFG
  offset: 12, size: 2, access: 
  STOP bits
  Field: CLKEN
  offset: 11, size: 1, access: 
  Clock enable
  Field: CPOL
  offset: 10, size: 1, access: 
  Clock polarity
  Field: CPHA
  offset: 9, size: 1, access: 
  Clock phase
  Field: LBCPOEN
  offset: 8, size: 1, access: 
  Last bit clock pulse
  Field: LBDIEN
  offset: 6, size: 1, access: 
  LIN break detection interrupt enable
  Field: LBDLCFG
  offset: 5, size: 1, access: 
  lin break detection length
  Field: ADDR
  offset: 0, size: 4, access: 
  Address of the USART node
*/
volatile uint32_t CTRL2;

/** CTRL3 CTRL3 (offset: 0x14)
  Control register 3
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: SAMCFG
  offset: 11, size: 1, access: 
  One sample bit method enable
  Field: CTSIEN
  offset: 10, size: 1, access: 
  CTS interrupt enable
  Field: CTSEN
  offset: 9, size: 1, access: 
  CTS enable
  Field: RTSEN
  offset: 8, size: 1, access: 
  RTS enable
  Field: DMATXEN
  offset: 7, size: 1, access: 
  DMA enable transmitter
  Field: DMARXEN
  offset: 6, size: 1, access: 
  DMA enable receiver
  Field: SCEN
  offset: 5, size: 1, access: 
  Smartcard mode enable
  Field: SCNACKEN
  offset: 4, size: 1, access: 
  Smartcard NACK enable
  Field: HDEN
  offset: 3, size: 1, access: 
  Half-duplex selection
  Field: IRLPEN
  offset: 2, size: 1, access: 
  IrDA low-power
  Field: IREN
  offset: 1, size: 1, access: 
  IrDA mode enable
  Field: ERRIEN
  offset: 0, size: 1, access: 
  Error interrupt enable
*/
volatile uint32_t CTRL3;

/** GTPSC GTPSC (offset: 0x18)
  Guard time and prescaler register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: GRDT
  offset: 8, size: 8, access: 
  Guard time value
  Field: PSC
  offset: 0, size: 8, access: 
  Prescaler value
*/
volatile uint32_t GTPSC;
} USART3_type;

#define USART3 ((USART3_type *) 0x40004800)

#endif // HW_USART3_H
