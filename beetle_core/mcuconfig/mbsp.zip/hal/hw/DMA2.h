#ifndef HW_DMA2_H
#define HW_DMA2_H
/** DMA controller */
/** Interrupt : DMA2_STR5 (Vector: 68) DMA2 Stream 5 global interrupt */
/** Interrupt : DMA2_STR6 (Vector: 69) DMA2 Stream 6 global interrupt */
/** Interrupt : DMA2_STR7 (Vector: 70) DMA2 Stream 7 global interrupt */
/** Interrupt : DMA2_STR0 (Vector: 56) DMA2 Stream 0 global interrupt */
/** Interrupt : DMA2_STR1 (Vector: 57) DMA2 Stream 1 global interrupt */
/** Interrupt : DMA2_STR2 (Vector: 58) DMA2 Stream 2 global interrupt */
/** Interrupt : DMA2_STR3 (Vector: 59) DMA2 Stream 3 global interrupt */
/** Interrupt : DMA2_STR4 (Vector: 60) DMA2 Stream 4 global interrupt */
/** Memory Block starting at 0x40026400 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define DMA2_LINTSTS_TXCIFLG3_OFFSET                       27
#define DMA2_LINTSTS_TXCIFLG3_MASK                         0x8000000

#define DMA2_LINTSTS_HTXIFLG3_OFFSET                       26
#define DMA2_LINTSTS_HTXIFLG3_MASK                         0x4000000

#define DMA2_LINTSTS_TXEIFLG3_OFFSET                       25
#define DMA2_LINTSTS_TXEIFLG3_MASK                         0x2000000

#define DMA2_LINTSTS_DMEIFLG3_OFFSET                       24
#define DMA2_LINTSTS_DMEIFLG3_MASK                         0x1000000

#define DMA2_LINTSTS_FEIFLG3_OFFSET                        22
#define DMA2_LINTSTS_FEIFLG3_MASK                          0x400000

#define DMA2_LINTSTS_TXCIFLG2_OFFSET                       21
#define DMA2_LINTSTS_TXCIFLG2_MASK                         0x200000

#define DMA2_LINTSTS_HTXIFLG2_OFFSET                       20
#define DMA2_LINTSTS_HTXIFLG2_MASK                         0x100000

#define DMA2_LINTSTS_TXEIFLG2_OFFSET                       19
#define DMA2_LINTSTS_TXEIFLG2_MASK                         0x80000

#define DMA2_LINTSTS_DMEIFLG2_OFFSET                       18
#define DMA2_LINTSTS_DMEIFLG2_MASK                         0x40000

#define DMA2_LINTSTS_FEIFLG2_OFFSET                        16
#define DMA2_LINTSTS_FEIFLG2_MASK                          0x10000

#define DMA2_LINTSTS_TXCIFLG1_OFFSET                       11
#define DMA2_LINTSTS_TXCIFLG1_MASK                         0x800

#define DMA2_LINTSTS_HTXIFLG1_OFFSET                       10
#define DMA2_LINTSTS_HTXIFLG1_MASK                         0x400

#define DMA2_LINTSTS_TXEIFLG1_OFFSET                       9
#define DMA2_LINTSTS_TXEIFLG1_MASK                         0x200

#define DMA2_LINTSTS_DMEIFLG1_OFFSET                       8
#define DMA2_LINTSTS_DMEIFLG1_MASK                         0x100

#define DMA2_LINTSTS_FEIFLG1_OFFSET                        6
#define DMA2_LINTSTS_FEIFLG1_MASK                          0x40

#define DMA2_LINTSTS_TXCIFLG0_OFFSET                       5
#define DMA2_LINTSTS_TXCIFLG0_MASK                         0x20

#define DMA2_LINTSTS_HTXIFLG0_OFFSET                       4
#define DMA2_LINTSTS_HTXIFLG0_MASK                         0x10

#define DMA2_LINTSTS_TXEIFLG0_OFFSET                       3
#define DMA2_LINTSTS_TXEIFLG0_MASK                         8

#define DMA2_LINTSTS_DMEIFLG0_OFFSET                       2
#define DMA2_LINTSTS_DMEIFLG0_MASK                         4

#define DMA2_LINTSTS_FEIFLG0_OFFSET                        0
#define DMA2_LINTSTS_FEIFLG0_MASK                          1

#define DMA2_HINTSTS_TXCIFLG7_OFFSET                       27
#define DMA2_HINTSTS_TXCIFLG7_MASK                         0x8000000

#define DMA2_HINTSTS_HTXIFLG7_OFFSET                       26
#define DMA2_HINTSTS_HTXIFLG7_MASK                         0x4000000

#define DMA2_HINTSTS_TXEIFLG7_OFFSET                       25
#define DMA2_HINTSTS_TXEIFLG7_MASK                         0x2000000

#define DMA2_HINTSTS_DMEIFLG7_OFFSET                       24
#define DMA2_HINTSTS_DMEIFLG7_MASK                         0x1000000

#define DMA2_HINTSTS_FEIFLG7_OFFSET                        22
#define DMA2_HINTSTS_FEIFLG7_MASK                          0x400000

#define DMA2_HINTSTS_TXCIFLG6_OFFSET                       21
#define DMA2_HINTSTS_TXCIFLG6_MASK                         0x200000

#define DMA2_HINTSTS_HTXIFLG6_OFFSET                       20
#define DMA2_HINTSTS_HTXIFLG6_MASK                         0x100000

#define DMA2_HINTSTS_TXEIFLG6_OFFSET                       19
#define DMA2_HINTSTS_TXEIFLG6_MASK                         0x80000

#define DMA2_HINTSTS_DMEIFLG6_OFFSET                       18
#define DMA2_HINTSTS_DMEIFLG6_MASK                         0x40000

#define DMA2_HINTSTS_FEIFLG6_OFFSET                        16
#define DMA2_HINTSTS_FEIFLG6_MASK                          0x10000

#define DMA2_HINTSTS_TXCIFLG5_OFFSET                       11
#define DMA2_HINTSTS_TXCIFLG5_MASK                         0x800

#define DMA2_HINTSTS_HTXIFLG5_OFFSET                       10
#define DMA2_HINTSTS_HTXIFLG5_MASK                         0x400

#define DMA2_HINTSTS_TXEIFLG5_OFFSET                       9
#define DMA2_HINTSTS_TXEIFLG5_MASK                         0x200

#define DMA2_HINTSTS_DMEIFLG5_OFFSET                       8
#define DMA2_HINTSTS_DMEIFLG5_MASK                         0x100

#define DMA2_HINTSTS_FEIFLG5_OFFSET                        6
#define DMA2_HINTSTS_FEIFLG5_MASK                          0x40

#define DMA2_HINTSTS_TXCIFLG4_OFFSET                       5
#define DMA2_HINTSTS_TXCIFLG4_MASK                         0x20

#define DMA2_HINTSTS_HTXIFLG4_OFFSET                       4
#define DMA2_HINTSTS_HTXIFLG4_MASK                         0x10

#define DMA2_HINTSTS_TXEIFLG4_OFFSET                       3
#define DMA2_HINTSTS_TXEIFLG4_MASK                         8

#define DMA2_HINTSTS_DMEIFLG4_OFFSET                       2
#define DMA2_HINTSTS_DMEIFLG4_MASK                         4

#define DMA2_HINTSTS_FEIFLG4_OFFSET                        0
#define DMA2_HINTSTS_FEIFLG4_MASK                          1

#define DMA2_LIFCLR_CTXCIFLG3_OFFSET                       27
#define DMA2_LIFCLR_CTXCIFLG3_MASK                         0x8000000

#define DMA2_LIFCLR_CHTXIFLG3_OFFSET                       26
#define DMA2_LIFCLR_CHTXIFLG3_MASK                         0x4000000

#define DMA2_LIFCLR_CTXEIFLG3_OFFSET                       25
#define DMA2_LIFCLR_CTXEIFLG3_MASK                         0x2000000

#define DMA2_LIFCLR_CDMEIFLG3_OFFSET                       24
#define DMA2_LIFCLR_CDMEIFLG3_MASK                         0x1000000

#define DMA2_LIFCLR_CFEIFLG3_OFFSET                        22
#define DMA2_LIFCLR_CFEIFLG3_MASK                          0x400000

#define DMA2_LIFCLR_CTXCIFLG2_OFFSET                       21
#define DMA2_LIFCLR_CTXCIFLG2_MASK                         0x200000

#define DMA2_LIFCLR_CHTXIFLG2_OFFSET                       20
#define DMA2_LIFCLR_CHTXIFLG2_MASK                         0x100000

#define DMA2_LIFCLR_CTXEIFLG2_OFFSET                       19
#define DMA2_LIFCLR_CTXEIFLG2_MASK                         0x80000

#define DMA2_LIFCLR_CDMEIFLG2_OFFSET                       18
#define DMA2_LIFCLR_CDMEIFLG2_MASK                         0x40000

#define DMA2_LIFCLR_CFEIFLG2_OFFSET                        16
#define DMA2_LIFCLR_CFEIFLG2_MASK                          0x10000

#define DMA2_LIFCLR_CTXCIFLG1_OFFSET                       11
#define DMA2_LIFCLR_CTXCIFLG1_MASK                         0x800

#define DMA2_LIFCLR_CHTXIFLG1_OFFSET                       10
#define DMA2_LIFCLR_CHTXIFLG1_MASK                         0x400

#define DMA2_LIFCLR_CTXEIFLG1_OFFSET                       9
#define DMA2_LIFCLR_CTXEIFLG1_MASK                         0x200

#define DMA2_LIFCLR_CDMEIFLG1_OFFSET                       8
#define DMA2_LIFCLR_CDMEIFLG1_MASK                         0x100

#define DMA2_LIFCLR_CFEIFLG1_OFFSET                        6
#define DMA2_LIFCLR_CFEIFLG1_MASK                          0x40

#define DMA2_LIFCLR_CTXCIFLG0_OFFSET                       5
#define DMA2_LIFCLR_CTXCIFLG0_MASK                         0x20

#define DMA2_LIFCLR_CHTXIFLG0_OFFSET                       4
#define DMA2_LIFCLR_CHTXIFLG0_MASK                         0x10

#define DMA2_LIFCLR_CTXEIFLG0_OFFSET                       3
#define DMA2_LIFCLR_CTXEIFLG0_MASK                         8

#define DMA2_LIFCLR_CDMEIFLG0_OFFSET                       2
#define DMA2_LIFCLR_CDMEIFLG0_MASK                         4

#define DMA2_LIFCLR_CFEIFLG0_OFFSET                        0
#define DMA2_LIFCLR_CFEIFLG0_MASK                          1

#define DMA2_HIFCLR_CTXCIFLG7_OFFSET                       27
#define DMA2_HIFCLR_CTXCIFLG7_MASK                         0x8000000

#define DMA2_HIFCLR_CHTXIFLG7_OFFSET                       26
#define DMA2_HIFCLR_CHTXIFLG7_MASK                         0x4000000

#define DMA2_HIFCLR_CTXEIFLG7_OFFSET                       25
#define DMA2_HIFCLR_CTXEIFLG7_MASK                         0x2000000

#define DMA2_HIFCLR_CDMEIFLG7_OFFSET                       24
#define DMA2_HIFCLR_CDMEIFLG7_MASK                         0x1000000

#define DMA2_HIFCLR_CFEIFLG7_OFFSET                        22
#define DMA2_HIFCLR_CFEIFLG7_MASK                          0x400000

#define DMA2_HIFCLR_CTXCIFLG6_OFFSET                       21
#define DMA2_HIFCLR_CTXCIFLG6_MASK                         0x200000

#define DMA2_HIFCLR_CHTXIFLG6_OFFSET                       20
#define DMA2_HIFCLR_CHTXIFLG6_MASK                         0x100000

#define DMA2_HIFCLR_CTXEIFLG6_OFFSET                       19
#define DMA2_HIFCLR_CTXEIFLG6_MASK                         0x80000

#define DMA2_HIFCLR_CDMEIFLG6_OFFSET                       18
#define DMA2_HIFCLR_CDMEIFLG6_MASK                         0x40000

#define DMA2_HIFCLR_CFEIFLG6_OFFSET                        16
#define DMA2_HIFCLR_CFEIFLG6_MASK                          0x10000

#define DMA2_HIFCLR_CTXCIFLG5_OFFSET                       11
#define DMA2_HIFCLR_CTXCIFLG5_MASK                         0x800

#define DMA2_HIFCLR_CHTXIFLG5_OFFSET                       10
#define DMA2_HIFCLR_CHTXIFLG5_MASK                         0x400

#define DMA2_HIFCLR_CTXEIFLG5_OFFSET                       9
#define DMA2_HIFCLR_CTXEIFLG5_MASK                         0x200

#define DMA2_HIFCLR_CDMEIFLG5_OFFSET                       8
#define DMA2_HIFCLR_CDMEIFLG5_MASK                         0x100

#define DMA2_HIFCLR_CFEIFLG5_OFFSET                        6
#define DMA2_HIFCLR_CFEIFLG5_MASK                          0x40

#define DMA2_HIFCLR_CTXCIFLG4_OFFSET                       5
#define DMA2_HIFCLR_CTXCIFLG4_MASK                         0x20

#define DMA2_HIFCLR_CHTXIFLG4_OFFSET                       4
#define DMA2_HIFCLR_CHTXIFLG4_MASK                         0x10

#define DMA2_HIFCLR_CTXEIFLG4_OFFSET                       3
#define DMA2_HIFCLR_CTXEIFLG4_MASK                         8

#define DMA2_HIFCLR_CDMEIFLG4_OFFSET                       2
#define DMA2_HIFCLR_CDMEIFLG4_MASK                         4

#define DMA2_HIFCLR_CFEIFLG4_OFFSET                        0
#define DMA2_HIFCLR_CFEIFLG4_MASK                          1

#define DMA2_SCFG0_CHSEL_OFFSET                            25
#define DMA2_SCFG0_CHSEL_MASK                              0xe000000

#define DMA2_SCFG0_MBCFG_OFFSET                            23
#define DMA2_SCFG0_MBCFG_MASK                              0x1800000

#define DMA2_SCFG0_PBCFG_OFFSET                            21
#define DMA2_SCFG0_PBCFG_MASK                              0x600000

#define DMA2_SCFG0_CTARG_OFFSET                            19
#define DMA2_SCFG0_CTARG_MASK                              0x80000

#define DMA2_SCFG0_DBM_OFFSET                              18
#define DMA2_SCFG0_DBM_MASK                                0x40000

#define DMA2_SCFG0_PRILCFG_OFFSET                          16
#define DMA2_SCFG0_PRILCFG_MASK                            0x30000

#define DMA2_SCFG0_PERIOSIZE_OFFSET                        15
#define DMA2_SCFG0_PERIOSIZE_MASK                          0x8000

#define DMA2_SCFG0_MEMSIZECFG_OFFSET                       13
#define DMA2_SCFG0_MEMSIZECFG_MASK                         0x6000

#define DMA2_SCFG0_PERSIZECFG_OFFSET                       11
#define DMA2_SCFG0_PERSIZECFG_MASK                         0x1800

#define DMA2_SCFG0_MEMIM_OFFSET                            10
#define DMA2_SCFG0_MEMIM_MASK                              0x400

#define DMA2_SCFG0_PERIM_OFFSET                            9
#define DMA2_SCFG0_PERIM_MASK                              0x200

#define DMA2_SCFG0_CIRCMEN_OFFSET                          8
#define DMA2_SCFG0_CIRCMEN_MASK                            0x100

#define DMA2_SCFG0_DIRCFG_OFFSET                           6
#define DMA2_SCFG0_DIRCFG_MASK                             0xc0

#define DMA2_SCFG0_PERFC_OFFSET                            5
#define DMA2_SCFG0_PERFC_MASK                              0x20

#define DMA2_SCFG0_TXCIEN_OFFSET                           4
#define DMA2_SCFG0_TXCIEN_MASK                             0x10

#define DMA2_SCFG0_HTXIEN_OFFSET                           3
#define DMA2_SCFG0_HTXIEN_MASK                             8

#define DMA2_SCFG0_TXEIEN_OFFSET                           2
#define DMA2_SCFG0_TXEIEN_MASK                             4

#define DMA2_SCFG0_DMEIEN_OFFSET                           1
#define DMA2_SCFG0_DMEIEN_MASK                             2

#define DMA2_SCFG0_EN_OFFSET                               0
#define DMA2_SCFG0_EN_MASK                                 1

#define DMA2_NDATA0_NDATA_OFFSET                           0
#define DMA2_NDATA0_NDATA_MASK                             0xffff

#define DMA2_PADDR0_PADDR_OFFSET                           0
#define DMA2_PADDR0_PADDR_MASK                             0xffffffff

#define DMA2_M0ADDR0_M0ADDR_OFFSET                         0
#define DMA2_M0ADDR0_M0ADDR_MASK                           0xffffffff

#define DMA2_M1ADDR0_M1ADDR_OFFSET                         0
#define DMA2_M1ADDR0_M1ADDR_MASK                           0xffffffff

#define DMA2_FCTRL0_FEIEN_OFFSET                           7
#define DMA2_FCTRL0_FEIEN_MASK                             0x80

#define DMA2_FCTRL0_FSTS_OFFSET                            3
#define DMA2_FCTRL0_FSTS_MASK                              0x38

#define DMA2_FCTRL0_DMDEN_OFFSET                           2
#define DMA2_FCTRL0_DMDEN_MASK                             4

#define DMA2_FCTRL0_FTHSEL_OFFSET                          0
#define DMA2_FCTRL0_FTHSEL_MASK                            3

#define DMA2_SCFG1_CHSEL_OFFSET                            25
#define DMA2_SCFG1_CHSEL_MASK                              0xe000000

#define DMA2_SCFG1_MBCFG_OFFSET                            23
#define DMA2_SCFG1_MBCFG_MASK                              0x1800000

#define DMA2_SCFG1_PBCFG_OFFSET                            21
#define DMA2_SCFG1_PBCFG_MASK                              0x600000

#define DMA2_SCFG1_ACK_OFFSET                              20
#define DMA2_SCFG1_ACK_MASK                                0x100000

#define DMA2_SCFG1_CTARG_OFFSET                            19
#define DMA2_SCFG1_CTARG_MASK                              0x80000

#define DMA2_SCFG1_DBM_OFFSET                              18
#define DMA2_SCFG1_DBM_MASK                                0x40000

#define DMA2_SCFG1_PRILCFG_OFFSET                          16
#define DMA2_SCFG1_PRILCFG_MASK                            0x30000

#define DMA2_SCFG1_PERIOSIZE_OFFSET                        15
#define DMA2_SCFG1_PERIOSIZE_MASK                          0x8000

#define DMA2_SCFG1_MEMSIZECFG_OFFSET                       13
#define DMA2_SCFG1_MEMSIZECFG_MASK                         0x6000

#define DMA2_SCFG1_PERSIZECFG_OFFSET                       11
#define DMA2_SCFG1_PERSIZECFG_MASK                         0x1800

#define DMA2_SCFG1_MEMIM_OFFSET                            10
#define DMA2_SCFG1_MEMIM_MASK                              0x400

#define DMA2_SCFG1_PERIM_OFFSET                            9
#define DMA2_SCFG1_PERIM_MASK                              0x200

#define DMA2_SCFG1_CIRCMEN_OFFSET                          8
#define DMA2_SCFG1_CIRCMEN_MASK                            0x100

#define DMA2_SCFG1_DIRCFG_OFFSET                           6
#define DMA2_SCFG1_DIRCFG_MASK                             0xc0

#define DMA2_SCFG1_PERFC_OFFSET                            5
#define DMA2_SCFG1_PERFC_MASK                              0x20

#define DMA2_SCFG1_TXCIEN_OFFSET                           4
#define DMA2_SCFG1_TXCIEN_MASK                             0x10

#define DMA2_SCFG1_HTXIEN_OFFSET                           3
#define DMA2_SCFG1_HTXIEN_MASK                             8

#define DMA2_SCFG1_TXEIEN_OFFSET                           2
#define DMA2_SCFG1_TXEIEN_MASK                             4

#define DMA2_SCFG1_DMEIEN_OFFSET                           1
#define DMA2_SCFG1_DMEIEN_MASK                             2

#define DMA2_SCFG1_EN_OFFSET                               0
#define DMA2_SCFG1_EN_MASK                                 1

#define DMA2_NDATA1_NDATA_OFFSET                           0
#define DMA2_NDATA1_NDATA_MASK                             0xffff

#define DMA2_PADDR1_PADDR_OFFSET                           0
#define DMA2_PADDR1_PADDR_MASK                             0xffffffff

#define DMA2_M0ADDR1_M0ADDR_OFFSET                         0
#define DMA2_M0ADDR1_M0ADDR_MASK                           0xffffffff

#define DMA2_M1ADDR1_M1ADDR_OFFSET                         0
#define DMA2_M1ADDR1_M1ADDR_MASK                           0xffffffff

#define DMA2_FCTRL1_FEIEN_OFFSET                           7
#define DMA2_FCTRL1_FEIEN_MASK                             0x80

#define DMA2_FCTRL1_FSTS_OFFSET                            3
#define DMA2_FCTRL1_FSTS_MASK                              0x38

#define DMA2_FCTRL1_DMDEN_OFFSET                           2
#define DMA2_FCTRL1_DMDEN_MASK                             4

#define DMA2_FCTRL1_FTHSEL_OFFSET                          0
#define DMA2_FCTRL1_FTHSEL_MASK                            3

#define DMA2_SCFG2_CHSEL_OFFSET                            25
#define DMA2_SCFG2_CHSEL_MASK                              0xe000000

#define DMA2_SCFG2_MBCFG_OFFSET                            23
#define DMA2_SCFG2_MBCFG_MASK                              0x1800000

#define DMA2_SCFG2_PBCFG_OFFSET                            21
#define DMA2_SCFG2_PBCFG_MASK                              0x600000

#define DMA2_SCFG2_ACK_OFFSET                              20
#define DMA2_SCFG2_ACK_MASK                                0x100000

#define DMA2_SCFG2_CTARG_OFFSET                            19
#define DMA2_SCFG2_CTARG_MASK                              0x80000

#define DMA2_SCFG2_DBM_OFFSET                              18
#define DMA2_SCFG2_DBM_MASK                                0x40000

#define DMA2_SCFG2_PRILCFG_OFFSET                          16
#define DMA2_SCFG2_PRILCFG_MASK                            0x30000

#define DMA2_SCFG2_PERIOSIZE_OFFSET                        15
#define DMA2_SCFG2_PERIOSIZE_MASK                          0x8000

#define DMA2_SCFG2_MEMSIZECFG_OFFSET                       13
#define DMA2_SCFG2_MEMSIZECFG_MASK                         0x6000

#define DMA2_SCFG2_PERSIZECFG_OFFSET                       11
#define DMA2_SCFG2_PERSIZECFG_MASK                         0x1800

#define DMA2_SCFG2_MEMIM_OFFSET                            10
#define DMA2_SCFG2_MEMIM_MASK                              0x400

#define DMA2_SCFG2_PERIM_OFFSET                            9
#define DMA2_SCFG2_PERIM_MASK                              0x200

#define DMA2_SCFG2_CIRCMEN_OFFSET                          8
#define DMA2_SCFG2_CIRCMEN_MASK                            0x100

#define DMA2_SCFG2_DIRCFG_OFFSET                           6
#define DMA2_SCFG2_DIRCFG_MASK                             0xc0

#define DMA2_SCFG2_PERFC_OFFSET                            5
#define DMA2_SCFG2_PERFC_MASK                              0x20

#define DMA2_SCFG2_TXCIEN_OFFSET                           4
#define DMA2_SCFG2_TXCIEN_MASK                             0x10

#define DMA2_SCFG2_HTXIEN_OFFSET                           3
#define DMA2_SCFG2_HTXIEN_MASK                             8

#define DMA2_SCFG2_TXEIEN_OFFSET                           2
#define DMA2_SCFG2_TXEIEN_MASK                             4

#define DMA2_SCFG2_DMEIEN_OFFSET                           1
#define DMA2_SCFG2_DMEIEN_MASK                             2

#define DMA2_SCFG2_EN_OFFSET                               0
#define DMA2_SCFG2_EN_MASK                                 1

#define DMA2_NDATA2_NDATA_OFFSET                           0
#define DMA2_NDATA2_NDATA_MASK                             0xffff

#define DMA2_PADDR2_PADDR_OFFSET                           0
#define DMA2_PADDR2_PADDR_MASK                             0xffffffff

#define DMA2_M0ADDR2_M0ADDR_OFFSET                         0
#define DMA2_M0ADDR2_M0ADDR_MASK                           0xffffffff

#define DMA2_M1ADDR2_M1ADDR_OFFSET                         0
#define DMA2_M1ADDR2_M1ADDR_MASK                           0xffffffff

#define DMA2_FCTRL2_FEIEN_OFFSET                           7
#define DMA2_FCTRL2_FEIEN_MASK                             0x80

#define DMA2_FCTRL2_FSTS_OFFSET                            3
#define DMA2_FCTRL2_FSTS_MASK                              0x38

#define DMA2_FCTRL2_DMDEN_OFFSET                           2
#define DMA2_FCTRL2_DMDEN_MASK                             4

#define DMA2_FCTRL2_FTHSEL_OFFSET                          0
#define DMA2_FCTRL2_FTHSEL_MASK                            3

#define DMA2_SCFG3_CHSEL_OFFSET                            25
#define DMA2_SCFG3_CHSEL_MASK                              0xe000000

#define DMA2_SCFG3_MBCFG_OFFSET                            23
#define DMA2_SCFG3_MBCFG_MASK                              0x1800000

#define DMA2_SCFG3_PBCFG_OFFSET                            21
#define DMA2_SCFG3_PBCFG_MASK                              0x600000

#define DMA2_SCFG3_ACK_OFFSET                              20
#define DMA2_SCFG3_ACK_MASK                                0x100000

#define DMA2_SCFG3_CTARG_OFFSET                            19
#define DMA2_SCFG3_CTARG_MASK                              0x80000

#define DMA2_SCFG3_DBM_OFFSET                              18
#define DMA2_SCFG3_DBM_MASK                                0x40000

#define DMA2_SCFG3_PRILCFG_OFFSET                          16
#define DMA2_SCFG3_PRILCFG_MASK                            0x30000

#define DMA2_SCFG3_PERIOSIZE_OFFSET                        15
#define DMA2_SCFG3_PERIOSIZE_MASK                          0x8000

#define DMA2_SCFG3_MEMSIZECFG_OFFSET                       13
#define DMA2_SCFG3_MEMSIZECFG_MASK                         0x6000

#define DMA2_SCFG3_PERSIZECFG_OFFSET                       11
#define DMA2_SCFG3_PERSIZECFG_MASK                         0x1800

#define DMA2_SCFG3_MEMIM_OFFSET                            10
#define DMA2_SCFG3_MEMIM_MASK                              0x400

#define DMA2_SCFG3_PERIM_OFFSET                            9
#define DMA2_SCFG3_PERIM_MASK                              0x200

#define DMA2_SCFG3_CIRCMEN_OFFSET                          8
#define DMA2_SCFG3_CIRCMEN_MASK                            0x100

#define DMA2_SCFG3_DIRCFG_OFFSET                           6
#define DMA2_SCFG3_DIRCFG_MASK                             0xc0

#define DMA2_SCFG3_PERFC_OFFSET                            5
#define DMA2_SCFG3_PERFC_MASK                              0x20

#define DMA2_SCFG3_TXCIEN_OFFSET                           4
#define DMA2_SCFG3_TXCIEN_MASK                             0x10

#define DMA2_SCFG3_HTXIEN_OFFSET                           3
#define DMA2_SCFG3_HTXIEN_MASK                             8

#define DMA2_SCFG3_TXEIEN_OFFSET                           2
#define DMA2_SCFG3_TXEIEN_MASK                             4

#define DMA2_SCFG3_DMEIEN_OFFSET                           1
#define DMA2_SCFG3_DMEIEN_MASK                             2

#define DMA2_SCFG3_EN_OFFSET                               0
#define DMA2_SCFG3_EN_MASK                                 1

#define DMA2_NDATA3_NDATA_OFFSET                           0
#define DMA2_NDATA3_NDATA_MASK                             0xffff

#define DMA2_PADDR3_PADDR_OFFSET                           0
#define DMA2_PADDR3_PADDR_MASK                             0xffffffff

#define DMA2_M0ADDR3_M0ADDR_OFFSET                         0
#define DMA2_M0ADDR3_M0ADDR_MASK                           0xffffffff

#define DMA2_M1ADDR3_M1ADDR_OFFSET                         0
#define DMA2_M1ADDR3_M1ADDR_MASK                           0xffffffff

#define DMA2_FCTRL3_FEIEN_OFFSET                           7
#define DMA2_FCTRL3_FEIEN_MASK                             0x80

#define DMA2_FCTRL3_FSTS_OFFSET                            3
#define DMA2_FCTRL3_FSTS_MASK                              0x38

#define DMA2_FCTRL3_DMDEN_OFFSET                           2
#define DMA2_FCTRL3_DMDEN_MASK                             4

#define DMA2_FCTRL3_FTHSEL_OFFSET                          0
#define DMA2_FCTRL3_FTHSEL_MASK                            3

#define DMA2_SCFG4_CHSEL_OFFSET                            25
#define DMA2_SCFG4_CHSEL_MASK                              0xe000000

#define DMA2_SCFG4_MBCFG_OFFSET                            23
#define DMA2_SCFG4_MBCFG_MASK                              0x1800000

#define DMA2_SCFG4_PBCFG_OFFSET                            21
#define DMA2_SCFG4_PBCFG_MASK                              0x600000

#define DMA2_SCFG4_ACK_OFFSET                              20
#define DMA2_SCFG4_ACK_MASK                                0x100000

#define DMA2_SCFG4_CTARG_OFFSET                            19
#define DMA2_SCFG4_CTARG_MASK                              0x80000

#define DMA2_SCFG4_DBM_OFFSET                              18
#define DMA2_SCFG4_DBM_MASK                                0x40000

#define DMA2_SCFG4_PRILCFG_OFFSET                          16
#define DMA2_SCFG4_PRILCFG_MASK                            0x30000

#define DMA2_SCFG4_PERIOSIZE_OFFSET                        15
#define DMA2_SCFG4_PERIOSIZE_MASK                          0x8000

#define DMA2_SCFG4_MEMSIZECFG_OFFSET                       13
#define DMA2_SCFG4_MEMSIZECFG_MASK                         0x6000

#define DMA2_SCFG4_PERSIZECFG_OFFSET                       11
#define DMA2_SCFG4_PERSIZECFG_MASK                         0x1800

#define DMA2_SCFG4_MEMIM_OFFSET                            10
#define DMA2_SCFG4_MEMIM_MASK                              0x400

#define DMA2_SCFG4_PERIM_OFFSET                            9
#define DMA2_SCFG4_PERIM_MASK                              0x200

#define DMA2_SCFG4_CIRCMEN_OFFSET                          8
#define DMA2_SCFG4_CIRCMEN_MASK                            0x100

#define DMA2_SCFG4_DIRCFG_OFFSET                           6
#define DMA2_SCFG4_DIRCFG_MASK                             0xc0

#define DMA2_SCFG4_PERFC_OFFSET                            5
#define DMA2_SCFG4_PERFC_MASK                              0x20

#define DMA2_SCFG4_TXCIEN_OFFSET                           4
#define DMA2_SCFG4_TXCIEN_MASK                             0x10

#define DMA2_SCFG4_HTXIEN_OFFSET                           3
#define DMA2_SCFG4_HTXIEN_MASK                             8

#define DMA2_SCFG4_TXEIEN_OFFSET                           2
#define DMA2_SCFG4_TXEIEN_MASK                             4

#define DMA2_SCFG4_DMEIEN_OFFSET                           1
#define DMA2_SCFG4_DMEIEN_MASK                             2

#define DMA2_SCFG4_EN_OFFSET                               0
#define DMA2_SCFG4_EN_MASK                                 1

#define DMA2_NDATA4_NDATA_OFFSET                           0
#define DMA2_NDATA4_NDATA_MASK                             0xffff

#define DMA2_PADDR4_PADDR_OFFSET                           0
#define DMA2_PADDR4_PADDR_MASK                             0xffffffff

#define DMA2_M0ADDR4_M0ADDR_OFFSET                         0
#define DMA2_M0ADDR4_M0ADDR_MASK                           0xffffffff

#define DMA2_M1ADDR4_M1ADDR_OFFSET                         0
#define DMA2_M1ADDR4_M1ADDR_MASK                           0xffffffff

#define DMA2_FCTRL4_FEIEN_OFFSET                           7
#define DMA2_FCTRL4_FEIEN_MASK                             0x80

#define DMA2_FCTRL4_FSTS_OFFSET                            3
#define DMA2_FCTRL4_FSTS_MASK                              0x38

#define DMA2_FCTRL4_DMDEN_OFFSET                           2
#define DMA2_FCTRL4_DMDEN_MASK                             4

#define DMA2_FCTRL4_FTHSEL_OFFSET                          0
#define DMA2_FCTRL4_FTHSEL_MASK                            3

#define DMA2_SCFG5_CHSEL_OFFSET                            25
#define DMA2_SCFG5_CHSEL_MASK                              0xe000000

#define DMA2_SCFG5_MBCFG_OFFSET                            23
#define DMA2_SCFG5_MBCFG_MASK                              0x1800000

#define DMA2_SCFG5_PBCFG_OFFSET                            21
#define DMA2_SCFG5_PBCFG_MASK                              0x600000

#define DMA2_SCFG5_ACK_OFFSET                              20
#define DMA2_SCFG5_ACK_MASK                                0x100000

#define DMA2_SCFG5_CTARG_OFFSET                            19
#define DMA2_SCFG5_CTARG_MASK                              0x80000

#define DMA2_SCFG5_DBM_OFFSET                              18
#define DMA2_SCFG5_DBM_MASK                                0x40000

#define DMA2_SCFG5_PRILCFG_OFFSET                          16
#define DMA2_SCFG5_PRILCFG_MASK                            0x30000

#define DMA2_SCFG5_PERIOSIZE_OFFSET                        15
#define DMA2_SCFG5_PERIOSIZE_MASK                          0x8000

#define DMA2_SCFG5_MEMSIZECFG_OFFSET                       13
#define DMA2_SCFG5_MEMSIZECFG_MASK                         0x6000

#define DMA2_SCFG5_PERSIZECFG_OFFSET                       11
#define DMA2_SCFG5_PERSIZECFG_MASK                         0x1800

#define DMA2_SCFG5_MEMIM_OFFSET                            10
#define DMA2_SCFG5_MEMIM_MASK                              0x400

#define DMA2_SCFG5_PERIM_OFFSET                            9
#define DMA2_SCFG5_PERIM_MASK                              0x200

#define DMA2_SCFG5_CIRCMEN_OFFSET                          8
#define DMA2_SCFG5_CIRCMEN_MASK                            0x100

#define DMA2_SCFG5_DIRCFG_OFFSET                           6
#define DMA2_SCFG5_DIRCFG_MASK                             0xc0

#define DMA2_SCFG5_PERFC_OFFSET                            5
#define DMA2_SCFG5_PERFC_MASK                              0x20

#define DMA2_SCFG5_TXCIEN_OFFSET                           4
#define DMA2_SCFG5_TXCIEN_MASK                             0x10

#define DMA2_SCFG5_HTXIEN_OFFSET                           3
#define DMA2_SCFG5_HTXIEN_MASK                             8

#define DMA2_SCFG5_TXEIEN_OFFSET                           2
#define DMA2_SCFG5_TXEIEN_MASK                             4

#define DMA2_SCFG5_DMEIEN_OFFSET                           1
#define DMA2_SCFG5_DMEIEN_MASK                             2

#define DMA2_SCFG5_EN_OFFSET                               0
#define DMA2_SCFG5_EN_MASK                                 1

#define DMA2_NDATA5_NDATA_OFFSET                           0
#define DMA2_NDATA5_NDATA_MASK                             0xffff

#define DMA2_PADDR5_PADDR_OFFSET                           0
#define DMA2_PADDR5_PADDR_MASK                             0xffffffff

#define DMA2_M1ADDR5_M0ADDR_OFFSET                         0
#define DMA2_M1ADDR5_M0ADDR_MASK                           0xffffffff

#define DMA2_S5M1AR_M1ADDR_OFFSET                          0
#define DMA2_S5M1AR_M1ADDR_MASK                            0xffffffff

#define DMA2_FCTRL5_FEIEN_OFFSET                           7
#define DMA2_FCTRL5_FEIEN_MASK                             0x80

#define DMA2_FCTRL5_FSTS_OFFSET                            3
#define DMA2_FCTRL5_FSTS_MASK                              0x38

#define DMA2_FCTRL5_DMDEN_OFFSET                           2
#define DMA2_FCTRL5_DMDEN_MASK                             4

#define DMA2_FCTRL5_FTHSEL_OFFSET                          0
#define DMA2_FCTRL5_FTHSEL_MASK                            3

#define DMA2_SCFG6_CHSEL_OFFSET                            25
#define DMA2_SCFG6_CHSEL_MASK                              0xe000000

#define DMA2_SCFG6_MBCFG_OFFSET                            23
#define DMA2_SCFG6_MBCFG_MASK                              0x1800000

#define DMA2_SCFG6_PBCFG_OFFSET                            21
#define DMA2_SCFG6_PBCFG_MASK                              0x600000

#define DMA2_SCFG6_ACK_OFFSET                              20
#define DMA2_SCFG6_ACK_MASK                                0x100000

#define DMA2_SCFG6_CTARG_OFFSET                            19
#define DMA2_SCFG6_CTARG_MASK                              0x80000

#define DMA2_SCFG6_DBM_OFFSET                              18
#define DMA2_SCFG6_DBM_MASK                                0x40000

#define DMA2_SCFG6_PRILCFG_OFFSET                          16
#define DMA2_SCFG6_PRILCFG_MASK                            0x30000

#define DMA2_SCFG6_PERIOSIZE_OFFSET                        15
#define DMA2_SCFG6_PERIOSIZE_MASK                          0x8000

#define DMA2_SCFG6_MEMSIZECFG_OFFSET                       13
#define DMA2_SCFG6_MEMSIZECFG_MASK                         0x6000

#define DMA2_SCFG6_PERSIZECFG_OFFSET                       11
#define DMA2_SCFG6_PERSIZECFG_MASK                         0x1800

#define DMA2_SCFG6_MEMIM_OFFSET                            10
#define DMA2_SCFG6_MEMIM_MASK                              0x400

#define DMA2_SCFG6_PERIM_OFFSET                            9
#define DMA2_SCFG6_PERIM_MASK                              0x200

#define DMA2_SCFG6_CIRCMEN_OFFSET                          8
#define DMA2_SCFG6_CIRCMEN_MASK                            0x100

#define DMA2_SCFG6_DIRCFG_OFFSET                           6
#define DMA2_SCFG6_DIRCFG_MASK                             0xc0

#define DMA2_SCFG6_PERFC_OFFSET                            5
#define DMA2_SCFG6_PERFC_MASK                              0x20

#define DMA2_SCFG6_TXCIEN_OFFSET                           4
#define DMA2_SCFG6_TXCIEN_MASK                             0x10

#define DMA2_SCFG6_HTXIEN_OFFSET                           3
#define DMA2_SCFG6_HTXIEN_MASK                             8

#define DMA2_SCFG6_TXEIEN_OFFSET                           2
#define DMA2_SCFG6_TXEIEN_MASK                             4

#define DMA2_SCFG6_DMEIEN_OFFSET                           1
#define DMA2_SCFG6_DMEIEN_MASK                             2

#define DMA2_SCFG6_EN_OFFSET                               0
#define DMA2_SCFG6_EN_MASK                                 1

#define DMA2_NDATA6_NDATA_OFFSET                           0
#define DMA2_NDATA6_NDATA_MASK                             0xffff

#define DMA2_PADDR6_PADDR_OFFSET                           0
#define DMA2_PADDR6_PADDR_MASK                             0xffffffff

#define DMA2_M0ADDR6_M0ADDR_OFFSET                         0
#define DMA2_M0ADDR6_M0ADDR_MASK                           0xffffffff

#define DMA2_M1ADDR6_M1ADDR_OFFSET                         0
#define DMA2_M1ADDR6_M1ADDR_MASK                           0xffffffff

#define DMA2_FCTRL6_FEIEN_OFFSET                           7
#define DMA2_FCTRL6_FEIEN_MASK                             0x80

#define DMA2_FCTRL6_FSTS_OFFSET                            3
#define DMA2_FCTRL6_FSTS_MASK                              0x38

#define DMA2_FCTRL6_DMDEN_OFFSET                           2
#define DMA2_FCTRL6_DMDEN_MASK                             4

#define DMA2_FCTRL6_FTHSEL_OFFSET                          0
#define DMA2_FCTRL6_FTHSEL_MASK                            3

#define DMA2_SCFG7_CHSEL_OFFSET                            25
#define DMA2_SCFG7_CHSEL_MASK                              0xe000000

#define DMA2_SCFG7_MBCFG_OFFSET                            23
#define DMA2_SCFG7_MBCFG_MASK                              0x1800000

#define DMA2_SCFG7_PBCFG_OFFSET                            21
#define DMA2_SCFG7_PBCFG_MASK                              0x600000

#define DMA2_SCFG7_ACK_OFFSET                              20
#define DMA2_SCFG7_ACK_MASK                                0x100000

#define DMA2_SCFG7_CTARG_OFFSET                            19
#define DMA2_SCFG7_CTARG_MASK                              0x80000

#define DMA2_SCFG7_DBM_OFFSET                              18
#define DMA2_SCFG7_DBM_MASK                                0x40000

#define DMA2_SCFG7_PRILCFG_OFFSET                          16
#define DMA2_SCFG7_PRILCFG_MASK                            0x30000

#define DMA2_SCFG7_PERIOSIZE_OFFSET                        15
#define DMA2_SCFG7_PERIOSIZE_MASK                          0x8000

#define DMA2_SCFG7_MEMSIZECFG_OFFSET                       13
#define DMA2_SCFG7_MEMSIZECFG_MASK                         0x6000

#define DMA2_SCFG7_PERSIZECFG_OFFSET                       11
#define DMA2_SCFG7_PERSIZECFG_MASK                         0x1800

#define DMA2_SCFG7_MEMIM_OFFSET                            10
#define DMA2_SCFG7_MEMIM_MASK                              0x400

#define DMA2_SCFG7_PERIM_OFFSET                            9
#define DMA2_SCFG7_PERIM_MASK                              0x200

#define DMA2_SCFG7_CIRCMEN_OFFSET                          8
#define DMA2_SCFG7_CIRCMEN_MASK                            0x100

#define DMA2_SCFG7_DIRCFG_OFFSET                           6
#define DMA2_SCFG7_DIRCFG_MASK                             0xc0

#define DMA2_SCFG7_PERFC_OFFSET                            5
#define DMA2_SCFG7_PERFC_MASK                              0x20

#define DMA2_SCFG7_TXCIEN_OFFSET                           4
#define DMA2_SCFG7_TXCIEN_MASK                             0x10

#define DMA2_SCFG7_HTXIEN_OFFSET                           3
#define DMA2_SCFG7_HTXIEN_MASK                             8

#define DMA2_SCFG7_TXEIEN_OFFSET                           2
#define DMA2_SCFG7_TXEIEN_MASK                             4

#define DMA2_SCFG7_DMEIEN_OFFSET                           1
#define DMA2_SCFG7_DMEIEN_MASK                             2

#define DMA2_SCFG7_EN_OFFSET                               0
#define DMA2_SCFG7_EN_MASK                                 1

#define DMA2_NDATA7_NDATA_OFFSET                           0
#define DMA2_NDATA7_NDATA_MASK                             0xffff

#define DMA2_PADDR7_PADDR_OFFSET                           0
#define DMA2_PADDR7_PADDR_MASK                             0xffffffff

#define DMA2_M0ADDR7_M0ADDR_OFFSET                         0
#define DMA2_M0ADDR7_M0ADDR_MASK                           0xffffffff

#define DMA2_M1ADDR7_M1ADDR_OFFSET                         0
#define DMA2_M1ADDR7_M1ADDR_MASK                           0xffffffff

#define DMA2_FCTRL7_FEIEN_OFFSET                           7
#define DMA2_FCTRL7_FEIEN_MASK                             0x80

#define DMA2_FCTRL7_FSTS_OFFSET                            3
#define DMA2_FCTRL7_FSTS_MASK                              0x38

#define DMA2_FCTRL7_DMDEN_OFFSET                           2
#define DMA2_FCTRL7_DMDEN_MASK                             4

#define DMA2_FCTRL7_FTHSEL_OFFSET                          0
#define DMA2_FCTRL7_FTHSEL_MASK                            3


typedef struct
{

/** LINTSTS LINTSTS (offset: 0x0)
  low interrupt status register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TXCIFLG3
  offset: 27, size: 1, access: 
  Stream x transfer complete interrupt flag (x = 3..0)
  Field: HTXIFLG3
  offset: 26, size: 1, access: 
  Stream x half transfer interrupt flag (x=3..0)
  Field: TXEIFLG3
  offset: 25, size: 1, access: 
  Stream x transfer error interrupt flag (x=3..0)
  Field: DMEIFLG3
  offset: 24, size: 1, access: 
  Stream x direct mode error interrupt flag (x=3..0)
  Field: FEIFLG3
  offset: 22, size: 1, access: 
  Stream x FIFO error interrupt flag (x=3..0)
  Field: TXCIFLG2
  offset: 21, size: 1, access: 
  Stream x transfer complete interrupt flag (x = 3..0)
  Field: HTXIFLG2
  offset: 20, size: 1, access: 
  Stream x half transfer interrupt flag (x=3..0)
  Field: TXEIFLG2
  offset: 19, size: 1, access: 
  Stream x transfer error interrupt flag (x=3..0)
  Field: DMEIFLG2
  offset: 18, size: 1, access: 
  Stream x direct mode error interrupt flag (x=3..0)
  Field: FEIFLG2
  offset: 16, size: 1, access: 
  Stream x FIFO error interrupt flag (x=3..0)
  Field: TXCIFLG1
  offset: 11, size: 1, access: 
  Stream x transfer complete interrupt flag (x = 3..0)
  Field: HTXIFLG1
  offset: 10, size: 1, access: 
  Stream x half transfer interrupt flag (x=3..0)
  Field: TXEIFLG1
  offset: 9, size: 1, access: 
  Stream x transfer error interrupt flag (x=3..0)
  Field: DMEIFLG1
  offset: 8, size: 1, access: 
  Stream x direct mode error interrupt flag (x=3..0)
  Field: FEIFLG1
  offset: 6, size: 1, access: 
  Stream x FIFO error interrupt flag (x=3..0)
  Field: TXCIFLG0
  offset: 5, size: 1, access: 
  Stream x transfer complete interrupt flag (x = 3..0)
  Field: HTXIFLG0
  offset: 4, size: 1, access: 
  Stream x half transfer interrupt flag (x=3..0)
  Field: TXEIFLG0
  offset: 3, size: 1, access: 
  Stream x transfer error interrupt flag (x=3..0)
  Field: DMEIFLG0
  offset: 2, size: 1, access: 
  Stream x direct mode error interrupt flag (x=3..0)
  Field: FEIFLG0
  offset: 0, size: 1, access: 
  Stream x FIFO error interrupt flag (x=3..0)
*/
volatile uint32_t LINTSTS;

/** HINTSTS HINTSTS (offset: 0x4)
  high interrupt status register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: TXCIFLG7
  offset: 27, size: 1, access: 
  Stream x transfer complete interrupt flag (x=7..4)
  Field: HTXIFLG7
  offset: 26, size: 1, access: 
  Stream x half transfer interrupt flag (x=7..4)
  Field: TXEIFLG7
  offset: 25, size: 1, access: 
  Stream x transfer error interrupt flag (x=7..4)
  Field: DMEIFLG7
  offset: 24, size: 1, access: 
  Stream x direct mode error interrupt flag (x=7..4)
  Field: FEIFLG7
  offset: 22, size: 1, access: 
  Stream x FIFO error interrupt flag (x=7..4)
  Field: TXCIFLG6
  offset: 21, size: 1, access: 
  Stream x transfer complete interrupt flag (x=7..4)
  Field: HTXIFLG6
  offset: 20, size: 1, access: 
  Stream x half transfer interrupt flag (x=7..4)
  Field: TXEIFLG6
  offset: 19, size: 1, access: 
  Stream x transfer error interrupt flag (x=7..4)
  Field: DMEIFLG6
  offset: 18, size: 1, access: 
  Stream x direct mode error interrupt flag (x=7..4)
  Field: FEIFLG6
  offset: 16, size: 1, access: 
  Stream x FIFO error interrupt flag (x=7..4)
  Field: TXCIFLG5
  offset: 11, size: 1, access: 
  Stream x transfer complete interrupt flag (x=7..4)
  Field: HTXIFLG5
  offset: 10, size: 1, access: 
  Stream x half transfer interrupt flag (x=7..4)
  Field: TXEIFLG5
  offset: 9, size: 1, access: 
  Stream x transfer error interrupt flag (x=7..4)
  Field: DMEIFLG5
  offset: 8, size: 1, access: 
  Stream x direct mode error interrupt flag (x=7..4)
  Field: FEIFLG5
  offset: 6, size: 1, access: 
  Stream x FIFO error interrupt flag (x=7..4)
  Field: TXCIFLG4
  offset: 5, size: 1, access: 
  Stream x transfer complete interrupt flag (x=7..4)
  Field: HTXIFLG4
  offset: 4, size: 1, access: 
  Stream x half transfer interrupt flag (x=7..4)
  Field: TXEIFLG4
  offset: 3, size: 1, access: 
  Stream x transfer error interrupt flag (x=7..4)
  Field: DMEIFLG4
  offset: 2, size: 1, access: 
  Stream x direct mode error interrupt flag (x=7..4)
  Field: FEIFLG4
  offset: 0, size: 1, access: 
  Stream x FIFO error interrupt flag (x=7..4)
*/
volatile uint32_t HINTSTS;

/** LIFCLR LIFCLR (offset: 0x8)
  low interrupt flag clear register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CTXCIFLG3
  offset: 27, size: 1, access: 
  Stream x clear transfer complete interrupt flag (x = 3..0)
  Field: CHTXIFLG3
  offset: 26, size: 1, access: 
  Stream x clear half transfer interrupt flag (x = 3..0)
  Field: CTXEIFLG3
  offset: 25, size: 1, access: 
  Stream x clear transfer error interrupt
 flag(x = 3..0)
  Field: CDMEIFLG3
  offset: 24, size: 1, access: 
  Stream x clear direct mode error interrupt flag (x = 3..0)
  Field: CFEIFLG3
  offset: 22, size: 1, access: 
  Stream x clear FIFO error interrupt
 flag (x = 3..0)
  Field: CTXCIFLG2
  offset: 21, size: 1, access: 
  Stream x clear transfer complete interrupt flag (x = 3..0)
  Field: CHTXIFLG2
  offset: 20, size: 1, access: 
  Stream x clear half transfer interrupt flag (x = 3..0)
  Field: CTXEIFLG2
  offset: 19, size: 1, access: 
  Stream x clear transfer error interrupt
 flag(x = 3..0)
  Field: CDMEIFLG2
  offset: 18, size: 1, access: 
  Stream x clear direct mode error interrupt flag (x = 3..0)
  Field: CFEIFLG2
  offset: 16, size: 1, access: 
  Stream x clear FIFO error interrupt flag (x = 3..0)
  Field: CTXCIFLG1
  offset: 11, size: 1, access: 
  Stream x clear transfer complete interrupt flag (x = 3..0)
  Field: CHTXIFLG1
  offset: 10, size: 1, access: 
  Stream x clear half transfer interrupt flag (x = 3..0)
  Field: CTXEIFLG1
  offset: 9, size: 1, access: 
  Stream x clear transfer error interrupt flag (x = 3..0)
  Field: CDMEIFLG1
  offset: 8, size: 1, access: 
  Stream x clear direct mode error interrupt flag (x = 3..0)
  Field: CFEIFLG1
  offset: 6, size: 1, access: 
  Stream x clear FIFO error interrupt flag (x = 3..0)
  Field: CTXCIFLG0
  offset: 5, size: 1, access: 
  Stream x clear transfer complete interrupt flag (x = 3..0)
  Field: CHTXIFLG0
  offset: 4, size: 1, access: 
  Stream x clear half transfer interrupt flag (x = 3..0)
  Field: CTXEIFLG0
  offset: 3, size: 1, access: 
  Stream x clear transfer error interrupt flag(x = 3..0)
  Field: CDMEIFLG0
  offset: 2, size: 1, access: 
  Stream x clear direct mode error interrupt flag (x = 3..0)
  Field: CFEIFLG0
  offset: 0, size: 1, access: 
  Stream x clear FIFO error interrupt flag (x = 3..0)
*/
volatile uint32_t LIFCLR;

/** HIFCLR HIFCLR (offset: 0xc)
  high interrupt flag clear register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CTXCIFLG7
  offset: 27, size: 1, access: 
  Stream x clear transfer complete interrupt flag (x = 7..4)
  Field: CHTXIFLG7
  offset: 26, size: 1, access: 
  Stream x clear half transfer interrupt flag (x = 7..4)
  Field: CTXEIFLG7
  offset: 25, size: 1, access: 
  Stream x clear transfer error interrupt flag (x = 7..4)
  Field: CDMEIFLG7
  offset: 24, size: 1, access: 
  Stream x clear direct mode error interrupt flag (x = 7..4)
  Field: CFEIFLG7
  offset: 22, size: 1, access: 
  Stream x clear FIFO error interrupt flag (x = 7..4)
  Field: CTXCIFLG6
  offset: 21, size: 1, access: 
  Stream x clear transfer complete interrupt flag (x = 7..4)
  Field: CHTXIFLG6
  offset: 20, size: 1, access: 
  Stream x clear half transfer interrupt flag (x = 7..4)
  Field: CTXEIFLG6
  offset: 19, size: 1, access: 
  Stream x clear transfer error interrupt flag (x = 7..4)
  Field: CDMEIFLG6
  offset: 18, size: 1, access: 
  Stream x clear direct mode error interrupt flag (x = 7..4)
  Field: CFEIFLG6
  offset: 16, size: 1, access: 
  Stream x clear FIFO error interrupt flag (x = 7..4)
  Field: CTXCIFLG5
  offset: 11, size: 1, access: 
  Stream x clear transfer complete interrupt flag (x = 7..4)
  Field: CHTXIFLG5
  offset: 10, size: 1, access: 
  Stream x clear half transfer interrupt flag (x = 7..4)
  Field: CTXEIFLG5
  offset: 9, size: 1, access: 
  Stream x clear transfer error interrupt flag (x = 7..4)
  Field: CDMEIFLG5
  offset: 8, size: 1, access: 
  Stream x clear direct mode error interrupt flag (x = 7..4)
  Field: CFEIFLG5
  offset: 6, size: 1, access: 
  Stream x clear FIFO error interrupt flag (x = 7..4)
  Field: CTXCIFLG4
  offset: 5, size: 1, access: 
  Stream x clear transfer complete interrupt flag (x = 7..4)
  Field: CHTXIFLG4
  offset: 4, size: 1, access: 
  Stream x clear half transfer interrupt flag (x = 7..4)
  Field: CTXEIFLG4
  offset: 3, size: 1, access: 
  Stream x clear transfer error interrupt flag (x = 7..4)
  Field: CDMEIFLG4
  offset: 2, size: 1, access: 
  Stream x clear direct mode error interrupt flag (x = 7..4)
  Field: CFEIFLG4
  offset: 0, size: 1, access: 
  Stream x clear FIFO error interrupt flag (x = 7..4)
*/
volatile uint32_t HIFCLR;

/** SCFG0 SCFG0 (offset: 0x10)
  stream x configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CHSEL
  offset: 25, size: 3, access: 
  Channel selection
  Field: MBCFG
  offset: 23, size: 2, access: 
  Memory burst transfer configuration
  Field: PBCFG
  offset: 21, size: 2, access: 
  Peripheral burst transfer configuration
  Field: CTARG
  offset: 19, size: 1, access: 
  Current target (only in double buffer mode)
  Field: DBM
  offset: 18, size: 1, access: 
  Double buffer mode
  Field: PRILCFG
  offset: 16, size: 2, access: 
  Priority level
  Field: PERIOSIZE
  offset: 15, size: 1, access: 
  Peripheral increment offset size
  Field: MEMSIZECFG
  offset: 13, size: 2, access: 
  Memory data size
  Field: PERSIZECFG
  offset: 11, size: 2, access: 
  Peripheral data size
  Field: MEMIM
  offset: 10, size: 1, access: 
  Memory increment mode
  Field: PERIM
  offset: 9, size: 1, access: 
  Peripheral increment mode
  Field: CIRCMEN
  offset: 8, size: 1, access: 
  Circular mode
  Field: DIRCFG
  offset: 6, size: 2, access: 
  Data transfer direction
  Field: PERFC
  offset: 5, size: 1, access: 
  Peripheral flow controller
  Field: TXCIEN
  offset: 4, size: 1, access: 
  Transfer complete interrupt enable
  Field: HTXIEN
  offset: 3, size: 1, access: 
  Half transfer interrupt enable
  Field: TXEIEN
  offset: 2, size: 1, access: 
  Transfer error interrupt enable
  Field: DMEIEN
  offset: 1, size: 1, access: 
  Direct mode error interrupt enable
  Field: EN
  offset: 0, size: 1, access: 
  Stream enable / flag stream ready when read low
*/
volatile uint32_t SCFG0;

/** NDATA0 NDATA0 (offset: 0x14)
  stream x number of data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: NDATA
  offset: 0, size: 16, access: 
  Number of data items to transfer
*/
volatile uint32_t NDATA0;

/** PADDR0 PADDR0 (offset: 0x18)
  stream x peripheral address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PADDR
  offset: 0, size: 32, access: 
  Peripheral address
*/
volatile uint32_t PADDR0;

/** M0ADDR0 M0ADDR0 (offset: 0x1c)
  stream x memory 0 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M0ADDR
  offset: 0, size: 32, access: 
  Memory 0 address
*/
volatile uint32_t M0ADDR0;

/** M1ADDR0 M1ADDR0 (offset: 0x20)
  stream x memory 1 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M1ADDR
  offset: 0, size: 32, access: 
  Memory 1 address (used in case of Double buffer mode)
*/
volatile uint32_t M1ADDR0;

/** FCTRL0 FCTRL0 (offset: 0x24)
  stream x FIFO control register
  reset value : 0x21
  reset mask : 0xFFFFFFFF
  Field: FEIEN
  offset: 7, size: 1, access: read-write
  FIFO error interrupt enable
  Field: FSTS
  offset: 3, size: 3, access: read-only
  FIFO status
  Field: DMDEN
  offset: 2, size: 1, access: read-write
  Direct mode disable
  Field: FTHSEL
  offset: 0, size: 2, access: read-write
  FIFO threshold selection
*/
volatile uint32_t FCTRL0;

/** SCFG1 SCFG1 (offset: 0x28)
  stream x configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CHSEL
  offset: 25, size: 3, access: 
  Channel selection
  Field: MBCFG
  offset: 23, size: 2, access: 
  Memory burst transfer configuration
  Field: PBCFG
  offset: 21, size: 2, access: 
  Peripheral burst transfer configuration
  Field: ACK
  offset: 20, size: 1, access: 
  ACK
  Field: CTARG
  offset: 19, size: 1, access: 
  Current target (only in double buffer mode)
  Field: DBM
  offset: 18, size: 1, access: 
  Double buffer mode
  Field: PRILCFG
  offset: 16, size: 2, access: 
  Priority level
  Field: PERIOSIZE
  offset: 15, size: 1, access: 
  Peripheral increment offset size
  Field: MEMSIZECFG
  offset: 13, size: 2, access: 
  Memory data size
  Field: PERSIZECFG
  offset: 11, size: 2, access: 
  Peripheral data size
  Field: MEMIM
  offset: 10, size: 1, access: 
  Memory increment mode
  Field: PERIM
  offset: 9, size: 1, access: 
  Peripheral increment mode
  Field: CIRCMEN
  offset: 8, size: 1, access: 
  Circular mode
  Field: DIRCFG
  offset: 6, size: 2, access: 
  Data transfer direction
  Field: PERFC
  offset: 5, size: 1, access: 
  Peripheral flow controller
  Field: TXCIEN
  offset: 4, size: 1, access: 
  Transfer complete interrupt enable
  Field: HTXIEN
  offset: 3, size: 1, access: 
  Half transfer interrupt enable
  Field: TXEIEN
  offset: 2, size: 1, access: 
  Transfer error interrupt enable
  Field: DMEIEN
  offset: 1, size: 1, access: 
  Direct mode error interrupt enable
  Field: EN
  offset: 0, size: 1, access: 
  Stream enable / flag stream ready when read low
*/
volatile uint32_t SCFG1;

/** NDATA1 NDATA1 (offset: 0x2c)
  stream x number of data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: NDATA
  offset: 0, size: 16, access: 
  Number of data items to transfer
*/
volatile uint32_t NDATA1;

/** PADDR1 PADDR1 (offset: 0x30)
  stream x peripheral address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PADDR
  offset: 0, size: 32, access: 
  Peripheral address
*/
volatile uint32_t PADDR1;

/** M0ADDR1 M0ADDR1 (offset: 0x34)
  stream x memory 0 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M0ADDR
  offset: 0, size: 32, access: 
  Memory 0 address
*/
volatile uint32_t M0ADDR1;

/** M1ADDR1 M1ADDR1 (offset: 0x38)
  stream x memory 1 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M1ADDR
  offset: 0, size: 32, access: 
  Memory 1 address (used in case of Double buffer mode)
*/
volatile uint32_t M1ADDR1;

/** FCTRL1 FCTRL1 (offset: 0x3c)
  stream x FIFO control register
  reset value : 0x21
  reset mask : 0xFFFFFFFF
  Field: FEIEN
  offset: 7, size: 1, access: read-write
  FIFO error interrupt enable
  Field: FSTS
  offset: 3, size: 3, access: read-only
  FIFO status
  Field: DMDEN
  offset: 2, size: 1, access: read-write
  Direct mode disable
  Field: FTHSEL
  offset: 0, size: 2, access: read-write
  FIFO threshold selection
*/
volatile uint32_t FCTRL1;

/** SCFG2 SCFG2 (offset: 0x40)
  stream x configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CHSEL
  offset: 25, size: 3, access: 
  Channel selection
  Field: MBCFG
  offset: 23, size: 2, access: 
  Memory burst transfer configuration
  Field: PBCFG
  offset: 21, size: 2, access: 
  Peripheral burst transfer configuration
  Field: ACK
  offset: 20, size: 1, access: 
  ACK
  Field: CTARG
  offset: 19, size: 1, access: 
  Current target (only in double buffer mode)
  Field: DBM
  offset: 18, size: 1, access: 
  Double buffer mode
  Field: PRILCFG
  offset: 16, size: 2, access: 
  Priority level
  Field: PERIOSIZE
  offset: 15, size: 1, access: 
  Peripheral increment offset size
  Field: MEMSIZECFG
  offset: 13, size: 2, access: 
  Memory data size
  Field: PERSIZECFG
  offset: 11, size: 2, access: 
  Peripheral data size
  Field: MEMIM
  offset: 10, size: 1, access: 
  Memory increment mode
  Field: PERIM
  offset: 9, size: 1, access: 
  Peripheral increment mode
  Field: CIRCMEN
  offset: 8, size: 1, access: 
  Circular mode
  Field: DIRCFG
  offset: 6, size: 2, access: 
  Data transfer direction
  Field: PERFC
  offset: 5, size: 1, access: 
  Peripheral flow controller
  Field: TXCIEN
  offset: 4, size: 1, access: 
  Transfer complete interrupt enable
  Field: HTXIEN
  offset: 3, size: 1, access: 
  Half transfer interrupt enable
  Field: TXEIEN
  offset: 2, size: 1, access: 
  Transfer error interrupt enable
  Field: DMEIEN
  offset: 1, size: 1, access: 
  Direct mode error interrupt enable
  Field: EN
  offset: 0, size: 1, access: 
  Stream enable / flag stream ready when read low
*/
volatile uint32_t SCFG2;

/** NDATA2 NDATA2 (offset: 0x44)
  stream x number of data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: NDATA
  offset: 0, size: 16, access: 
  Number of data items to transfer
*/
volatile uint32_t NDATA2;

/** PADDR2 PADDR2 (offset: 0x48)
  stream x peripheral address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PADDR
  offset: 0, size: 32, access: 
  Peripheral address
*/
volatile uint32_t PADDR2;

/** M0ADDR2 M0ADDR2 (offset: 0x4c)
  stream x memory 0 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M0ADDR
  offset: 0, size: 32, access: 
  Memory 0 address
*/
volatile uint32_t M0ADDR2;

/** M1ADDR2 M1ADDR2 (offset: 0x50)
  stream x memory 1 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M1ADDR
  offset: 0, size: 32, access: 
  Memory 1 address (used in case of Double buffer mode)
*/
volatile uint32_t M1ADDR2;

/** FCTRL2 FCTRL2 (offset: 0x54)
  stream x FIFO control register
  reset value : 0x21
  reset mask : 0xFFFFFFFF
  Field: FEIEN
  offset: 7, size: 1, access: read-write
  FIFO error interrupt enable
  Field: FSTS
  offset: 3, size: 3, access: read-only
  FIFO status
  Field: DMDEN
  offset: 2, size: 1, access: read-write
  Direct mode disable
  Field: FTHSEL
  offset: 0, size: 2, access: read-write
  FIFO threshold selection
*/
volatile uint32_t FCTRL2;

/** SCFG3 SCFG3 (offset: 0x58)
  stream x configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CHSEL
  offset: 25, size: 3, access: 
  Channel selection
  Field: MBCFG
  offset: 23, size: 2, access: 
  Memory burst transfer configuration
  Field: PBCFG
  offset: 21, size: 2, access: 
  Peripheral burst transfer configuration
  Field: ACK
  offset: 20, size: 1, access: 
  ACK
  Field: CTARG
  offset: 19, size: 1, access: 
  Current target (only in double buffer mode)
  Field: DBM
  offset: 18, size: 1, access: 
  Double buffer mode
  Field: PRILCFG
  offset: 16, size: 2, access: 
  Priority level
  Field: PERIOSIZE
  offset: 15, size: 1, access: 
  Peripheral increment offset size
  Field: MEMSIZECFG
  offset: 13, size: 2, access: 
  Memory data size
  Field: PERSIZECFG
  offset: 11, size: 2, access: 
  Peripheral data size
  Field: MEMIM
  offset: 10, size: 1, access: 
  Memory increment mode
  Field: PERIM
  offset: 9, size: 1, access: 
  Peripheral increment mode
  Field: CIRCMEN
  offset: 8, size: 1, access: 
  Circular mode
  Field: DIRCFG
  offset: 6, size: 2, access: 
  Data transfer direction
  Field: PERFC
  offset: 5, size: 1, access: 
  Peripheral flow controller
  Field: TXCIEN
  offset: 4, size: 1, access: 
  Transfer complete interrupt enable
  Field: HTXIEN
  offset: 3, size: 1, access: 
  Half transfer interrupt enable
  Field: TXEIEN
  offset: 2, size: 1, access: 
  Transfer error interrupt enable
  Field: DMEIEN
  offset: 1, size: 1, access: 
  Direct mode error interrupt enable
  Field: EN
  offset: 0, size: 1, access: 
  Stream enable / flag stream ready when read low
*/
volatile uint32_t SCFG3;

/** NDATA3 NDATA3 (offset: 0x5c)
  stream x number of data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: NDATA
  offset: 0, size: 16, access: 
  Number of data items to transfer
*/
volatile uint32_t NDATA3;

/** PADDR3 PADDR3 (offset: 0x60)
  stream x peripheral address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PADDR
  offset: 0, size: 32, access: 
  Peripheral address
*/
volatile uint32_t PADDR3;

/** M0ADDR3 M0ADDR3 (offset: 0x64)
  stream x memory 0 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M0ADDR
  offset: 0, size: 32, access: 
  Memory 0 address
*/
volatile uint32_t M0ADDR3;

/** M1ADDR3 M1ADDR3 (offset: 0x68)
  stream x memory 1 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M1ADDR
  offset: 0, size: 32, access: 
  Memory 1 address (used in case of Double buffer mode)
*/
volatile uint32_t M1ADDR3;

/** FCTRL3 FCTRL3 (offset: 0x6c)
  stream x FIFO control register
  reset value : 0x21
  reset mask : 0xFFFFFFFF
  Field: FEIEN
  offset: 7, size: 1, access: read-write
  FIFO error interrupt enable
  Field: FSTS
  offset: 3, size: 3, access: read-only
  FIFO status
  Field: DMDEN
  offset: 2, size: 1, access: read-write
  Direct mode disable
  Field: FTHSEL
  offset: 0, size: 2, access: read-write
  FIFO threshold selection
*/
volatile uint32_t FCTRL3;

/** SCFG4 SCFG4 (offset: 0x70)
  stream x configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CHSEL
  offset: 25, size: 3, access: 
  Channel selection
  Field: MBCFG
  offset: 23, size: 2, access: 
  Memory burst transfer configuration
  Field: PBCFG
  offset: 21, size: 2, access: 
  Peripheral burst transfer configuration
  Field: ACK
  offset: 20, size: 1, access: 
  ACK
  Field: CTARG
  offset: 19, size: 1, access: 
  Current target (only in double buffer mode)
  Field: DBM
  offset: 18, size: 1, access: 
  Double buffer mode
  Field: PRILCFG
  offset: 16, size: 2, access: 
  Priority level
  Field: PERIOSIZE
  offset: 15, size: 1, access: 
  Peripheral increment offset size
  Field: MEMSIZECFG
  offset: 13, size: 2, access: 
  Memory data size
  Field: PERSIZECFG
  offset: 11, size: 2, access: 
  Peripheral data size
  Field: MEMIM
  offset: 10, size: 1, access: 
  Memory increment mode
  Field: PERIM
  offset: 9, size: 1, access: 
  Peripheral increment mode
  Field: CIRCMEN
  offset: 8, size: 1, access: 
  Circular mode
  Field: DIRCFG
  offset: 6, size: 2, access: 
  Data transfer direction
  Field: PERFC
  offset: 5, size: 1, access: 
  Peripheral flow controller
  Field: TXCIEN
  offset: 4, size: 1, access: 
  Transfer complete interrupt enable
  Field: HTXIEN
  offset: 3, size: 1, access: 
  Half transfer interrupt enable
  Field: TXEIEN
  offset: 2, size: 1, access: 
  Transfer error interrupt enable
  Field: DMEIEN
  offset: 1, size: 1, access: 
  Direct mode error interrupt enable
  Field: EN
  offset: 0, size: 1, access: 
  Stream enable / flag stream ready when read low
*/
volatile uint32_t SCFG4;

/** NDATA4 NDATA4 (offset: 0x74)
  stream x number of data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: NDATA
  offset: 0, size: 16, access: 
  Number of data items to transfer
*/
volatile uint32_t NDATA4;

/** PADDR4 PADDR4 (offset: 0x78)
  stream x peripheral address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PADDR
  offset: 0, size: 32, access: 
  Peripheral address
*/
volatile uint32_t PADDR4;

/** M0ADDR4 M0ADDR4 (offset: 0x7c)
  stream x memory 0 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M0ADDR
  offset: 0, size: 32, access: 
  Memory 0 address
*/
volatile uint32_t M0ADDR4;

/** M1ADDR4 M1ADDR4 (offset: 0x80)
  stream x memory 1 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M1ADDR
  offset: 0, size: 32, access: 
  Memory 1 address (used in case of Double buffer mode)
*/
volatile uint32_t M1ADDR4;

/** FCTRL4 FCTRL4 (offset: 0x84)
  stream x FIFO control register
  reset value : 0x21
  reset mask : 0xFFFFFFFF
  Field: FEIEN
  offset: 7, size: 1, access: read-write
  FIFO error interrupt enable
  Field: FSTS
  offset: 3, size: 3, access: read-only
  FIFO status
  Field: DMDEN
  offset: 2, size: 1, access: read-write
  Direct mode disable
  Field: FTHSEL
  offset: 0, size: 2, access: read-write
  FIFO threshold selection
*/
volatile uint32_t FCTRL4;

/** SCFG5 SCFG5 (offset: 0x88)
  stream x configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CHSEL
  offset: 25, size: 3, access: 
  Channel selection
  Field: MBCFG
  offset: 23, size: 2, access: 
  Memory burst transfer configuration
  Field: PBCFG
  offset: 21, size: 2, access: 
  Peripheral burst transfer configuration
  Field: ACK
  offset: 20, size: 1, access: 
  ACK
  Field: CTARG
  offset: 19, size: 1, access: 
  Current target (only in double buffer mode)
  Field: DBM
  offset: 18, size: 1, access: 
  Double buffer mode
  Field: PRILCFG
  offset: 16, size: 2, access: 
  Priority level
  Field: PERIOSIZE
  offset: 15, size: 1, access: 
  Peripheral increment offset size
  Field: MEMSIZECFG
  offset: 13, size: 2, access: 
  Memory data size
  Field: PERSIZECFG
  offset: 11, size: 2, access: 
  Peripheral data size
  Field: MEMIM
  offset: 10, size: 1, access: 
  Memory increment mode
  Field: PERIM
  offset: 9, size: 1, access: 
  Peripheral increment mode
  Field: CIRCMEN
  offset: 8, size: 1, access: 
  Circular mode
  Field: DIRCFG
  offset: 6, size: 2, access: 
  Data transfer direction
  Field: PERFC
  offset: 5, size: 1, access: 
  Peripheral flow controller
  Field: TXCIEN
  offset: 4, size: 1, access: 
  Transfer complete interrupt enable
  Field: HTXIEN
  offset: 3, size: 1, access: 
  Half transfer interrupt enable
  Field: TXEIEN
  offset: 2, size: 1, access: 
  Transfer error interrupt enable
  Field: DMEIEN
  offset: 1, size: 1, access: 
  Direct mode error interrupt enable
  Field: EN
  offset: 0, size: 1, access: 
  Stream enable / flag stream ready when read low
*/
volatile uint32_t SCFG5;

/** NDATA5 NDATA5 (offset: 0x8c)
  stream x number of data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: NDATA
  offset: 0, size: 16, access: 
  Number of data items to transfer
*/
volatile uint32_t NDATA5;

/** PADDR5 PADDR5 (offset: 0x90)
  stream x peripheral address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PADDR
  offset: 0, size: 32, access: 
  Peripheral address
*/
volatile uint32_t PADDR5;

/** M1ADDR5 M1ADDR5 (offset: 0x94)
  stream x memory 0 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M0ADDR
  offset: 0, size: 32, access: 
  Memory 0 address
*/
volatile uint32_t M1ADDR5;

/** S5M1AR S5M1AR (offset: 0x98)
  stream x memory 1 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M1ADDR
  offset: 0, size: 32, access: 
  Memory 1 address (used in case of Double buffer mode)
*/
volatile uint32_t S5M1AR;

/** FCTRL5 FCTRL5 (offset: 0x9c)
  stream x FIFO control register
  reset value : 0x21
  reset mask : 0xFFFFFFFF
  Field: FEIEN
  offset: 7, size: 1, access: read-write
  FIFO error interrupt enable
  Field: FSTS
  offset: 3, size: 3, access: read-only
  FIFO status
  Field: DMDEN
  offset: 2, size: 1, access: read-write
  Direct mode disable
  Field: FTHSEL
  offset: 0, size: 2, access: read-write
  FIFO threshold selection
*/
volatile uint32_t FCTRL5;

/** SCFG6 SCFG6 (offset: 0xa0)
  stream x configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CHSEL
  offset: 25, size: 3, access: 
  Channel selection
  Field: MBCFG
  offset: 23, size: 2, access: 
  Memory burst transfer configuration
  Field: PBCFG
  offset: 21, size: 2, access: 
  Peripheral burst transfer configuration
  Field: ACK
  offset: 20, size: 1, access: 
  ACK
  Field: CTARG
  offset: 19, size: 1, access: 
  Current target (only in double buffer mode)
  Field: DBM
  offset: 18, size: 1, access: 
  Double buffer mode
  Field: PRILCFG
  offset: 16, size: 2, access: 
  Priority level
  Field: PERIOSIZE
  offset: 15, size: 1, access: 
  Peripheral increment offset size
  Field: MEMSIZECFG
  offset: 13, size: 2, access: 
  Memory data size
  Field: PERSIZECFG
  offset: 11, size: 2, access: 
  Peripheral data size
  Field: MEMIM
  offset: 10, size: 1, access: 
  Memory increment mode
  Field: PERIM
  offset: 9, size: 1, access: 
  Peripheral increment mode
  Field: CIRCMEN
  offset: 8, size: 1, access: 
  Circular mode
  Field: DIRCFG
  offset: 6, size: 2, access: 
  Data transfer direction
  Field: PERFC
  offset: 5, size: 1, access: 
  Peripheral flow controller
  Field: TXCIEN
  offset: 4, size: 1, access: 
  Transfer complete interrupt enable
  Field: HTXIEN
  offset: 3, size: 1, access: 
  Half transfer interrupt enable
  Field: TXEIEN
  offset: 2, size: 1, access: 
  Transfer error interrupt enable
  Field: DMEIEN
  offset: 1, size: 1, access: 
  Direct mode error interrupt enable
  Field: EN
  offset: 0, size: 1, access: 
  Stream enable / flag stream ready when read low
*/
volatile uint32_t SCFG6;

/** NDATA6 NDATA6 (offset: 0xa4)
  stream x number of data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: NDATA
  offset: 0, size: 16, access: 
  Number of data items to transfer
*/
volatile uint32_t NDATA6;

/** PADDR6 PADDR6 (offset: 0xa8)
  stream x peripheral address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PADDR
  offset: 0, size: 32, access: 
  Peripheral address
*/
volatile uint32_t PADDR6;

/** M0ADDR6 M0ADDR6 (offset: 0xac)
  stream x memory 0 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M0ADDR
  offset: 0, size: 32, access: 
  Memory 0 address
*/
volatile uint32_t M0ADDR6;

/** M1ADDR6 M1ADDR6 (offset: 0xb0)
  stream x memory 1 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M1ADDR
  offset: 0, size: 32, access: 
  Memory 1 address (used in case of Double buffer mode)
*/
volatile uint32_t M1ADDR6;

/** FCTRL6 FCTRL6 (offset: 0xb4)
  stream x FIFO control register
  reset value : 0x21
  reset mask : 0xFFFFFFFF
  Field: FEIEN
  offset: 7, size: 1, access: read-write
  FIFO error interrupt enable
  Field: FSTS
  offset: 3, size: 3, access: read-only
  FIFO status
  Field: DMDEN
  offset: 2, size: 1, access: read-write
  Direct mode disable
  Field: FTHSEL
  offset: 0, size: 2, access: read-write
  FIFO threshold selection
*/
volatile uint32_t FCTRL6;

/** SCFG7 SCFG7 (offset: 0xb8)
  stream x configuration register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CHSEL
  offset: 25, size: 3, access: 
  Channel selection
  Field: MBCFG
  offset: 23, size: 2, access: 
  Memory burst transfer configuration
  Field: PBCFG
  offset: 21, size: 2, access: 
  Peripheral burst transfer configuration
  Field: ACK
  offset: 20, size: 1, access: 
  ACK
  Field: CTARG
  offset: 19, size: 1, access: 
  Current target (only in double buffer mode)
  Field: DBM
  offset: 18, size: 1, access: 
  Double buffer mode
  Field: PRILCFG
  offset: 16, size: 2, access: 
  Priority level
  Field: PERIOSIZE
  offset: 15, size: 1, access: 
  Peripheral increment offset size
  Field: MEMSIZECFG
  offset: 13, size: 2, access: 
  Memory data size
  Field: PERSIZECFG
  offset: 11, size: 2, access: 
  Peripheral data size
  Field: MEMIM
  offset: 10, size: 1, access: 
  Memory increment mode
  Field: PERIM
  offset: 9, size: 1, access: 
  Peripheral increment mode
  Field: CIRCMEN
  offset: 8, size: 1, access: 
  Circular mode
  Field: DIRCFG
  offset: 6, size: 2, access: 
  Data transfer direction
  Field: PERFC
  offset: 5, size: 1, access: 
  Peripheral flow controller
  Field: TXCIEN
  offset: 4, size: 1, access: 
  Transfer complete interrupt enable
  Field: HTXIEN
  offset: 3, size: 1, access: 
  Half transfer interrupt enable
  Field: TXEIEN
  offset: 2, size: 1, access: 
  Transfer error interrupt enable
  Field: DMEIEN
  offset: 1, size: 1, access: 
  Direct mode error interrupt enable
  Field: EN
  offset: 0, size: 1, access: 
  Stream enable / flag stream ready when read low
*/
volatile uint32_t SCFG7;

/** NDATA7 NDATA7 (offset: 0xbc)
  stream x number of data register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: NDATA
  offset: 0, size: 16, access: 
  Number of data items to transfer
*/
volatile uint32_t NDATA7;

/** PADDR7 PADDR7 (offset: 0xc0)
  stream x peripheral address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PADDR
  offset: 0, size: 32, access: 
  Peripheral address
*/
volatile uint32_t PADDR7;

/** M0ADDR7 M0ADDR7 (offset: 0xc4)
  stream x memory 0 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M0ADDR
  offset: 0, size: 32, access: 
  Memory 0 address
*/
volatile uint32_t M0ADDR7;

/** M1ADDR7 M1ADDR7 (offset: 0xc8)
  stream x memory 1 address register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: M1ADDR
  offset: 0, size: 32, access: 
  Memory 1 address (used in case of Double buffer mode)
*/
volatile uint32_t M1ADDR7;

/** FCTRL7 FCTRL7 (offset: 0xcc)
  stream x FIFO control register
  reset value : 0x21
  reset mask : 0xFFFFFFFF
  Field: FEIEN
  offset: 7, size: 1, access: read-write
  FIFO error interrupt enable
  Field: FSTS
  offset: 3, size: 3, access: read-only
  FIFO status
  Field: DMDEN
  offset: 2, size: 1, access: read-write
  Direct mode disable
  Field: FTHSEL
  offset: 0, size: 2, access: read-write
  FIFO threshold selection
*/
volatile uint32_t FCTRL7;
} DMA2_type;

#define DMA2 ((DMA2_type *) 0x40026400)

#endif // HW_DMA2_H
