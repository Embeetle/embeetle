#ifndef HW_IWDT_H
#define HW_IWDT_H
/** Independent watchdog */
/** Memory Block starting at 0x40003000 + 0x0 is 0x400 bytes in size. It is used for registers. Protection:  */

#include <stdint.h>


#define IWDT_KEY_KEY_OFFSET                                0
#define IWDT_KEY_KEY_MASK                                  0xffff

#define IWDT_PSC_PSC_OFFSET                                0
#define IWDT_PSC_PSC_MASK                                  7

#define IWDT_CNTRLD_CNTRLD_OFFSET                          0
#define IWDT_CNTRLD_CNTRLD_MASK                            0xfff

#define IWDT_STS_CNTUFLG_OFFSET                            1
#define IWDT_STS_CNTUFLG_MASK                              2

#define IWDT_STS_PSCUFLG_OFFSET                            0
#define IWDT_STS_PSCUFLG_MASK                              1


typedef struct
{

/** KEY KEY (offset: 0x0)
  Key register
  access : write-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: KEY
  offset: 0, size: 16, access: 
  Key value (write only, read 0000h)
*/
volatile uint32_t KEY;

/** PSC PSC (offset: 0x4)
  Prescaler register
  access : read-write
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: PSC
  offset: 0, size: 3, access: 
  Prescaler divider
*/
volatile uint32_t PSC;

/** CNTRLD CNTRLD (offset: 0x8)
  Reload register
  access : read-write
  reset value : 0xFFF
  reset mask : 0xFFFFFFFF
  Field: CNTRLD
  offset: 0, size: 12, access: 
  Watchdog counter reload value
*/
volatile uint32_t CNTRLD;

/** STS STS (offset: 0xc)
  Status register
  access : read-only
  reset value : 0x0
  reset mask : 0xFFFFFFFF
  Field: CNTUFLG
  offset: 1, size: 1, access: 
  Watchdog counter reload value update
  Field: PSCUFLG
  offset: 0, size: 1, access: 
  Watchdog prescaler value update
*/
volatile uint32_t STS;
} IWDT_type;

#define IWDT ((IWDT_type *) 0x40003000)

#endif // HW_IWDT_H
